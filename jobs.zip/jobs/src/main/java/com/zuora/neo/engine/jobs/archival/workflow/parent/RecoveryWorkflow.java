package com.zuora.neo.engine.jobs.archival.workflow.parent;

import com.zuora.neo.engine.temporal.workflows.BaseWorkflow;

import io.temporal.workflow.WorkflowInterface;

@WorkflowInterface
public interface RecoveryWorkflow extends BaseWorkflow {
}
