package com.zuora.neo.engine.jobs.transferaccounting.api;

public class OrgBookStatus {
    private String orgId;
    private String status;
    private Long bookId;

    public OrgBookStatus(String orgId, String status, Long bookId) {
        this.orgId = orgId;
        this.status = status;
        this.bookId = bookId;
    }

    public String getOrgId() {
        return orgId;
    }

    public String getStatus() {
        return status;
    }

    public Long getBookId() {
        return bookId;
    }

    public OrgBookStatus() {

    }
}
