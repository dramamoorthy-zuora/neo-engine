package com.zuora.neo.engine.jobs.summarization.db.doa;

import org.jdbi.v3.core.statement.OutParameters;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.OutParameter;
import org.jdbi.v3.sqlobject.statement.SqlCall;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.math.BigDecimal;
import java.sql.Types;

public interface SummarizationDao {

    @SqlCall("{call rpro_neo_engine_pkg.summarization_wrapper_for_nova(:p_errbuf, :p_retcode, :secAtrVal, :batchId)}")
    @OutParameter(name = "p_errbuf", sqlType = Types.VARCHAR)
    @OutParameter(name = "p_retcode", sqlType = Types.INTEGER)
    OutParameters callSummarization(@Bind("secAtrVal") String secAtrVal, @Bind("batchId") BigDecimal batchId);

    @SqlUpdate("INSERT INTO RPRO_RUN_TIME_SUMM_INPUT (ID, RC_ID, BOOK_ID, SEC_ATR_VAL, CLIENT_ID, BATCH_ID, CRTD_BY, CRTD_DT, UPDT_BY, UPDT_DT) "
            +   "SELECT rpro_utility_pkg.generate_id ('RPRO_RUN_TIME_SUMM_INPUT_ID_S', header.client_id), header.rc_id, header.book_id, header.sec_atr_val,"
            +   "header.client_id, :batch_id, :user, SYSDATE, :user, SYSDATE FROM rpro_rtp_wi_header header WHERE batch_id = :batch_id "
            +   "AND status = 'IN PROGRESS'")
    Integer populateSummarizationInputEntries(@Bind("batch_id") BigDecimal rtpBatchId, @Bind("user") String user);
}
