package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.db.api.RcLineDetails;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.PreparedBatch;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RcLineDetailsService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(RcLineDetailsService.class);

    private static final String UPDATE_RC_LINE_DETAILS_PRINCIPLE_AMT = "update rpro_rc_line set principle_amt = :principleAmt where doc_line_id = :docLineId";

    public void updatePrincipleAmountToRcLineDetailsBatch(Handle handle, List<RcLineDetails> rcLineDetailsList) {

        LOGGER.debug("Updating the Principle Amounts to RC Line Details..");
        PreparedBatch updatePrincipleAmountToRcLineDetailsBatch = handle.prepareBatch(UPDATE_RC_LINE_DETAILS_PRINCIPLE_AMT);
        for (RcLineDetails rcLineDetail : rcLineDetailsList) {
            bindRcLineDetailsForUpdate(updatePrincipleAmountToRcLineDetailsBatch, rcLineDetail);
        }

        doBulkUpdateRcLineDetails(updatePrincipleAmountToRcLineDetailsBatch);
    }

    public void bindRcLineDetailsForUpdate(PreparedBatch updatePrincipleAmountToRcLineDetailsBatch, RcLineDetails rcLineDetail) {

        updatePrincipleAmountToRcLineDetailsBatch.bind("principleAmt", rcLineDetail.getPrincipleAmount())
                .bind("docLineId", rcLineDetail.getDocLineId()).add();

    }

    public void doBulkUpdateRcLineDetails(PreparedBatch updatePrincipleAmountToRcLineDetailsBatch) {
        LOGGER.info("Update RC Line Details Batch Size : " + updatePrincipleAmountToRcLineDetailsBatch.size());
        int[] updateCount = updatePrincipleAmountToRcLineDetailsBatch.execute();
        LOGGER.info("Number of Records updated Rc Line Details Batch Size : " + updateCount.length);
    }

}
