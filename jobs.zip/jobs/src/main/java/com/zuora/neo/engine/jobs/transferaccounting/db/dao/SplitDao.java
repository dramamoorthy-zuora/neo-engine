package com.zuora.neo.engine.jobs.transferaccounting.db.dao;

import com.zuora.neo.engine.jobs.transferaccounting.db.api.ChunkStatus;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.SplitBatchRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.ChunkMapper;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.SplitBatchRecordMapper;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.statement.UseRowMapper;

import java.util.List;

public interface SplitDao {

    @SqlUpdate("DELETE rpro_batch_split WHERE type = :p_type AND batch_type = :p_batch_type"
            + " AND sec_atr_val = :orgId AND client_id = :clientId")
    Integer deleteBatchesByType(@Bind("p_type") String type, @Bind("p_batch_type") String batchType,
            @Bind("orgId") String orgId, @Bind("clientId") Long clientId);

    @SqlUpdate("INSERT INTO rpro_batch_split_h SELECT * FROM rpro_batch_split WHERE type = :p_type"
            + " AND batch_type = :p_batch_type AND sec_atr_val = :orgId AND client_id = :clientId")
    Integer insertBatchesInHistory(@Bind("p_type") String type, @Bind("p_batch_type") String batchType,
            @Bind("orgId") String orgId, @Bind("clientId") Long clientId);

    @SqlQuery("select * FROM rpro_batch_split WHERE batch_id = :postBatchId"
            + " AND type = :split_type AND batch_type = :batch_type"
            + " AND book_id = :bookId AND processed in ('N','R') ORDER BY chunk_id")
    @UseRowMapper(SplitBatchRecordMapper.class)
    List<SplitBatchRecord> getSplitBatches(@Bind("postBatchId") Long postBatchId, @Bind("split_type") String splitType,
            @Bind("bookId") Long bookId, @Bind("batch_type") String batchType);

    @SqlQuery("select * FROM rpro_batch_split_h WHERE batch_id = :postBatchId"
            + " AND type = :split_type AND batch_type = :batch_type ORDER BY chunk_id")
    @UseRowMapper(SplitBatchRecordMapper.class)
    List<SplitBatchRecord> getSplitBatchesHistory(@Bind("postBatchId") Long postBatchId, @Bind("split_type") String splitType,
            @Bind("batch_type") String batchType);

    @SqlQuery("select * FROM rpro_batch_split WHERE batch_id = :postBatchId"
            + " AND type = :split_type AND batch_type = :batch_type AND book_id = :bookId"
            + " AND chunk_id = :chunkId AND processed in ('N','R') ORDER BY chunk_id")
    @UseRowMapper(SplitBatchRecordMapper.class)
    SplitBatchRecord getSplitBatchById(@Bind("postBatchId") Long postBatchId, @Bind("split_type") String splitType,
            @Bind("bookId") Long bookId, @Bind("batch_type") String batchType, @Bind("chunkId") Long chunkId);

    @SqlUpdate("INSERT INTO rpro_batch_split SELECT * FROM rpro_batch_split_h WHERE type = :p_type"
            + " AND batch_type = :p_batch_type AND sec_atr_val = :orgId AND client_id = :clientId and batch_id = :batchId")
    Integer insertBatchesFromHistToMain(@Bind("p_type") String type, @Bind("p_batch_type") String batchType,
                                        @Bind("orgId") String orgId, @Bind("clientId") Long clientId, @Bind("batchId") Long batchId);

    @SqlUpdate("DELETE rpro_batch_split_h WHERE type = :p_type AND batch_type = :p_batch_type"
            + " AND sec_atr_val = :orgId AND client_id = :clientId and batch_id = :batchId")
    Integer deleteHistBatchesByType(@Bind("p_type") String type, @Bind("p_batch_type") String batchType,
                                    @Bind("orgId") String orgId, @Bind("clientId") Long clientId, @Bind("batchId") Long batchId);

    @SqlUpdate("UPDATE rpro_acct_xfer_details set status = :status, message = RTRIM(message || ' ' || :message), updt_dt = SYSDATE, "
            + " updt_by = :updatedBy where post_batch_id = :postBatchId and chunk_Id = :chunkId and ( INSTR( message, :message) = 0 OR message is null)")
    void updateTransferStatusChunk(@Bind("status") String status, @Bind("message") String message, @Bind("updatedBy") String updatedBy,
            @Bind("postBatchId") Long postBatchId, @Bind("chunkId") Long chunkId);

    @SqlQuery("select status from rpro_acct_xfer_details where post_batch_id=:postBatchId and chunk_Id=:chunkId")
    String getChunkTransferStatus(@Bind("postBatchId") Long postBatchId, @Bind("chunkId") Long chunkId);

    @SqlUpdate("insert into rpro_acct_xfer_details (status, message, chunk_id, post_batch_id, client_id, created_by, created_dt, sec_atr_val) "
            + " values (?,?,?,?,?,?,SYSDATE,?) ")
    void insertDetailHeader(String status, String message, Long chunkId, Long postBatchId, Long clientId, String createdBy, String org);

    @SqlQuery("select distinct chunk_id, status FROM rpro_acct_xfer_details where post_batch_id=:postBatchId")
    @UseRowMapper(ChunkMapper.class)
    List<ChunkStatus> getAllChunkStatus(@Bind("postBatchId") Long postBatchId);

    @SqlQuery("select chunk_id FROM rpro_acct_xfer_details where post_batch_id=:postBatchId and chunk_Id=:chunkId")
    Long getChunkId(@Bind("postBatchId") Long postBatchId, @Bind("chunkId") Long chunkId);

}

