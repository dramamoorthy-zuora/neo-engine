package com.zuora.neo.engine.jobs.transferaccounting.constants;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum AccountingObjectType {
    GENERAL_LEDGER("GL"),
    MANUAL_JE("MANUAL-JE");

    private final String objectType;

    @JsonValue
    public String getObjectTypeType() {
        return objectType;
    }

    AccountingObjectType(String objectType) {
        this.objectType = objectType;
    }

    private static final Map<String, AccountingObjectType> LOOKUP =
            Arrays.stream(AccountingObjectType.values()).collect(Collectors.toMap(AccountingObjectType::getObjectTypeType, Function.identity()));

    @JsonCreator
    public static AccountingObjectType fromObjectType(String objectType) {
        return LOOKUP.get(objectType);
    }
}
