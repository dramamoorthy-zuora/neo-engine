package com.zuora.neo.engine.common.indicators;

public class FlagValuePair<T extends Enum<T> & IndicatorEnum> {
    public T indicator;
    public char val;

    FlagValuePair(T indicator, char val) {
        this.indicator = indicator;
        this.val = val;
    }
}
