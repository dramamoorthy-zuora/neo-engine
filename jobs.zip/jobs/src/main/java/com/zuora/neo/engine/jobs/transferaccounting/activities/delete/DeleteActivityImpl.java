package com.zuora.neo.engine.jobs.transferaccounting.activities.delete;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.config.Properties;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.AccountingDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.CriteriaLookupDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.ScheduleDao;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.jdbi.v3.core.Jdbi;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@ActivityImplementation
@Component
public class DeleteActivityImpl implements DeleteActivity {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(DeleteActivityImpl.class);

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;
    @Autowired
    Properties properties;

    @Override
    public void performBatchDeletion(ThreadedAccountingResult result) {
        neoWorkflowLogger.log("Delete activity called for Testing delete not called from UI:");
        long startTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Long postBatchId = result.getPostBatchId();
        Jdbi jdbi = DbContext.getConnection();

        jdbi.useHandle(handle -> {
            CriteriaLookupDao lookupDao = handle.attach(CriteriaLookupDao.class);
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            ScheduleDao scheduleDao = handle.attach(ScheduleDao.class);

            Integer count = scheduleDao.resetBatchSchdData(postBatchId);
            neoWorkflowLogger.log("Updated Schedules. Number of records: " + count);

            Integer rowCount1 = accountingDao.deleteXferRecord(postBatchId);
            neoWorkflowLogger.log("Deleted Account transfer Batch. Number of records: " + rowCount1);

            Integer rowCount2 = accountingDao.deleteXferDetailsRecord(postBatchId);
            neoWorkflowLogger.log("Deleted Number of records from xfer_details Table: " + rowCount2);

            Integer deleteCount = lookupDao.deleteCriteriaRecords(postBatchId);
            neoWorkflowLogger.log("Deleted Account transfer Criteria. Number of records: " + deleteCount);

            long endTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
            neoWorkflowLogger.log("Time Taken for delete operation: " + " is: " + (endTime - startTime));
            LOGGER.info("Time Taken for delete operation: " + " is: " + (endTime - startTime));

            properties.resetLoadedFlag(request.getTenantId());
        });

    }
}
