package com.zuora.neo.engine.jobs.transferaccounting.activities.transfer;

import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;

import io.temporal.activity.ActivityInterface;

import java.util.HashMap;
import java.util.List;

@ActivityInterface
public interface TransferActivity {
    ThreadedAccountingResult doTransferProcess(ThreadedAccountingResult accountingResult, String orgId);

    void updateStatusToProgress(Long postBatchId);

    void resetRetryChunks(ThreadedAccountingResult accountingResult);

    HashMap<Long, List<Long>> getRetryChunks();
}
