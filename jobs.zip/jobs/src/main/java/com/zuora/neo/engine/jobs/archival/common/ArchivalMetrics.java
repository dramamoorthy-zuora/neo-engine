package com.zuora.neo.engine.jobs.archival.common;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class ArchivalMetrics {
    private final ConcurrentHashMap<String,Double> copyCounters = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String,Double> deleteCounters = new ConcurrentHashMap<>();

    public ArchivalMetrics(List<String> tableNames) {
        for (String tableName : tableNames) {
            copyCounters.putIfAbsent(tableName, (double) 0);
            deleteCounters.putIfAbsent(tableName, (double) 0);
        }
    }


    public Double updateCopyCountersForTable(String tableName, Double val) {
        return copyCounters.computeIfPresent(tableName, (key, currVal) -> currVal + val);
    }

    public Double updateDeleteCountersForTable(String tableName, Double val) {
        return deleteCounters.computeIfPresent(tableName, (key, currVal) -> currVal + val);
    }
}
