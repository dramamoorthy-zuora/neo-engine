package com.zuora.neo.engine.jobs.rtp.api;

public class RtpWiHeader {

    Integer id;
    Integer rcId;
    Integer prdId;
    Integer bookId;
    String secAtrVal;
    Integer clientId;
    Integer wfId;
    String status;

    public RtpWiHeader() {

    }

    public RtpWiHeader(Integer id, Integer rcId, Integer prdId,
                       Integer bookId, String secAtrVal, Integer clientId, Integer wfId, String status) {
        this.id = id;
        this.rcId = rcId;
        this.prdId = prdId;
        this.bookId = bookId;
        this.secAtrVal = secAtrVal;
        this.clientId = clientId;
        this.wfId = wfId;
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getRcId() {
        return rcId;
    }

    public void setRcId(Integer rcId) {
        this.rcId = rcId;
    }

    public Integer getPrdId() {
        return prdId;
    }

    public void setPrdId(Integer prdId) {
        this.prdId = prdId;
    }

    public Integer getBookId() {
        return bookId;
    }

    public void setBookId(Integer bookId) {
        this.bookId = bookId;
    }

    public String getSecAtrVal() {
        return secAtrVal;
    }

    public void setSecAtrVal(String secAtrVal) {
        this.secAtrVal = secAtrVal;
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public Integer getWfId() {
        return wfId;
    }

    public void setWfId(Integer wfId) {
        this.wfId = wfId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
