package com.zuora.neo.engine.jobs.transferaccounting.common;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.jobs.transferaccounting.constants.AccountTypeParams;
import com.zuora.neo.engine.jobs.transferaccounting.constants.ScheduleParams;

public class AccountingQuery {

    public static StringBuilder createRegularSchdQuery(StringBuilder sqlQuery, WorkflowRequest request, Long currentPeriodId,
            Long minRcId, Long maxRcId, StringBuilder scheduleWhereClause, StringBuilder bookWhereClause,
            StringBuilder prdWhereClause, StringBuilder nonSchWhereClause, int size) {
        sqlQuery = sqlQuery.append(" SUBSTR(rrs.indicators,1,1) = 'N' AND rpro_rc_schd_pkg.get_initial_entry_flag(rrs.indicators) = 'N'")
                .append(" AND rpro_rc_schd_pkg.get_schd_type_flag(rrs.indicators) NOT IN ('").append(ScheduleParams.MJE_ENTRY.getScheduleParam()).append("')")
                .append(" AND rrs.post_prd_id = ").append(currentPeriodId).append(" AND rrs.client_id = ").append(request.getClientId())
                .append(" AND rrs.sec_atr_val =  :orgId ");
        if (minRcId != null && maxRcId != null) {
            sqlQuery.append(" AND rrs.rc_id BETWEEN :minRcId AND :maxRcId");
        }
        if (size != 0) {
            sqlQuery.append(' ').append(scheduleWhereClause).append(' ')
                    .append(bookWhereClause).append(' ').append(prdWhereClause).append(' ');
        }
        sqlQuery.append(" AND EXISTS (SELECT 1 FROM rpro_rc_head rh, rpro_rc_line rl WHERE rh.id = rl.rc_id AND rl.id = rrs.root_line_id"
                        + " AND rl.client_id = rrs.client_id AND rh.client_id = rl.client_id AND rpro_rc_head_pkg.get_approval_status_flag(rh.indicators) = 'A'"
                        + " AND rh.book_id = rrs.book_id AND rh.book_id = rl.book_id AND (( rpro_rc_schd_pkg.get_schd_type_flag(rrs.indicators) <> '")
                .append(ScheduleParams.ALLOC_ENTRY.getScheduleParam())
                .append("' AND rpro_rc_head_pkg.get_rev_rec_hold_flag(rh.indicators)= 'N' AND rpro_rc_line_pkg.get_rev_rec_hold_flag(rl.indicators)= 'N') OR "
                        + " ( rpro_rc_schd_pkg.get_schd_type_flag(rrs.indicators) = '").append(ScheduleParams.ALLOC_ENTRY.getScheduleParam())
                .append("' AND rpro_rc_head_pkg.get_alloc_rec_hold_flag(rh.indicators)= 'N' AND rpro_rc_line_pkg.get_alloc_rec_hold_flag(rl.indicators)= 'N')"
                        + " OR ( rpro_rc_head_pkg.get_alloc_rec_hold_flag(rh.indicators)= 'N'"
                        + " AND rpro_rc_schd_pkg.get_initial_rep_entry_flag(rrs.indicators) = 'Y'"
                        + " AND rpro_rc_Schd_pkg.get_schd_type_flag(rrs.indicators) = '").append(ScheduleParams.ALLOC_ENTRY.getScheduleParam())
                .append("') OR ( rpro_rc_head_pkg.get_rev_rec_hold_flag(rh.indicators)= 'N' "
                        + " AND rpro_rc_schd_pkg.get_initial_rep_entry_flag(rrs.indicators) = 'Y'"
                        + " AND rpro_rc_schd_pkg.get_schd_type_flag(rrs.indicators) = '")
                .append(ScheduleParams.REVENUE_ENTRY.getScheduleParam()).append("') )");
        if (size != 0) {
            sqlQuery.append(nonSchWhereClause);
        }
        sqlQuery.append(" )");

        return sqlQuery;
    }

    public static StringBuilder createMjeQuery(StringBuilder sqlMjeQuery, WorkflowRequest request, Long currentPeriodId,
            Long minRcId, Long maxRcId, StringBuilder scheduleWhereClause, StringBuilder bookWhereClause,
            StringBuilder prdWhereClause, StringBuilder mjtWhereClause, int size) {
        sqlMjeQuery = sqlMjeQuery.append(" SUBSTR(rrs.indicators,1,1) = 'N'"
                        + " AND rpro_rc_schd_pkg.get_initial_entry_flag(rrs.indicators) = 'N'"
                        + " AND rpro_rc_schd_pkg.get_schd_type_flag(rrs.indicators) IN ('D', 'M') AND rrs.post_prd_id = ")
                .append(currentPeriodId).append(" AND rrs.client_id = ").append(request.getClientId())
                .append(" AND rrs.sec_atr_val = :orgId ");
        if (minRcId != null && maxRcId != null) {
            sqlMjeQuery.append(" AND rrs.rc_id  BETWEEN :minRcId AND :maxRcId");
        }
        if (size != 0) {
            sqlMjeQuery.append(' ').append(scheduleWhereClause).append(' ').append(bookWhereClause).append(' ')
                    .append(prdWhereClause);
        }
        sqlMjeQuery.append(" AND EXISTS (SELECT 1 FROM rpro_je_head rjh, rpro_je_line rjl "
                + "WHERE rjl.id = rrs.line_id AND rjh.book_id = rrs.book_id "
                + "AND rjh.id = rjl.header_id AND rjl.client_id = rrs.client_id AND rjh.client_id = rjl.client_id "
                + "AND rpro_je_head_pkg.get_status_flag (rjh.indicators)  = 'A' AND rpro_je_line_pkg.get_active_flag (rjl.indicators) = 'Y' ");
        if (size != 0) {
            sqlMjeQuery.append(mjtWhereClause);
        }
        sqlMjeQuery.append(" AND ROWNUM < 2 ) AND EXISTS  (SELECT 1 FROM rpro_rc_head rh, rpro_rc_line rl "
                        + "WHERE rh.id = rl.rc_id AND rl.id = rrs.root_line_id AND rl.client_id = rrs.client_id AND rh.client_id = rl.client_id "
                        + "AND rpro_rc_head_pkg.get_approval_status_flag(rh.indicators) = 'A' AND rh.book_id = rrs.book_id AND rh.book_id = rl.book_id"
                        + " AND ((( rpro_rc_schd_pkg.get_dr_acctg_flag(rrs.indicators) NOT IN ( '")
                .append(AccountTypeParams.ADJUSTMENT_LIABILITY.getAccountTypeParam())
                .append("','").append(AccountTypeParams.ADJUSTMENT_REVENUE.getAccountTypeParam())
                .append("') AND rpro_rc_schd_pkg.get_cr_acctg_flag(rrs.indicators) NOT IN ( '")
                .append(AccountTypeParams.ADJUSTMENT_LIABILITY.getAccountTypeParam())
                .append("', '").append(AccountTypeParams.ADJUSTMENT_REVENUE.getAccountTypeParam())
                .append("')) AND rpro_rc_head_pkg.get_rev_rec_hold_flag(rh.indicators)= 'N' AND "
                        + "rpro_rc_line_pkg.get_rev_rec_hold_flag(rl.indicators)= 'N')"
                        + " OR (( rpro_rc_schd_pkg.get_dr_acctg_flag(rrs.indicators) IN ( '")
                .append(AccountTypeParams.ADJUSTMENT_LIABILITY.getAccountTypeParam()).append("', '")
                .append(AccountTypeParams.ADJUSTMENT_REVENUE.getAccountTypeParam())
                .append("') OR rpro_rc_schd_pkg.get_cr_acctg_flag(rrs.indicators) IN ( '")
                .append(AccountTypeParams.ADJUSTMENT_LIABILITY.getAccountTypeParam())
                .append("', '").append(AccountTypeParams.ADJUSTMENT_REVENUE.getAccountTypeParam()).append("')) ")
                .append(" AND rpro_rc_head_pkg.get_alloc_rec_hold_flag(rh.indicators)= 'N' "
                        + " AND rpro_rc_line_pkg.get_alloc_rec_hold_flag(rl.indicators)= 'N' )))");

        return sqlMjeQuery;
    }
}
