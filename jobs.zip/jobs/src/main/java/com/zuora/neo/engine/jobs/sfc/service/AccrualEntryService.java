package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SchdIndicator;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class AccrualEntryService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AccrualEntryService.class);
    @Autowired
    RcScheduleService rcScheduleService;

    public void createAccrualEntry(List<RcLineDetails> rcLineDetails,
            List<RcLinePaData> rcLinePaDataRecord, WorkflowRequest request, BigDecimal intAccrual, List<FinanceTypeFlagDetails> financeTypeFlagDetailsList,
            long openPeriodId, long rcVersion, String drAcctSeg, String crAcctSeg, SchdIndicator schdIndicator, List<RcScheduleRecord> rcScheduleRecordBatch,
            long lineStartDatePeriod) {
        List<RcScheduleRecord> rcScheduleRecordList = new ArrayList<>();
        schdIndicator.setCrAcctgFlag(financeTypeFlagDetailsList.get(0).getDrAcctgFlag().charAt(0));
        schdIndicator.setDrAcctgFlag(financeTypeFlagDetailsList.get(0).getCrAcctgFlag().charAt(0));
        RcScheduleRecord rcScheduleRecord = rcScheduleService.populateRcScheduleRecord(rcLineDetails, rcLinePaDataRecord, null,
                request, intAccrual.multiply(BigDecimal.valueOf(-1)), rcVersion, openPeriodId, crAcctSeg, drAcctSeg, schdIndicator);
        if (lineStartDatePeriod > openPeriodId) {
            rcScheduleRecord.setPeriodId(lineStartDatePeriod);
            rcScheduleRecord.setPostPeriodId(lineStartDatePeriod);
        } else {
            rcScheduleRecord.setPeriodId(openPeriodId);
            rcScheduleRecord.setPostPeriodId(openPeriodId);
        }
        schdIndicator.setIntialRepEntryFlag('Y');
        rcScheduleRecord.setIndicators(schdIndicator.getIndicator());
        rcScheduleRecordList.add(rcScheduleRecord);
        rcScheduleRecordBatch.addAll(rcScheduleRecordList);
        LOGGER.debug("RC Schedule Accrual Entry created");
    }

    public void createAccrualEntry(List<RcLineDetails> rcLineDetails,
            List<RcLinePaData> rcLinePaDataRecord, WorkflowRequest request, BigDecimal intAccrual,
            String crAcctgFlag, String drAcctgFlag, long openPeriodId, long rcVersion, String drAcctSeg, String crAcctSeg, SchdIndicator schdIndicator,
            List<RcScheduleRecord> rcScheduleRecordBatch, long lineStartDatePeriod, char initialRepEntryFlag) {
        List<RcScheduleRecord> rcScheduleRecordList = new ArrayList<>();
        schdIndicator.setCrAcctgFlag(crAcctgFlag.charAt(0));
        schdIndicator.setDrAcctgFlag(drAcctgFlag.charAt(0));
        RcScheduleRecord rcScheduleRecord = rcScheduleService.populateRcScheduleRecord(rcLineDetails, rcLinePaDataRecord, null,
                request, intAccrual.multiply(BigDecimal.valueOf(-1)), rcVersion, openPeriodId, drAcctSeg, crAcctSeg, schdIndicator);
        if (lineStartDatePeriod > openPeriodId) {
            rcScheduleRecord.setPeriodId(lineStartDatePeriod);
            rcScheduleRecord.setPostPeriodId(lineStartDatePeriod);
        } else {
            rcScheduleRecord.setPeriodId(openPeriodId);
            rcScheduleRecord.setPostPeriodId(openPeriodId);
        }
        schdIndicator.setIntialRepEntryFlag(initialRepEntryFlag);
        rcScheduleRecord.setIndicators(schdIndicator.getIndicator());
        rcScheduleRecordList.add(rcScheduleRecord);
        rcScheduleRecordBatch.addAll(rcScheduleRecordList);
        LOGGER.debug("RC Schedule Accrual Entry created");
    }

    public void createImpairmentEntry(List<RcLineDetails> rcLineDetails,
            List<RcLinePaData> rcLinePaDataRecord, WorkflowRequest request, BigDecimal intAccrual, long openPeriodId,
            long rcVersion, String drAcctSeg, String crAcctSeg,
            char crAcctgFlag, char drAcctgFlag, SchdIndicator schdIndicator, List<RcScheduleRecord> rcScheduleRecordBatch) {
        List<RcScheduleRecord> rcScheduleRecordList = new ArrayList<>();
        schdIndicator.setCrAcctgFlag(crAcctgFlag); //sfcSegmentsFlagsVersions.getContractImpairmentAccountFlag().charAt(0),
        schdIndicator.setDrAcctgFlag(drAcctgFlag); //vcTypeDetailsList.get(0).getCrAcctgFlag().charAt(0),
        RcScheduleRecord rcScheduleRecord = rcScheduleService.populateRcScheduleRecord(rcLineDetails, rcLinePaDataRecord, null,
                request, intAccrual, rcVersion, openPeriodId, drAcctSeg, crAcctSeg, schdIndicator);
        rcScheduleRecord.setPeriodId(openPeriodId);
        rcScheduleRecord.setPostPeriodId(openPeriodId);
        schdIndicator.setIntialRepEntryFlag('N');
        rcScheduleRecord.setIndicators(schdIndicator.getIndicator());
        rcScheduleRecordList.add(rcScheduleRecord);
        rcScheduleRecordBatch.addAll(rcScheduleRecordList);
        LOGGER.debug("RC Schedule Accrual Entry created");
    }
}
