package com.zuora.neo.engine.jobs.transferaccounting.activities.support;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface SupportActivity {

    WorkflowResponse checkTransferBatch(ThreadedAccountingResult accountingResult);

    WorkflowResponse handleCustomApiErrors(ThreadedAccountingResult accountingResult);

    WorkflowResponse handleIncorrectBatchSetup(ThreadedAccountingResult accountingResult);

    Boolean checkBatchExists(Long postBatchId);

    void updateHeaderForRetry(Long postBatchId, String user);

    Boolean glDataExists(Long postBatchId);

    void resetErrorMsgOnRetry(Long postBatchId, String user);

    String getDeleteAction(WorkflowRequest request);

    Long getPostBatchId(WorkflowRequest request);
}
