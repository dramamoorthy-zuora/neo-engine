package com.zuora.neo.engine.jobs.transferaccounting.db.api;

public class StageHandlerTable {
    private String procedureName;

    public StageHandlerTable(String procedureName) {
        this.procedureName = procedureName;
    }

    public String getProcedureName() {
        return procedureName;
    }

    public void setProcedureName(String procedureName) {
        this.procedureName = procedureName;
    }
}
