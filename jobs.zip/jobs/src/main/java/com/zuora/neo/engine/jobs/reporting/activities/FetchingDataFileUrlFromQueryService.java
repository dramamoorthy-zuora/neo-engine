package com.zuora.neo.engine.jobs.reporting.activities;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface FetchingDataFileUrlFromQueryService {
    String getUrlFromQueryService2(String config);

    String generatePresignedUrl2();
}
