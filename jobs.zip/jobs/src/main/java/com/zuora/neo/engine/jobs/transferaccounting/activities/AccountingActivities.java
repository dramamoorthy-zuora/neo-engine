package com.zuora.neo.engine.jobs.transferaccounting.activities;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.api.ThreadDetails;

import io.temporal.activity.ActivityInterface;

import java.util.List;

/**
 * This is the Activity Definition's Interface. Activities are building blocks of any Temporal
 * Workflow and contain any business logic that could perform long running computation, network calls, etc.
 *
 * <p>Annotating Activity Definition methods with @ActivityMethod is optional.
 *
 * @see io.temporal.activity.ActivityInterface
 * @see io.temporal.activity.ActivityMethod
 */
@ActivityInterface
public interface AccountingActivities {
    ThreadedAccountingResult processTransferAccounting(String orgId);

    List<String> getAllOrgs();

    ThreadDetails getNumThreadAndBatches(ThreadedAccountingResult accountingResult, String org);

    Integer getNumberOfThreads();

    void resetBatchDetailsForUpdateUI(Long postBatchId);

    void releaseLock(String orgId);

    void processBatchPerOrgInfo(String orgId, Long postBatchId, String status, String message);

    void acquireLock(Long postBatchId, String orgId);

    String getOrgId(WorkflowRequest request);

    void cleanupActivities(String org, WorkflowRequest request);

}
