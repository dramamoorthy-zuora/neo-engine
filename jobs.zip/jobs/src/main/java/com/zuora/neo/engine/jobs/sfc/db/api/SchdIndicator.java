package com.zuora.neo.engine.jobs.sfc.db.api;

import java.util.Arrays;

public class SchdIndicator {


    static final int INTERFACED_FLAG_POS = 0;
    static final int DR_ACCT_FLAG_POS = 1;
    static final int CR_ACCT_FLAG_POS = 2;
    static final int INITIAL_ENTRY_FLAG_POS = 3;
    static final int REVERSAL_FLAG_POS = 4;
    static final int UNBILLED_FLAG_POS = 5;
    static final int FCST_FLAG_POS = 6;
    static final int PP_CL_FLAG = 7;
    static final int REALLOCATION_FLAG_POS = 8;
    static final int NETTING_ENTRY_FLAG_POS = 9;
    static final int SCHD_TYPE_POS = 10;
    static final int PP_ADJ_FLAG_POS = 11;
    static final int INITIAL_REP_ENTRY_FLAG_POS = 12;
    static final int IMPACT_TRANS_PRC_FLAG_POS = 13;
    static final int LINE_TYPE_FLAG_POS = 14;
    static final int MASS_ACTION_FLAG_POS = 15;
    static final int SPECIAL_ALLOC_FLAG_POS = 16;
    static final int VC_EXPIRY_SCHD_FLAG_POS = 17;
    static final int PQ_ADJ_FLAG_POS = 18;
    static final int DELINK_FLAG_POS = 19;
    static final int RETRO_RVRSL_FLAG_POS = 20;
    static final int PORD_FLAG_POS = 21;
    static final int UNBILL_RVRSL_FLAG_POS = 22;
    static final int REC_EVT_ACT_FLAG_POS = 23;
    static final int CMRO_CONTRA_ENTRY_FLAG_POS = 24;
    static final int RETRO_ENTRY_FLAG_POS = 25;
    static final int LEFT_OVER_ENTRY_FLAG_POS = 26;
    static final int REVS_POSTED_INV_FLAG_POS = 27;
    static final int CL_DIST_ENTRY_FLAG_POS = 28;
    static final int AFTER_RIP_SCHD_FLAG_POS = 29;
    static final int SCHD_SUBTYPE_FLAG_POS = 30;

    static final  char[] defaultSchdIndicator = {'N' /* Interfaced Flag */,
            'N' /* Dr Acct  Flag */,
            'N' /* Cr Acct  Flag */,
            'N' /* Initial Entry Flag */,
            'N' /* Reversal Flag */,
            'N' /* Unbilled Flag */,
            'N' /* Fcst Flag */,
            'N' /* Pp_Cl Flag */,
            'N' /* Reallocation Flag */,
            'N' /* Netting Entry Flag */,
            'N' /* Schd Type Flag */,
            'N' /* Pp Adj Flag */,
            'N' /* Initial Rep Entry Flag */,
            'N' /* Impact Trans Prc Flag */,
            'N' /* Line Type Flag */,
            'N' /* Mass Action Flag */,
            'N' /* Special Alloc Flag */,
            'N' /* Vc expiry Schd Flag */,
            'N' /* Pq Adj Flag */,
            'N' /* Delink Flag */,
            'N' /* Retro Rvrsl Flag */,
            'N' /* Pord Flag */,
            'N' /* Unbill Rvrsl Flag */,
            'N' /* Rec Evt Act Flag */,
            'N' /* Cmro Contra Entry Flag */,
            'N' /* Retro Entry Flag */,
            'N' /* Left Over entry Flag */,
            'N' /* Revs Posted Inv Flag */,
            'N' /* Cl Dist Entry Flag */,
            'N' /* After Rip Schd Flag */,
            'N' /* Schd Subtype Flag */,
            'N' /* Flag Not used */,
            'N' /* Flag Not used  */,
            'N' /* Flag Not used */,
            'N' /* Flag Not used */,
            'N' /* Flag Not used*/,
            'N' /* Flag Not used */,
            'N' /* Flag Not used */,
            'N' /* Flag Not used */,
            'N' /* Flag Not used */,
            'N' /* Flag Not used */
    };

    char[] schdIndicator;

    public static String getDefault() {
        return String.valueOf(defaultSchdIndicator);
    }

    public SchdIndicator() {
        this.schdIndicator = Arrays.copyOf(defaultSchdIndicator,defaultSchdIndicator.length - 1);
    }

    public  String getIndicator() {
        return String.valueOf(schdIndicator);
    }

    public static SchdIndicator valueOf(String indicators) {

        int maxLength = defaultSchdIndicator.length - 1;
        int stringLength = indicators.length();

        SchdIndicator si = new SchdIndicator();
        for (int i = 0; i < maxLength; i++) {
            if (i >= stringLength) {
                break;
            }
            si.schdIndicator[i] = indicators.charAt(i);
        }
        return si;
    }

    public char getInterfacedFlag() {
        return schdIndicator[INTERFACED_FLAG_POS];
    }

    public void setInterfacedFlag(char interfacedFlag) {
        this.schdIndicator[INTERFACED_FLAG_POS] = interfacedFlag;
    }

    public char getDrAcctgFlag() {
        return schdIndicator[DR_ACCT_FLAG_POS];
    }

    public void setDrAcctgFlag(char drAcctgFlag) {
        this.schdIndicator[DR_ACCT_FLAG_POS] = drAcctgFlag;
    }

    public char getCrAcctgFlag() {
        return schdIndicator[CR_ACCT_FLAG_POS];
    }

    public void setCrAcctgFlag(char crAcctgFlag) {
        this.schdIndicator[CR_ACCT_FLAG_POS] = crAcctgFlag;
    }

    public char getIntialEntryFlag() {
        return schdIndicator[INITIAL_ENTRY_FLAG_POS];
    }

    public void setIntialEntryFlag(char intialEntryFlag) {
        this.schdIndicator[INITIAL_ENTRY_FLAG_POS] = intialEntryFlag;
    }

    public char getReversalFlag() {
        return schdIndicator[REVERSAL_FLAG_POS];
    }

    public void setReversalFlag(char reversalFlag) {
        this.schdIndicator[REVERSAL_FLAG_POS] = reversalFlag;
    }

    public char getUnbilledFlag() {
        return schdIndicator[UNBILLED_FLAG_POS];
    }

    public void setUnbilledFlag(char unbilledFlag) {
        this.schdIndicator[UNBILLED_FLAG_POS] = unbilledFlag;
    }

    public char getFcstFlag() {
        return schdIndicator[FCST_FLAG_POS];
    }

    public void setFcstFlag(char fcstFlag) {
        this.schdIndicator[FCST_FLAG_POS] = fcstFlag;
    }

    public char getPpClFlag() {
        return schdIndicator[PP_CL_FLAG];
    }

    public void setPpClFlag(char ppClFlag) {
        this.schdIndicator[PP_CL_FLAG] = ppClFlag;
    }

    public char getReAllocationFlag() {
        return schdIndicator[REALLOCATION_FLAG_POS];
    }

    public void setReAllocationFlag(char reAllocationFlag) {
        this.schdIndicator[REALLOCATION_FLAG_POS] = reAllocationFlag;
    }

    public char getNettingEntryFlag() {
        return schdIndicator[NETTING_ENTRY_FLAG_POS];
    }

    public void setNettingEntryFlag(char nettingEntryFlag) {
        this.schdIndicator[NETTING_ENTRY_FLAG_POS] = nettingEntryFlag;
    }

    public char getSchdTypeFlag() {
        return schdIndicator[SCHD_TYPE_POS];
    }

    public void setSchdTypeFlag(char schdTypeFlag) {
        this.schdIndicator[SCHD_TYPE_POS] = schdTypeFlag;
    }

    public char getPpAdjFlag() {
        return schdIndicator[PP_ADJ_FLAG_POS];
    }

    public void setPpAdjFlag(char ppAdjFlag) {
        this.schdIndicator[PP_ADJ_FLAG_POS] = ppAdjFlag;
    }

    public char getIntialRepEntryFlag() {
        return schdIndicator[INITIAL_REP_ENTRY_FLAG_POS];
    }

    public void setIntialRepEntryFlag(char intialRepEntryFlag) {
        this.schdIndicator[INITIAL_REP_ENTRY_FLAG_POS] = intialRepEntryFlag;
    }

    public char getImpactTransPrcFlag() {
        return schdIndicator[IMPACT_TRANS_PRC_FLAG_POS];
    }

    public void setImpactTransPrcFlag(char impactTransPrcFlag) {
        this.schdIndicator[IMPACT_TRANS_PRC_FLAG_POS] = impactTransPrcFlag;
    }

    public char getLineTypeFlag() {
        return schdIndicator[LINE_TYPE_FLAG_POS];
    }

    public void setLineTypeFlag(char lineTypeFlag) {
        this.schdIndicator[LINE_TYPE_FLAG_POS] = lineTypeFlag;
    }

    public char getMassActionFlag() {
        return schdIndicator[MASS_ACTION_FLAG_POS];
    }

    public void setMassActionFlag(char massActionFlag) {
        this.schdIndicator[MASS_ACTION_FLAG_POS] = massActionFlag;
    }

    public char getSpecialAllocFlag() {
        return schdIndicator[SPECIAL_ALLOC_FLAG_POS];
    }

    public void setSpecialAllocFlag(char specialAllocFlag) {
        this.schdIndicator[SPECIAL_ALLOC_FLAG_POS] = specialAllocFlag;
    }

    public char getVcExpirySchdFlag() {
        return schdIndicator[VC_EXPIRY_SCHD_FLAG_POS];
    }

    public void setVcExpirySchdFlag(char vcExpirySchdFlag) {
        this.schdIndicator[VC_EXPIRY_SCHD_FLAG_POS] = vcExpirySchdFlag;
    }

    public char getPqAdjFlag() {
        return schdIndicator[PQ_ADJ_FLAG_POS];
    }

    public void setPqAdjFlag(char pqAdjFlag) {
        this.schdIndicator[PQ_ADJ_FLAG_POS] = pqAdjFlag;
    }

    public char getDelinkFlag() {
        return schdIndicator[DELINK_FLAG_POS];
    }

    public void setDelinkFlag(char delinkFlag) {
        this.schdIndicator[DELINK_FLAG_POS] = delinkFlag;
    }

    public char getRetrorvrslFlag() {
        return schdIndicator[RETRO_RVRSL_FLAG_POS];
    }

    public void setRetrorvrslFlag(char retrorvrslFlag) {
        this.schdIndicator[RETRO_RVRSL_FLAG_POS] = retrorvrslFlag;
    }

    public char getPordFlag() {
        return schdIndicator[PORD_FLAG_POS];
    }

    public void setPordFlag(char pordFlag) {
        this.schdIndicator[PORD_FLAG_POS] = pordFlag;
    }

    public char getUnbillrvrslFlag() {
        return schdIndicator[UNBILL_RVRSL_FLAG_POS];
    }

    public void setUnbillrvrslFlag(char unbillrvrslFlag) {
        this.schdIndicator[UNBILL_RVRSL_FLAG_POS] = unbillrvrslFlag;
    }

    public char getRecEvtFlag() {
        return schdIndicator[REC_EVT_ACT_FLAG_POS];
    }

    public void setRecEvtFlag(char recEvtFlag) {
        this.schdIndicator[REC_EVT_ACT_FLAG_POS] = recEvtFlag;
    }

    public char getCmroContraEntryFlag() {
        return schdIndicator[CMRO_CONTRA_ENTRY_FLAG_POS];
    }

    public void setCmroContraEntryFlag(char cmroContraEntryFlag) {
        this.schdIndicator[CMRO_CONTRA_ENTRY_FLAG_POS] = cmroContraEntryFlag;
    }

    public char getRetroEntryFlag() {
        return schdIndicator[RETRO_ENTRY_FLAG_POS];
    }

    public void setRetroEntryFlag(char retroEntryFlag) {
        this.schdIndicator[RETRO_ENTRY_FLAG_POS] = retroEntryFlag;
    }

    public char getLeftOverEntryFlag() {
        return schdIndicator[LEFT_OVER_ENTRY_FLAG_POS];
    }

    public void setLeftOverEntryFlag(char leftOverEntryFlag) {
        this.schdIndicator[LEFT_OVER_ENTRY_FLAG_POS] = leftOverEntryFlag;
    }

    public char getRevsPostedInvFlag() {
        return schdIndicator[REVS_POSTED_INV_FLAG_POS];
    }

    public void setRevsPostedInvFlag(char revsPostedInvFlag) {
        this.schdIndicator[REVS_POSTED_INV_FLAG_POS] = revsPostedInvFlag;
    }

    public char getClDistEntryFlag() {
        return schdIndicator[CL_DIST_ENTRY_FLAG_POS];
    }

    public void setClDistEntryFlag(char clDistEntryFlag) {
        this.schdIndicator[CL_DIST_ENTRY_FLAG_POS] = clDistEntryFlag;
    }

    public char getAfterRipSchdFlag() {
        return schdIndicator[AFTER_RIP_SCHD_FLAG_POS];
    }

    public void setAfterRipSchdFlag(char afterRipSchdFlag) {
        this.schdIndicator[AFTER_RIP_SCHD_FLAG_POS] = afterRipSchdFlag;
    }

    public char getSchdSubTypeFlag() {
        return schdIndicator[SCHD_SUBTYPE_FLAG_POS];
    }

    public void setSchdSubTypeFlag(char schdSubTypeFlag) {
        this.schdIndicator[SCHD_SUBTYPE_FLAG_POS] = schdSubTypeFlag;
    }

}
