package com.zuora.neo.engine.jobs.caclnetting.service;

import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.PeriodDetails;
import com.zuora.neo.engine.db.common.DbCommonUtils;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.caclnetting.config.CaclProperties;
import com.zuora.neo.engine.jobs.caclnetting.constants.CaclMessages;
import com.zuora.neo.engine.jobs.caclnetting.db.dao.CaclNettingDao;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;

import com.google.common.annotations.VisibleForTesting;

import org.springframework.stereotype.Service;

@Service
public class InitializerService {

    private final CaclProperties caclProperties;

    public InitializerService(CaclProperties caclProperties) {
        this.caclProperties = caclProperties;
    }

    @VisibleForTesting
    void performInitialChecks() {
        if (!caclProperties.isNettingEnabled()) {
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.COMPLETED, CaclMessages.NETTING_DISABLED);
        }
    }

    @VisibleForTesting
    void initializePeriodDetails(CommonDao commonDao, CaclNettingDao nettingDao, long bookId,
                                                 long clientId, String orgId) {

        long currentPeriodId = commonDao.getCrtdPeriodId(bookId, orgId);

        PeriodDetails periodDetails = new PeriodDetails(currentPeriodId);

        CalendarDetails currentPeriodDetails = commonDao.getPeriodDetailsById(currentPeriodId).get(0);

        long previousPeriodId = DbCommonUtils.getPreviousPeriodId(currentPeriodDetails, commonDao);
        long nextPeriodId = DbCommonUtils.getNextPeriodId(currentPeriodDetails, commonDao);
        long previousNettingPeriodId = nettingDao.getPreviousNettingPeriodId(caclProperties.getHeadPeriod(), currentPeriodId, bookId,
                clientId, orgId);


        // fallback to previous period ID if there is no previous netting period
        previousNettingPeriodId = (previousNettingPeriodId != 0) ? previousNettingPeriodId : previousPeriodId;

        periodDetails.setPreviousPeriodId(previousPeriodId);
        periodDetails.setNextPeriodId(nextPeriodId);

        caclProperties.setPeriodDetails(periodDetails);
        caclProperties.setPrevNettingPeriodId(previousNettingPeriodId);

    }

    /**
     * Checks for Netting enabled profile and initializes the period details for a given book
     */
    public void performInitOperations(CommonDao commonDao, CaclNettingDao nettingDao, long bookId,
                                      long clientId, String orgId, String user) {
        caclProperties.loadProperties(commonDao, bookId, clientId, orgId, user);
        performInitialChecks();
        initializePeriodDetails(commonDao, nettingDao, caclProperties.getBookId(), caclProperties.getClientId(), caclProperties.getOrgId());
    }

}
