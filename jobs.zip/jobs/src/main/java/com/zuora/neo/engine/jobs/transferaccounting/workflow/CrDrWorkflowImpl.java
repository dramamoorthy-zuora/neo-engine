package com.zuora.neo.engine.jobs.transferaccounting.workflow;

import com.zuora.neo.engine.annotations.workflow.WorkflowImplementation;
import com.zuora.neo.engine.jobs.transferaccounting.activities.gllink.GlLinkingActivity;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.workflows.LoggerWorkflowImpl;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.workflow.Workflow;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@WorkflowImplementation
public class CrDrWorkflowImpl extends LoggerWorkflowImpl implements CrDrWorkflow {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CrDrWorkflowImpl.class);

    private final GlLinkingActivity glLinkingActivity = Workflow.newActivityStub(GlLinkingActivity.class);

    @Override
    public WorkflowResponse performCrDrLink() {
        LOGGER.info("starting CR DR as a separate job");
        glLinkingActivity.updateGlLink();

        return new WorkflowResponse(RevenueJobStatus.COMPLETED, "");
    }
}
