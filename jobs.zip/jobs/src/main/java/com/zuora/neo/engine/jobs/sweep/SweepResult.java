package com.zuora.neo.engine.jobs.sweep;

import com.google.common.base.MoreObjects;

public class SweepResult {

    int rowsUpdated;

    int summaryRecords;

    long bookId;

    String sweepType;

    String orgId;

    public long getBookId() {
        return bookId;
    }

    public void setBookId(long bookId) {
        this.bookId = bookId;
    }

    public int getRowsUpdated() {
        return rowsUpdated;
    }

    public void setRowsUpdated(int rowsUpdated) {
        this.rowsUpdated = rowsUpdated;
    }

    public String getSweepType() {
        return sweepType;
    }

    public void setSweepType(String sweepType) {
        this.sweepType = sweepType;
    }

    public int getSummaryRecords() {
        return summaryRecords;
    }

    public void setSummaryRecords(int summaryRecords) {
        this.summaryRecords = summaryRecords;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("rowsUpdated", rowsUpdated)
                .add("summaryRecords", summaryRecords)
                .toString();
    }
}
