package com.zuora.neo.engine.jobs.transferaccounting.db.mapper;

import com.zuora.neo.engine.jobs.transferaccounting.db.api.StageHandlerTable;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class StageHandlerMapper implements RowMapper<StageHandlerTable> {


    @Override
    public StageHandlerTable map(ResultSet rs, StatementContext ctx) throws SQLException {
        return new StageHandlerTable(rs.getString("Procedure_Name"));
    }
}
