package com.zuora.neo.engine.common;

public enum AccountTypes {
    REVENUE_ID("R"),
    ASSETS_ID("A"),
    LIABILITY_ID("L"),
    DUMMY_ACCT_ID("Z"),
    UNBILLED_ID("U"),
    VC_ADJUSTMENT("V"),
    ADJUSTMENT_LIABILITY("W"),
    ADJUSTMENT_REVENUE("X"),
    RCOG_ID("C"),
    DCOG_ID("D"),
    REVENUE_OFFSET("S"),
    DEFERRAL_OFFSET("P"),
    RO_CONTRA("T"),
    IMPAIRMENT("M"),
    INTER_COMP("I"),
    CONTRA_INVENTORY_COST("K");

    private final String accountType;

    public String getAccountType() {
        return accountType;
    }

    AccountTypes(String accountType) {
        this.accountType = accountType;
    }

}
