package com.zuora.neo.engine.jobs.transferaccounting.workflow;

import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.workflow.WorkflowInterface;
import io.temporal.workflow.WorkflowMethod;

@WorkflowInterface
public interface TransferAccountingWorkflow {

    /**
     * This is the method that is executed when the Workflow Execution is started. The Workflow
     * Execution completes when this method finishes execution.
     */
    @WorkflowMethod
    WorkflowResponse processTransferAccounting();
}
