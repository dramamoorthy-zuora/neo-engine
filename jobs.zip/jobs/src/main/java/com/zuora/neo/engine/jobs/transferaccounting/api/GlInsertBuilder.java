package com.zuora.neo.engine.jobs.transferaccounting.api;

import com.zuora.neo.engine.jobs.transferaccounting.activities.transfer.TransferActivityImpl;
import com.zuora.neo.engine.jobs.transferaccounting.constants.AccountingObjectType;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.GlIntegrationMap;

import org.jdbi.v3.core.Handle;
import org.slf4j.LoggerFactory;

public class GlInsertBuilder {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(GlInsertBuilder.class);

    private StringBuilder insertStmt;
    private StringBuilder insertSelect;
    private StringBuilder groupByStr;

    public GlInsertBuilder(StringBuilder insertStmt, StringBuilder insertSelect, StringBuilder groupByStr) {
        this.insertStmt = insertStmt;
        this.insertSelect = insertSelect;
        this.groupByStr = groupByStr;
    }

    public StringBuilder getInsertStmt() {
        return insertStmt;
    }

    public StringBuilder getInsertSelect() {
        return insertSelect;
    }

    public StringBuilder getGroupByStr() {
        return groupByStr;
    }

    public static GlInsertBuilder formGlInsertFromMap(GlIntegrationMap glMap, String objectType, Handle handle,
            StringBuilder groupByStr, String summaryTransfer, String mjeSummaryTransfer,
            StringBuilder insertStmt, StringBuilder insertSelect, int index, int size, boolean roundingEnabled) {
        String val = null;
        if (glMap.getSourceFrom().equals(TransferActivityImpl.SourceFrom.CONSTANT.name())) {
            val = glMap.getSourceValue();
        } else if (glMap.getSourceFrom().equals(TransferActivityImpl.SourceFrom.TRANSACTION.name())) {
            val = glMap.getSourceValue();
            //Rounding per currency at schedule level ZR-20673
            if (AccountingObjectType.GENERAL_LEDGER.getObjectTypeType().equals(objectType) && "Y".equals(summaryTransfer)) {
                if ((glMap.getSourceValue().contains("CR") && glMap.getSourceValue().contains("AMOUNT")
                        && glMap.getSourceValue().indexOf("CR") < glMap.getSourceValue().indexOf("AMOUNT"))
                        || (glMap.getSourceValue().contains("DR") && glMap.getSourceValue().contains("AMOUNT")
                        && glMap.getSourceValue().indexOf("DR") < glMap.getSourceValue().indexOf("AMOUNT"))) {
                    val = roundingEnabled ? "SUM(ROUND(" + glMap.getSourceValue() + ",rpro_utility_pkg.curr_rounding(LINE_F_CUR))) "
                            : "SUM(" + glMap.getSourceValue() + ") ";
                } else {
                    if (groupByStr == null) {
                        groupByStr = new StringBuilder(glMap.getSourceValue());
                    } else {
                        groupByStr.append(',').append(glMap.getSourceValue());
                    }
                }
            } else if (AccountingObjectType.MANUAL_JE.getObjectTypeType().equals(objectType) && "Y".equals(mjeSummaryTransfer)) {
                if ((glMap.getSourceValue().contains("CR") && glMap.getSourceValue().contains("AMOUNT")
                        && glMap.getSourceValue().indexOf("CR") < glMap.getSourceValue().indexOf("AMOUNT"))
                        || (glMap.getSourceValue().contains("DR") && glMap.getSourceValue().contains("AMOUNT")
                        && glMap.getSourceValue().indexOf("DR") < glMap.getSourceValue().indexOf("AMOUNT"))) {
                    val = roundingEnabled ? "SUM(ROUND(" + glMap.getSourceValue() + ",rpro_utility_pkg.curr_rounding(HEAD_FN_CUR))) "
                            : "SUM(" + glMap.getSourceValue() + ") ";
                } else {
                    if (groupByStr == null) {
                        groupByStr = new StringBuilder(glMap.getSourceValue());
                    } else {
                        groupByStr.append(',').append(glMap.getSourceValue());
                    }
                }
            }
        } else if (glMap.getSourceFrom().equals(TransferActivityImpl.SourceFrom.EXPRESSION.name())) {
            val = glMap.getSourceValue();
            if (objectType.equals(AccountingObjectType.GENERAL_LEDGER.getObjectTypeType()) && "Y".equals(summaryTransfer)
                    || objectType.equals(AccountingObjectType.MANUAL_JE.getObjectTypeType()) && "Y".equals(mjeSummaryTransfer)) {
                if (groupByStr == null) {
                    groupByStr = new StringBuilder(glMap.getSourceValue());
                } else {
                    groupByStr = groupByStr.append(',').append(glMap.getSourceValue());
                }
            }
        } else if (glMap.getSourceFrom().equals(TransferActivityImpl.SourceFrom.DYNAMIC.name())) {
            try {
                val = handle.createQuery(glMap.getSourceValue()).mapTo(String.class).first();
            } catch (Exception e) {
                String errMsg = "Dynamic SQL IN GL MAPPING failed. Verify the: " + objectType + " Interface Mapping. Error: " + e.getMessage();
                LOGGER.error(errMsg);
                throw e;
            }
        }

        insertStmt.append(',').append(glMap.getFieldName());
        if (val != null) {
            if (glMap.getSourceFrom().equals(TransferActivityImpl.SourceFrom.DYNAMIC.name())) {
                insertSelect.append(",'").append(val).append('\'');
            } else {
                insertSelect.append(',').append(val);
            }
        } else {
            insertSelect.append(", NULL");
        }

        if (index == size - 1) {
            GlInsertBuilder glInsertBuilder = new GlInsertBuilder(insertStmt, insertSelect, groupByStr);
            return glInsertBuilder;
        }

        return null;
    }
}
