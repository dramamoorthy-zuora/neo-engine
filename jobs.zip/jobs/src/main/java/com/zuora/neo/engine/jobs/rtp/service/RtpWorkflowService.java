package com.zuora.neo.engine.jobs.rtp.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.dao.LockDao;
import com.zuora.neo.engine.exception.NeoEngineException;
import com.zuora.neo.engine.jobs.rtp.WorkItemResult;
import com.zuora.neo.engine.jobs.rtp.api.RtpBatchContext;
import com.zuora.neo.engine.jobs.rtp.api.RtpWorkflowDefinition;
import com.zuora.neo.engine.jobs.rtp.config.RtpProperties;
import com.zuora.neo.engine.jobs.rtp.constants.RtpConstants;
import com.zuora.neo.engine.jobs.rtp.constants.RtpWiHeaderStatus;
import com.zuora.neo.engine.jobs.rtp.constants.RtpWiStatus;
import com.zuora.neo.engine.jobs.rtp.db.doa.RtpDao;
import com.zuora.neo.engine.jobs.rtp.factory.RtpWorkflowFactory;

import com.zuora.neo.engine.scheduler.dao.ScheduledProgramDao;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import com.google.common.annotations.VisibleForTesting;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.OutParameters;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class RtpWorkflowService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(RtpWorkflowService.class);

    @Autowired
    RtpWorkflowFactory rtpWorkflowFactory;

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;

    @Autowired
    RtpProperties rtpProperties;

    @Autowired
    RtpBatchCreatorService rtpBatchCreatorService;

    @Autowired
    RtpCleanupService rtpCleanupService;

    @VisibleForTesting
    RtpService getServiceFromFactory(Integer stepId) {
        return rtpWorkflowFactory.getService(stepId);
    }

    public long performRtp(Handle handle, RtpDao rtpDao, ScheduledProgramDao programDao, String secAtrVal) {

        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        RtpBatchContext batchContext = new RtpBatchContext(secAtrVal);
        long processedCount = 0;
        int pendingJobExistsInQueue = 0;

        do {

            Integer noOfHeaders = rtpBatchCreatorService.prepareWiHeaderBatchForRtp(handle, rtpDao, batchContext);

            if (noOfHeaders.equals(0)) {
                neoWorkflowLogger.log("No WorkItem Headers present to perform RTP");
                return processedCount;
            }

            neoWorkflowLogger.log("Rtp Batch " + batchContext.getBatchId() + " - No. of Headers picked " + noOfHeaders);

            try {

                List<RtpWorkflowDefinition> rtpWorkflowDefinitions = rtpDao.getRtpWorkflowDefinition(RtpWorkflowDefinition.DEFAULT_WF_ID);
                boolean stepFailed = false;

                for (RtpWorkflowDefinition rtpWorkflowDefinition : rtpWorkflowDefinitions) {
                    Integer stepId = rtpWorkflowDefinition.getStep().getId();
                    Integer noOfWisInserted = rtpDao.createRtpWiEntries(
                            batchContext.getBatchId(), RtpWiStatus.IN_PROGRESS.getStatus(), stepId, request.getUser());
                    LOGGER.info("No.of Work items inserted - " + noOfWisInserted);

                    try {
                        WorkItemResult workItemResult = getServiceFromFactory(stepId).process(batchContext.getSecAtrVal(), batchContext.getBatchId());
                        LOGGER.info(
                                "WorkItemResult for batchId " + batchContext.getBatchId() + " stepId " + stepId + " - " + workItemResult.toString());

                        if (workItemResult.isSuccess()) {
                            Integer noOfWiUpdated = rtpDao.updateWiStatus(batchContext.getBatchId(), RtpWiStatus.COMPLETED.getStatus(), stepId);
                            LOGGER.info("No.of Wi entries updated - " + noOfWiUpdated);
                        } else if (workItemResult.isSkipped()) {
                            Integer noOfWiUpdated = rtpDao.updateWiStatusWithMessage(
                                    batchContext.getBatchId(), workItemResult.getErrorMessage(), RtpWiStatus.SKIPPED.getStatus(), stepId);
                            LOGGER.info("No.of Wi entries skipped - " + noOfWiUpdated + " with message - " + workItemResult.getErrorMessage());
                        } else {
                            Integer noOfWiErrorUpdated = rtpDao.updateWiStatusWithMessage(
                                    batchContext.getBatchId(), workItemResult.getErrorMessage(), RtpWiStatus.ERROR.getStatus(), stepId);
                            neoWorkflowLogger.log("No.of Wi errors updated - " + noOfWiErrorUpdated);
                            stepFailed = true;
                            break;
                        }
                    } catch (Exception e) {
                        Integer noOfWiErrorUpdated = rtpDao.updateWiStatusWithMessage(
                                batchContext.getBatchId(), e.getMessage(), RtpWiStatus.ERROR.getStatus(), stepId);
                        neoWorkflowLogger.log("No.of Wi errors updated - " + noOfWiErrorUpdated);
                        throw e;
                    }
                }

                String status = stepFailed ? RtpWiHeaderStatus.ERROR.getHeaderStatus() : RtpWiHeaderStatus.COMPLETED.getHeaderStatus();
                Integer noOfHeadersUpdated = rtpDao.updateHeaderStatus(batchContext.getBatchId(), status, request.getUser());
                LOGGER.info("No.of Headers status updated - " + noOfHeadersUpdated);

                rtpCleanupService.postProcessCleanup(rtpDao, batchContext);

                processedCount += noOfHeaders;

                pendingJobExistsInQueue = programDao.pendingJobExistsInQueue(batchContext.getSecAtrVal(), request.getRequestId());
                LOGGER.info("Pending job exists in Queue - " + pendingJobExistsInQueue);

            } catch (Exception e) {
                Integer noOfHeadersUpdated = rtpDao.updateHeaderStatus(
                        batchContext.getBatchId(), RtpWiHeaderStatus.ERROR.getHeaderStatus(), request.getUser());
                neoWorkflowLogger.log("No.of Headers status updated - " + noOfHeadersUpdated);
                throw e;
            }

        } while (pendingJobExistsInQueue == 0);

        return processedCount;
    }


    public void removeLock(LockDao lockDao, String secAtrVal) {
        Integer lockCount = lockDao.checkLockExists();
        if (lockCount > 0) {
            lockDao.removeLock(secAtrVal);
        }
    }

    public OutParameters acquireLock(LockDao lockDao, String secAtrVal) {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        OutParameters lockOutParameters = lockDao.acquireLock(request.getRequestId(), RtpConstants.REALTIME_PROCESS,
                RtpConstants.REALTIME_PROCESS_IN_PROGRESS, secAtrVal);
        String errorBuffer = lockOutParameters.getString("p_ret_msg");
        String lockResult = lockOutParameters.getString("p_result");
        if ("FALSE".equals(lockResult)) {
            LOGGER.error(RtpConstants.UNABLE_TO_LOCK + errorBuffer);
            throw new NeoEngineException(RtpConstants.UNABLE_TO_LOCK + errorBuffer);
        }
        return lockOutParameters;
    }

}
