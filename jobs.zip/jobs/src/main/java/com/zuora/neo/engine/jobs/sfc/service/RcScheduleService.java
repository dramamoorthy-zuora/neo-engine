package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.jobs.sfc.db.api.SchdIndicator;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.PreparedBatch;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class RcScheduleService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AccrualEntryService.class);
    private static final String INSERT_RC_SCHD_QUERY = "INSERT INTO rpro_rc_schd (id, rc_id, rc_ver, line_id, pob_id, curr, amount,"
            + " indicators, prd_id, post_prd_id, dr_segments, cr_segments, f_ex_rate, g_ex_rate, ex_rate_date, client_id, "
            + " crtd_prd_id, sec_atr_val, crtd_by, crtd_dt, updt_by, updt_dt, ref_bill_id, root_line_id, book_id, orig_line_id) VALUES "
            + " (rpro_utility_pkg.generate_id ('rpro_rc_schd_id_s', :client_id), :rc_id, :rc_ver, :line_id, :pob_id, :curr, :amount,"
            + " :indicators, :prd_id, :post_prd_id, :dr_segments, :cr_segments, :f_ex_rate, :g_ex_rate, :ex_rate_date, :client_id, "
            + " :crtd_prd_id, :sec_atr_val, :crtd_by, sysdate, :updt_by, sysdate, :ref_bill_id, :root_line_id, :book_id, :orig_line_id)";

    public RcScheduleRecord populateRcScheduleRecord(List<RcLineDetails> rcLineDetails,
            List<RcLinePaData> rcLinePaDataRecord, CalendarDetails calendarDetail, WorkflowRequest request, BigDecimal interest, long rcVersion,
            long openPeriodId, String drSegment, String crSegment, SchdIndicator schdIndicator) {
        RcScheduleRecord rcScheduleRecord = new RcScheduleRecord();

        rcScheduleRecord.setAmount(interest);
        rcScheduleRecord.setRcId(rcLineDetails.get(0).getRcId());
        rcScheduleRecord.setLineId(rcLinePaDataRecord.get(0).getId());
        rcScheduleRecord.setRootLineId(rcLineDetails.get(0).getId());
        rcScheduleRecord.setRcVer(rcVersion);
        rcScheduleRecord.setPobId(rcLineDetails.get(0).getRcPobId());
        rcScheduleRecord.setCurr(rcLineDetails.get(0).getCurrencyCode());
        if (calendarDetail != null) {
            rcScheduleRecord.setPeriodId(Math.max(openPeriodId, calendarDetail.getId()));
            rcScheduleRecord.setPostPeriodId(Math.max(openPeriodId, calendarDetail.getId()));
        }
        rcScheduleRecord.setfexRate(rcLineDetails.get(0).getfexRate());
        rcScheduleRecord.setgexRate(rcLineDetails.get(0).getgexRate());
        rcScheduleRecord.setRefBillId(1);
        rcScheduleRecord.setBookId(rcLineDetails.get(0).getBookId());
        rcScheduleRecord.setExRateDate(rcLineDetails.get(0).getDocDate());
        rcScheduleRecord.setClientId(rcLineDetails.get(0).getClientId());
        rcScheduleRecord.setSecAtrVal(rcLineDetails.get(0).getSecAtrVal());
        rcScheduleRecord.setCrtdBy(request.getUser());
        rcScheduleRecord.setUpdtBy(request.getUser());
        rcScheduleRecord.setRootLineId(rcLineDetails.get(0).getId());
        rcScheduleRecord.setOrigLineId(rcLinePaDataRecord.get(0).getId());
        rcScheduleRecord.setCrtdPeriodId(openPeriodId);
        rcScheduleRecord.setDrSegments(drSegment);
        rcScheduleRecord.setCrSegments(crSegment);
        schdIndicator.setSchdTypeFlag('V');
        schdIndicator.setSchdSubTypeFlag('F');
        rcScheduleRecord.setIndicators(schdIndicator.getIndicator());
        return rcScheduleRecord;
    }

    public void insertRcScheduleRecordsBatch(List<RcScheduleRecord> rcScheduleRecordBatch, Handle handle) {

        PreparedBatch insertRcScheduleRecordsBatch = handle.prepareBatch(INSERT_RC_SCHD_QUERY);
        for (RcScheduleRecord rcScheduleRecord : rcScheduleRecordBatch) {
            bindRcScheduleRecordForInsert(insertRcScheduleRecordsBatch, rcScheduleRecord);
        }
        doBulkInsertRcScheduleRecords(insertRcScheduleRecordsBatch);
    }

    public void doBulkInsertRcScheduleRecords(PreparedBatch insertRcScheduleRecordsBatch) {

        LOGGER.info("Insert RC Schedule Batch Size : " + insertRcScheduleRecordsBatch.size());
        int[] insertCount = insertRcScheduleRecordsBatch.execute();
        LOGGER.info("Number of Records inserted RC Schedule : " + insertCount.length);
    }

    public void bindRcScheduleRecordForInsert(PreparedBatch insertRcScheduleRecordsBatch, RcScheduleRecord rcScheduleRecord) {

        insertRcScheduleRecordsBatch.bind("id", rcScheduleRecord.getId())
                .bind("rc_id", rcScheduleRecord.getRcId())
                .bind("rc_ver", rcScheduleRecord.getRcVer())
                .bind("line_id", rcScheduleRecord.getLineId())
                .bind("pob_id", rcScheduleRecord.getPobId())
                .bind("curr", rcScheduleRecord.getCurr())
                .bind("amount", rcScheduleRecord.getAmount())
                .bind("prd_id", rcScheduleRecord.getPeriodId())
                .bind("indicators", rcScheduleRecord.getIndicators())
                .bind("post_prd_id", rcScheduleRecord.getPostPeriodId())
                .bind("book_id", rcScheduleRecord.getBookId())
                .bind("dr_segments", rcScheduleRecord.getDrSegments())
                .bind("cr_segments", rcScheduleRecord.getCrSegments())
                .bind("f_ex_rate", rcScheduleRecord.getfexRate())
                .bind("g_ex_rate", rcScheduleRecord.getgexRate())
                .bind("ex_rate_date", rcScheduleRecord.getExRateDate())
                .bind("client_id", rcScheduleRecord.getClientId())
                .bind("crtd_prd_id", rcScheduleRecord.getCrtdPeriodId())
                .bind("sec_atr_val", rcScheduleRecord.getSecAtrVal())
                .bind("ref_bill_id", rcScheduleRecord.getRefBillId())
                .bind("root_line_id", rcScheduleRecord.getRootLineId())
                .bind("book_id", rcScheduleRecord.getBookId())
                .bind("orig_line_id", rcScheduleRecord.getOrigLineId())
                .bind("crtd_by", rcScheduleRecord.getCrtdBy())
                .bind("updt_by", rcScheduleRecord.getUpdtBy()).add();
    }

}
