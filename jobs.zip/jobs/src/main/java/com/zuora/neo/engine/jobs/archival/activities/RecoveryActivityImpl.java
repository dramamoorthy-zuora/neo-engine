package com.zuora.neo.engine.jobs.archival.activities;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.common.util.CommonUtils;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.jobs.archival.ArchivalResult;
import com.zuora.neo.engine.jobs.archival.common.Constants;
import com.zuora.neo.engine.jobs.archival.common.QueryLogger;
import com.zuora.neo.engine.jobs.archival.db.model.ArchivalSettingsEntity;
import com.zuora.neo.engine.jobs.archival.db.model.DataArchivalTable;
import com.zuora.neo.engine.jobs.archival.enums.ArchivalStatus;
import com.zuora.neo.engine.jobs.archival.enums.BatchStatus;
import com.zuora.neo.engine.jobs.archival.exceptions.ArchivalException;
import com.zuora.neo.engine.jobs.archival.service.ArchivalTableService;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.Update;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;


@ActivityImplementation
@Component
public class RecoveryActivityImpl implements RecoveryActivity {

    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(RecoveryActivityImpl.class);
    private final ArchivalTableService archivalTableService;
    private List<DataArchivalTable> archivalOrDeletableTables;
    private ArchivalResult result;
    private String schemaName;
    private ArchivalSettingsEntity archivalSettings;
    private  final QueryLogger queryLogger;
    private ParseProgramParameters parseProgramParameters;
    private StringBuilder batchFailureMessage = new StringBuilder();
    private int failureCount = 0;
    private int totalRcs = 0;
    private String rcDelimiter = ",";

    RecoveryActivityImpl(ArchivalTableService archivalTableService, QueryLogger queryLogger,
                         ParseProgramParameters parseProgramParameters) {
        this.archivalTableService = archivalTableService;
        this.queryLogger = queryLogger;
        this.parseProgramParameters = parseProgramParameters;
    }

    @Override
    public ArchivalResult recoverRecords() {
        logger.debug("Started executing recovery workflow.");
        result = new ArchivalResult();
        Jdbi jdbi = DbContext.getConnection();
        jdbi.setSqlLogger(queryLogger);
        List<Long> recoverableRCs;

        String parameterText = WorkflowContextManager.getWorkflowContext().getRequest().getParameterText();
        try (Handle h = jdbi.open()) {
            archivalSettings =  archivalTableService.getArchivalSettings(h, "DATA_ARCHIVE");
            this.queryLogger.setLogQuery(archivalSettings.isLogQuery());
            recoverableRCs = fetchRecoverableRCs(h, archivalSettings.getBatchSize(), parameterText);
            if (recoverableRCs.isEmpty()) {
                result.setStatus(ArchivalStatus.EMPTY_BATCH);
                result.setMessage("No RCs found to recover");
                result.isRetryPossible(false);
                return result;
            }

            archivalOrDeletableTables = archivalTableService.fetchArchivalTables(h);
            if (archivalOrDeletableTables.isEmpty()) {
                result.setStatus(ArchivalStatus.DATA_ERROR);
                result.setMessage("Recovery Meta data table is empty");
                result.isRetryPossible(false);
                return result;
            }

            logger.debug("Calling SP to update copy Query");
            //archivalTableService.updateCopyQueryInDaTable(h);
            schemaName = archivalTableService.getSchemaName(h);
            logger.debug("Schema Name::" + schemaName);
            logger.info("Total number of archival or deletable tables : " + archivalOrDeletableTables.size());

            AtomicInteger currentFailureCount = new AtomicInteger();
            while (!recoverableRCs.isEmpty()) {
                final List<Long> finalRecoverableRcs = recoverableRCs;
                if (CommonUtils.isActivityCancelled(logger)) {
                    result.setStatus(ArchivalStatus.ACTIVITY_CANCELLED);
                    result.setMessage("Activity is cancelled by the temporal cluster ");
                    result.isRetryPossible(false);
                    return result;
                }
                boolean continueBatch = performRecoveryAndDelete(finalRecoverableRcs, h, currentFailureCount);
                if (!continueBatch || !parameterText.isEmpty()) {
                    return result;
                }
                recoverableRCs = fetchRecoverableRCs(h, archivalSettings.getBatchSize(), parameterText);
            }
            if (failureCount > 0) {
                result.isRetryPossible(false);
                result.setStatus(ArchivalStatus.PARTIAL_COPIED);
                result.setMessage("Recovery batch failed " + failureCount + " time/s and the cause is " + batchFailureMessage);
                return result;
            }
            result.setStatus(ArchivalStatus.RECOVERY_SUCCESS);
            result.isRetryPossible(true);
            result.setMessage(Constants.WorkflowConstants.RECOVERY_WORKFLOW_SUCCESS);
            return result;
        }
    }



    private boolean performRecoveryAndDelete(List<Long> rcIds, Handle h, AtomicInteger currentFailureCount) {
        try {
            h.useTransaction(handle -> {
                int copiedRecordsCount = recoverBatch(handle, rcIds);
                int deletedRecordsCount = deleteBatch(handle, rcIds);
                logger.info("Total number of records copied " + copiedRecordsCount + " and deleted "
                        + deletedRecordsCount);
            });
            return true;
        } catch (Exception e) {
            failureCount++;
            batchFailureMessage.append(failureCount + ":" + e.getMessage() + "\n");
            logger.error("Error while recovering the records::" + e.getMessage());
            markBatchAsFailed(h, currentFailureCount, rcIds);
            if ((currentFailureCount.get() > archivalSettings.getSuccessiveBatchUpdateFailureThreshold())
                    || (maxFailureThresholdExceeded(totalRcs, failureCount))) {
                logger.error("Successive batch failed for more than " + failureCount + " times. " + e.getMessage());
                result.setStatus(ArchivalStatus.RECOVERY_FAILED);
                result.isRetryPossible(false);
                result.setMessage("Successive batch failed for more than " + failureCount + " times. Reason :" + e.getMessage());
                return false;
            }
            return true;
        }
    }


    private boolean maxFailureThresholdExceeded(int totalRcs, int failureCount) {
        int batches = Math.floorDiv(totalRcs, archivalSettings.getBatchSize());
        int maxFailureCount = (int) Math.floor(batches * archivalSettings.getMaxFailureAttemptsInPercentage());
        return failureCount > maxFailureCount;
    }

    private int recoverBatch(Handle handle, List<Long> rcIds) {
        int recoveredRecordsCount = 0;
        String tableName = "";
        try {
            for (DataArchivalTable table : archivalOrDeletableTables) {
                tableName = table.getName();
                String recoverFilterQuery = table.getRecoverFilterQuery().replace("l_revpro_schema", schemaName);
                Update update = handle.createUpdate(recoverFilterQuery);
                update.bindList("rcIds", rcIds);
                int count =  update.execute();
                logger.info("Copied " + count + " records from " + tableName);
                recoveredRecordsCount += count;
            }

            archivalTableService.deleteRcMapping(handle, rcIds);
            logger.info("RC mapping records have been deleted.");
            return recoveredRecordsCount;

        } catch (Exception e) {
            logger.error("Failed to copy the data for table " + tableName + " " + e.getMessage() + " rc ids" + rcIds);
            throw new ArchivalException("Failed to perform copy to original schema for table " + tableName + " " + e.getMessage(), e);
        }

    }

    private int deleteBatch(Handle handle, List<Long> rcIds) {
        logger.info("Delete process is invoked.");
        int deletedRecordsCount = 0;
        String tableName = "";
        try {
            for (DataArchivalTable table : archivalOrDeletableTables) {
                String deleteAfterRecoverQuery = table.getDeleteAfterRecover();
                tableName = table.getName();
                logger.info("Deleting for " + tableName);
                Update statement = handle.createUpdate(deleteAfterRecoverQuery);
                statement.bindList("rcIds", rcIds);
                int count =  statement.execute();
                logger.info("Deleted " + count + " records from " + tableName);
                deletedRecordsCount += count;
            }
            archivalTableService.updateRecoveryStatus(handle,BatchStatus.RECOVERED.label, rcIds);
            return deletedRecordsCount;
        } catch (RuntimeException e) {
            logger.error("Failed to delete the data for table " + tableName + " " + e.getMessage() + " rc ids" + rcIds);
            throw new ArchivalException("Failed while deleting the records from archival schema", e);
        }

    }

    private void markBatchAsFailed(Handle h, AtomicInteger failureCount, List<Long> finalExpiredRcs) {
        try {
            h.useTransaction(handle -> archivalTableService.updateBatchStatus(handle,BatchStatus.RECOVERY_EXCEPTION.label, finalExpiredRcs));
        } catch (Exception ex) {
            logger.error("Setting the batch status failed as well", ex);
            failureCount.incrementAndGet();
        }
    }

    private List<Long> parseRcIds(String rcsToBeRecovered) {
        if (!rcsToBeRecovered.isEmpty()) {
            List<Long> rcIds = Arrays.stream(rcsToBeRecovered.split(rcDelimiter))
                    .mapToLong(Long::parseLong)
                    .boxed()
                    .collect(Collectors.toList());
            return rcIds;
        }
        return new ArrayList<>();
    }

    private List<Long> fetchRecoverableRCs(Handle handle, int batchSize, String parameterText) {
        long requestId = WorkflowContextManager.getWorkflowContext().getRequest().getRequestId();
        if (!parameterText.isEmpty()) {
            String tenantId = WorkflowContextManager.getWorkflowContext().getRequest().getTenantId();
            long programId = WorkflowContextManager.getWorkflowContext().getRequest().getProgramId();

            Map<String, String> rcsToBeRecovered = parseProgramParameters.parseParamString(tenantId, programId, parameterText);
            List<Long> recoverableRCs = parseRcIds(rcsToBeRecovered.get("RECOVER RC ID"));
            archivalTableService.insertHeadGDetailsRecovery(handle, recoverableRCs);
            return recoverableRCs;
        }
        logger.info("Reading RCs from DB now.");
        archivalTableService.updateIdOfInsertedRCs(handle, requestId);
        return archivalTableService.fetchRecoverableRCs(handle, requestId, BatchStatus.TO_BE_RECOVERED.label, batchSize);
    }
}
