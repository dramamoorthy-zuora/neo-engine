package com.zuora.neo.engine.jobs.transferaccounting.constants;

public class AccountingProfiles {
    public static final String CUSTOM_CODE_ALLOWED = "CUSTOM_CODE_ALLOWED";
    public static final String SUMMARY_TRANSFER = "SUMMARY_TRANSFER";
    public static final String MJE_SUMMARY_TRANSFER = "MJE_SUMMARY_TRANSFER";
    public static final String POST_SCHEDULES = "POST_SCHEDULES";
    public static final String POST_MANUAL_JE_SCHEDULES = "POST_MANUAL_JE_SCHEDULES";
    public static final String ENABLE_GL_LINK = "ENABLE_GL_LINK";
    public static final String MJE_ENABLED = "MJE_ENABLED";
    public static final String DO_TRANSFER_VALIDATION = "DO_TRANSFER_VALIDATION";
    public static final String FILE_TRNSFR_BATCH = "GENERATE_FILE_TRNSFR_BATCH";
    public static final String ENABLE_CLOSE_PROCESS = "ENABLE_CLOSE_PROCESS_API";
    public static final String NETTING_PROCESS = "NETTING_PROCESS_LEVEL";
    public static final String ADJUST_CR_DR = "ADJUST_UNBALANCED_CR_DR";
    public static final String WEBSERVICE_ENABLED = "WEB_SERVICE_ENABLED";
    public static final String STOP_BATCH_ON_ERR = "STOP_BATCH_ON_ERROR";
    public static final String ENABLE_ALLOCATIONS = "ENABLE_ALLOCATIONS";
    public static final String SCHD_VALIDATION = "REG_SCHD_CC_ID_VALIDATION";
    public static final String LANGUAGE = "LANGUAGE";

    //multi-thread related profiles
    public static final String BATCH_SIZE = "TA_BATCH_SIZE";
    public static final String NUM_THREADS = "TA_NUMBER_OF_THREADS";

}
