package com.zuora.neo.engine.jobs.caclnetting.activities;

import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface CaclNettingActivities {

    WorkflowResponse performNetting();

}
