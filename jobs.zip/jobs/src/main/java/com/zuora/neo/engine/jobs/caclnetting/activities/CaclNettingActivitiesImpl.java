package com.zuora.neo.engine.jobs.caclnetting.activities;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.db.dao.LockDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.caclnetting.api.WorkflowResultBuffer;
import com.zuora.neo.engine.jobs.caclnetting.config.CaclProperties;
import com.zuora.neo.engine.jobs.caclnetting.constants.CaclMessages;
import com.zuora.neo.engine.jobs.caclnetting.constants.CaclParams;
import com.zuora.neo.engine.jobs.caclnetting.db.dao.CaclNettingDao;
import com.zuora.neo.engine.jobs.caclnetting.service.CaclService;
import com.zuora.neo.engine.jobs.caclnetting.service.CarryForwardService;
import com.zuora.neo.engine.jobs.caclnetting.service.CleanupService;
import com.zuora.neo.engine.jobs.caclnetting.service.InitializerService;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.OutParameters;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.Map;

@ActivityImplementation
public class CaclNettingActivitiesImpl implements CaclNettingActivities {

    final CaclService caclService;

    final ParseProgramParameters parseProgramParameters;

    final CleanupService cleanupService;

    final CaclProperties caclProperties;
    final NeoWorkflowLogger neoWorkflowLogger;
    final InitializerService initializerService;
    final CarryForwardService carryForwardService;

    private static final String caclProcess = "CA/CL Netting";
    private static final String caclInProgress = "CA/CL Netting process in progress";
    static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CaclNettingActivitiesImpl.class);


    public CaclNettingActivitiesImpl(CaclService caclService, ParseProgramParameters parseProgramParameters,
                                     CleanupService cleanupService, CaclProperties caclProperties, NeoWorkflowLogger neoWorkflowLogger,
                                     InitializerService initializerService, CarryForwardService carryForwardService) {
        this.caclService = caclService;
        this.parseProgramParameters = parseProgramParameters;
        this.cleanupService = cleanupService;
        this.caclProperties = caclProperties;
        this.neoWorkflowLogger = neoWorkflowLogger;
        this.initializerService = initializerService;
        this.carryForwardService = carryForwardService;
    }

    @Override
    public WorkflowResponse performNetting() {
        WorkflowContext workflowContext = WorkflowContextManager.getWorkflowContext();
        WorkflowRequest request = workflowContext.getRequest();
        long clientId = request.getClientId();
        String orgId = request.getOrgId();
        String user = request.getUser();

        Map<String, String> paramsMap = parseProgramParameters.parseParamString(request.getTenantId(), request.getProgramId(), request.getParameterText());

        if (!paramsMap.containsKey(CaclParams.PERIOD_NAME) || !paramsMap.containsKey(CaclParams.BOOK_NAME)
                || !paramsMap.containsKey(CaclParams.CREATE_LINE_LEVEL)) {
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, "All mandatory parameters not passed");
        }
        String periodName = paramsMap.get(CaclParams.PERIOD_NAME);
        String bookName = (paramsMap.get(CaclParams.BOOK_NAME));
        String createLineLevel = paramsMap.get(CaclParams.CREATE_LINE_LEVEL);

        Long rcId = null;
        if (paramsMap.containsKey(CaclParams.RC_ID)) {
            rcId = Long.parseLong(paramsMap.get(CaclParams.RC_ID));
        }

        String includeAllRc = "N";
        if (paramsMap.containsKey(CaclParams.INCLUDE_ALL_RCS)) {
            includeAllRc = paramsMap.get(CaclParams.INCLUDE_ALL_RCS);
        }

        Jdbi jdbi = DbContext.getConnection();

        String fullRefresh = includeAllRc;
        Long tempFinalRcId = rcId;

        WorkflowResultBuffer workflowResultBuffer = new WorkflowResultBuffer();

        jdbi.useTransaction(handle -> {
            CaclNettingDao nettingDao = handle.attach(CaclNettingDao.class);
            CommonDao commonDao = handle.attach(CommonDao.class);
            LockDao lockDao = handle.attach(LockDao.class);
            OutParameters lockOutParameters = null;

            if (fullRefresh != null && fullRefresh.equals("Y")) {
                OutParameters outParameters = nettingDao.performNettingProcedure(periodName, orgId, bookName, createLineLevel, tempFinalRcId, fullRefresh);
                String errorBuffer = outParameters.getString("errorBuffer");
                Integer retCode = outParameters.getInt("retCode");

                workflowResultBuffer.setMessageBuffer(errorBuffer);
                workflowResultBuffer.setReturnCode(retCode);
                return;
            }

            try {
                Long bookId = commonDao.getBookId(bookName, clientId);
                if (bookId == null) {
                    NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, "ERROR: Invalid book name.");
                }

                initializerService.performInitOperations(commonDao, nettingDao, bookId, clientId, orgId, user);

                BigDecimal batchId = nettingDao.getBatchId(clientId);
                int rowsInserted = caclService.insertNettingRc(nettingDao, batchId, tempFinalRcId,
                        fullRefresh, false);
                // No RC's were eligible for netting
                if (rowsInserted == 0) {
                    workflowResultBuffer.setReturnCode(0);
                    workflowResultBuffer.setMessageBuffer(CaclMessages.NO_RCS_TO_PROCESS);
                    return;
                }
                if (!caclProperties.isShadowMode()) {
                    // acquire lock only if not in shadow mode to not interrupt the actual processes running
                    lockOutParameters = lockDao.acquireLock(request.getRequestId(), caclProcess, caclInProgress, request.getOrgId());
                    String errorBuffer = lockOutParameters.getString("p_ret_msg");
                    String lockResult = lockOutParameters.getString("p_result");
                    if ("FALSE".equals(lockResult)) {
                        LOGGER.error("Unable to lock application - " + errorBuffer);
                        NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, "Unable to lock application - " + errorBuffer);
                    }
                }
                caclService.performNettingService(nettingDao, commonDao, batchId, bookId, createLineLevel, user, clientId, orgId);
            } finally {
                if (lockOutParameters != null && lockOutParameters.getString("p_result").equals("TRUE")) {
                    Integer lockCount = lockDao.checkLockExists();
                    if (lockCount > 0) {
                        LOGGER.info("Removing lock");
                        lockDao.removeLock(request.getOrgId());
                    }
                }
            }
            workflowResultBuffer.setReturnCode(0);
        });

        if (workflowResultBuffer.getReturnCode() != 0) {
            return new WorkflowResponse(RevenueJobStatus.ERROR, workflowResultBuffer.getMessageBuffer());
        }
        return new WorkflowResponse(RevenueJobStatus.COMPLETED, workflowResultBuffer.getMessageBuffer());
    }

}
