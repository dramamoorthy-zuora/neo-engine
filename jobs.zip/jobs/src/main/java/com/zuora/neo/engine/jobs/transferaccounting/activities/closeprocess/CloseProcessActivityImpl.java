package com.zuora.neo.engine.jobs.transferaccounting.activities.closeprocess;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.common.JobsMetadata;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.config.Properties;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.AccountingDao;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@ActivityImplementation
@Component
public class CloseProcessActivityImpl implements CloseProcessActivity {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CloseProcessActivityImpl.class);

    @Autowired
    Properties properties;

    /*
    If "ENABLE_CLOSE_PROCESS_API" is enabled we call close process api rpro_rco_trx_validation_pkg
        1) Schedule the Close process Dashboard Job for program id rpro_prog_head_pkg.c_pid_rev_analysis=503
        2) Call RCO job, rpro_rco_trx_validation_pkg.create_new_queue_message for event type 'UNPOSTED-SCHEDULES'
        3) Call the CR DR linking job
     */
    @Override
    public void doSummaryAnalysis(ThreadedAccountingResult accountingResult, String orgId) {
        Long bookId = accountingResult.getBookId();
        Long postBatchId = accountingResult.getPostBatchId();
        Jdbi jdbi = DbContext.getConnection();

        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            String enableCloseProcess = properties.getCloseProcessEnabled() ? "Y" : "N";
            if ("Y".equals(enableCloseProcess)) {
                String parameterText = "NULL~" + bookId + "~NULL~" + orgId + "~" + postBatchId + "~";
                accountingDao.scheduleJob(503, parameterText);

                String additionalParams = buildAdditionalParams(bookId, orgId, postBatchId);
                commonDao.createRcoJob("UNPOSTED-SCHEDULES", bookId, Timestamp.valueOf(LocalDateTime.now()), additionalParams);

                //schedule CR DR job
                parameterText = postBatchId + "~" + orgId;
                LOGGER.info("job parameter: " + parameterText);
                accountingDao.scheduleJob(JobsMetadata.CR_DR_LINK.getId(), parameterText);
            }
        });
    }

    private String buildAdditionalParams(Long bookId, String orgId, Long postBatchId) {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode additionalParams = mapper.createObjectNode();
        additionalParams.put("ORG_ID", orgId);
        additionalParams.put("BOOK_ID", bookId);
        additionalParams.put("POST_BATCH_ID", postBatchId);
        try {
            return mapper.writeValueAsString(additionalParams);
        } catch (JsonProcessingException e) {
            LOGGER.error("error in writing json for Rco", e);
            throw new NonRetryableActivityException(e);
        }
    }
}
