package com.zuora.neo.engine.jobs.transferaccounting.common;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.activities.closeprocess.CloseProcessActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.copy.GlCopyRoundActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.filedownload.DownloadActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.split.SplitActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.stagehandler.StageHandlerActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.support.SupportActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.transfer.TransferActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.update.UpdateActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.validation.ValidateActivity;
import com.zuora.neo.engine.jobs.transferaccounting.api.ChunkRecord;
import com.zuora.neo.engine.jobs.transferaccounting.constants.StageHandlerType;
import com.zuora.neo.engine.jobs.transferaccounting.constants.TransferStatus;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.ChunkStatus;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;

import io.temporal.workflow.Promise;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class TransferUtility {
    private static final String RETRY_TRANSFER_ERR = "Transfer failed even after max retry, please validate";
    private static final String CUSTOM_API_ERR = "ERROR: During custom stage processor:";
    private static final String UPDATE_ERR = "Update failed even after max retry, please validate";
    private static final String WRONG_BATCH = "Batch should not contain criteria from both arrangement and manual journal level";
    private static final String INCORRECT_BATCH_SETUP = "Batch criteria setup is incorrect";
    private static final String CRITERIA_ERR = "Batch Criteria Field does not exist in the lookup TRANSFER_BATCH_CRITERIA OR Alias is NULL";
    private static final String GL_INTERFACE_ERR = "GL Interface failed";
    private static final String DYNAMIC_SQL_ERR = "Dynamic SQL IN GL MAPPING failed";
    private static final String GL_INSERT_ERR = "Error: Inserting into GL Staging";
    private static final String TRANSFER_ERROR = "Error in Transfer: ";
    private static final String COPY_ERR = "Copy Activity failed to push to GL";
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(TransferUtility.class);

    public static HashSet getUniqueChunkStatuses(ThreadedAccountingResult accountingResult, SplitActivity splitActivity) {
        List<ChunkStatus> chunkTransferStatuses = splitActivity.getAllChunkStatus(accountingResult);
        HashSet<String> uniqueStatusSet = new HashSet();
        for (ChunkStatus chunkStatus : chunkTransferStatuses) {
            uniqueStatusSet.add(chunkStatus.getStatus());
        }

        return uniqueStatusSet;
    }

    public static void retryUpdateMulti(ThreadedAccountingResult accountingResult, String org, int maxRetry, int count, ThreadExecutor threadExecutor,
            SplitActivity splitActivity, UpdateActivity updateActivity, Integer totalThreads, List<ChunkRecord> batchIds,
            List<Promise<ThreadedAccountingResult>> promiseUpdateList) {
        //if we fail at the update step retry from start
        updateActivity.updateStatusToInProgress(accountingResult.getPostBatchId());
        while (count < maxRetry) {
            //execute UPDATE activity in parallel based on number of threads and split batches
            updateActivity.resetNoOfSchedules(accountingResult.getPostBatchId());
            accountingResult = threadExecutor.executeThreadedSteps(totalThreads, accountingResult, org, promiseUpdateList,
                    ActivityType.UPDATE.name(), batchIds);

            HashSet<String> uniqueStatusSet = TransferUtility.getUniqueChunkStatuses(accountingResult, splitActivity);
            if (uniqueStatusSet.contains(TransferStatus.ERROR.getTransferStatus())) {
                count++;
            } else {
                break;
            }
        }

        // even after max retry if update fails throw exception
        HashSet<String> uniqueStatusSet = TransferUtility.getUniqueChunkStatuses(accountingResult, splitActivity);
        if (count == maxRetry && uniqueStatusSet.contains(TransferStatus.ERROR.getTransferStatus())) {
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, UPDATE_ERR);
        }
    }

    public static void retryTransfer(ThreadedAccountingResult accountingResult, String org, int maxRetry,
            SplitActivity splitActivity, TransferActivity transferActivity) {
        accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
        List<Long> chunkIds = transferActivity.getRetryChunks().get(accountingResult.getPostBatchId());
        for (Long chunkId : chunkIds) {
            accountingResult.setChunkId(chunkId);
            splitActivity.updateTransferChunkStatus(accountingResult);
        }
        transferActivity.resetRetryChunks(accountingResult);
        int count = 0;
        String errorMsg = "";
        String xferMsg = "";
        HashSet<String> uniqueStatusSet;
        //if we fail at the transfer step retry from start
        while (count < maxRetry) {
            List<ChunkStatus> chunkTransferStatuses = splitActivity.getAllChunkStatus(accountingResult);
            uniqueStatusSet = getUniqueChunkStatuses(accountingResult, splitActivity);
            if (uniqueStatusSet.contains(TransferStatus.ERROR.getTransferStatus())) {
                for (ChunkStatus chunkStatus : chunkTransferStatuses) {
                    if (chunkStatus.getStatus().equals(TransferStatus.ERROR.getTransferStatus())) {
                        Long chunkId = chunkStatus.getChunkId();
                        accountingResult.setChunkId(chunkId);
                        try {
                            transferActivity.doTransferProcess(accountingResult, org);
                        } catch (Exception e) {
                            if (e.getCause() != null) {
                                if (e.getCause().getMessage().contains(GL_INTERFACE_ERR)) {
                                    if (!errorMsg.contains(GL_INTERFACE_ERR)) {
                                        errorMsg = errorMsg + " " + e.getCause().getMessage();
                                        xferMsg = xferMsg + " " + GL_INTERFACE_ERR;
                                    }
                                } else if (e.getCause().getMessage().contains(DYNAMIC_SQL_ERR)) {
                                    if (!errorMsg.contains(DYNAMIC_SQL_ERR)) {
                                        errorMsg = errorMsg + " " + e.getCause().getMessage();
                                        xferMsg = xferMsg + " " + DYNAMIC_SQL_ERR;
                                    }
                                } else if (e.getCause().getMessage().contains(GL_INSERT_ERR)) {
                                    if (!errorMsg.contains(GL_INSERT_ERR)) {
                                        errorMsg = errorMsg + " " + e.getCause().getMessage();
                                        xferMsg = xferMsg + " " + GL_INSERT_ERR;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                break;
            }
            count++;
        }
        uniqueStatusSet = getUniqueChunkStatuses(accountingResult, splitActivity);
        // even after max retry if transfer fails throw exception
        if (count == maxRetry && uniqueStatusSet.contains(TransferStatus.ERROR.getTransferStatus())) {
            accountingResult.setTransferMessage(TRANSFER_ERROR + xferMsg);
            accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
            splitActivity.insertTransferError(accountingResult, org, errorMsg);
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, RETRY_TRANSFER_ERR);
        }
    }

    public static ThreadedAccountingResult performAfterPostActivities(ThreadedAccountingResult accountingResult, String org,
            StageHandlerActivity stageHandlerActivity, SplitActivity splitActivity, GlCopyRoundActivity copyActivity,
            DownloadActivity downloadActivity, CloseProcessActivity summaryActivity, SupportActivity supportActivity) {
        String transferStatus = null;
        //copy temp table data to GL stage table and fx gain loss rounding and move batch to READY_TO_TRANSFER
        try {
            copyActivity.copyDataFromTempToStage(accountingResult);
        } catch (Exception e) {
            accountingResult.setTransferMessage(COPY_ERR);
            accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
            splitActivity.updateTransferStatus(accountingResult);
            return accountingResult;
        }

        accountingResult.setStageHandlerType(StageHandlerType.AFTER_POST);
        if (accountingResult.getStageHandlerType() == StageHandlerType.AFTER_POST) {
            accountingResult = stageHandlerActivity.executeCustomCodeStageHandler(accountingResult, org);
        }
        if (accountingResult.getTransferMessage() != null && accountingResult.getTransferMessage().contains(CUSTOM_API_ERR)) {
            return accountingResult;
        }

        List<ChunkStatus> chunkTransferStatuses = splitActivity.getAllChunkStatus(accountingResult);
        HashSet<String> uniqueStatusSet = new HashSet();
        for (ChunkStatus chunkStatus : chunkTransferStatuses) {
            uniqueStatusSet.add(chunkStatus.getStatus());
        }
        if (!chunkTransferStatuses.isEmpty() && uniqueStatusSet.size() > 1) { //TODO: do we need anything to handle here else remove
            for (ChunkStatus chunkStatus : chunkTransferStatuses) {
                Long chunkId = chunkStatus.getChunkId();
                String status = chunkStatus.getStatus();
                LOGGER.info("Transfer accounting chunk Id: " + chunkId + " status: " + status);
            }
        } else {
            transferStatus =  chunkTransferStatuses.get(0).getStatus();
            LOGGER.info("chunk status after Transfer Activity : " + transferStatus);
        }
        accountingResult.setTransferStatus(transferStatus);
        splitActivity.updateTransferStatus(accountingResult);
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        supportActivity.resetErrorMsgOnRetry(accountingResult.getPostBatchId(), request.getUser());

        //these activities NEED NOT happen chunk wise but can be done by the main single thread
        if (accountingResult.getTransferStatus().equals(TransferStatus.READY_TO_TRANSFER.getTransferStatus())
                || accountingResult.getTransferStatus().equals(TransferStatus.TRANSFERRED.getTransferStatus())) {
            //download file
            downloadActivity.fileDownload(accountingResult);

            //close process
            summaryActivity.doSummaryAnalysis(accountingResult, org);
        }
        return accountingResult;
    }

    public static ThreadedAccountingResult accountingChunkStepsPreUpdate(ThreadedAccountingResult accountingResult, ChunkRecord batchRecord,
            String orgId, UpdateActivity updateActivity, ValidateActivity validateActivity, SplitActivity splitActivity) {
        accountingResult.setChunkId(batchRecord.getChunkId());

        int count = 0;
        int maxRetry = 5;
        //call update activity
        accountingResult = updateActivity.doUpdateProcess(accountingResult, orgId);
        //no point retrying setup/user errors
        if (accountingResult.getTransferMessage() != null
                && (accountingResult.getTransferMessage().contains(WRONG_BATCH)
                || accountingResult.getTransferMessage().contains(INCORRECT_BATCH_SETUP)
                || accountingResult.getTransferMessage().contains(CRITERIA_ERR))) {
            return accountingResult;
        }
        HashSet<String> uniqueStatusSet = getUniqueChunkStatuses(accountingResult, splitActivity);
        if (uniqueStatusSet.contains(TransferStatus.ERROR.getTransferStatus())) {
            accountingResult = retryUpdate(count, maxRetry, uniqueStatusSet, updateActivity, splitActivity, accountingResult,
                    orgId);
        }

        //call validation
        accountingResult = validateActivity.validateAccountingProcess(accountingResult, orgId);
        return accountingResult;
    }

    private static ThreadedAccountingResult retryUpdate(int count, int maxRetry, HashSet<String> uniqueStatusSet, UpdateActivity updateActivity,
                                           SplitActivity splitActivity, ThreadedAccountingResult accountingResult, String orgId) {
        while (count < maxRetry) {
            if (uniqueStatusSet.contains(TransferStatus.ERROR.getTransferStatus())) {
                count++;
            } else {
                break;
            }
            updateActivity.resetNoOfSchedules(accountingResult.getPostBatchId());
            updateActivity.updateStatusToInProgress(accountingResult.getPostBatchId());
            accountingResult = updateActivity.doUpdateProcess(accountingResult, orgId);
            uniqueStatusSet = getUniqueChunkStatuses(accountingResult, splitActivity);
            if (accountingResult.getTransferMessage() != null && (accountingResult.getTransferMessage().contains(INCORRECT_BATCH_SETUP))) {
                return accountingResult;
            }
        }
        return accountingResult;
    }

    public static ThreadedAccountingResult accountingChunkStepsPostUpdate(ThreadedAccountingResult accountingResult, ChunkRecord batchRecord,
            String orgId, TransferActivity transferActivity, SplitActivity splitActivity) {
        accountingResult.setChunkId(batchRecord.getChunkId());

        //call transfer activity
        accountingResult = transferActivity.doTransferProcess(accountingResult, orgId);

        return accountingResult;
    }

    public static ThreadedAccountingResult performActivitiesForSingleThread(ThreadedAccountingResult accountingResult, List<ChunkRecord> batchIds, String org,
            StageHandlerActivity stageHandlerActivity, UpdateActivity updateActivity, ValidateActivity validateActivity,
            TransferActivity transferActivity, SplitActivity splitActivity) {
        //update main batch to in-progress
        long startTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        updateActivity.updateStatusToInProgress(accountingResult.getPostBatchId());
        for (ChunkRecord record : batchIds) {
            accountingResult = TransferUtility.accountingChunkStepsPreUpdate(accountingResult, record, org, updateActivity,
                    validateActivity, splitActivity);
            if (accountingResult.getTransferMessage() != null
                    && (accountingResult.getTransferMessage().contains(WRONG_BATCH)
                    || accountingResult.getTransferMessage().contains(INCORRECT_BATCH_SETUP)
                    || accountingResult.getTransferMessage().contains(CRITERIA_ERR))) {
                return accountingResult;
            }
        }
        long endTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        LOGGER.info("Time Taken for UPDATE: " + (endTime - startTime));
        if (accountingResult.getStageHandlerType() == StageHandlerType.AFTER_UPDATE) {
            accountingResult = stageHandlerActivity.executeCustomCodeStageHandler(accountingResult, org);
        }
        if (accountingResult.getTransferMessage() != null && accountingResult.getTransferMessage().contains(CUSTOM_API_ERR)) {
            return accountingResult;
        }
        accountingResult.setStageHandlerType(StageHandlerType.BEFORE_POST);
        if (accountingResult.getStageHandlerType() == StageHandlerType.BEFORE_POST) {
            accountingResult = stageHandlerActivity.executeCustomCodeStageHandler(accountingResult, org);
        }
        if (accountingResult.getTransferMessage() != null && accountingResult.getTransferMessage().contains(CUSTOM_API_ERR)) {
            return accountingResult;
        }
        //update main batch to in-progress
        startTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        transferActivity.updateStatusToProgress(accountingResult.getPostBatchId());
        for (ChunkRecord record : batchIds) {
            accountingResult = accountingChunkStepsPostUpdate(accountingResult, record, org, transferActivity, splitActivity);
        }
        endTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        LOGGER.info("Time Taken for TRANSFER: " + (endTime - startTime));
        return accountingResult;
    }

    public static ThreadedAccountingResult performActivitiesForMultipleThread(ThreadedAccountingResult result, List<ChunkRecord> batchIds, String org,
            int count, int maxRetry, ThreadExecutor threadExecutor, int totalThreads, TransferActivity transferActivity,
            SplitActivity splitActivity, StageHandlerActivity stageHandlerActivity, UpdateActivity updateActivity) {
        List<Promise<ThreadedAccountingResult>> promiseUpdateList = new ArrayList<>();
        List<Promise<ThreadedAccountingResult>> promiseValidateList = new ArrayList<>();
        List<Promise<ThreadedAccountingResult>> promiseTransferList = new ArrayList<>();
        //update main batch to in-progress
        updateActivity.updateStatusToInProgress(result.getPostBatchId());
        result = threadExecutor.executeThreadedSteps(totalThreads, result, org, promiseUpdateList,
                ActivityType.UPDATE.name(), batchIds);
        //no point retrying setup/user errors
        if (result.getTransferMessage() != null
                && (result.getTransferMessage().contains(WRONG_BATCH)
                || result.getTransferMessage().contains(INCORRECT_BATCH_SETUP)
                || result.getTransferMessage().contains(CRITERIA_ERR))) {
            return result;
        }

        HashSet<String> uniqueStatusSet = getUniqueChunkStatuses(result, splitActivity);
        if (uniqueStatusSet.contains(TransferStatus.ERROR.getTransferStatus())) {
            //for other system errors retry max 5 times
            retryUpdateMulti(result, org, maxRetry, count, threadExecutor, splitActivity, updateActivity,
                    totalThreads, batchIds, promiseUpdateList);
        }

        //Run validate activity in parallel based on number of threads and split batches
        result = threadExecutor.executeThreadedSteps(totalThreads, result, org, promiseValidateList, ActivityType.VALIDATE.name(), batchIds);
        //run the after update and before post stage handlers outside of the chunk logic
        result.setStageHandlerType(StageHandlerType.AFTER_UPDATE);
        stageHandlerActivity.executeCustomCodeStageHandler(result, org);
        if (result.getTransferMessage() != null && result.getTransferMessage().contains(CUSTOM_API_ERR)) {
            return result;
        }
        result.setStageHandlerType(StageHandlerType.BEFORE_POST);
        stageHandlerActivity.executeCustomCodeStageHandler(result, org);
        if (result.getTransferMessage() != null && result.getTransferMessage().contains(CUSTOM_API_ERR)) {
            return result;
        }
        //update main batch to in-progress
        transferActivity.updateStatusToProgress(result.getPostBatchId());
        //execute TRANSFER activity in parallel based on number of threads and split batches
        result = threadExecutor.executeThreadedSteps(totalThreads, result, org, promiseTransferList,
                ActivityType.TRANSFER.name(), batchIds);

        return result;
    }


}
