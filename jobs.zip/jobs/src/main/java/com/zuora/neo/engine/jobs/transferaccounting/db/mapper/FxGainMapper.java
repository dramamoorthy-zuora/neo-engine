package com.zuora.neo.engine.jobs.transferaccounting.db.mapper;

import com.zuora.neo.engine.jobs.transferaccounting.db.api.FxGainLossRecord;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class FxGainMapper implements RowMapper<FxGainLossRecord> {
    @Override
    public FxGainLossRecord map(ResultSet rs, StatementContext ctx) throws SQLException {
        Long sobId1 = rs.getLong(1);
        Long sobId = rs.wasNull() ? null : sobId1;
        Long ledgerId1 = rs.getLong(1);
        Long ledgerId = rs.wasNull() ? null : ledgerId1;
        return new FxGainLossRecord(sobId, ledgerId, rs.getString(3),
                rs.getString(4), rs.getDate(5),
                rs.getDouble(6), rs.getDouble(7));
    }
}
