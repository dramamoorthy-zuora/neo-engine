package com.zuora.neo.engine.common.lookup;

import java.util.List;

public interface LookupMapper<T> {
    T map(List<LookupEntity> data);
}
