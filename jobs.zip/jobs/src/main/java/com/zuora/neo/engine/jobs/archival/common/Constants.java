package com.zuora.neo.engine.jobs.archival.common;

/**
 * @author tkrishnakumar All the constants are placed here under different category.
 */
public final class Constants {

    public static class WorkflowConstants {

        public static final String ARCHIVAL_WORKFLOW_SUCCESS = "Archival workflow completed successfully.";
        public static final String ARCHIVAL_WORKFLOW_FAILURE = "Archival workflow failed.";
        public static final String ARCHIVAL_WORKFLOW_WARNING = "Archival workflow partially succeeded. Refer to the log for more details.";

        public static final String MIRROR_WORKFLOW_SUCCESS = "Mirror workflow completed successfully.";
        public static final String ARCHIVAL_NOT_ENABLED = "Archival not enabled.";

        public static final String ARCHIVAL_EMPTY_BATCH = "No expired RCs to migrate.";

        public static final String RECOVERY_WORKFLOW_SUCCESS = "Recovery workflow completed successfully.";
        public static final String RECOVERY_WORKFLOW_FAILURE = "Recovery workflow failed.";

        public static final String RECOVERY_WORKFLOW_WARNING = "Recovery workflow partially succeeded. Refer to the log for more details.";


    }

    public static class Observability {
        public static final String ARCHIVAL_TOTAL_RECORDS_COPY = "TOTAL_RECORDS_COPY";
        public static final String ARCHIVAL_RECORDS_COPY_PER_TABLE_PREFIX = "TABLE_COPY_";
        public static final String ARCHIVAL_RECORDS_COPY_STATS_PER_TABLE_PREFIX = "TABLE_COPY_STATS_";
        public static final String ARCHIVAL_RECORDS_COPY_TIME_PER_TABLE_PREFIX = "TABLE_COPY_TIME_";
        public static final String ARCHIVAL_RECORDS_DELETE_PER_TABLE_PREFIX = "TABLE_DELETE_";
        public static final String ARCHIVAL_RECORDS_DELETE_STATS_PER_TABLE_PREFIX = "TABLE_DELETE_STATS_";
        public static final String ARCHIVAL_RECORDS_DELETE_TIME_PER_TABLE_PREFIX = "TABLE_DELETE_TIME_";

        public static final String ARCHIVAL_BATCH_TIMER = "ARCHIVAL_TIME_TAKEN_PER_BATCH";
        public static final String ARCHIVAL_BATCH_TIMER_COPY = "ARCHIVAL_TIME_TAKEN_PER_BATCH_COPY";
        public static final String ARCHIVAL_BATCH_TIMER_DELETE = "ARCHIVAL_TIME_TAKEN_PER_BATCH_DELETE";


    }

    public static class ProfileConstants {
        public static final String PROFILE_KEY = "ENABLE_DATA_ARCHIVAL";
        public static final String DEFAULT_PROFILE_VALUE = "N";
        public static final String PROFILE_ENABLED = "Y";

    }

}
