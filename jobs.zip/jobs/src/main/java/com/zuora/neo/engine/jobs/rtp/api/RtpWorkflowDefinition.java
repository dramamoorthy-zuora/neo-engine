package com.zuora.neo.engine.jobs.rtp.api;

public class RtpWorkflowDefinition {

    public static final Integer DEFAULT_WF_ID = 1;

    RtpStep step;

    Integer executionOrder;

    public RtpWorkflowDefinition(RtpStep step, Integer executionOrder) {
        this.step = step;
        this.executionOrder = executionOrder;
    }

    public RtpStep getStep() {
        return step;
    }

    public void setStep(RtpStep step) {
        this.step = step;
    }

    public Integer getExecutionOrder() {
        return executionOrder;
    }

    public void setExecutionOrder(Integer executionOrder) {
        this.executionOrder = executionOrder;
    }
}
