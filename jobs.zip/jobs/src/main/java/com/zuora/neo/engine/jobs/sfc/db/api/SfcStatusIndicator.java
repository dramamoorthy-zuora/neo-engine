package com.zuora.neo.engine.jobs.sfc.db.api;

import java.util.Arrays;

public class SfcStatusIndicator {


    static final int PLACEHOLDER1_FLAG_POS = 0;
    static final int RECALC_FLAG_POS = 1;
    static final int RIPPED_FLAG_POS = 2;
    static final int CANCELLED_FLAG_POS = 3;
    static final int REALTIME_SUMM_READY_FLAG_POS = 4;
    static final int UPDATE_OR_INSERT_FLAG_POS = 19;

    static final  char[] defaultSfcStatusIndicator = {'N' /* TBD */,
            'N' /* Recalc Flag */,
            'N' /* Ripped  Flag */,
            'N' /* Cancelled Flag */,
            'N' /* Real Time Summarization Ready Flag */,
            'N' /* TBD */,
            'N' /* TBD */,
            'N' /* TBD */,
            'N' /* TBD */,
            'N' /* TBD */,
            'N' /* TBD */,
            'N' /* TBD */,
            'N' /* TBD */,
            'N' /* TBD */,
            'N' /* TBD */,
            'N' /* TBD */,
            'N' /* TBD */,
            'N' /* TBD */,
            'N' /* TBD */,
            'N' /* Update or Insert Flag */,
    };

    char[] sfcStatusIndicator;

    public static String getDefault() {
        return String.valueOf(defaultSfcStatusIndicator);
    }

    public SfcStatusIndicator() {
        this.sfcStatusIndicator = Arrays.copyOf(defaultSfcStatusIndicator,defaultSfcStatusIndicator.length - 1);
    }

    public  String getIndicator() {
        return String.valueOf(sfcStatusIndicator);
    }

    public static SfcStatusIndicator valueOf(String indicators) {

        int maxLength = defaultSfcStatusIndicator.length - 1;
        int stringLength = indicators.length();

        SfcStatusIndicator si = new SfcStatusIndicator();
        for (int i = 0; i < maxLength; i++) {
            if (i >= stringLength) {
                break;
            }
            si.sfcStatusIndicator[i] = indicators.charAt(i);
        }
        return si;
    }

    public char getRecalcFlag() {
        return sfcStatusIndicator[RECALC_FLAG_POS];
    }

    public void setRecalcFlag(char recalcFlag) {
        this.sfcStatusIndicator[RECALC_FLAG_POS] = recalcFlag;
    }

    public char getRippedFlag() {
        return sfcStatusIndicator[RIPPED_FLAG_POS];
    }

    public void setRippedFlag(char rippedFlag) {
        this.sfcStatusIndicator[RIPPED_FLAG_POS] = rippedFlag;
    }

    public char getCancelledFlag() {
        return sfcStatusIndicator[CANCELLED_FLAG_POS];
    }

    public void setCancelledFlag(char cancelledFlag) {
        this.sfcStatusIndicator[CANCELLED_FLAG_POS] = cancelledFlag;
    }

    public char getRealTimeSummReadyFlag() {
        return sfcStatusIndicator[REALTIME_SUMM_READY_FLAG_POS];
    }

    public void setRealTimeSummReadyFlag(char realTimeSummReadyFlag) {
        this.sfcStatusIndicator[REALTIME_SUMM_READY_FLAG_POS] = realTimeSummReadyFlag;
    }

    public char getUpdateOrInsertFlag() {
        return sfcStatusIndicator[UPDATE_OR_INSERT_FLAG_POS];
    }

    public void setUpdateOrInsertFlag(char updateOrInsertFlag) {
        this.sfcStatusIndicator[UPDATE_OR_INSERT_FLAG_POS] = updateOrInsertFlag;
    }



}
