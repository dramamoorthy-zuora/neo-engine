package com.zuora.neo.engine.jobs.internal.workflow;

import com.zuora.neo.engine.annotations.workflow.WorkflowImplementation;
import com.zuora.neo.engine.jobs.internal.activities.NovaInternalWorkflowActivities;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.workflows.LoggerWorkflowImpl;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.workflow.Workflow;
import org.springframework.stereotype.Component;

@Component
@WorkflowImplementation
public class NovaInternalWorkflowImpl extends LoggerWorkflowImpl implements NovaInternalWorkflow {

    private static final org.slf4j.Logger LOGGER = Workflow.getLogger(NovaInternalWorkflowImpl.class);

    private final NovaInternalWorkflowActivities internalWorkflowActivities = Workflow.newActivityStub(NovaInternalWorkflowActivities.class);

    @Override
    public WorkflowResponse execute() {
        LOGGER.info("Inside Internal workflow");
        internalWorkflowActivities.sync();
        return new WorkflowResponse(RevenueJobStatus.COMPLETED, "");
    }
}
