package com.zuora.neo.engine.jobs.transferaccounting.constants;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum StageHandlerType {
    BEFORE_UPDATE("BEFORE UPDATE"),
    AFTER_UPDATE("AFTER UPDATE"),
    BEFORE_POST("BEFORE POST"),
    AFTER_POST("AFTER POST");

    private final String stageHandlerType;

    @JsonValue
    public String getStageHandlerType() {
        return stageHandlerType;
    }

    StageHandlerType(String stageHandlerType) {
        this.stageHandlerType = stageHandlerType;
    }

    private static final Map<String, StageHandlerType> LOOKUP =
            Arrays.stream(StageHandlerType.values()).collect(Collectors.toMap(StageHandlerType::getStageHandlerType, Function.identity()));

    @JsonCreator
    public static StageHandlerType fromHandlerType(String stageHandlerType) {
        return LOOKUP.get(stageHandlerType);
    }
}
