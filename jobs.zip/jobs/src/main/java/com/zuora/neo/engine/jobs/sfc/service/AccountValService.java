package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.api.AccountValue;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.jobs.sfc.db.api.AccountValueIndicator;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.PreparedBatch;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class AccountValService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AccountValService.class);

    private static final String INSERT_ACCT_SEGMENTS_STATEMENT = "INSERT INTO RPRO_ACCT_VAL (ID, ACCT_SEG, VAL_ACCT_SEG, INDICATORS, CLIENT_ID,"
            + " CRTD_PRD_ID, CRTD_DT, CRTD_BY, UPDT_DT, UPDT_BY) VALUES(rpro_utility_pkg.generate_id ('RPRO_ACCT_VAL_ID_S', :client_id),"
            + " :acct_seg, :val_acct_seg, :indicators, :client_id, :crtd_prd_id, :crtd_dt, :crtd_by, :updt_dt, :updt_by)";

    //TODO - Check during schedule creation which segments to insert
    public AccountValue populateAccountSegment(String acctSeg, long crtdPrdId, RcScheduleRecord rcScheduleRecord, WorkflowRequest request) {

        AccountValue accountValue = new AccountValue();
        accountValue.setAcctSeg(acctSeg);
        accountValue.setValAcctSeg(acctSeg);

        AccountValueIndicator accountValueIndicator = new AccountValueIndicator();
        accountValueIndicator.setStatusFlag('Y');
        accountValueIndicator.setValidatedFlag('Y');
        accountValueIndicator.setUpdRclFlag('N');
        accountValueIndicator.setUpdateOrInsertFlag('I');
        accountValue.setIndicators(accountValueIndicator.getIndicator());

        accountValue.setClientId(rcScheduleRecord.getClientId());
        accountValue.setCrtdPrdId(crtdPrdId);
        accountValue.setCrtdDt(new Date());
        accountValue.setCrtdBy(request.getUser());
        accountValue.setUpdtDt(new Date());
        accountValue.setUpdtBy(request.getUser());

        return accountValue;
    }

    public void insertAccountSegmentsBatch(List<RcScheduleRecord> rcScheduleRecordBatch, List<AccountValue> accountValuesList,
            long openPeriodId, Handle handle) {

        LOGGER.info("Insert accounting string w/o validations (when account validations turned off)");
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        List<AccountValue> accountValuesToBeInserted = new ArrayList<>();
        Map<String, AccountValue> acctSegMap = accountValuesList.stream().collect(Collectors.toMap(AccountValue::getAcctSeg, Function.identity()));
        for (RcScheduleRecord rcScheduleRecord : rcScheduleRecordBatch) {
            String defAcct = rcScheduleRecord.getDrSegments();
            String revAcct = rcScheduleRecord.getCrSegments();
            if (defAcct != null && !defAcct.isEmpty()) {
                if (!acctSegMap.containsKey(defAcct)) {
                    AccountValue accountValue = populateAccountSegment(defAcct, openPeriodId, rcScheduleRecord, request);
                    accountValuesToBeInserted.add(accountValue);
                    acctSegMap.put(defAcct, accountValue);
                }
            }

            if (revAcct != null && !revAcct.isEmpty()) {
                if (!acctSegMap.containsKey(revAcct)) {
                    AccountValue accountValue = populateAccountSegment(revAcct, openPeriodId, rcScheduleRecord, request);
                    accountValuesToBeInserted.add(accountValue);
                    acctSegMap.put(revAcct, accountValue);
                }
            }
        }


        if (!accountValuesToBeInserted.isEmpty()) {
            prepareBatchAndInsertAcctSegments(handle, accountValuesToBeInserted);
        }


    }

    public void prepareBatchAndInsertAcctSegments(Handle handle, List<AccountValue> accountValuesToBeInserted) {
        PreparedBatch insertAcctSegmentsBatch = handle.prepareBatch(INSERT_ACCT_SEGMENTS_STATEMENT);

        for (AccountValue accountValue : accountValuesToBeInserted) {
            bindAccountValueForInsert(insertAcctSegmentsBatch, accountValue);
        }
        doBulkInsertAcctSegments(insertAcctSegmentsBatch);
    }

    public void bindAccountValueForInsert(PreparedBatch insertAcctSegmentsBatch, AccountValue accountValue) {
        insertAcctSegmentsBatch.bind("acct_seg", accountValue.getAcctSeg())
                .bind("val_acct_seg", accountValue.getValAcctSeg())
                .bind("indicators", accountValue.getIndicators())
                .bind("client_id", accountValue.getClientId())
                .bind("crtd_prd_id", accountValue.getCrtdPrdId())
                .bind("crtd_dt", accountValue.getCrtdDt())
                .bind("crtd_by", accountValue.getCrtdBy())
                .bind("updt_dt", accountValue.getUpdtDt())
                .bind("updt_by", accountValue.getUpdtBy())
                .add();
    }

    public void doBulkInsertAcctSegments(PreparedBatch insertAcctSegmentsBatch) {
        LOGGER.info("Insert Account Segments Batch Size : " + insertAcctSegmentsBatch.size());
        int[] insertCount = insertAcctSegmentsBatch.execute();
        LOGGER.info("Number of Records inserted Account Segments : " + insertCount.length);
    }
}
