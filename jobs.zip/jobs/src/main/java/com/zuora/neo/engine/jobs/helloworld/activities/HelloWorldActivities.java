package com.zuora.neo.engine.jobs.helloworld.activities;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface HelloWorldActivities {

    void hello();
}
