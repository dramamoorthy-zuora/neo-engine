package com.zuora.neo.engine.jobs.caclnetting.constants;

public class CaclMessages {
    public static final String NO_RCS_TO_PROCESS = "No RC's to process";
    public static final String NETTING_DISABLED = "Netting is not enabled. Enable profile ALLOW_NETTING_PROCESS";
}
