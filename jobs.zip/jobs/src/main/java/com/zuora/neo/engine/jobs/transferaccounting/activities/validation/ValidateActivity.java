package com.zuora.neo.engine.jobs.transferaccounting.activities.validation;

import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface ValidateActivity {
    ThreadedAccountingResult validateAccountingProcess(ThreadedAccountingResult accountingResult, String orgId);

}
