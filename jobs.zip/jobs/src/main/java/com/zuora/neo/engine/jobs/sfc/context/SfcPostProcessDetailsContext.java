package com.zuora.neo.engine.jobs.sfc.context;

import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;

import java.util.List;
import java.util.Map;

public class SfcPostProcessDetailsContext {

    List<RcScheduleRecord> rcScheduleRecordBatch;
    List<SfcCalcDetails> sfcCalcDetailsBatch;
    List<RcLinePaData> rcLinePaDataRecordBatch;
    Map<String, List<RcLineDetails>> rcLineDetailsBatchMap;
    Map<String, List<SfcPaymentDetails>> sfcPaymentDetailsBatchMap;

    public SfcPostProcessDetailsContext(List<RcScheduleRecord> rcScheduleRecordBatch,
            List<SfcCalcDetails> sfcCalcDetailsBatch, List<RcLinePaData> rcLinePaDataRecordBatch,
            Map<String, List<RcLineDetails>> rcLineDetailsBatchMap,
            Map<String, List<SfcPaymentDetails>> sfcPaymentDetailsBatchMap) {
        this.rcScheduleRecordBatch = rcScheduleRecordBatch;
        this.sfcCalcDetailsBatch = sfcCalcDetailsBatch;
        this.rcLinePaDataRecordBatch = rcLinePaDataRecordBatch;
        this.rcLineDetailsBatchMap = rcLineDetailsBatchMap;
        this.sfcPaymentDetailsBatchMap = sfcPaymentDetailsBatchMap;
    }

    public SfcPostProcessDetailsContext() {
    }

    public List<RcScheduleRecord> getRcScheduleRecordBatch() {
        return rcScheduleRecordBatch;
    }

    public void setRcScheduleRecordBatch(List<RcScheduleRecord> rcScheduleRecordBatch) {
        this.rcScheduleRecordBatch = rcScheduleRecordBatch;
    }

    public List<SfcCalcDetails> getSfcCalcDetailsBatch() {
        return sfcCalcDetailsBatch;
    }

    public void setSfcCalcDetailsBatch(List<SfcCalcDetails> sfcCalcDetailsBatch) {
        this.sfcCalcDetailsBatch = sfcCalcDetailsBatch;
    }

    public List<RcLinePaData> getRcLinePaDataRecordBatch() {
        return rcLinePaDataRecordBatch;
    }

    public void setRcLinePaDataRecordBatch(List<RcLinePaData> rcLinePaDataRecordBatch) {
        this.rcLinePaDataRecordBatch = rcLinePaDataRecordBatch;
    }

    public Map<String, List<RcLineDetails>> getRcLineDetailsBatchMap() {
        return rcLineDetailsBatchMap;
    }

    public void setRcLineDetailsBatchMap(Map<String, List<RcLineDetails>> rcLineDetailsBatchMap) {
        this.rcLineDetailsBatchMap = rcLineDetailsBatchMap;
    }

    public Map<String, List<SfcPaymentDetails>> getSfcPaymentDetailsBatchMap() {
        return sfcPaymentDetailsBatchMap;
    }

    public void setSfcPaymentDetailsBatchMap(
            Map<String, List<SfcPaymentDetails>> sfcPaymentDetailsBatchMap) {
        this.sfcPaymentDetailsBatchMap = sfcPaymentDetailsBatchMap;
    }
}
