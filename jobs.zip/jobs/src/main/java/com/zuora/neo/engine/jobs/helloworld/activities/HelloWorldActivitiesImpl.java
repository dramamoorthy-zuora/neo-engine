package com.zuora.neo.engine.jobs.helloworld.activities;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@ActivityImplementation
@Component
public class HelloWorldActivitiesImpl implements HelloWorldActivities {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(HelloWorldActivitiesImpl.class);
    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;

    @Override
    public void hello() {
        LOGGER.info("Inside HelloWorld activity");
    }

}
