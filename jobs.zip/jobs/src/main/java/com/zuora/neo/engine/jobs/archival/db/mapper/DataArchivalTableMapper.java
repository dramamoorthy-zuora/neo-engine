package com.zuora.neo.engine.jobs.archival.db.mapper;

import com.zuora.neo.engine.jobs.archival.db.model.DataArchivalTable;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author tkrishnakumar
 */
public class DataArchivalTableMapper implements RowMapper<DataArchivalTable> {

    @Override
    public DataArchivalTable map(ResultSet rs, StatementContext ctx) throws SQLException {
        return new DataArchivalTable(rs.getInt("id"), rs.getString("name"), rs.getString("type"),
                rs.getString("archivable"), rs.getString("deletable"), rs.getString("archive_group"),
                rs.getString("filter_query"), rs.getInt("order_by"), rs.getString("created_by"),
                rs.getString("updated_by"), rs.getDate("created_date"),
                rs.getDate("updated_date"), rs.getString("delete_filter_query"),
                rs.getString("archival_filter_query"), rs.getString("update_filter_query"),
                rs.getString("copy_filter_query"), rs.getString("delete_mirror_query"),
                rs.getString("recover_filter_query"), rs.getString("delete_after_recover")
                );
    }
}
