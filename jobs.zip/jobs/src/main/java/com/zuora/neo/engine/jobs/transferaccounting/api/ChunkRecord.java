package com.zuora.neo.engine.jobs.transferaccounting.api;

public class ChunkRecord {
    private Long batchId;
    private Long chunkId;

    public Long getBatchId() {
        return batchId;
    }

    public void setBatchId(Long batchId) {
        this.batchId = batchId;
    }

    public Long getChunkId() {
        return chunkId;
    }

    public void setChunkId(Long chunkId) {
        this.chunkId = chunkId;
    }

    public ChunkRecord(Long batchId, Long chunkId) {
        this.batchId = batchId;
        this.chunkId = chunkId;
    }

    public ChunkRecord() {

    }
}
