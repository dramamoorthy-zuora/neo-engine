package com.zuora.neo.engine.jobs.sfc.db.mapper;

import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class FinanceTypeValuesMapper implements RowMapper<FinanceTypeValues> {

    @Override
    public FinanceTypeValues map(ResultSet rs, StatementContext ctx) throws SQLException {
        return new FinanceTypeValues(rs.getLong("id"),
                rs.getString("name"), rs.getString("description"),
                rs.getLong("version"), rs.getString("rev_rec_type"), rs.getBigDecimal("interest_rate"),
                rs.getString("eligiblity_column"), rs.getString("eligiblity_value"), rs.getString("prncl_weightage_column"),
                rs.getDate("start_date"), rs.getDate("end_date"), rs.getLong("client_id"), rs.getLong("crtd_prd_id"), rs.getString("crtd_by"),
                rs.getDate("crtd_dt"),
                rs.getString("updt_by"), rs.getDate("updt_dt"), rs.getLong("seq"), rs.getString("indicators"));
    }
}
