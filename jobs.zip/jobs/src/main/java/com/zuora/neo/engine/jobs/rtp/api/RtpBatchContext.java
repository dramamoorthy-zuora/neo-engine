package com.zuora.neo.engine.jobs.rtp.api;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class RtpBatchContext {

    public static final BigDecimal BATCH_INCREMENT_VALUE = BigDecimal.valueOf(0.0000000001);
    private String secAtrVal;
    private BigDecimal batchId;

    public RtpBatchContext(String secAtrVal) {
        this.secAtrVal = secAtrVal;
    }

    public RtpBatchContext(String secAtrVal, BigDecimal batchId) {
        this.secAtrVal = secAtrVal;
        this.batchId = batchId;
    }
}
