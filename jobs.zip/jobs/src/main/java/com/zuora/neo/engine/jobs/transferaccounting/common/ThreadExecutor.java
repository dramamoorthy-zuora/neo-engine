package com.zuora.neo.engine.jobs.transferaccounting.common;

import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.activities.transfer.TransferActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.update.UpdateActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.validation.ValidateActivity;
import com.zuora.neo.engine.jobs.transferaccounting.api.ChunkRecord;

import io.temporal.workflow.Async;
import io.temporal.workflow.Promise;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/*
This class has the basic multi-threading logic
Based on the profile AccountingProfiles.BATCH_SIZE we split the total schedules into multiple chunks
Based on the profile AccountingProfiles.NUM_THREADS we spawn those many number of threads to run
in parallel using Temporal's promiselist async flow. At any point of time batches that will
run in parallel is equal to NUM_THREADS
TODO: make it generic so that can be used by other Nova jobs for parallel flow
 */
public class ThreadExecutor {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(ThreadExecutor.class);

    private UpdateActivity updateActivity;
    private TransferActivity transferActivity;
    private ValidateActivity validateActivity;

    public ThreadExecutor(UpdateActivity updateActivity, TransferActivity transferActivity, ValidateActivity validateActivity) {
        this.updateActivity = updateActivity;
        this.transferActivity = transferActivity;
        this.validateActivity = validateActivity;

    }

    public ThreadedAccountingResult executeThreadedSteps(Integer totalThreads, ThreadedAccountingResult accountingResult,
            String org, List<Promise<ThreadedAccountingResult>> promiseList, String activityName, List<ChunkRecord> batches) {
        List<ThreadedAccountingResult> results = new ArrayList<>();
        for (int batch = 0; batch < batches.size(); batch = batch + totalThreads) {
            for (int threadId = 1; threadId <= totalThreads; threadId++) {
                if (batch + threadId <= batches.size()) {
                    accountingResult.setChunkId(batches.get(batch + threadId - 1).getChunkId());
                    LOGGER.info("** CHUNK ID" + accountingResult.getChunkId().toString());
                    if (ActivityType.UPDATE.name().equals(activityName)) {
                        promiseList.add(Async.function(updateActivity::doUpdateProcess, accountingResult, org));
                    } else if (ActivityType.TRANSFER.name().equals(activityName)) {
                        promiseList.add(Async.function(transferActivity::doTransferProcess, accountingResult, org));
                    } else if (ActivityType.VALIDATE.name().equals(activityName)) {
                        promiseList.add(Async.function(validateActivity::validateAccountingProcess, accountingResult, org));
                    }
                }
            }
            Promise.allOf(promiseList).get();
        }

        // Loop through promises and get results
        for (Promise<ThreadedAccountingResult> promise : promiseList) {
            if (promise.getFailure() == null) {
                results.add(promise.get());
            }
        }
        if (!promiseList.isEmpty()) {
            accountingResult = results.get(promiseList.size() - 1);
        }

        return accountingResult;
    }
}
