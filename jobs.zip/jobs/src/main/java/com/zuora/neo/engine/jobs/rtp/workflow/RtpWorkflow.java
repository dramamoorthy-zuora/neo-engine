package com.zuora.neo.engine.jobs.rtp.workflow;

import com.zuora.neo.engine.temporal.workflows.BaseWorkflow;

import io.temporal.workflow.WorkflowInterface;

@WorkflowInterface
public interface RtpWorkflow extends BaseWorkflow {

}
