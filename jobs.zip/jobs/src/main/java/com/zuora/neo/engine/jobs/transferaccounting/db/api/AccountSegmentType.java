package com.zuora.neo.engine.jobs.transferaccounting.db.api;

public class AccountSegmentType {
    private String segment;
    private String sourceValue;

    public String getSegment() {
        return segment;
    }

    public void setSegment(String segment) {
        this.segment = segment;
    }

    public String getSourceValue() {
        return sourceValue;
    }

    public void setSourceValue(String sourceValue) {
        this.sourceValue = sourceValue;
    }

    public AccountSegmentType(String segment, String sourceValue) {
        this.segment = segment;
        this.sourceValue = sourceValue;
    }
}
