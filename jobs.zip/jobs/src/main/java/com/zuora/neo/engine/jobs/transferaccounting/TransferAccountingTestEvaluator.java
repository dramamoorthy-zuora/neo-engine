package com.zuora.neo.engine.jobs.transferaccounting;

import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.transferaccounting.constants.TransferStatus;

import com.zuora.neo.engine.test.NeoTestContext;

import java.util.List;

public class TransferAccountingTestEvaluator {
    public static final String UPDATE_RETRY_LOGIC_KEY = "simulateUpdateRetryLogic";
    public static final String UPDATE_MAX_RETRY_LOGIC_KEY = "simulateMaxUpdateRetryLogic";
    public static final String TRANSFER_RETRY_LOGIC_KEY = "simulateTransferRetryLogic";
    public static final String TRANSFER_MAX_RETRY_LOGIC_KEY = "simulateMaxTransferRetryLogic";
    public static final String TRANSFER_MULTI_THREAD_SETUP_KEY = "multiThreadSetup";
    public static final String TRANSFER_SINGLE_THREAD_SETUP_KEY = "singleThreadSetup";
    public static final String TRANSFER_NO_GLOBAL_BOOK_ID_KEY = "noGlobalBookId";
    public static final String TRANSFER_MULTIPLE_GLOBAL_BOOK_ID_KEY = "multipleGlobalBookId";
    public static final String TRANSFER_INVALID_CRTD_PERIOD_ID_KEY = "invalidCrtdPeriodId";
    public static final String TRANSFER_BATCH_ALREADY_TRANSFER_KEY = "batchAlreadyTransferred";
    public static final String CRITERIA_FROM_ARRANGEMENT_AND_MANUAL_JOURNAL_KEY = "criteriaFromArrangementAndManualJournal";
    static int updateRetryCount = 1;
    static int transferRetryCount = 1;

    public static String evaluateForUpdateRetryLogic(String status) {
        if (NeoTestContext.isIntegrationTesting()) {
            Object simulateUpdateRetryLogic = NeoTestContext.getTestVariable(UPDATE_RETRY_LOGIC_KEY);
            Object simulateMaxUpdateRetryLogic = NeoTestContext.getTestVariable(UPDATE_MAX_RETRY_LOGIC_KEY);
            if (simulateMaxUpdateRetryLogic != null && simulateMaxUpdateRetryLogic.equals(Boolean.TRUE)) {
                return TransferStatus.ERROR.getTransferStatus();
            }
            if (simulateUpdateRetryLogic != null && simulateUpdateRetryLogic.equals(Boolean.TRUE)) {
                if (updateRetryCount > 0) {
                    updateRetryCount--;
                    return TransferStatus.ERROR.getTransferStatus();
                }
            }
        }
        return status;
    }

    public static int evaluateForTransferRetryLogic() throws NonRetryableActivityException {
        if (NeoTestContext.isIntegrationTesting()) {
            Object simulateMaxTransferRetryLogic = NeoTestContext.getTestVariable(TRANSFER_MAX_RETRY_LOGIC_KEY);
            if (simulateMaxTransferRetryLogic != null && simulateMaxTransferRetryLogic.equals(Boolean.TRUE)) {
                return 1;
            }
            Object simulateTransferRetryLogic = NeoTestContext.getTestVariable(TRANSFER_RETRY_LOGIC_KEY);
            if (simulateTransferRetryLogic != null && simulateTransferRetryLogic.equals(Boolean.TRUE)) {
                if (transferRetryCount > 0) {
                    transferRetryCount--;
                    return transferRetryCount;
                }
            }
        }
        return -1;
    }

    public static boolean multiThreadSetup() throws NonRetryableActivityException {
        if (NeoTestContext.isIntegrationTesting()) {
            Object simulateMultiThreadSetup = NeoTestContext.getTestVariable(TRANSFER_MULTI_THREAD_SETUP_KEY);
            if (simulateMultiThreadSetup != null && simulateMultiThreadSetup.equals(Boolean.TRUE)) {
                return true;
            }
        }
        return false;
    }

    public static boolean singleThreadSetup() throws NonRetryableActivityException {
        if (NeoTestContext.isIntegrationTesting()) {
            Object simulateSingleThreadSetup = NeoTestContext.getTestVariable(TRANSFER_SINGLE_THREAD_SETUP_KEY);
            if (simulateSingleThreadSetup != null && simulateSingleThreadSetup.equals(Boolean.TRUE)) {
                return true;
            }
        }
        return false;
    }

    public static List<Long> noGlobalBookId(List<Long> globalBookId) throws NonRetryableActivityException {
        if (NeoTestContext.isIntegrationTesting()) {
            Object simulateNoGlobalBookId = NeoTestContext.getTestVariable(TRANSFER_NO_GLOBAL_BOOK_ID_KEY);
            if (simulateNoGlobalBookId != null && simulateNoGlobalBookId.equals(Boolean.TRUE)) {
                globalBookId.clear();
                return globalBookId;
            }
        }
        return globalBookId;
    }

    public static List<Long> multipleGlobalBookId(List<Long> globalBookId) throws NonRetryableActivityException {
        if (NeoTestContext.isIntegrationTesting()) {
            Object simulateMultipleGlobalBookId = NeoTestContext.getTestVariable(TRANSFER_MULTIPLE_GLOBAL_BOOK_ID_KEY);
            if (simulateMultipleGlobalBookId != null && simulateMultipleGlobalBookId.equals(Boolean.TRUE)) {
                globalBookId.add(100L);
                globalBookId.add(200L);
                return globalBookId;
            }
        }
        return globalBookId;
    }

    public static Long invalidCrtdPeriodId(Long crtdPeriodId) throws NonRetryableActivityException {
        if (NeoTestContext.isIntegrationTesting()) {
            Object simulateInvalidCrtdPeriodId = NeoTestContext.getTestVariable(TRANSFER_INVALID_CRTD_PERIOD_ID_KEY);
            if (simulateInvalidCrtdPeriodId != null && simulateInvalidCrtdPeriodId.equals(Boolean.TRUE)) {
                return null;
            }
        }
        return crtdPeriodId;
    }

    public static int batchAlreadyTransferred(int count) throws NonRetryableActivityException {
        if (NeoTestContext.isIntegrationTesting()) {
            Object simulateBatchAlreadyTransferred = NeoTestContext.getTestVariable(TRANSFER_BATCH_ALREADY_TRANSFER_KEY);
            if (simulateBatchAlreadyTransferred != null && simulateBatchAlreadyTransferred.equals(Boolean.TRUE)) {
                return 1;
            }
        }
        return count;
    }

    public static boolean criteriaFromArrangementAndManualJournal() {
        if (NeoTestContext.isIntegrationTesting()) {
            Object simulateArrangementAndManualJournal = NeoTestContext.getTestVariable(CRITERIA_FROM_ARRANGEMENT_AND_MANUAL_JOURNAL_KEY);
            if (simulateArrangementAndManualJournal != null && simulateArrangementAndManualJournal.equals(Boolean.TRUE)) {
                return true;
            }
        }
        return false;
    }

}
