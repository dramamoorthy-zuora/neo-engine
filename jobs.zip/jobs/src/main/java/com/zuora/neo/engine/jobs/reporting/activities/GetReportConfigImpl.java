package com.zuora.neo.engine.jobs.reporting.activities;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.exception.NonRetryableActivityException;

import io.temporal.workflow.Workflow;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

/**
 * @author achaudhary
 *         <p>
 *         Implementation of {@link GetReportConfig}
 */
@ActivityImplementation
@Component
public class GetReportConfigImpl implements GetReportConfig {

    private static final org.slf4j.Logger logger = Workflow.getLogger(GetReportConfig.class);

    @Override
    public String getRecords() {
        // this should return config json object from data basee
        logger.info("get records started at " + (new Date()));
        Jdbi jdbi = DbContext.getConnection();
        WorkflowContext context = WorkflowContextManager.getWorkflowContext();
        WorkflowRequest request = context.getRequest();
        String clientID = String.valueOf(request.getClientId());
        String parameterText = request.getParameterText();
        logger.info("Client id from the request ", clientID);

        try (Handle handle = jdbi.open()) {
            // todo make it dynamic based on parameter text and client id
            List<ReportConfig> values = handle
                    .createQuery("select config,query,(select value from rpro_profile_value_g where prof_id = 726) QS_URL "
                            + "from rpro_rep_schd_g where id = " + parameterText + " and client_id = " + clientID + " ")
                    .map((result, ctx) -> new ReportConfig(result.getString("query"),
                            new JSONObject(result.getString("config")),result.getString("qs_url")))
                    .list();
            ReportConfig finalConfig = values.get(0);
            System.out.println(finalConfig.getQuery());
            System.out.println(finalConfig.getConfig().toString());
            System.out.println(finalConfig.getQsurl());
            JSONObject returnObject = new JSONObject(finalConfig.getConfig().toString());
            returnObject.put("query", finalConfig.getQuery());
            returnObject.put("qsurl",finalConfig.getQsurl() == null ? "null" : finalConfig.getQsurl());
            handle.close();

            return returnObject.toString();
        } catch (RuntimeException e) {
            logger.error("Non Retryable exception occurred in processing Data Archival." + e);
            throw new NonRetryableActivityException(e);
        }
    }

}
