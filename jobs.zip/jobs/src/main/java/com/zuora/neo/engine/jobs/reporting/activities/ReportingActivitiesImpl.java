package com.zuora.neo.engine.jobs.reporting.activities;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.amazonaws.services.s3.transfer.Upload;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@ActivityImplementation
@Component
public class ReportingActivitiesImpl implements ReportingActivities {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(ReportingActivities.class);
    FetchDataFromDb db = new FetchDataFromDb();
    AmazonS3 s3 = db.s3();
    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;
    String path = "nova-efs/reporting/";
    String pathNova = "nova-efs/";
    String envCheck = System.getenv("LOCAL_DEV");
    String envValue;
    String bucketName;
    String keyFinalPrefix;
    // List<InputStream> readStreams;
    // List<byte[]> outputStreamList;

    @Override
    public String buildReportHere(Map<Integer, String> mapStore, InputStream ty, JSONObject config) {
        LOGGER.info("in build report " + config);
        JSONObject config2 = new JSONObject(config);
        WorkflowContext context = WorkflowContextManager.getWorkflowContext();
        WorkflowRequest request = context.getRequest();
        String requestId = String.valueOf(request.getRequestId());
        String tenantId = String.valueOf(request.getTenantId());
        String parameterText = request.getParameterText();
        double[] totals = new double[1000];
        BuildReportResult rowNcol = new BuildReportResult(0, 0);
        try {
            File f = new File(pathNova);
            if (f.exists() && f.isDirectory()) {
                LOGGER.info("efs nova does exists");
                File folderReport = new File(path);
                if (folderReport.exists() && folderReport.isDirectory()) {
                    LOGGER.info("Reporting Exists");
                } else {
                    LOGGER.info("creating reporting folder");
                    Boolean statusFr = folderReport.mkdir();
                    LOGGER.info("folder created for reporting" + statusFr);
                }
            } else {
                LOGGER.info("efs nova not exists");
                Boolean status = f.mkdir();
                LOGGER.info("folder created status for efs nova" + status);
                File folderReport = new File(path);
                Boolean statusFr = folderReport.mkdir();
                LOGGER.info("Both folders created" + statusFr);
            }
            BufferedWriter fr = new BufferedWriter(new OutputStreamWriter(
                    Files.newOutputStream(Paths.get(path + requestId + tenantId + parameterText + "randomFile")),
                    StandardCharsets.UTF_8));

            LOGGER.info(config2.toString(), config + "Here are the configs that we are getting ");
            OutputStream finalFile = loopingOverInStream(mapStore, fr, ty, config, totals, rowNcol);
            Integer noOfCols = rowNcol.getCols();
            Integer noOfRows = rowNcol.getRows();
            String totalsStr = "";
            LOGGER.info(noOfCols + "no of cols s " + noOfRows + "no of Rows");
            if (config.getString("Enable Totals").equals("Y")) {
                for (int col1 = 1; col1 < noOfCols + 1; col1++) {
                    if (col1 == 1) {
                        totalsStr += " Totals,";
                    } else {
                        String colCheck = mapStore.get(col1);
                        if (Objects.equals(colCheck, "Y")) {
                            totalsStr = totalsStr.concat(String.format("%.9f", totals[col1]));
                        }
                        if (col1 != noOfCols) {
                            totalsStr = totalsStr.concat(",");
                        }
                    }
                }
                finalFile.write(totalsStr.getBytes("UTF-8"));
            }
            if (config.getString("Show Filters").equals("Y")) {
                String footer = "";
                // todo convert time in proper format required
                TimeZone.setDefault(TimeZone.getTimeZone("EST"));
                Date date = new Date();
                SimpleDateFormat formatTime = new SimpleDateFormat("dd-MMM-yyyy HH:mm a", Locale.ENGLISH);
                String time = formatTime.format(date);
                time = time.toUpperCase(Locale.ENGLISH);
                footer = "\n" + "Report Run End Date," + time + "\n";
                LOGGER.info(footer);
                finalFile.write(footer.getBytes("UTF-8"));
            }
            finalFile.close();

            // readStreams.add(readstream23);
            // System.out.println(era1);
            // final stream here
            return noOfRows.toString();
        } catch (UnsupportedEncodingException e) {

            LOGGER.info("UNsupported exception " + e);
            throw new NonRetryableActivityException("Error in build Report ", e);
        } catch (IOException e) {
            LOGGER.info("IO Exception Occurred  " + e);
            throw new NonRetryableActivityException("IO Error in build Report ", e);
        }
    }

    @Override
    public OutputStream loopingOverInStream(Map<Integer, String> mapStore, BufferedWriter fr,
            InputStream fileUrlStream, JSONObject config, double[] totals, BuildReportResult asd) {

        InputStreamReader isr = null;
        try {
            isr = new InputStreamReader(fileUrlStream, "UTF-8");
            BufferedReader br = new BufferedReader(isr);
            // Getting Config for config Object
            int i;
            int j = 0;
            // todo get this value from select
            // String read = prepareingConfig(config, 450);
            String read = "";
            // readStreams = new ArrayList<>();
            // outputStreamList = new ArrayList<>();
            // InputStream readstream;
            int col = 1;
            String currVal = "";
            int check = 0;
            int commaInsideCol = 0;
            int noOfCols = 0;
            int noOfRows = 0;

            while ((i = br.read()) != -1) {
                // System.out.print((char)i);
                read = read + (char) i;
                char e = (char) i;
                // todo make this 10000000
                if (e == '"') {
                    commaInsideCol = 1 - commaInsideCol;
                }

                if (read.length() == 1000 && check == 0) {
                    // readstream = new ByteArrayInputStream(read.getBytes("UTF-8"));
                    // readStreams.add(readstream);
                    // outputStreamList.add(read.getBytes("UTF-8"));
                    fr.write(read);
                    read = "";
                    // System.out.println(partNumber+" part this is done for
                    // upload"+uploadResult.toString());
                }
                if ((e == ',' || e == '\n') && j != 0 && commaInsideCol == 0) {
                    currVal = currVal.trim();
                    if (currVal.isEmpty()) {
                        currVal = "0";
                    }
                    if (config.getString("Enable Totals").equals("Y")) {
                        String colCheck = mapStore.get(col);
                        if (Objects.equals(colCheck, "Y")) {

                            // System.out.println(colCheck + mapStore.toString() + col + currVal);
                            double er = Double.parseDouble(currVal);

                            totals[col] += er;
                        }
                    }
                    if (e == ',') {
                        col += 1;
                    }
                    currVal = "";

                }
                if (!(e == ',' || e == '\n') && j != 0) {
                    currVal = currVal + (char) i;
                }
                if (e == '\n') {
                    j = j + 1;
                    noOfCols = col;
                    col = 1;
                    currVal = "";
                    // if (j == 14000) {
                    // break;
                    // }

                }
            }
            noOfRows = j - 1;
            br.close();
            fr.close();
            asd.updateRowsAndColumns(noOfRows, noOfCols);
            String configString = "";
            if (config.getString("Show Filters").equals("Y")) {
                configString = prepareingConfig(config, noOfRows);
            }

            return organizingFinalReportFile(configString, read, config);

        } catch (UnsupportedEncodingException e) {
            LOGGER.info("UNsupported exception " + e);
            throw new NonRetryableActivityException(e);
        } catch (IOException e) {

            LOGGER.info("IO exception " + e);
            throw new NonRetryableActivityException(e);
        } catch (NumberFormatException e) {
            LOGGER.info("Config is Not is Sync with query file");
            cleaningUpEfsStorage();
            throw new NonRetryableActivityException(e);
        }
    }

    public void cleaningUpEfsStorage() {
        WorkflowContext context = WorkflowContextManager.getWorkflowContext();
        WorkflowRequest request = context.getRequest();
        String requestId = String.valueOf(request.getRequestId());
        String tenantId = String.valueOf(request.getTenantId());
        String parameterText = request.getParameterText();
        File newFile = new File(path + requestId + tenantId + parameterText + "randomFile");
        if (newFile.delete()) {
            LOGGER.info("newfile deleted");
        } else {
            LOGGER.info("new file not deleted");
        }
    }

    public OutputStream organizingFinalReportFile(String configString, String read, JSONObject config) {
        try {
            WorkflowContext context = WorkflowContextManager.getWorkflowContext();
            WorkflowRequest request = context.getRequest();
            String requestId = String.valueOf(request.getRequestId());
            String tenantId = String.valueOf(request.getTenantId());
            String parameterText = request.getParameterText();
            // out stream for the final file which will be uploaded
            OutputStream finalFile = Files
                    .newOutputStream(Paths.get(path + requestId + tenantId + parameterText + ".csv"));
            // todo add config condition
            if (config.getString("Show Filters").equals("Y")) {
                finalFile.write(configString.getBytes("UTF-8"), 0, configString.length());
            }
            // reading the processed data ...
            InputStream is = Files
                    .newInputStream(Paths.get(path + requestId + tenantId + parameterText + "randomFile"));
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                // writing the processed data to final file
                finalFile.write(buffer, 0, length);
            }
            is.close();
            // deleting the processed data file
            File newFile = new File(path + requestId + tenantId + parameterText + "randomFile");
            if (newFile.delete()) {
                LOGGER.info("newfile deleted");
            } else {
                LOGGER.info("new file not deleted");
            }
            // adding the remaining string to final file not present in the processed file
            finalFile.write(read.getBytes("UTF-8"), 0, read.length());
            return finalFile;

        } catch (IOException e) {
            LOGGER.info("error in organizing file" + e);
            throw new NonRetryableActivityException(e);
        }

    }

    @Override
    public Map<Integer, String> buildingMapStore(JSONObject config) {
        Map<Integer, String> mapStore = new HashMap<>();
        LOGGER.info("In building map store" + config);
        JSONArray jsonArray = config.getJSONArray("Totals Required Fields");
        for (int i = 0; i < jsonArray.length(); i++) {

            JSONObject explrObject = jsonArray.getJSONObject(i);

            int pos = explrObject.getInt("Column Position");
            // String res = explrObject.getString("Totals Required");
            String res = "Y";
            mapStore.put(pos, res);
        }

        return mapStore;

    }

    @Override
    public String getTenantIdAndRequestId() {
        WorkflowContext context = WorkflowContextManager.getWorkflowContext();
        WorkflowRequest request = context.getRequest();

        String requestId = String.valueOf(request.getRequestId());
        String tenantId = String.valueOf(request.getTenantId());
        String parameterText = request.getParameterText();
        LOGGER.info(requestId + "Request For this Nova Job Tenant with" + "Tenant Id" + tenantId + " Parameter Text "
                + parameterText);

        envCheck = System.getenv("LOCAL_DEV");
        String currentBucketUsed = System.getenv("FILE_SYNC_S3_BUCKET");
        currentBucketUsed = currentBucketUsed == null ? "filesync-devops.revpro.cloud" : currentBucketUsed;
        LOGGER.info("s3 bucket to be used in this request is " + currentBucketUsed);
        LOGGER.info("current bucket used in the flow" + currentBucketUsed);
        envValue = envCheck == null ? "0" : envCheck;
        bucketName = envValue.equals("1") ? "snowflake-poc-devops" : currentBucketUsed;
        keyFinalPrefix = envValue.equals("1") ? "report-builder/FinalFileBuiltOnLocal" : "";

        return "Success";

    }

    @Override
    public String finalMultiparUploadStep(InputStream k) {
        // low level multipart api -- We decided not to use this...
        // partNumber++;
        // System.out.println(partNumber+" part this is started for upload");
        // UploadPartRequest up= null;
        // try {
        // up = new UploadPartRequest()
        // .withBucketName(bucketName)
        // .withKey(multipartKey)
        // .withUploadId(initResponse.getUploadId())
        // .withPartNumber(partNumber)
        // .withInputStream(k)
        // .withPartSize(k.available());
        // UploadPartResult uploadResult = s3.uploadPart(up);
        // partETags.add(uploadResult.getPartETag());
        // System.out.println(partNumber + " part this is done for upload");
        // System.out.println(partNumber + " final upload started ");
        // CompleteMultipartUploadRequest compRequest = new
        // CompleteMultipartUploadRequest(bucketName, multipartKey,
        // initResponse.getUploadId(), partETags);
        // s3.completeMultipartUpload(compRequest);

        // System.out.println(partNumber + " final upload done");
        // }
        // catch (IOException e) {
        // throw new RuntimeException(e);
        // }
        return "sf";
    }

    @Override
    public String uploadZipStream(TransferManager tm, String fileName, JSONObject config, String keyCreation) {
        WorkflowContext context = WorkflowContextManager.getWorkflowContext();
        WorkflowRequest request = context.getRequest();
        String tenantId = String.valueOf(request.getTenantId());
        String requestId = String.valueOf(request.getRequestId());
        String parameterText = request.getParameterText();
        InputStream finalReportInCsv = null;
        ObjectMetadata objectMetadata = new ObjectMetadata();
        try {
            finalReportInCsv = Files.newInputStream(Paths.get(fileName));

            // File finalReportFile = new File(requestId+tenantId+parameterText+".csv");
            String compression = "ZIP";
            LOGGER.info("converting to zip required, " + compression);

            ZipOutputStream zipOutputStream;
            ByteArrayOutputStream finalZipfile = new ByteArrayOutputStream();
            zipOutputStream = new ZipOutputStream(finalZipfile);
            // exact report name will be present here
            ZipEntry ze = new ZipEntry(config.getString("File Name"));
            zipOutputStream.putNextEntry(ze);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = finalReportInCsv.read(buffer)) > 0) {
                zipOutputStream.write(buffer, 0, length);
            }
            // zipOutputStream.write(finalSOut.toByteArray(), 0,
            // finalSOut.toByteArray().length);
            zipOutputStream.closeEntry();
            zipOutputStream.close();

            InputStream rew = new ByteArrayInputStream(finalZipfile.toByteArray());
            LOGGER.info("Upload started before upload command");

            // TransferManager processes all transfers asynchronously,
            // so this call returns immediately.

            LOGGER.info(keyCreation + " " + requestId);
            Upload upload = tm.upload(bucketName, keyCreation, rew, objectMetadata);
            LOGGER.info("Object upload started");
            // Optionally, wait for the upload to finish before continuing.
            upload.waitForCompletion();
            rew.close();
            LOGGER.info("Object upload finished");
            File finalReportFile = new File(path + requestId + tenantId + parameterText + ".csv");
            if (finalReportFile.delete()) {
                LOGGER.info("file deleted");
            } else {
                LOGGER.info("file not deleted");
            }
            finalReportInCsv.close();
            return keyCreation;
        } catch (IOException | InterruptedException e) {
            LOGGER.info("error in upload zip stream" + e);
            throw new NonRetryableActivityException(e);
        }
    }

    @Override
    public String uploadingToS3UsingMultipart(JSONObject config, String url) {
        try {
            WorkflowContext context = WorkflowContextManager.getWorkflowContext();
            WorkflowRequest request = context.getRequest();
            String tenantId = String.valueOf(request.getTenantId());
            String requestId = String.valueOf(request.getRequestId());
            String parameterText = request.getParameterText();
            TransferManager tm = TransferManagerBuilder.standard()
                    .withS3Client(s3)
                    .build();
            ObjectMetadata objectMetadata = new ObjectMetadata();
            String keyCreation = keyFinalPrefix + tenantId + "/reports/" + config.getString("File Name");
            String fileName = path + requestId + tenantId + parameterText + ".csv";

            if (config.getString("Internal Layout").equals("N") && config.getString("ZIP Compression").equals("Y")) {
                // ByteArrayOutputStream finalSOut = new ByteArrayOutputStream();

                // for (byte[] arr : outputStreamList) {
                // // byte [] arr=outputStreamList.get(i);
                // finalSOut.write(arr);
                // }
                keyCreation = keyCreation.substring(0, keyCreation.length() - 4) + ".zip";
                return uploadZipStream(tm, fileName, config, keyCreation);

            } else if (config.getString("Internal Layout").equals("N")
                    && config.getString("ZIP Compression").equals("N")) {
                // InputStream rewWithout = new ByteArrayInputStream(finalSOut.toByteArray());
                InputStream finalReportInCsv = Files.newInputStream(Paths.get(fileName));

                Upload upload = tm.upload(bucketName,
                        keyCreation,
                        finalReportInCsv, objectMetadata);
                LOGGER.info("Object upload started");
                upload.waitForCompletion();
                LOGGER.info("Object upload complete");
                File finalReportFile = new File(requestId + tenantId + parameterText + ".csv");
                if (finalReportFile.delete()) {
                    LOGGER.info("file deleted");
                } else {
                    LOGGER.info("file not deleted");
                }
                finalReportInCsv.close();
                return keyCreation;
            } else {
                InputStream streamFromUrl = new URL(url).openStream();
                Upload upload = tm.upload(bucketName,
                        keyCreation, streamFromUrl,
                        objectMetadata);
                LOGGER.info("Object upload started");
                upload.waitForCompletion();
                streamFromUrl.close();
                LOGGER.info("Object upload complete");
                return keyCreation;
            }

        } catch (IOException | InterruptedException e) {
            LOGGER.info("error in Reporting activity upload to s3" + e);
            throw new NonRetryableActivityException(e);
        }

    }

    @Override
    public void uploadingToS3() {
        // this is old method not used as of now
        // InputStream story = new
        // SequenceInputStream(Collections.enumeration(readStreams));
        //
        // ObjectMetadata objectMetadata = new ObjectMetadata();
        // // String bukName="filesync-devops.revpro.cloud";
        // System.out.println("here we are trying to access the file sync");
        // PutObjectRequest poR = new PutObjectRequest(bucketName,
        // "report-builder/Report_File221_with_fromStaging_fromDEV23" + "tenantid" +
        // ".csv",
        // story, objectMetadata);
        // poR.getRequestClientOptions().setReadLimit(900000000);
        // System.out.println("here we are trying to access the file sync here it is
        // done");
        // s3.putObject(poR);
    }

    @Override
    public String getEtag(String keyFinal) {
        // Get the metadata for the object
        ObjectMetadata objectMetadata = s3.getObjectMetadata(bucketName, keyFinal);
        // Get the ETag of the object
        keyFinalPrefix = envValue.equals("1") ? "report-builder/FinalFileBuiltOnLocal" : "";
        String etag = objectMetadata.getETag();
        LOGGER.info("etag for the file..." + etag);
        return etag;
    }

    @Override
    public String prepareingConfig(JSONObject config2, int j) {
        JSONArray rfilters = config2.getJSONArray("Report Filters");
        String config = "Report Parameters \n"
                + "Report Name," + config2.getString("Report Name") + "\n"
                + "Layout Name," + config2.getString("Layout Name") + "\n"
                + "Report Submitted By," + config2.getString("Report Submitted By") + "\n"
                + "Report Run Start Date," + config2.getString("Report Run Start Date") + "\n"
                + "Report Run Submission ID," + config2.getInt("Report Submission ID") + "\n"
                + "Number of Rows," + j + "\n";

        if (rfilters.length() > 0) {
            config += "Report Filters," + "\n";

            for (int i3 = 0; i3 < rfilters.length(); i3++) {
                JSONObject explrObject = rfilters.getJSONObject(i3);

                config = config.concat(explrObject.getString("Name") + "," + explrObject.get("Operator") + ","
                        + (explrObject.has("Value") ? explrObject.get("Value") : "") + "\n");

            }

        }
        config = config.concat("\n");
        // try {

        // InputStream configStream = new
        // ByteArrayInputStream(config.getBytes("UTF-8"));
        // System.out.println(configStream.available());
        return config;
        // } catch (UnsupportedEncodingException e) {
        // LOGGER.info("error in Reporting activitiy" + e);
        // throw new NonRetryableActivityException(e);
        // }

    }

    @Override
    public InputStream streamingToLocalFromS3(String url) {
        LOGGER.info("Opening stream From URL which we get from Query Service ");
        LOGGER.info("Inside activity reporting- Download To local from s3");

        // String
        // url="https://owl-auw2-stg01-query-result.s3.us-west-2.amazonaws.com/2120d74c-977e-4e16-aa05-c739b0d3e75c_2430307224976219.csv?X-Amz-Security-Token=IQoJb3JpZ2luX2VjEL3%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLXdlc3QtMiJIMEYCIQDBL9K%2BBqmhPjtXMt17qjmbHQy6rb5qSSxZnjxjgl3o3QIhAOs8lfYF42ocLbb0eu1kn%2B3pCujEEZ37U5bDc%2B4ZUw3bKvwDCOb%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEQABoMMTIyOTcyOTIxNzE3Igym2S9Tdd3gzCTeJ8wq0AN1iqqpOftvlxOp6EN%2FG7oUQFkNcSEqt7DXgzES0aydmBcyXn0LFbSEDKai1CjQPnidrRbHNWK1pA7oVHU%2BB%2Bz3GE4eeMQHpERpJ%2Be6ef7hoNkuBnxrnjnCxyyLqug7F1o9qD%2Fk%2B2LUZ28oOOxhvmnIyufawmQ3NHAUeAh%2Fnrl95sBDRdaHRmAZUD76b2uOExe7aLgtZG%2FoX2SZUBTGItZwJDc%2BHKjOyruIqLyMAOrDbtZruF1ESwFTXp7H4ni2lAQ4hgyS%2FOOnGZeNJaAQmgoXk8tB6Op1SPgIqcxYbzi8SCd4U%2BjE8yEPk%2F0pkSgCQSV0HQx7DStO8GoDEWpUbsEiMEyT8Yn4Xua6RnPZoZM0uMHWmgSWSamGtm12xn9UUTo1Txog%2Ft%2B3aj0UZgDdDxi42EbDiu5eMPuyIWEfPf%2FjDRDx8OzG0BleHMkKjYUz7J6N%2BhbtkZixj22U3BkK6gckxNpEm%2BKcNcGNMTOBUcdv67lIyC0d0KG4FhcLWXDDYHvLhNp%2FDIdumcpB4Z3kTE%2F9BnrUgPKQevMgxV4JSC1quRftLThF8YjHo60ZLEW6NZy7wJACE%2FOpOPjB1Iea04E989BpDmkK%2Bk6r5XyudDbhWjC%2BxOqcBjqkASZeKmdSyc4QWx4bXt0wt4ATMuFUoPWyQ45%2BKDPSdxZh6Cw96i%2BBE5oedLt8gLuR9gzLfN7X%2BE86XYXACaDu0EI50BwAXfwjZKAGw4rqKyHyQu7QULaY%2ByXlvL5Jvou5bT5IPi5UtmUfdyv1QZVhVd4VZrXGzFJjfEZGmWJUr99Uj7Hyt0v%2Bl6n1KXYvvPW7V6vvVITHns5eHblg1aNw6rjvWyTb&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20221215T065517Z&X-Amz-SignedHeaders=host&X-Amz-Expires=14400&X-Amz-Credential=ASIARZIOB352VUVOOIGE%2F20221215%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Signature=0fc17b4f58f91ec684cff36d0fd808e5eb06b0738bfc86f6bce16b467c0a5205";
        // fileUrl="https://snowflake-poc-devops.s3.us-west-2.amazonaws.com/report-builder/10581_20221216_012457.csv?response-content-disposition=inline&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEBgaCXVzLXdlc3QtMiJIMEYCIQDSwO9Tj3Ju8U%2BeT4w9ulkdo95ttrNXzHx9E%2FXYz%2F3BZQIhAJTrL8UkcNExrLW43Vgyp3MnOBCvddEeR7QIH54GLY9gKp4DCHEQAxoMNDE3Mzg2MjAyOTkzIgwcGJJjOj10Iqk6wzQq%2BwJYLegM7hMoTC0ZT61IGRoVVGwrPWVBvTBgY3iRQgd%2Byz%2BEIay%2BifhOeLO3b4tyWTrTgaWtCcLDBBO9R0dCN9FK4IysolWZPl3QKqrymU4U86ltD74epn1lAiuBFuxFLAzkYYU6FAcJHtLgEkHtCGgT3%2FwXIQ7DcB7128aazZFXN37carugizZaBFrMoiy6gWwdhW0RvG8ZRim1JBV%2BaLy0j%2BlPdaaT5k6ase8F93SvzeL5nh7eoy8KA0E%2BdD%2BOdi8jBSvag%2FIvKbny8G6JkqPCd%2BKCVb%2Buh1d%2FVHEsNXexbh0iZaGn5CcuVvMcnPArtUBKJJtJrAnMcoOXd202%2FdeV%2FRNdurlqSy9QZRIHBFU1N4aZdbbD5M05EW2xpfQ9FGlxtr2N1LG%2FBmpLBdVxLJdwMKExmh3U0YlJkgENC55ptd0wMjlFDANO8SiXNP7tLBt8%2FYh9NnwIS4AAlJ3CY%2B%2F%2BH6KF855HSSZU42mellb3L%2Fx%2FlzNl3oAi9gCnMMuX750GOoMCuI4bSkuYeHW%2BvEsWAskQneNX3elKHzfgirffGUhw5Gk%2BNhXs0MgSOEFVXTuybOlhT1y5fXX2TikNhJaDxi6xiClbT%2B8rhYyJm4Lz3bmMhVmtFJXnW2QxmHRSAJTiSZ2oiEMtf7J%2FhIm1Dmin%2FGXLqBVJeQ0c6VIzRIIIMWJTapilVkR7b5bsshDK9T13xpLNPFRk7eEb3vdq1VInymR5wvzDrZE0s851hKNWG7riTKKp%2FFv5MwAbJPU3pi8r8GjPaWz2fpxDs8xn5AE2MA1HEbRDZoWVvh9NYqJHtiX9CTvsjBymHjk5i7cfwOWqXeIlnDz2DLMbME8X53dXtQrSbHoMPA%3D%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20230109T112235Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=ASIAWCLRIA5Y7IKV5ZEG%2F20230109%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Signature=7d7cc3f75de4c237e76692c2b4a7cca966a07f39b9e0b905cc0be15fbe4abf31";
        // String url = new String(fileUrl);
        InputStream input = null;
        LOGGER.info("this url " + url);

        // for local i am reading from s3 only
        // GetObjectRequest getObjectRequest;
        // getObjectRequest = new GetObjectRequest(bucketName, key);
        // S3Object obj = s3.getObject(getObjectRequest);
        // when in prod i will use streamFromUrl obj..
        // InputStream inSt=streamFromUrl;
        // streamFromUrl = obj.getObjectContent();
        try {

            input = new URL(url).openStream();
            // InputStreamReader isr = new InputStreamReader(input, "UTF-8");
            // BufferedReader br = new BufferedReader(isr);
            // int i;
            // while ((i = br.read()) != -1) {
            // System.out.print((char) i);
            // }
            // System.out.println("end of the file");
            // LOGGER.info("Exiting activity reporting- Download To local from s3");
            // br.close();

            // return input;

        } catch (IOException e) {
            LOGGER.info(e + "error in opening file url");
            throw new NonRetryableActivityException(e);
        }
        return input;

    }

    @Override
    public String buildAndUploadReport(String configFromOracle, String objFromQueryService) {
        LOGGER.info("Inside Main Reporting Activity");
        try {
            JSONObject configFromOracleJson = new JSONObject(configFromOracle);
            getTenantIdAndRequestId();
            Map<Integer, String> mapStoreF = new HashMap<>();
            if (configFromOracleJson.getString("Enable Totals").equals("Y")) {
                mapStoreF = buildingMapStore(configFromOracleJson);
            }
            JSONObject urlObjectFromQueryService = new JSONObject(objFromQueryService);
            if (urlObjectFromQueryService.has("fileUrl")
                    && urlObjectFromQueryService.get("fileUrl").equals("null")) {
                JSONObject errorMessage = new JSONObject();
                errorMessage.put(urlObjectFromQueryService.has("postError") ? "postRequestError" : "getRequestError",
                        urlObjectFromQueryService.has("postError")
                                ? urlObjectFromQueryService.getJSONObject("postError")
                                : urlObjectFromQueryService.getJSONObject("getError"));
                LOGGER.info("File Url is null some error in QS check temporal logs");
                throw new NonRetryableActivityException("Query Service Error " + errorMessage.toString());
            }
            InputStream streamFromQueryUrl = streamingToLocalFromS3(urlObjectFromQueryService.getString("fileUrl"));
            String rows = "";
            if (configFromOracleJson.getString("Internal Layout").equals("N")) {
                rows = buildReportHere(mapStoreF, streamFromQueryUrl, configFromOracleJson);
            }
            String keyFinal = uploadingToS3UsingMultipart(configFromOracleJson, urlObjectFromQueryService.getString("fileUrl"));
            String er = getEtag(keyFinal);
            LOGGER.info(" Exiting main  activity reporting config is Etag is found just now update the status");
            JSONObject returnObject = new JSONObject();
            returnObject.put("etag", er);
            returnObject.put("rows", rows);
            returnObject.put("finalFileName", keyFinal);
            return returnObject.toString();
        } catch (Exception e) {
            LOGGER.info("Error in set Config and Reporting activities function " + e);
            throw new NonRetryableActivityException("error" + (e.getCause() != null ? e.getCause().getMessage() : e.getMessage())
                    + "buildAndUploadReport Error In Activity Please check Temporal Logs for more",e);
        }
    }
}
