package com.zuora.neo.engine.common.indicators;

public interface IndicatorEnum {

    int getPosition();

    int getSize();

    char getUnusedDefaultValue();

    char[] getDefaultValue();



}
