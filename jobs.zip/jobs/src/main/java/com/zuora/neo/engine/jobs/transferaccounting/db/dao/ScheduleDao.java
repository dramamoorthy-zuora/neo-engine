package com.zuora.neo.engine.jobs.transferaccounting.db.dao;

import com.zuora.neo.engine.jobs.transferaccounting.db.api.RcSchedMinRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.RcSchedMinRecordMapper;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.statement.UseRowMapper;

import java.util.List;

public interface ScheduleDao {

    @SqlUpdate("UPDATE rpro_rc_schd SET indicators = rpro_rc_schd_pkg.set_interfaced_flag ( indicators, 'Y')"
            + " ,post_date = SYSDATE,updt_dt = SYSDATE,updt_by = :user"
            + " ,updt_prd_id = rpro_utility_pkg.get_crtd_prd_id (:book_id, :sec_atr_val)"
            + " WHERE post_batch_id = :p_post_batch_id AND rc_id between :minRcId AND :maxRcId"
            + " AND rpro_rc_schd_pkg.get_interfaced_flag (indicators) = 'N'"
            + " AND rpro_rc_schd_pkg.get_initial_entry_flag (indicators) = 'N'")
    Integer updateRcPostDetails(@Bind("user") String user, @Bind("book_id") long bookId, @Bind("sec_atr_val") String orgId,
            @Bind("p_post_batch_id") long postBatchId, @Bind("minRcId") Long minRcId, @Bind("maxRcId") Long maxRcId);

    @SqlQuery("SELECT LINE_ID lineId, ROOT_LINE_ID rootLineId, amount, indicators, CR_SEGMENTS crSegments, "
            + " DR_SEGMENTS drSegments, F_EX_RATE foreignExRate, G_EX_RATE globalExRate, "
            + " POST_PRD_ID postPeriodId FROM rpro_rc_schd WHERE post_batch_id = :p_post_batch_id"
            + " AND rc_id between :minRcId AND :maxRcId"
            + " AND rpro_rc_schd_pkg.get_interfaced_flag (indicators) = 'Y' "
            + " AND rpro_rc_schd_pkg.get_initial_entry_flag (indicators) = 'N'")
    @UseRowMapper(RcSchedMinRecordMapper.class)
    List<RcSchedMinRecord> getRcSchdRecord(@Bind("p_post_batch_id") long postBatchId,
            @Bind("minRcId") Long minRcId, @Bind("maxRcId") Long maxRcId);

    @SqlUpdate("insert into rpro_ri_rc_schd_min_data_gt (LINE_ID, ROOT_LINE_ID, AMOUNT, INDICATORS, CR_SEGMENTS,DR_SEGMENTS, F_EX_RATE, G_EX_RATE, "
            + " POST_PRD_ID) SELECT LINE_ID lineId, ROOT_LINE_ID rootLineId, amount, indicators, CR_SEGMENTS crSegments,DR_SEGMENTS drSegments,"
            + " F_EX_RATE foreignExRate, G_EX_RATE globalExRate, POST_PRD_ID postPeriodId FROM rpro_rc_schd WHERE post_batch_id = :postBatchId AND rc_id "
            + " BETWEEN :minRcId AND :maxRcId AND rpro_rc_schd_pkg.get_interfaced_flag (indicators) = 'Y'"
            + " AND rpro_rc_schd_pkg.get_schd_type_flag (indicators) NOT IN ('M','T', :l_schd_flg)")
    Integer insertGlobalRcSchdGlData(@Bind("postBatchId") Long postBatchId, @Bind("minRcId") Long minRcId, @Bind("maxRcId") Long maxRcId,
            @Bind("l_schd_flg") String schdFlag);

    @SqlUpdate("insert into rpro_ri_rc_schd_min_data_gt (LINE_ID, ROOT_LINE_ID, AMOUNT, INDICATORS, CR_SEGMENTS,DR_SEGMENTS, F_EX_RATE, G_EX_RATE, "
            + " POST_PRD_ID) SELECT LINE_ID lineId, ROOT_LINE_ID rootLineId, amount, indicators, CR_SEGMENTS crSegments,DR_SEGMENTS drSegments,"
            + " F_EX_RATE foreignExRate,G_EX_RATE globalExRate, POST_PRD_ID postPeriodId FROM rpro_rc_schd WHERE post_batch_id = :postBatchId AND rc_id "
            + " BETWEEN :minRcId AND :maxRcId AND rpro_rc_schd_pkg.get_interfaced_flag (indicators) = 'Y'"
            + " AND rpro_rc_schd_pkg.get_schd_type_flag (indicators) IN ('M','T','D')")
    Integer insertGlobalRcSchdMjeData(@Bind("postBatchId") Long postBatchId, @Bind("minRcId") Long minRcId, @Bind("maxRcId") Long maxRcId);

    @SqlUpdate("UPDATE rpro_rc_schd schd SET indicators = rpro_rc_schd_pkg.set_interfaced_flag ( indicators, 'Y')"
            + " ,post_date = SYSDATE,updt_dt = SYSDATE,updt_by = :g_user"
            + " ,updt_prd_id = :createdPeriodId WHERE post_batch_id = :p_post_batch_id AND rc_id BETWEEN :minRcId AND :maxRcId"
            + " AND rpro_rc_schd_pkg.get_interfaced_flag (indicators) = 'N'"
            + " AND rpro_rc_schd_pkg.get_schd_type_flag (indicators) NOT IN ('M','T', :l_schd_flg)"
            + " AND (:l_post_schedules = 'N' OR :l_exist_gl_int_stg = 1 OR EXISTS ( SELECT 1"
            + " FROM rpro_gl_int_stage stg WHERE :l_summary_transfer = 'N' AND stg.schedule_id = schd.id"
            + " AND stg.object_type = :p_obj_type ))")
    Integer updateRcPostDetailsGl(@Bind("g_user") String user, @Bind("createdPeriodId") Long createdPeriodId,
            @Bind("book_id") long bookId, @Bind("sec_atr_val") String orgId,
            @Bind("p_post_batch_id") long postBatchId, @Bind("minRcId") Long minRcId, @Bind("maxRcId") Long maxRcId,
            @Bind("l_schd_flg") String schdFlag, @Bind("l_post_schedules") String postSchdFlag,
            @Bind("l_exist_gl_int_stg") Integer glIntStgExists, @Bind("l_summary_transfer") String summaryFlag,
            @Bind("p_obj_type") String objectType);

    @SqlUpdate("UPDATE rpro_rc_schd schd SET indicators = rpro_rc_schd_pkg.set_interfaced_flag ( indicators, 'Y')"
            + " ,post_date = SYSDATE,updt_dt = SYSDATE, updt_by = :g_user,updt_prd_id = :createdPeriodId"
            + " WHERE post_batch_id = :p_post_batch_id AND rc_id BETWEEN :minRcId AND :maxRcId"
            + " AND rpro_rc_schd_pkg.get_interfaced_flag (indicators) = 'N'"
            + " AND rpro_rc_schd_pkg.get_schd_type_flag (indicators) IN ('M','T','D')"
            + " AND (:l_post_manual_je = 'N' OR :l_exist_gl_int_stg = 1 OR EXISTS ( SELECT 1"
            + " FROM rpro_gl_int_stage stg WHERE :l_mje_summary_transfer = 'N' AND stg.schedule_id = schd.id"
            + " AND stg.object_type = :p_obj_type ))")
    Integer updateRcPostDetailsMje(@Bind("g_user") String user, @Bind("createdPeriodId") Long createdPeriodId,
            @Bind("book_id") long bookId, @Bind("sec_atr_val") String orgId,
            @Bind("p_post_batch_id") long postBatchId, @Bind("minRcId") Long minRcId, @Bind("maxRcId") Long maxRcId,
            @Bind("l_post_manual_je") String postMjeFlag, @Bind("l_exist_gl_int_stg") Integer glIntStgExists,
            @Bind("l_mje_summary_transfer") String mjeSummaryFlag, @Bind("p_obj_type") String objectType);

    @SqlUpdate("UPDATE rpro_rc_schd rrs SET rrs.post_batch_id = NULL,rrs.post_date = NULL,rrs.updt_by=:user,rrs.updt_dt= sysdate"
            + " WHERE rpro_rc_schd_pkg.get_interfaced_flag(rrs.indicators) = 'N' AND post_batch_id = :postBatchId"
            + " AND rrs.root_line_id IN (SELECT id FROM rpro_rc_line WHERE rc_id = :rc_id"
            + " AND book_id = :book_id) AND rrs.book_id = :book_id")
    void resetRcSchedule(@Bind("user") String user, @Bind("postBatchId") long postBatchId,
            @Bind("rc_id") Long rcId, @Bind("book_id") Long bookId);

    @SqlUpdate("UPDATE rpro_rc_schd set post_batch_id = NULL , dr_link_id = NULL, cr_link_id= NULL"
            + " WHERE post_batch_id = :post_batch_id AND rpro_rc_schd_pkg.get_interfaced_flag (indicators) = 'N'")
    Integer resetBatchSchdData(@Bind("post_batch_id") Long postBatchId);
}
