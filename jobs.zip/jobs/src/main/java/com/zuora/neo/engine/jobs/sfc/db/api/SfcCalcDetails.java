package com.zuora.neo.engine.jobs.sfc.db.api;

import java.math.BigDecimal;
import java.util.Date;

public class SfcCalcDetails {

    private long id;
    private long rcId;
    private long lineId;
    private BigDecimal receivableBegin;
    private BigDecimal receivableEnd;
    private BigDecimal npvReceivable;
    private BigDecimal interest;
    private long periodId;
    private long clientId;
    private long createdPeriodId;
    private String secAtrVal;
    private long bookId;
    private String createdBy;
    private Date createdDate;
    private String updatedBy;
    private Date updatedDate;
    private String indicators;
    private Date startDate;
    private Date endDate;


    public SfcCalcDetails(long clientId) {
        this.clientId = clientId;
    }

    public SfcCalcDetails(long id, long rcId, long lineId, BigDecimal receivableBegin, BigDecimal receivableEnd, BigDecimal npvReceivable,
            BigDecimal interest, long periodId, long clientId, long createdPeriodId, String secAtrVal, long bookId, String createdBy, Date createdDate,
            String updatedBy, Date updatedDate, String indicators, Date startDate, Date endDate) {
        this.id = id;
        this.rcId = rcId;
        this.lineId = lineId;
        this.receivableBegin = receivableBegin;
        this.receivableEnd = receivableEnd;
        this.npvReceivable = npvReceivable;
        this.interest = interest;
        this.periodId = periodId;
        this.clientId = clientId;
        this.createdPeriodId = createdPeriodId;
        this.secAtrVal = secAtrVal;
        this.bookId = bookId;
        this.createdBy = createdBy;
        this.createdDate = createdDate == null ? null : new Date(createdDate.getTime());
        this.updatedBy = updatedBy;
        this.updatedDate = updatedDate == null ? null : new Date(updatedDate.getTime());
        this.indicators = indicators;
        this.startDate = startDate == null ? null : new Date(startDate.getTime());
        this.endDate = endDate == null ? null : new Date(endDate.getTime());
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getRcId() {
        return rcId;
    }

    public void setRcId(long rcId) {
        this.rcId = rcId;
    }

    public long getLineId() {
        return lineId;
    }

    public void setLineId(long lineId) {
        this.lineId = lineId;
    }

    public BigDecimal getReceivableBegin() {
        return receivableBegin;
    }

    public void setReceivableBegin(BigDecimal receivableBegin) {
        this.receivableBegin = receivableBegin;
    }

    public BigDecimal getReceivableEnd() {
        return receivableEnd;
    }

    public void setReceivableEnd(BigDecimal receivableEnd) {
        this.receivableEnd = receivableEnd;
    }

    public BigDecimal getNpvReceivable() {
        return npvReceivable;
    }

    public void setNpvReceivable(BigDecimal npvReceivable) {
        this.npvReceivable = npvReceivable;
    }

    public BigDecimal getInterest() {
        return interest;
    }

    public void setInterest(BigDecimal interest) {
        this.interest = interest;
    }

    public long getPeriodId() {
        return periodId;
    }

    public void setPeriodId(long periodId) {
        this.periodId = periodId;
    }

    public long getClientId() {
        return clientId;
    }

    public void setClientId(long clientId) {
        this.clientId = clientId;
    }

    public long getCreatedPeriodId() {
        return createdPeriodId;
    }

    public void setCreatedPeriodId(long createdPeriodId) {
        this.createdPeriodId = createdPeriodId;
    }

    public String getSecAtrVal() {
        return secAtrVal;
    }

    public void setSecAtrVal(String secAtrVal) {
        this.secAtrVal = secAtrVal;
    }

    public long getBookId() {
        return bookId;
    }

    public void setBookId(long bookId) {
        this.bookId = bookId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate == null ? null : new Date(createdDate.getTime());
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate == null ? null : new Date(createdDate.getTime());
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return  updatedDate == null ? null : new Date(updatedDate.getTime());
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate =  updatedDate == null ? null : new Date(updatedDate.getTime());
    }

    public String getIndicators() {
        return indicators;
    }

    public void setIndicators(String indicators) {
        this.indicators = indicators;
    }

    public Date getStartDate() {
        return  startDate == null ? null : new Date(startDate.getTime());
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate == null ? null : new Date(startDate.getTime());
    }

    public Date getEndDate() {
        return endDate == null ? null : new Date(endDate.getTime());
    }

    public void setEndDate(Date endDate) {
        this.endDate =  endDate == null ? null : new Date(endDate.getTime());
    }

    @Override
    public String toString() {
        return "SfcCalcDetails{"
                + "id=" + id
                + ", rcId=" + rcId
                + ", lineId=" + lineId
                + ", receivableBegin=" + receivableBegin
                + ", receivableEnd=" + receivableEnd
                + ", npvReceivable=" + npvReceivable
                + ", interest=" + interest
                + ", periodId=" + periodId
                + ", clientId=" + clientId
                + ", createdPeriodId=" + createdPeriodId
                + ", secAtrVal='" + secAtrVal + '\''
                + ", bookId=" + bookId
                + ", createdBy='" + createdBy + '\''
                + ", createdDate=" + createdDate
                + ", updatedBy='" + updatedBy + '\''
                + ", updatedDate=" + updatedDate
                + ", indicators='" + indicators + '\''
                + ", startDate=" + startDate
                + ", endDate=" + endDate
                + '}';
    }
}
