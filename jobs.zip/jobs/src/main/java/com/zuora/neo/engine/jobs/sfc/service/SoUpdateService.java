package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.sfc.SfcResult;
import com.zuora.neo.engine.jobs.sfc.api.SfcSegmentsFlagsVersions;
import com.zuora.neo.engine.jobs.sfc.constants.SfcConstants;
import com.zuora.neo.engine.jobs.sfc.constants.SfcStatus;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.context.SfcPostProcessDetailsContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.SchdIndicator;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusIndicator;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;

import org.jdbi.v3.core.Handle;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class SoUpdateService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SoUpdateService.class);

    @Autowired
    private SfcServiceUtils sfcServiceUtils;

    @Autowired
    private RippedLineProcessingService rippedLineProcessingService;

    @Autowired
    private RcLinePaDataService rcLinePaDataService;

    @Autowired
    private SfcCalcDetailService sfcCalcDetailService;

    @Autowired
    private SfcTablesBatchInsertUpdateService sfcTablesBatchInsertUpdateService;

    @Autowired
    private RcScheduleService rcScheduleService;

    @Autowired
    RcHeadDataService rcHeadDataService;

    /*
       Service Method to process updated SO records

       Input :
       sfcStatusValuesList -> Lines from Sfc Status Table
       sfcDbCacheContext -> Has common details such as data from rpro_account, rpro_currency, rpro_financ_typ and rpro_calendar
       sfcResult -> contains warning count
       handle -> Jdbi Handle object to perform DB operations

     */
    public void processUpdatedSo(List<SfcStatusValues> sfcStatusValuesList, SfcDbCacheContext sfcDbCacheContext,
            SfcResult sfcResult, Handle handle) {

        CommonDao commonDao = handle.attach(CommonDao.class);
        SfcDao sfcDao = handle.attach(SfcDao.class);

        long openPeriodId = sfcDbCacheContext.getCurrentPeriodId();
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();

        SfcPostProcessDetailsContext sfcPostProcessDetailsContext = getSfcDetails(sfcStatusValuesList, handle);
        Map<String, List<RcLineDetails>> rcLineDetailsBatchMap = sfcPostProcessDetailsContext.getRcLineDetailsBatchMap();
        Map<String, List<SfcPaymentDetails>> sfcPaymentDetailsBatchMap = sfcPostProcessDetailsContext.getSfcPaymentDetailsBatchMap();
        List<RcScheduleRecord> rcScheduleRecordBatch = sfcPostProcessDetailsContext.getRcScheduleRecordBatch();
        List<RcLinePaData> rcLinePaDataRecordBatch = sfcPostProcessDetailsContext.getRcLinePaDataRecordBatch();
        List<SfcCalcDetails> sfcCalcDetailsHistoryBatch = new ArrayList<>();
        List<Long> rcIdList = new ArrayList<>();
        for (SfcStatusValues sfcStatusValue : sfcStatusValuesList) {
            if (sfcStatusValue != null && sfcStatusValue.getDocLineId() != null) {
                sfcStatusValue.setErrMsg(null);
                List<SfcPaymentDetails> sfcPaymentDetails = sfcPaymentDetailsBatchMap.get(sfcStatusValue.getDocLineId());
                List<RcLineDetails> rcLineDetails = rcLineDetailsBatchMap.get(sfcStatusValue.getDocLineId());
                long lineId = rcLineDetails.get(0).getId();
                long bookId = rcLineDetails.get(0).getBookId();
                LOGGER.info("Fetching Finance Type Values for SFC for doc line id.." + sfcStatusValue.getDocLineId());
                List<RcLinePaData> rcLinePaDataRecordBeforeProcessing = SfcBatchProcessingService.getRcLinePaRecordForFinanceId(sfcDao,
                        rcLineDetails.get(0).getId(), sfcDbCacheContext);
                List<FinanceTypeValues> financeTypeValueForRcLine = sfcServiceUtils.getFinanceTypeForRcLine(rcLinePaDataRecordBeforeProcessing,
                        sfcDbCacheContext, rcLineDetails);
                if (financeTypeValueForRcLine.isEmpty()) {
                    LOGGER.error("Finance Type Table is not available for doc line id " + sfcStatusValue.getDocLineId());
                    sfcServiceUtils.updateSfcStatusAndAddWarningCount(sfcResult, sfcStatusValue, SfcConstants.SFC_SETUP_NOT_AVAILABLE);
                    continue;
                }
                Boolean isSfcValid = sfcServiceUtils.validSfcLine(sfcStatusValue, sfcPaymentDetails, rcLineDetails, financeTypeValueForRcLine);
                SchdIndicator schdIndicator = new SchdIndicator();
                if (isSfcValid) {
                    long vcTypeId = Math.toIntExact(financeTypeValueForRcLine.get(0).getId());
                    List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
                    SfcSegmentsFlagsVersions sfcSegmentsFlagsVersions = sfcServiceUtils.getSegmentsFlagsVersions(financeTypeValueForRcLine,
                            financeTypeFlagDetailsList, rcLineDetails, vcTypeId, bookId, lineId, sfcDbCacheContext, commonDao, sfcDao);
                    List<RcLinePaData> rcLinePaDataRecord = SfcBatchProcessingService.getRcLinePaRecordForFinanceId(sfcDao,
                            rcLineDetails.get(0).getId(), sfcDbCacheContext);
                    SfcStatusIndicator sfcStatusIndicators = SfcStatusIndicator.valueOf(sfcStatusValue.getIndicators());
                    if (sfcStatusIndicators.getRecalcFlag() == 'N') {
                        rippedLineProcessingService.processRippedSfcLine(rcLinePaDataRecord, sfcStatusValue, rcLineDetails,
                                financeTypeFlagDetailsList, sfcPaymentDetails, openPeriodId, sfcSegmentsFlagsVersions, rcScheduleRecordBatch,
                                sfcCalcDetailsHistoryBatch, schdIndicator, handle);
                    }
                    sfcStatusValue.setStatus(SfcStatus.COMPLETED.getStatus());
                    if (sfcStatusIndicators.getRecalcFlag() == 'Y') {
                        //Move SFC Calc Details to history table
                        LOGGER.info("Move SFC Calc Details to history table for " + sfcStatusValue.getDocLineId());
                        List<SfcCalcDetails> sfcCalcDetailsList = getSfcCalcDetailsBatch(sfcDao, sfcStatusValue);
                        deleteSfcCalcDetailsForLine(handle, sfcStatusValue);
                        sfcCalcDetailsHistoryBatch.addAll(sfcCalcDetailsList);

                        sfcStatusValue.setStatus(SfcStatus.READY_FOR_SFC.getStatus());
                        sfcStatusIndicators.setRecalcFlag('N');
                    }
                    sfcStatusIndicators.setRealTimeSummReadyFlag('Y');
                    sfcStatusValue.setIndicators(sfcStatusIndicators.getIndicator());
                    rcLinePaDataRecordBatch.addAll(rcLinePaDataRecord);
                    rcIdList.add(rcLinePaDataRecord.get(0).getRcId());
                }
            }
        }
        rcLinePaDataService.updateAmountsToRcLinePaDataBatch(handle, rcLinePaDataRecordBatch);
        rcHeadDataService.updateAmountsToRcHeadDataBatch(handle, rcIdList, request.getUser());
        if (!sfcCalcDetailsHistoryBatch.isEmpty()) {
            sfcCalcDetailService.insertSfcCalcDetailsHistoryBatch(sfcCalcDetailsHistoryBatch, handle);
        }
        if (!rcScheduleRecordBatch.isEmpty()) {
            rcScheduleService.insertRcScheduleRecordsBatch(rcScheduleRecordBatch, handle);
        }
        sfcTablesBatchInsertUpdateService.batchUpdateSfcStatusTable(sfcStatusValuesList, handle);
    }


    public SfcPostProcessDetailsContext getSfcDetails(List<SfcStatusValues> sfcStatusValuesList, Handle handle) {
        SfcDao sfcDao = handle.attach(SfcDao.class);

        List<String> sfcDocLineIds = sfcStatusValuesList.stream().map(SfcStatusValues::getDocLineId).collect(Collectors.toList());
        LOGGER.info("Fetching RC Line Table details..");
        List<RcLineDetails> rcLineDetailsBatch = sfcDao.getRcLineDetailsByDocLineIdListWithAttributes(sfcDocLineIds);

        LOGGER.debug("Fetching Payment Table details..");
        List<SfcPaymentDetails> sfcPaymentDetailsBatch = sfcDao.getSfcPaymentDetailsByDocLineIdList(sfcDocLineIds);

        Map<String, List<RcLineDetails>> rcLineDetailsBatchMap = rcLineDetailsBatch.stream()
                .collect(Collectors.groupingBy(rcLineDetails -> rcLineDetails.getDocLineId()));
        Map<String, List<SfcPaymentDetails>> sfcPaymentDetailsBatchMap = sfcPaymentDetailsBatch.stream()
                .collect(Collectors.groupingBy(sfcPaymentDetails -> sfcPaymentDetails.getDocLineId()));

        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();
        List<SfcCalcDetails> sfcCalcDetailsBatch = new ArrayList<>();
        List<RcLinePaData> rcLinePaDataRecordBatch = new ArrayList<>();

        SfcPostProcessDetailsContext sfcPostProcessDetailsContext = new SfcPostProcessDetailsContext(rcScheduleRecordBatch, sfcCalcDetailsBatch,
                rcLinePaDataRecordBatch, rcLineDetailsBatchMap, sfcPaymentDetailsBatchMap);

        return sfcPostProcessDetailsContext;
    }

    /*
       Service Method to get records from rpro_sfc_calc_det table for a line id.

       Input :
       sfcStatusValue -> Line from Sfc Status Table
       sfcDao -> Dao Object to perform DB operations

       Output:
       returns the list of records from rpro_sfc_calc_det table
     */
    public List<SfcCalcDetails> getSfcCalcDetailsBatch(SfcDao sfcDao, SfcStatusValues sfcStatusValue) {

        List<SfcCalcDetails> sfcCalcDetailsBatch = sfcDao.getSfcCalcByDocLine(sfcStatusValue.getLineId());
        return sfcCalcDetailsBatch;
    }

    /*
       Service Method to delete records from rpro_sfc_calc_det table for a line id.

       Input :
       sfcStatusValue -> Line from Sfc Status Table
       sfcDao -> Dao Object to perform DB operations
     */
    public void deleteSfcCalcDetailsForLine(Handle handle, SfcStatusValues sfcStatusValue) {
        int deletedRows = handle.createUpdate("DELETE FROM rpro_sfc_calc_det WHERE line_id = :lineId")
                .bind("lineId", sfcStatusValue.getLineId())
                .execute();
        LOGGER.debug("Deleted SFC Calc Detail table rows for {} : {}", sfcStatusValue.getDocLineId(), deletedRows);
    }

}
