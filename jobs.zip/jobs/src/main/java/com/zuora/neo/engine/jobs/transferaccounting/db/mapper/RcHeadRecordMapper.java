package com.zuora.neo.engine.jobs.transferaccounting.db.mapper;

import com.zuora.neo.engine.jobs.transferaccounting.db.api.RcHeadRecord;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class RcHeadRecordMapper implements RowMapper<RcHeadRecord> {

    @Override
    public RcHeadRecord map(ResultSet rs, StatementContext ctx) throws SQLException {

        return new RcHeadRecord(rs.getLong(1), rs.getLong(2), rs.getLong(3));
    }
}
