package com.zuora.neo.engine.jobs.transferaccounting.activities.split;

import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.api.ThreadDetails;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.ChunkStatus;

import io.temporal.activity.ActivityInterface;

import java.util.List;

@ActivityInterface
public interface SplitActivity {

    ThreadDetails getThreadDetails(ThreadedAccountingResult accountingResult, String org);

    long newPostBatchIdForMasterJobError(ThreadedAccountingResult accountingResult);

    void updateTransferStatus(ThreadedAccountingResult accountingResult);

    void updateTransferChunkStatus(ThreadedAccountingResult accountingResult);

    void insertTransferError(ThreadedAccountingResult accountingResult, String orgId, String errMsg);

    List<ChunkStatus> getAllChunkStatus(ThreadedAccountingResult accountingResult);

    void moveHistToMainBatch(Long postBatchId, String orgId);

    ThreadDetails getBatchDetailFromHist(ThreadedAccountingResult accountingResult, String org);

}
