package com.zuora.neo.engine.jobs.archival.workflow.parent;

import com.zuora.neo.engine.annotations.workflow.WorkflowImplementation;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.archival.common.Constants;
import com.zuora.neo.engine.jobs.archival.workflow.child.MirrorWorkflow;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.workflows.LoggerWorkflowImpl;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.common.RetryOptions;
import io.temporal.workflow.ChildWorkflowOptions;
import io.temporal.workflow.Workflow;
import org.springframework.stereotype.Component;

import java.time.Duration;

/**
 * @author rpolepalli archival workflow which is responsible for the following and it comprises below child workflows
 *  1. MirrorWorkflow which will copy the expired RC rleated data to mirror schema
 *  2. ArchivalWorkflow read the data from mirror schema and copy to s3 Glacior
 */

@Component
@WorkflowImplementation
public class ArchivalWorkflowImpl extends LoggerWorkflowImpl implements ArchivalWorkflow {

    private static final org.slf4j.Logger logger = Workflow.getLogger(ArchivalWorkflowImpl.class);

    @Override
    public WorkflowResponse execute() {
        logger.info("Started executing archival workflow.");
        ChildWorkflowOptions childWorkflowOptions =
                ChildWorkflowOptions.newBuilder()
                        .setWorkflowExecutionTimeout(Duration.ofHours(24 * 30))
                        .setRetryOptions(RetryOptions.newBuilder()
                                .setMaximumAttempts(3)
                                .setInitialInterval(Duration.ofMinutes(1))
                                .setMaximumInterval(Duration.ofMinutes(20))
                                .setDoNotRetry(NonRetryableActivityException.class.getName())
                                .build())
                        .build();
        MirrorWorkflow mirrorWorkflow = Workflow.newChildWorkflowStub(MirrorWorkflow.class, childWorkflowOptions);

        WorkflowResponse mirrorWorkflowResponse = mirrorWorkflow.execute();

        RevenueJobStatus mirrorWorkflowStatus = mirrorWorkflowResponse.getStatus();
        logger.info("Mirror workflow status : " + mirrorWorkflowStatus);

        logger.info("Archival workflow execution completed.");

        if (mirrorWorkflowStatus.equals(RevenueJobStatus.COMPLETED)) {
            return new WorkflowResponse(RevenueJobStatus.COMPLETED, Constants.WorkflowConstants.ARCHIVAL_WORKFLOW_SUCCESS);
        } else if (mirrorWorkflowStatus.equals(RevenueJobStatus.FAILED)) {
            return new WorkflowResponse(RevenueJobStatus.FAILED, Constants.WorkflowConstants.ARCHIVAL_WORKFLOW_FAILURE);
        } else {
            return new WorkflowResponse(RevenueJobStatus.WARNING, Constants.WorkflowConstants.ARCHIVAL_WORKFLOW_WARNING);
        }
    }
}
