package com.zuora.neo.engine.jobs.rtp.db.mapper;

import com.zuora.neo.engine.jobs.rtp.api.RtpWiHeader;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class RtpWiHeaderMapper implements RowMapper<RtpWiHeader> {
    @Override
    public RtpWiHeader map(ResultSet rs, StatementContext ctx) throws SQLException {
        return new RtpWiHeader(
                rs.getInt("id"),
                rs.getInt("rc_id"),
                rs.getInt("prd_id"),
                rs.getInt("book_id"),
                rs.getString("sec_atr_val"),
                rs.getInt("client_id"),
                rs.getInt("wf_id"),
                rs.getString("status")
        );
    }
}
