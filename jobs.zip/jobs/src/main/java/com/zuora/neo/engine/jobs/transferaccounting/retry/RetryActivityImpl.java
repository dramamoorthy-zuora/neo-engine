package com.zuora.neo.engine.jobs.transferaccounting.retry;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.JobsMetadata;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.transferaccounting.api.OrgBookStatus;
import com.zuora.neo.engine.jobs.transferaccounting.config.Properties;
import com.zuora.neo.engine.jobs.transferaccounting.constants.AccountingParams;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.BookOrgRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.AccountingDao;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.jdbi.v3.core.Jdbi;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@ActivityImplementation
@Component
public class RetryActivityImpl implements RetryActivity {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(RetryActivityImpl.class);
    private static final String BATCH_ID_ERR = "Post batch Id can't be null";

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;
    @Autowired
    Properties properties;
    @Autowired
    ParseProgramParameters parseProgramParameters;

    @Override
    public Long getBatchDetails() {
        LOGGER.info("starting retry job");
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Map<String, String> paramsMap;
        Long postBatchId = null;
        if (request.getProgramId() == JobsMetadata.RETRY_ACCOUNTING.getId()) {
            paramsMap = parseProgramParameters.parseParamString(request.getTenantId(), request.getProgramId(), request.getParameterText());
            String postBatchIdStr = paramsMap.get(AccountingParams.POST_BATCH_ID);
            postBatchId =  Long.valueOf(postBatchIdStr);
            if (postBatchId == null) {
                NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, BATCH_ID_ERR);
            }
        }

        return postBatchId;
    }

    @Override
    public OrgBookStatus getTransferStatus() {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Map<String, String> paramsMap;

        Long postBatchId = null;
        if (request.getProgramId() == JobsMetadata.RETRY_ACCOUNTING.getId()) {
            paramsMap = parseProgramParameters.parseParamString(request.getTenantId(), request.getProgramId(), request.getParameterText());
            String postBatchIdStr = paramsMap.get(AccountingParams.POST_BATCH_ID);
            postBatchId =  Long.valueOf(postBatchIdStr);
            if (postBatchId == null) {
                NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, BATCH_ID_ERR);
            }
        }

        Jdbi jdbi = DbContext.getConnection();
        final String[] transferStatus = {null};
        final String[] orgId = {null};
        final Long[] bookId = new Long[1];
        Long finalPostBatchId = postBatchId;
        jdbi.useHandle(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            CommonDao commonDao  = handle.attach(CommonDao.class);
            properties.load(commonDao, request.getTenantId());
            transferStatus[0] = accountingDao.getTransferStatus(finalPostBatchId);

            BookOrgRecord rec = accountingDao.getBookIdForBatch(finalPostBatchId).get(0);
            orgId[0] = rec.getOrgId();
            bookId[0] = rec.getBookId();
        });
        OrgBookStatus orgStatus = new OrgBookStatus(orgId[0], transferStatus[0], bookId[0]);
        return orgStatus;
    }

    @Override
    public String getErrorDetails() {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Map<String, String> paramsMap;

        Long postBatchId = null;
        if (request.getProgramId() == JobsMetadata.RETRY_ACCOUNTING.getId()) {
            paramsMap = parseProgramParameters.parseParamString(request.getTenantId(), request.getProgramId(), request.getParameterText());
            String postBatchIdStr = paramsMap.get(AccountingParams.POST_BATCH_ID);
            postBatchId =  Long.valueOf(postBatchIdStr);
            if (postBatchId == null) {
                NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, BATCH_ID_ERR);
            }
        }
        Jdbi jdbi = DbContext.getConnection();
        final String[] message = {null};
        Long finalPostBatchId = postBatchId;
        jdbi.useHandle(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            message[0] = accountingDao.getTransferErrorMessage(finalPostBatchId);
        });
        return message[0];
    }
}
