package com.zuora.neo.engine.jobs.sfc.db.api;

import java.util.Arrays;

public class FinanceTypeIndicator {

    static final int ENABLED_FLAG_POS = 0;
    static final int FOLLOW_REV_REL_FLAG_POS = 1;
    static final int ACCRUAL_UPON_BILLING_POS = 2;
    static final int ACCRUAL_DR_ACCTG_FLAG_POS = 3;
    static final int ACCRUAL_CR_ACCTG_FLAG_POS = 4;
    static final int INCOME_STMT_DR_ACCTG_FLAG_POS = 5;
    static final int ELIGIBILITY_CRITERIA_FLAG_POS = 6;
    static final int PRINCIPLE_WEIGHTAGE_FLAG_POS = 7;
    static final int INTEREST_RT_FLAG_POS = 8;
    static final int ACCRUAL_DEBIT_FLAG_POS = 9;
    static final int IMPRT_ACCT_FLAG_POS = 10;
    static final int CONTRACT_IMPRT_ACCT_FLAG_POS = 11;
    static final int CONTRACT_LIABILITY_FLAG_POS = 12;


    static final  char[] defaultFinanceTypeIndicator = {'N' /* Enabled Flag */,
            'N' /* Follow Revenue Release Flag */,
            'N' /* Accrual Upon Billing Flag */,
            'N' /* Accrual Dr Flag */,
            'N' /* Accrual Cr Flag */,
            'N' /* Income Statement Flag */,
            'N' /* Eligibility Criteria Flag */,
            'N' /* Principle Weightage Flag */,
            'N' /* Interest Rate Flag */,
            'N' /* Accrual Debit Flag */,
            'N' /* Impairment Account Flag */,
            'N' /* Contract Impairment Account Flag */,
            'N' /* Contract Liability Flag */,
            'N' /* Flag not Used */,
            'N' /* Flag not Used */,
            'N' /* Flag not Used */,
            'N' /* Flag not Used */,
            'N' /* Flag not Used */,
            'N' /* Flag not Used */,
            'N' /* Flag not Used */
    };

    char[] financeTypeIndicator;

    public static String getDefault() {
        return String.valueOf(defaultFinanceTypeIndicator);
    }

    public FinanceTypeIndicator() {
        this.financeTypeIndicator = Arrays.copyOf(defaultFinanceTypeIndicator,defaultFinanceTypeIndicator.length - 1);
    }

    public  String getIndicator() {
        return String.valueOf(financeTypeIndicator);
    }

    public static FinanceTypeIndicator valueOf(String indicators) {

        int maxLength = defaultFinanceTypeIndicator.length - 1;
        int stringLength = indicators.length();

        FinanceTypeIndicator si = new FinanceTypeIndicator();
        for (int i = 0; i < maxLength; i++) {
            if (i >= stringLength) {
                break;
            }
            si.financeTypeIndicator[i] = indicators.charAt(i);
        }
        return si;
    }

    public char getEnabledFlag() {
        return financeTypeIndicator[ENABLED_FLAG_POS];
    }

    public void setEnabledFlag(char enabledFlag) {
        this.financeTypeIndicator[ENABLED_FLAG_POS] = enabledFlag;
    }

    public char getFollowRevRelFlag() {
        return financeTypeIndicator[FOLLOW_REV_REL_FLAG_POS];
    }

    public void setFollowRevRelFlag(char followRevRelFlag) {
        this.financeTypeIndicator[FOLLOW_REV_REL_FLAG_POS] = followRevRelFlag;
    }

    public char getAccrualUponBillingFlag() {
        return financeTypeIndicator[ACCRUAL_UPON_BILLING_POS];
    }

    public void setAccrualUponBillingFlag(char accrualUponBillingFlag) {
        this.financeTypeIndicator[ACCRUAL_UPON_BILLING_POS] = accrualUponBillingFlag;
    }

    public char getAccrualDrAcctgFlag() {
        return financeTypeIndicator[ACCRUAL_DR_ACCTG_FLAG_POS];
    }

    public void setAccrualDrAcctgFlag(char accrualDrAcctgFlag) {
        this.financeTypeIndicator[ACCRUAL_DR_ACCTG_FLAG_POS] = accrualDrAcctgFlag;
    }

    public char getAccrualCrAcctgFlag() {
        return financeTypeIndicator[ACCRUAL_CR_ACCTG_FLAG_POS];
    }

    public void setAccrualCrAcctgFlag(char accrualCrAcctgFlag) {
        this.financeTypeIndicator[ACCRUAL_CR_ACCTG_FLAG_POS] = accrualCrAcctgFlag;
    }

    public char getIncomeStatementDrAcctgFlag() {
        return financeTypeIndicator[INCOME_STMT_DR_ACCTG_FLAG_POS];
    }

    public void setIncomeStatementDrAcctgFlag(char incomeStatementDrAcctgFlag) {
        this.financeTypeIndicator[INCOME_STMT_DR_ACCTG_FLAG_POS] = incomeStatementDrAcctgFlag;
    }

    public char getEligibilityCriteriaFlag() {
        return financeTypeIndicator[ELIGIBILITY_CRITERIA_FLAG_POS];
    }

    public void setEligibilityCriteriaFlag(char eligibilityCriteriaFlag) {
        this.financeTypeIndicator[ELIGIBILITY_CRITERIA_FLAG_POS] = eligibilityCriteriaFlag;
    }

    public char getPrincipleWeightageFlag() {
        return financeTypeIndicator[PRINCIPLE_WEIGHTAGE_FLAG_POS];
    }

    public void setPrincipleWeightageFlag(char principleWeightageFlag) {
        this.financeTypeIndicator[PRINCIPLE_WEIGHTAGE_FLAG_POS] = principleWeightageFlag;
    }

    public char getInterestRtFlag() {
        return financeTypeIndicator[INTEREST_RT_FLAG_POS];
    }

    public void setInterestRtFlag(char interestRtFlag) {
        this.financeTypeIndicator[INTEREST_RT_FLAG_POS] = interestRtFlag;
    }

    public char getAccrualDebitFlag() {
        return financeTypeIndicator[ACCRUAL_DEBIT_FLAG_POS];
    }

    public void setAccrualDebitFlag(char accrualDebitFlag) {
        this.financeTypeIndicator[ACCRUAL_DEBIT_FLAG_POS] = accrualDebitFlag;
    }

    public char getImpairmentAccountFlag() {
        return financeTypeIndicator[IMPRT_ACCT_FLAG_POS];
    }

    public void setImpairmentAccountFlag(char impairmentAccountFlag) {
        this.financeTypeIndicator[IMPRT_ACCT_FLAG_POS] = impairmentAccountFlag;
    }

    public char getContractImpairmentAccountFlag() {
        return financeTypeIndicator[CONTRACT_IMPRT_ACCT_FLAG_POS];
    }

    public void setContractImpairmentAccountFlag(char contractImpairmentAccountFlag) {
        this.financeTypeIndicator[CONTRACT_IMPRT_ACCT_FLAG_POS] = contractImpairmentAccountFlag;
    }

    public char getContractLiabilityFlag() {
        return financeTypeIndicator[CONTRACT_LIABILITY_FLAG_POS];
    }

    public void setContractLiabilityFlag(char contractLiabilityFlag) {
        this.financeTypeIndicator[CONTRACT_LIABILITY_FLAG_POS] = contractLiabilityFlag;
    }

}
