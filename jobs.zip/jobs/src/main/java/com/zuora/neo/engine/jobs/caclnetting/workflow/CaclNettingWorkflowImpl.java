package com.zuora.neo.engine.jobs.caclnetting.workflow;

import com.zuora.neo.engine.annotations.workflow.WorkflowImplementation;
import com.zuora.neo.engine.jobs.caclnetting.activities.CaclNettingActivities;
import com.zuora.neo.engine.temporal.workflows.LoggerWorkflowImpl;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.workflow.Workflow;

import org.springframework.stereotype.Component;

@WorkflowImplementation
@Component
public class CaclNettingWorkflowImpl extends LoggerWorkflowImpl implements CaclNettingWorkflow {

    private final CaclNettingActivities caclActivities = Workflow.newActivityStub(CaclNettingActivities.class);

    @Override
    public WorkflowResponse execute() {
        return caclActivities.performNetting();
    }

}
