package com.zuora.neo.engine.jobs.sweep.activities;

import com.zuora.neo.engine.jobs.sweep.SweepResult;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface SweepActivities {

    SweepResult sweep();
}
