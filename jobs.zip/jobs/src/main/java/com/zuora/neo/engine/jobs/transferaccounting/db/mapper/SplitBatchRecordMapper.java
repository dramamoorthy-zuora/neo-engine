package com.zuora.neo.engine.jobs.transferaccounting.db.mapper;

import com.zuora.neo.engine.jobs.transferaccounting.db.api.SplitBatchRecord;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SplitBatchRecordMapper implements RowMapper<SplitBatchRecord> {

    @Override
    public SplitBatchRecord map(ResultSet rs, StatementContext ctx) throws SQLException {

        return new SplitBatchRecord(rs.getLong(1), rs.getString(2), rs.getString(3),
                rs.getLong(4), rs.getString(5), rs.getString(6), rs.getString(7),
                rs.getDate(8), rs.getDate(9), rs.getLong(10), rs.getString(11),
                rs.getLong(12), rs.getLong(13));
    }
}
