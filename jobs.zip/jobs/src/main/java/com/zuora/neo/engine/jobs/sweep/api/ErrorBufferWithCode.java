package com.zuora.neo.engine.jobs.sweep.api;

public class ErrorBufferWithCode {

    private String errorBuffer;
    private Integer returnCode;

    public ErrorBufferWithCode(String errorBuffer, Integer returnCode) {
        this.errorBuffer = errorBuffer;
        this.returnCode = returnCode;
    }

    public String getErrorBuffer() {
        return errorBuffer;
    }

    public Integer getReturnCode() {
        return returnCode;
    }
}
