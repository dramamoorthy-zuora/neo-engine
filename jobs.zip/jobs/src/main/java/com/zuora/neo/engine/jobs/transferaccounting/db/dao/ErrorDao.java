package com.zuora.neo.engine.jobs.transferaccounting.db.dao;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

public interface ErrorDao {
    @SqlUpdate("UPDATE rpro_int_error SET indicators = rpro_int_error_pkg.set_current_batch_flag(indicators,'N')"
            + " WHERE acct_xfer_id = :post_batch_id AND chunk_id = :chunkId AND rpro_int_error_pkg.get_current_batch_flag(indicators) = 'Y'")
    void updateIntErr(@Bind("post_batch_id") Long postBatchId, @Bind("chunkId") Long chunkId);

    @SqlUpdate("insert into rpro_int_error (acct_xfer_id,err_msg,crtd_by,crtd_dt,client_id,book_id,sec_atr_val, chunk_id)"
            + " values (?,?,?,SYSDATE,?,?,?,?)")
    void insertError(Long id, String errMsg, String user, Long clientId, Long bookId, String secAttrVal, Long chunkId);

    @SqlUpdate("insert into rpro_int_error (acct_xfer_id,rc_id,err_type,chunk_id,err_msg,crtd_by,crtd_dt,client_id,crtd_prd_id,book_id,sec_atr_val)"
            + " WITH schd AS (SELECT rc_id, indicators, amount,sec_atr_val, root_line_id FROM rpro_rc_schd "
            + " WHERE post_batch_id = :postBatchId and rc_id between :minRcId and :maxRcId"
            + " AND rpro_rc_schd_pkg.get_schd_type_flag(indicators) = 'A') SELECT :postBatchId,rc_id,'CV',:chunkId, :err_msg || carveout_amount,"
            + " :user,SYSDATE,:clientId,:periodId,:bookId,sec_atr_val FROM (SELECT schd.rc_id,l.sec_atr_val, SUM (schd.amount) carveout_amount"
            + " FROM schd, rpro_rc_line l WHERE rpro_rc_schd_pkg.get_initial_rep_entry_flag(schd.indicators) = 'Y' AND l.id = schd.root_line_id"
            + " GROUP BY schd.rc_id,l.sec_atr_val HAVING SUM (schd.amount) <> 0 UNION ALL SELECT schd.rc_id,l.sec_atr_val, SUM (schd.amount) carveout_amount"
            + " FROM schd, rpro_rc_line l WHERE  rpro_rc_schd_pkg.get_dr_acctg_flag(schd.indicators) = 'I' AND l.id = schd.root_line_id"
            + " GROUP BY schd.rc_id,l.sec_atr_val HAVING SUM (schd.amount) <> 0 UNION ALL SELECT rc_id,sec_atr_val, SUM (cv_amt) carveout_amount"
            + " FROM rpro_rc_line WHERE rc_id IN (SELECT rc_id  FROM schd ) AND NOT EXISTS (SELECT 1 FROM rpro_rc_head WHERE id = rpro_rc_line.rc_id"
            + " AND rpro_rc_head_pkg.get_alloc_trtmt_flag(indicators) = 'P') GROUP BY rc_id,sec_atr_val HAVING SUM (cv_amt) <> 0)")
    int insertCvValidateErrors(@Bind("postBatchId") Long postBatchId, @Bind("chunkId") Long chunkId, @Bind("err_msg") String errMsg, @Bind("user") String user,
            @Bind("clientId") Long clientId, @Bind("periodId") Long periodId, @Bind("bookId") Long bookId,
            @Bind("minRcId") Long minRcId, @Bind("maxRcId") Long maxRcId);

    @SqlUpdate("insert into rpro_int_error (acct_xfer_id,rc_id,line_id,schd_id,err_type,chunk_id,err_msg,crtd_by,crtd_dt,client_id,crtd_prd_id,"
            + "book_id,sec_atr_val)"
            + " SELECT :postBatchId,line_rc_id rc_id,schd_root_line_id,schd_id,'ACCTG SEGMENT', :chunkId"
            + ",'Invalid Accounting Segments:' || schd_acctg_segments,:user,SYSDATE,:clientId,:createdPeriodId,:bookId,:orgId"
            + " FROM rpro_post_v WHERE interfaced_flag = 'N' AND schd_post_batch_id =:postBatchId"
            + " AND line_rc_id between :minRcId and :maxRcId"
            + " AND rpro_rc_schd_pkg.get_initial_rep_entry_flag (schd_indicators) = 'N'"
            + " AND NVL(schd_acctg_segments,'-*!123456978') = NVL(:accountSegments,'-*!123456978')")
    int insertAccountSegValidateErrors(@Bind("postBatchId") Long postBatchId, @Bind("chunkId") Long chunkId, @Bind("user") String user,
            @Bind("clientId") Long clientId, @Bind("createdPeriodId") Long createdPeriodId,
            @Bind("bookId") Long bookId,@Bind("orgId") String orgId,@Bind("accountSegments") String accountSegments,
            @Bind("minRcId") Long minRcId, @Bind("maxRcId") Long maxRcId);

    @SqlQuery("select count(*) FROM rpro_int_error WHERE acct_xfer_id = :postBatchId "
            + "AND rpro_int_error_pkg.get_current_batch_flag(indicators) = 'Y' AND chunk_id = :chunkId")
    Integer getValidationErrCount(@Bind("postBatchId") Long postBatchId, @Bind("chunkId") Long chunkId);
}
