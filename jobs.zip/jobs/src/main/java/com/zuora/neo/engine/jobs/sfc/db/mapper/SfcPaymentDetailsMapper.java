package com.zuora.neo.engine.jobs.sfc.db.mapper;

import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SfcPaymentDetailsMapper implements RowMapper<SfcPaymentDetails> {

    @Override
    public SfcPaymentDetails map(ResultSet rs, StatementContext ctx) throws SQLException {
        return new SfcPaymentDetails(rs.getLong("id"), rs.getDate("paymt_date"), rs.getString("doc_line_id"),
                rs.getBigDecimal("paymt_amount"), rs.getBigDecimal("net_paymt_value"), rs.getBigDecimal("interest_accrual"), rs.getDate("paymt_start_dt"),
                rs.getDate("paymt_end_dt"));
    }
}
