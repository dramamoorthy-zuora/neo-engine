package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeIndicator;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.PrincipleWeightageColumn;
import com.zuora.neo.engine.jobs.sfc.exception.NoDetailsFoundException;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Service
public class PrincipleAmountCalculationService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(PrincipleAmountCalculationService.class);

    /*
       Service Method to get the weightage column from rpro_financ_type table according the the indicator.

       Input :
       financeTypeValuesList : Finance Type Table Values
     */
    public PrincipleWeightageColumn determineWeightageMethod(List<FinanceTypeValues> financeTypeValuesList) {
        PrincipleWeightageColumn principleWeightageColumn = PrincipleWeightageColumn.EXT_SLL_PRC;
        if (!financeTypeValuesList.isEmpty()) {
            String indicators = financeTypeValuesList.get(0).getIndicators();
            FinanceTypeIndicator financeTypeIndicator = FinanceTypeIndicator.valueOf(indicators);
            char principleWeightageFlag = financeTypeIndicator.getPrincipleWeightageFlag();
            if (principleWeightageFlag == 'C') {
                principleWeightageColumn = PrincipleWeightageColumn.valueOf(financeTypeValuesList.get(0).getPrnclWeightageColumn());
            }
        }
        return principleWeightageColumn;
    }

    /*
       Service Method to calculate principle amount for the RC Line.
       This method also gets the weightage column from rpro_financ_type table and calls the principle amount calculation service.

       Input :
       sfcStatusValuesList : Lines from Sfc Status Table
       sfcDbCacheContext : Has common details such as data from rpro_account, rpro_currency, rpro_financ_typ and rpro_calendar
       rcLineDetailsBatchMap : Map with key as doc line id and rc line details for that line
       rcLineDetailsByDocNumMap : Map with key as doc num and rc line details for that doc num with sum of amounts
       sfcResult : Sfc Result object
       request : Request
       handle : JDBI Handle
     */
    public void calculatePrincipleAmount(RcLineDetails rcLineDetails, Map<String, RcLineDetails> rcLineDetailsByDocNumMap,
            PrincipleWeightageColumn principleWeightageColumn, Integer currRound) throws NoDetailsFoundException {

        List<RcLineDetails> priceDetailsForDocNum = Arrays.asList(rcLineDetailsByDocNumMap.get(rcLineDetails.getDocNum()));

        if (priceDetailsForDocNum.isEmpty() || priceDetailsForDocNum.get(0).getSumOfExtSllPrc() == null
                || priceDetailsForDocNum.get(0).getSumOfExtSllPrc() == BigDecimal.ZERO) {
            LOGGER.error("RC Line Data not present for Doc Num filtering during Principle Amount Calculation for doc line " + rcLineDetails.getDocLineId());
            throw new NoDetailsFoundException("Rc Line Data not present during Principle Amount Calculation");
        }

        BigDecimal principleAmount = null;
        BigDecimal weightageRatio;
        RcLineDetails rcLinePriceDetailForDocNum = priceDetailsForDocNum.get(0);
        LOGGER.debug("Principle Weightage Column : " + principleWeightageColumn);
        if (principleWeightageColumn == PrincipleWeightageColumn.EXT_SLL_PRC) {
            if (rcLineDetails.getExtSllPrc() == null || rcLinePriceDetailForDocNum.getSumOfExtSllPrc() == null
                    || rcLinePriceDetailForDocNum.getSumOfExtSllPrc() == BigDecimal.ZERO) {
                LOGGER.error("Ext Sell Price is null for the RC Doc Line " + rcLineDetails.getDocLineId());
                throw new NoDetailsFoundException("Ext Sell Price is null for the RC Doc Line " + rcLineDetails.getDocLineId());
            }
            weightageRatio = rcLineDetails.getExtSllPrc().divide(rcLinePriceDetailForDocNum.getSumOfExtSllPrc(), 20, RoundingMode.HALF_EVEN);
            principleAmount = weightageRatio.multiply(rcLinePriceDetailForDocNum.getSumOfExtSllPrc());
        } else if (principleWeightageColumn == PrincipleWeightageColumn.EXT_FV_PRC) {
            if (rcLineDetails.getExtFvPrc() == null || rcLinePriceDetailForDocNum.getSumOfExtFvPrc() == null
                    || rcLinePriceDetailForDocNum.getSumOfExtFvPrc() == BigDecimal.ZERO) {
                LOGGER.error("Ext FV Price is null for the RC Doc Line " + rcLineDetails.getDocLineId());
                throw new NoDetailsFoundException("Ext FV Price is null for the RC Doc Line " + rcLineDetails.getDocLineId());
            }
            weightageRatio = rcLineDetails.getExtFvPrc().divide(rcLinePriceDetailForDocNum.getSumOfExtFvPrc(), 20, RoundingMode.HALF_EVEN);
            principleAmount = weightageRatio.multiply(rcLinePriceDetailForDocNum.getSumOfExtSllPrc());

        } else if (principleWeightageColumn == PrincipleWeightageColumn.EXT_LST_PRC) {
            if (rcLineDetails.getExtLstPrc() == null || rcLinePriceDetailForDocNum.getSumOfExtLstPrc() == null
                    || rcLinePriceDetailForDocNum.getSumOfExtLstPrc() == BigDecimal.ZERO) {
                LOGGER.error("Ext List Price is null for the RC Doc Line " + rcLineDetails.getDocLineId());
                throw new NoDetailsFoundException("Ext List Price is null for the RC Doc Line " + rcLineDetails.getDocLineId());
            }
            weightageRatio = rcLineDetails.getExtLstPrc().divide(rcLinePriceDetailForDocNum.getSumOfExtLstPrc(), 20, RoundingMode.HALF_EVEN);
            principleAmount = weightageRatio.multiply(rcLinePriceDetailForDocNum.getSumOfExtSllPrc());
        }
        principleAmount = principleAmount == null ? null : principleAmount.setScale(currRound, RoundingMode.HALF_EVEN);
        LOGGER.debug("Principle Amount Calculated : " + principleAmount);
        rcLineDetails.setPrincipleAmount(principleAmount);
    }
}
