package com.zuora.neo.engine.jobs.transferaccounting.db.dao;

import com.zuora.neo.engine.jobs.transferaccounting.db.api.GlIntegrationMap;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.GlIntegrationMapper;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.statement.UseRowMapper;

import java.util.Date;
import java.util.List;

public interface GeneralLedgerDao {

    @SqlQuery("SELECT 1 FROM rpro_gl_int_stage_temp stg WHERE stg.batch_id = :postBatchId AND stg.object_type = :objectType "
            + "and stg.CHUNK_ID = :chunkId AND ROWNUM = 1")
    Integer getGlIntStage(@Bind("postBatchId") long postBatchId, @Bind("objectType") String objectType, @Bind("chunkId") long chunkId);

    @SqlQuery("SELECT 1 FROM rpro_gl_int_stage stg WHERE stg.batch_id = :postBatchId AND ROWNUM = 1")
    Integer glIntStageExists(@Bind("postBatchId") long postBatchId);

    @SqlQuery("SELECT id, field_name, object_type, source_from, source_value FROM rpro_gl_int_map\n"
            + " WHERE source_from IS NOT NULL\n"
            + " AND rpro_gl_int_map_pkg.get_active_flag (indicators) = 'Y'\n"
            + " AND object_type = :objectType")
    @UseRowMapper(GlIntegrationMapper.class)
    List<GlIntegrationMap> getGlIntegrationMap(@Bind("objectType") String objectType);

    @SqlQuery("SELECT field_name FROM rpro_gl_int_map WHERE source_from IS NOT NULL AND rpro_gl_int_map_pkg.get_active_flag (indicators) = 'Y'"
            + " AND object_type = :p_obj_type AND source_value LIKE '%COMP%CODE%' AND ROWNUM = 1")
    String getCompanyAttribute(@Bind("p_obj_type") String objectType);

    @SqlQuery("SELECT field_name FROM rpro_gl_int_map WHERE source_from IS NOT NULL AND rpro_gl_int_map_pkg.get_active_flag (indicators) = 'Y'"
            + " AND object_type = :p_obj_type AND UPPER(source_value) = 'SCHD_ACCTG_TYPE' AND ROWNUM = 1")
    String getAccountTypeAttribute(@Bind("p_obj_type") String objectType);

    @SqlQuery("SELECT field_name FROM rpro_gl_int_map WHERE source_from IS NOT NULL AND rpro_gl_int_map_pkg.get_active_flag (indicators) = 'Y'"
            + " AND object_type = :p_obj_type AND UPPER(source_value) = 'SCHD_ACCOUNT_NAME' AND ROWNUM = 1")
    String getAccountNameAttribute(@Bind("p_obj_type") String objectType);

    @SqlUpdate("insert into rpro_gl_int_stage (ID, SET_OF_BOOKS_ID,ACCOUNTING_DATE,CURRENCY_CODE,DATE_CREATED,CRTD_BY,ACTUAL_FLAG,USER_JE_CATEGORY_NAME,"
            + "USER_JE_SOURCE_NAME,CURRENCY_CONVERSION_DATE,USER_CURRENCY_CONVERSION_TYPE,CURRENCY_CONVERSION_RATE,ENTERED_DR,ENTERED_CR,"
            + "ACCOUNTED_DR,ACCOUNTED_CR,TRANSACTION_DATE,JE_BATCH_ID,PERIOD_NAME,BATCH_ID,OBJECT_TYPE,LEDGER_ID,STATUS,SEGMENT1,"
            + "SEGMENT2,SEGMENT3,SEGMENT4,SEGMENT5,SEGMENT6,SEGMENT7,SEGMENT8,SEGMENT9,SEGMENT10,SEGMENT11,SEGMENT12,SEGMENT13,SEGMENT14,"
            + "SEGMENT15,SEGMENT16,SEGMENT17,SEGMENT18,SEGMENT19,SEGMENT20,SEGMENT21,SEGMENT22,SEGMENT23,SEGMENT24,SEGMENT25,"
            + "SEGMENT26,SEGMENT27,SEGMENT28,SEGMENT29,SEGMENT30) "
            + " values (:id,:sobId,:accountingDate,:currencyCode,:createdDate,:createdBy,:actualFlag,:jeCategoryName,"
            + " :jeSourceName,:currencyConvDate,:userCurrencyConvType,:currencyConversionRate,"
            + " DECODE(SIGN(:l_ent_dif_amt), -1, ABS(:l_ent_dif_amt), DECODE(SIGN(:l_ent_dif_amt), 0, NULL, 0)),"
            + " DECODE(SIGN(:l_ent_dif_amt), -1, 0, DECODE(SIGN(:l_ent_dif_amt), 0, NULL, ABS(:l_ent_dif_amt))),"
            + " DECODE(SIGN(:l_acc_dif_amt), -1, ABS(:l_acc_dif_amt), DECODE(SIGN(:l_acc_dif_amt), 0, NULL, 0)),"
            + " DECODE(SIGN(:l_acc_dif_amt), -1, 0, DECODE(SIGN(:l_acc_dif_amt), 0, NULL, ABS(:l_acc_dif_amt))),"
            + " :transactionDate,:jeBatchId,:periodName,:postBatchId,:objectType,:ledgerId,:status,"
            + " :segment1,:segment2,:segment3,:segment4,:segment5,:segment6,:segment7,:segment8,:segment9,"
            + " :segment10,:segment11,:segment12,:segment13,:segment14,:segment15,:segment16,"
            + " :segment17,:segment18,:segment19,:segment20,:segment21,:segment22,:segment23,:segment24,:segment25,"
            + " :segment26,:segment27,:segment28,:segment29,:segment30)")
    Integer insertGlIntStage(@Bind("id") Long id, @Bind("sobId") Long sobId, @Bind("accountingDate") Date accountingDate,
            @Bind("currencyCode") String currencyCode, @Bind("createdDate") Date createdDate, @Bind("createdBy") Long createdBy,
            @Bind("actualFlag") String actualFlag, @Bind("jeCategoryName") String jeCategoryName,
            @Bind("jeSourceName") String jeSourceName, @Bind("currencyConvDate") Date currencyConvDate,
            @Bind("userCurrencyConvType") String userCurrencyConvType, @Bind("currencyConversionRate") Double currencyConversionRate,
            @Bind("l_ent_dif_amt") Double entDiffAmount, @Bind("l_acc_dif_amt") Double accDiffAmount,
            @Bind("transactionDate") Date transactionDate, @Bind("jeBatchId") Long jeBatchId,@Bind("periodName") String periodName,
            @Bind("postBatchId") Long postBatchId, @Bind("objectType") String objectType, @Bind("ledgerId") Long ledgerId, @Bind("status") String status,
            @Bind("segment1") String segment1,@Bind("segment2") String segment2,@Bind("segment3") String segment3,
            @Bind("segment4") String segment4,@Bind("segment5") String segment5,@Bind("segment6") String segment6,
            @Bind("segment7") String segment7,@Bind("segment8") String segment8,@Bind("segment9") String segment9,
            @Bind("segment10") String segment10,@Bind("segment11") String segment11,@Bind("segment12") String segment12,
            @Bind("segment13") String segment13,@Bind("segment14") String segment14,@Bind("segment15") String segment15,
            @Bind("segment16") String segment16,@Bind("segment17") String segment17,@Bind("segment18") String segment18,
            @Bind("segment19") String segment19,@Bind("segment20") String segment20,@Bind("segment21") String segment21,
            @Bind("segment22") String segment22,@Bind("segment23") String segment23,@Bind("segment24") String segment24,
            @Bind("segment25") String segment25,@Bind("segment26") String segment26,@Bind("segment27") String segment27,
            @Bind("segment28") String segment28,@Bind("segment29") String segment29,@Bind("segment30") String segment30);

    @SqlUpdate("DELETE FROM RPRO_GL_INT_STAGE_TEMP where BATCH_ID = :postBatchId AND object_type = :p_obj_type")
    Integer deleteTempData(@Bind("postBatchId") Long postBatchId,@Bind("p_obj_type") String objectType);
}
