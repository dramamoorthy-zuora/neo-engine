package com.zuora.neo.engine.jobs.sfc.db.mapper;

import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SfcCalcDetailsMapper implements RowMapper<SfcCalcDetails> {

    @Override
    public SfcCalcDetails map(ResultSet rs, StatementContext ctx) throws SQLException {
        return new SfcCalcDetails(rs.getLong("id"), rs.getLong("rc_id"), rs.getLong("line_id"), rs.getBigDecimal("receivable_begin"),
                rs.getBigDecimal("receivable_end"), rs.getBigDecimal("npv_receivable"), rs.getBigDecimal("interest"), rs.getLong("prd_id"),
                rs.getLong("client_id"), rs.getLong("crtd_prd_id"), rs.getString("sec_atr_val"), rs.getLong("book_id"), rs.getString("crtd_by"),
                rs.getDate("crtd_dt"), rs.getString("updt_by"), rs.getDate("updt_dt"), rs.getString("indicators"),
                rs.getDate("start_date"), rs.getDate("end_date"));
    }
}
