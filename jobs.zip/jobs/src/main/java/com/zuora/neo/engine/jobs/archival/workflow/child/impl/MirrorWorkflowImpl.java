package com.zuora.neo.engine.jobs.archival.workflow.child.impl;

import com.zuora.neo.engine.annotations.workflow.WorkflowImplementation;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.archival.ArchivalResult;
import com.zuora.neo.engine.jobs.archival.activities.MirrorActivity;
import com.zuora.neo.engine.jobs.archival.enums.ArchivalStatus;
import com.zuora.neo.engine.jobs.archival.workflow.child.MirrorWorkflow;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.workflows.LoggerWorkflowImpl;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.activity.ActivityOptions;
import io.temporal.common.RetryOptions;
import io.temporal.workflow.Workflow;

import java.time.Duration;

/**
 * @author Zuora inc. MoveWorkflow which moves the data from Original schema to Mirrored Schema and it comprises the following Activities.
 */

@WorkflowImplementation
public class MirrorWorkflowImpl extends LoggerWorkflowImpl implements MirrorWorkflow {

    private static final org.slf4j.Logger logger = Workflow.getLogger(MirrorWorkflowImpl.class);

    //TODO: The current retry options from default is unlimited. Seems no way to override
    // other than creating a new option.  Changing that might impact every other job using
    // the same activity option. Need to check with Manas.
    private final MirrorActivity mirrorActivity = Workflow.newActivityStub(MirrorActivity.class,
            ActivityOptions.newBuilder().setStartToCloseTimeout(Duration.ofHours(24 * 30)) // This activity can run for 30 days
                    //Total time for activity + retries. keeping it same.We don't want to retry after a long run. Keeping it the same.
                    .setScheduleToCloseTimeout(Duration.ofHours(24 * 30))
                    .setHeartbeatTimeout(Duration.ofMinutes(5))
                    .setRetryOptions(RetryOptions.newBuilder()
                            .setMaximumAttempts(3)
                            .setInitialInterval(Duration.ofMinutes(1))
                            .setMaximumInterval(Duration.ofMinutes(20))
                            .setDoNotRetry(NonRetryableActivityException.class.getName())
                            .build())
                    .validateAndBuildWithDefaults());

    @Override
    public WorkflowResponse execute() {
        ArchivalResult result = mirrorActivity.processArchivalRecords();
        ArchivalStatus status = result.getStatus();

        if (status != ArchivalStatus.SUCCESS && status != ArchivalStatus.ARCHIVAL_NOT_ENABLED) {

            if (!result.isRetryPossible()) {
                logger.error(result.getStatus().status + ":" + result.getMessage());
                NonRetryableActivityException.throwNonRetryableActivityException(
                        RevenueJobStatus.FAILED,
                        result.getMessage()
                );
            }
        } else {
            logger.info(result.getStatus().status + ":" + result.getMessage());

        }
        return new WorkflowResponse(
                ArchivalStatus.getRevenueJobStatusFor(status),
                ArchivalStatus.getMessage(status)
        );
    }
}
