package com.zuora.neo.engine.jobs.rtp.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.jobs.rtp.api.RtpBatchContext;
import com.zuora.neo.engine.jobs.rtp.config.RtpProperties;
import com.zuora.neo.engine.jobs.rtp.constants.RtpConstants;
import com.zuora.neo.engine.jobs.rtp.constants.RtpParams;
import com.zuora.neo.engine.jobs.rtp.constants.RtpWiHeaderStatus;
import com.zuora.neo.engine.jobs.rtp.db.doa.RtpDao;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.Update;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

@Component
public class RtpBatchCreatorService {

    private static BigDecimal batchId;

    public static void setBatchId(BigDecimal batchId) {
        RtpBatchCreatorService.batchId = batchId;
    }

    @Autowired
    ParseProgramParameters parseProgramParameters;

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;

    @Autowired
    RtpProperties rtpProperties;

    public int prepareWiHeaderBatchForRtp(Handle handle, RtpDao rtpDao, RtpBatchContext batchContext) {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();

        // Increment only the decimals of batchId for Headers in same run.
        setBatchId(batchId.add(RtpBatchContext.BATCH_INCREMENT_VALUE).setScale(10, RoundingMode.DOWN));
        batchContext.setBatchId(batchId);

        // parse and retrieve input params
        Map<String, String> paramsMap = parseProgramParameters.parseParamString(request.getTenantId(), request.getProgramId(), request.getParameterText());
        RtpParams rtpParams = new RtpParams(paramsMap);

        String queryStatus = rtpParams.getErrorsOnly().equals("Y") ? RtpWiHeaderStatus.ERROR.getHeaderStatus() : RtpWiHeaderStatus.NEW.getHeaderStatus();

        Update query = handle.createUpdate(getRtpBatchQuery(rtpParams))
                .bind("sec_atr_val", batchContext.getSecAtrVal())
                .bind("status", queryStatus)
                .bind("batch_size", rtpProperties.getBatchSize())
                .bind("batch_id", batchContext.getBatchId())
                .bind("to_status", RtpWiHeaderStatus.IN_PROGRESS.getHeaderStatus());

        // Bind conditional
        if (!rtpParams.getRcIds().isEmpty()) {
            query.bindList("rc_ids", rtpParams.getRcIds());
        }

        int noOfHeadersUpdated = query.execute();

        int noOfHeadersSkipped = rtpDao.skipDuplicateRcIdsInBatch(batchContext.getSecAtrVal(), batchContext.getBatchId());

        return noOfHeadersUpdated - noOfHeadersSkipped;
    }

    private String getRtpBatchQuery(RtpParams rtpParams) {
        String additionalWhereClause = (!rtpParams.getRcIds().isEmpty()) ? RtpConstants.RTP_WI_HEADERS_QUERY_RC_ID_WHERE_CLAUSE : "";
        return String.format(RtpConstants.RTP_WI_HEADERS_BATCH_QUERY, additionalWhereClause);
    }

}
