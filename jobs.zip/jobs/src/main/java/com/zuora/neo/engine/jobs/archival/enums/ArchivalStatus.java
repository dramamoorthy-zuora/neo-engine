package com.zuora.neo.engine.jobs.archival.enums;

import com.zuora.neo.engine.jobs.archival.common.Constants.WorkflowConstants;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;

import com.google.common.collect.ImmutableMap;

import java.util.Map;

public enum ArchivalStatus {

    DATA_ERROR("DATA ERROR"),
    EMPTY_BATCH("NO DATA"),
    ACTIVITY_CANCELLED("USER CANCELLED"),
    COPY_FAILED("COPY FAILED"),
    PARTIAL_COPIED("PARTIAL COPIED"),
    SUCCESS("SUCCESS"),
    ARCHIVAL_NOT_ENABLED("ARCHIVAL NOT ENABLED"),
    RECOVERY_SUCCESS("SUCCESS"),
    PARTIALLY_RECOVERED("PARTIALLY RECOVERED"),
    RECOVERY_FAILED("RECOVERY FAILED");


    public final String status;
    ArchivalStatus(String status) {
        this.status = status;
    }

    public static final Map<ArchivalStatus,String> STATUS_TO_RESPONSE_MESSAGE_MAP = ImmutableMap.<ArchivalStatus, String>builder()
            .put(ArchivalStatus.SUCCESS, WorkflowConstants.MIRROR_WORKFLOW_SUCCESS)
            .put(ArchivalStatus.DATA_ERROR, WorkflowConstants.ARCHIVAL_WORKFLOW_FAILURE)
            .put(ArchivalStatus.ACTIVITY_CANCELLED, WorkflowConstants.ARCHIVAL_WORKFLOW_WARNING)
            .put(ArchivalStatus.EMPTY_BATCH, WorkflowConstants.ARCHIVAL_EMPTY_BATCH)
            .put(ArchivalStatus.PARTIAL_COPIED, WorkflowConstants.ARCHIVAL_WORKFLOW_FAILURE)
            .put(ArchivalStatus.COPY_FAILED, WorkflowConstants.ARCHIVAL_WORKFLOW_FAILURE)
            .put(ArchivalStatus.ARCHIVAL_NOT_ENABLED, WorkflowConstants.ARCHIVAL_NOT_ENABLED)
            .put(ArchivalStatus.RECOVERY_SUCCESS, WorkflowConstants.RECOVERY_WORKFLOW_SUCCESS)
            .put(ArchivalStatus.PARTIALLY_RECOVERED, WorkflowConstants.RECOVERY_WORKFLOW_FAILURE)
            .put(ArchivalStatus.RECOVERY_FAILED, WorkflowConstants.RECOVERY_WORKFLOW_FAILURE)
            .build();

    public static final Map<ArchivalStatus, RevenueJobStatus> STATUS_TO_REVENUE_JOB_STATUS_MAP = ImmutableMap.<ArchivalStatus, RevenueJobStatus>builder()
            .put(ArchivalStatus.SUCCESS,RevenueJobStatus.COMPLETED)
            .put(ArchivalStatus.DATA_ERROR, RevenueJobStatus.ERROR)
            .put(ArchivalStatus.ACTIVITY_CANCELLED, RevenueJobStatus.CANCELED)
            .put(ArchivalStatus.EMPTY_BATCH, RevenueJobStatus.ERROR)
            .put(ArchivalStatus.PARTIAL_COPIED, RevenueJobStatus.WARNING)
            .put(ArchivalStatus.COPY_FAILED, RevenueJobStatus.FAILED)
            .put(ArchivalStatus.ARCHIVAL_NOT_ENABLED, RevenueJobStatus.COMPLETED)
            .put(ArchivalStatus.RECOVERY_SUCCESS,RevenueJobStatus.COMPLETED)
            .build();

    public static String getMessage(ArchivalStatus status) {
        return STATUS_TO_RESPONSE_MESSAGE_MAP.get(status);
    }

    public static RevenueJobStatus getRevenueJobStatusFor(ArchivalStatus status) {
        return STATUS_TO_REVENUE_JOB_STATUS_MAP.get(status);
    }
}
