package com.zuora.neo.engine.jobs.sfc.config;

import com.zuora.neo.engine.config.YamlPropertySourceFactory;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ConfigurationProperties(prefix = "sfc.db")
@PropertySource(value = "classpath:sfc.yml", factory = YamlPropertySourceFactory.class)
public class SfcConfigProperties {

    private int batchSize;
    private int fetchSize;

    public int getBatchSize() {
        return batchSize;
    }

    public void setBatchSize(int batchSize) {
        this.batchSize = batchSize;
    }

    public int getFetchSize() {
        return fetchSize;
    }

    public void setFetchSize(int fetchSize) {
        this.fetchSize = fetchSize;
    }
}
