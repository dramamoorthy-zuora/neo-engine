package com.zuora.neo.engine.jobs.reporting.activities;

import com.amazonaws.services.s3.transfer.TransferManager;
import io.temporal.activity.ActivityInterface;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

@ActivityInterface
public interface ReportingActivities {

    // void hello1() ;
    // String generatePresignedUrl();

    // InputStream buildReportHere();

    InputStream streamingToLocalFromS3(String url);

    // void countNoOfRecords();
    // void uploadFileToS3();

    String buildReportHere(Map<Integer, String> mapStore, InputStream ty, JSONObject config);

    // OutputStream loopingOverInStream(Map<Integer, String> mapStore,
    // BufferedWriter fr,
    // InputStream ty, JSONObject config, int noOfRows, int noOfCols, double[]
    // totals);

    // OutputStream loopingOverInStream(Map<Integer, String> mapStore,
    // BufferedWriter fr,
    // InputStream ty, JSONObject config, Integer noOfRows, Integer noOfCols,
    // double[] totals);

    OutputStream loopingOverInStream(Map<Integer, String> mapStore, BufferedWriter fr,
            InputStream ty, JSONObject config, double [] totals, BuildReportResult asd);

    Map<Integer, String> buildingMapStore(JSONObject config);

    String getTenantIdAndRequestId();

    String finalMultiparUploadStep(InputStream k);

    // String uploadingToS3UsingMultipart();

    String getEtag(String keyFinal);

    String prepareingConfig(JSONObject config, int j);

    // String uploadingToS3UsingMultipart(JSONObject config);

    String uploadZipStream(TransferManager tm, String fileName, JSONObject config, String keyCreation);

    String uploadingToS3UsingMultipart(JSONObject config, String url);

    void uploadingToS3();

    String buildAndUploadReport(String config2, String dataFileUrl);

    // void ReadAFile();
}
