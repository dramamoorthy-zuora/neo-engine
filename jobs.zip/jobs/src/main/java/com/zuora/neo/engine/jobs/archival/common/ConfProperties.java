package com.zuora.neo.engine.jobs.archival.common;

import com.zuora.neo.engine.config.YamlPropertySourceFactory;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ConfigurationProperties(prefix = "da")
@PropertySource(value = "classpath:data-archival.yml", factory = YamlPropertySourceFactory.class)
public class ConfProperties {
    private int timeout;
    private int maxCount;

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public int getMaxCount() {
        return maxCount;
    }

    public void setMaxCount(int maxCount) {
        this.maxCount = maxCount;
    }

}
