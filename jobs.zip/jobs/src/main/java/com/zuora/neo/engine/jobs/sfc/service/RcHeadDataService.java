package com.zuora.neo.engine.jobs.sfc.service;

import org.jdbi.v3.core.Handle;

import org.jdbi.v3.core.statement.PreparedBatch;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RcHeadDataService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(RcLinePaDataService.class);

    private static final String UPDATE_RC_HEAD_DATA_QUERY = "UPDATE rpro_rc_head SET updt_dt = SYSDATE"
            + ", updt_by = :updtBy where id = :rcId";

    public void bindRcHeadDataForUpdate(PreparedBatch updateRcHeadDataBatch, Long rcId, String user) {

        updateRcHeadDataBatch.bind("updtBy", user)
                .bind("rcId", rcId).add();

    }

    public void doBulkUpdateRcHeadData(PreparedBatch updateRcHeadDataBatch) {
        LOGGER.info("Update RC Head Data Batch Size : " + updateRcHeadDataBatch.size());
        int[] updateCount = updateRcHeadDataBatch.execute();
        LOGGER.info("Number of Records updated Rc Head Data Batch Size : " + updateCount.length);
    }

    public void updateAmountsToRcHeadDataBatch(Handle handle, List<Long> rcIdList, String user) {

        LOGGER.debug("Updating the Amounts to RC Line PA Data..");
        PreparedBatch updateRcLinePaDataBatch = handle.prepareBatch(UPDATE_RC_HEAD_DATA_QUERY);
        for (Long rcId : rcIdList) {
            bindRcHeadDataForUpdate(updateRcLinePaDataBatch, rcId, user);
        }
        doBulkUpdateRcHeadData(updateRcLinePaDataBatch);
    }

}
