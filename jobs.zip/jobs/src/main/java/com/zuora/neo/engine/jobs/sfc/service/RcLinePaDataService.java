package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.db.api.RcLinePaData;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.PreparedBatch;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class RcLinePaDataService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(RcLinePaDataService.class);

    private static final String UPDATE_RC_LINE_PA_DATA_QUERY = "UPDATE rpro_rc_line_pa SET rec_amt = :recAmt, def_amt = :defAmt, accrued_amt = :accruedAmt, "
            + "fnc_type_version = :fncTypeVersion, start_date = :startDate, end_date = :endDate "
            + " where line_id = :lineId and vc_type_id = :vcTypeId and indicators like 'Y%'";

    public void updateAmountsToRcLinePaDataBatch(Handle handle, List<RcLinePaData> rcLinePaDataBatch) {

        LOGGER.debug("Updating the Amounts to RC Line PA Data..");
        PreparedBatch updateRcLinePaDataBatch = handle.prepareBatch(UPDATE_RC_LINE_PA_DATA_QUERY);
        for (RcLinePaData rcLinePaData : rcLinePaDataBatch) {
            bindRcLinePaDataForUpdate(updateRcLinePaDataBatch, rcLinePaData, rcLinePaData.getLineId(), rcLinePaData.getVcTypeId());
        }
        doBulkUpdateRcLinePaData(updateRcLinePaDataBatch);
    }

    public void populateAmountsForPaRecord(RcLinePaData rcLinePaData, BigDecimal recAmt, BigDecimal defAmt,
            BigDecimal accruedAmt) {

        rcLinePaData.setRecAmt(recAmt);
        rcLinePaData.setDefAmt(defAmt);
        rcLinePaData.setAccruedAmt(accruedAmt);
    }

    public void populateIdsVersionsForPaRecord(RcLinePaData rcLinePaData, long lineId, long vcTypeId, long financeTypeVersion) {
        rcLinePaData.setLineId(lineId);
        rcLinePaData.setVcTypeId(vcTypeId);
        rcLinePaData.setFncTypeVersion(financeTypeVersion);
    }

    public void bindRcLinePaDataForUpdate(PreparedBatch updateRcLinePaDataBatch, RcLinePaData rcLinePaData, long lineId, long vcTypeId) {

        updateRcLinePaDataBatch.bind("recAmt", rcLinePaData.getRecAmt())
                .bind("defAmt", rcLinePaData.getDefAmt())
                .bind("accruedAmt", rcLinePaData.getAccruedAmt())
                .bind("lineId", lineId)
                .bind("vcTypeId", vcTypeId)
                .bind("fncTypeVersion", rcLinePaData.getFncTypeVersion())
                .bind("startDate", rcLinePaData.getStartDate())
                .bind("endDate", rcLinePaData.getEndDate()).add();

    }

    public void doBulkUpdateRcLinePaData(PreparedBatch updateRcLinePaDataBatch) {
        LOGGER.info("Update RC Line Pa Data Batch Size : " + updateRcLinePaDataBatch.size());
        int[] updateCount = updateRcLinePaDataBatch.execute();
        LOGGER.info("Number of Records updated Rc Line Pa Data Batch Size : " + updateCount.length);
    }
}
