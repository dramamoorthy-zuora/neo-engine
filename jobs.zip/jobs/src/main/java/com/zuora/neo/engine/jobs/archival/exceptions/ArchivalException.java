package com.zuora.neo.engine.jobs.archival.exceptions;

import com.zuora.neo.engine.exception.NeoEngineException;

public class ArchivalException extends NeoEngineException {
    public ArchivalException(String message) {
        super(message);
    }

    public ArchivalException(String message, Throwable cause) {
        super(message, cause);
    }
}
