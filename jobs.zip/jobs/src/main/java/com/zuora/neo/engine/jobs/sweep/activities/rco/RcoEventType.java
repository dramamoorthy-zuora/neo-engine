package com.zuora.neo.engine.jobs.sweep.activities.rco;

public enum RcoEventType {
    ACCOUNT_ANALYSIS("ACCOUNT-ANALYSIS"), UNPOSTED_SCHEDULES("UNPOSTED-SCHEDULES");

    String type;

    public String getType() {
        return type;
    }

    RcoEventType(String type) {
        this.type = type;
    }
}
