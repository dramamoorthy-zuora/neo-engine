package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.jobs.sfc.constants.SfcConstants;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.OutParameters;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class SfcPaymentProcessingService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcPaymentProcessingService.class);

    /*
        Service Method to Process Unprocessed Payments for the batch
        Takes the list of doc line ids and distinct doc nums and checks if there are any error lines
        in payment stage table for these doc line ids and doc nums through checkForErrorLinesAndProcessInPaymentStageTable

        Input Args :
        sfcStatusValuesList -> Records from rpro_sfc_status for this batch
     */
    public void processedUnProcessedPayments(List<SfcStatusValues> sfcStatusValuesList, Handle handle) {

        List<String> sfcDocLineIds = sfcStatusValuesList.stream().map(SfcStatusValues::getDocLineId).collect(Collectors.toList());
        List<String> sfcDocNums = sfcStatusValuesList.stream().map(SfcStatusValues::getDocNum).collect(Collectors.toList())
                .stream().distinct().collect(Collectors.toList());

        SfcDao sfcDao = handle.attach(SfcDao.class);
        checkForErrorLinesAndProcessInPaymentStageTable(sfcDao, sfcDocLineIds, sfcDocNums);
    }

    /*
        Service Method to check for error lines, unprocessed payments in stage table and process those lines to populate payment table.
        A PL/SQL call is made if there are any error lines or unprocessed payments. This call processes those lines and
        popoluates rpro_sfc_paymt_det table

        Input Args :
        sfcDao -> SFC Dao object
        sfcDocLineIds -> List of doc lines in this batch
        sfcDocNums -> list of distinct doc nums in this batch
     */
    public void checkForErrorLinesAndProcessInPaymentStageTable(SfcDao sfcDao, List<String> sfcDocLineIds, List<String> sfcDocNums) {

        List<String> errorMsgList = new ArrayList<>();
        errorMsgList.add(SfcConstants.SFC_PYMT_STG_SO_NUM_ID_NOT_EXISTS);
        errorMsgList.add(SfcConstants.SFC_PYMT_PRINC_AMT_NOT_CALCULATED);
        Optional<Integer> numOfErrorUnProcessedPayments = sfcDao.getNumberOfErrorLinesInPaymentStageTable(errorMsgList, sfcDocLineIds, sfcDocNums);
        if (numOfErrorUnProcessedPayments.isPresent()) {
            //To process the unprocessed payment lines in stage table
            OutParameters outParameters = sfcDao.processUnprocessedPaymentLines(-1);
            Integer returnCode = outParameters.getInt("p_retcode");
            String errMsg = outParameters.getString("p_errbuff");
            LOGGER.debug("After calling process_paymt_record proc errMsg is " + errMsg + " returnCode is " + returnCode);
        }
    }

}
