package com.zuora.neo.engine.jobs.reporting.workflow;

import com.zuora.neo.engine.annotations.workflow.WorkflowImplementation;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.jobs.reporting.activities.FetchingDataFileUrlFromQueryService;
import com.zuora.neo.engine.jobs.reporting.activities.GetReportConfig;
import com.zuora.neo.engine.jobs.reporting.activities.ReportingActivities;
import com.zuora.neo.engine.jobs.reporting.activities.SetReportStatus;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;

import com.zuora.neo.engine.temporal.workflows.LoggerWorkflowImpl;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.workflow.Workflow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@WorkflowImplementation
public class ReportingWorkflowImpl extends LoggerWorkflowImpl implements ReportingWorkflow {
    private static final org.slf4j.Logger LOGGER = Workflow.getLogger(ReportingWorkflowImpl.class);

    private final ReportingActivities reportingActivities = Workflow.newActivityStub(ReportingActivities.class);
    private final GetReportConfig getReportConfig = Workflow.newActivityStub(GetReportConfig.class);

    private final SetReportStatus setReportStatus = Workflow.newActivityStub(SetReportStatus.class);

    private final FetchingDataFileUrlFromQueryService fetchingDataFileUrlFromQueryService = Workflow
            .newActivityStub(FetchingDataFileUrlFromQueryService.class);

    @Autowired
    ParseProgramParameters parseProgramParameters;

    void handleError(String error) {
        String last = setReportStatus.setErrorInDB(error);
        LOGGER.info("Reporting workflow for reporting ended" + last);
    }

    @Override
    public WorkflowResponse execute() {
        LOGGER.info("Inside reporting workflow for reporting");
        try {

            String config = getReportConfig.getRecords();
            String urlObject = fetchingDataFileUrlFromQueryService.getUrlFromQueryService2(config);
            String etagObject = reportingActivities.buildAndUploadReport(config, urlObject);

            String fin = setReportStatus.setRecords(etagObject);
            LOGGER.info("Reporting workflow for reporting ended" + fin);

            return new WorkflowResponse(RevenueJobStatus.COMPLETED, "");
        } catch (Exception e) {
            LOGGER.info("Error Caught Reporting workflow for reporting from pinot" + e.getLocalizedMessage() + " "
                    + e.getMessage());

            String errorMsg = "error" + (e.getCause() != null ? e.getCause().getMessage() : e.getMessage());
            handleError(errorMsg);
            return new WorkflowResponse(RevenueJobStatus.FAILED, errorMsg.length() > 1997 ? errorMsg.substring(0, 1995) : errorMsg);
        }

    }

}
