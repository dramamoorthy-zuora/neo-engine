package com.zuora.neo.engine.jobs.caclnetting.constants;

public class CaclParams {

    public static final String RC_ID = "RC ID";
    public static final String BOOK_NAME = "BOOK NAME";
    public static final String ORG_ID = "ORG ID";
    public static final String PERIOD_NAME = "PERIOD NAME";
    public static final String CREATE_LINE_LEVEL = "CREATE LINE LEVEL";
    public static final String INCLUDE_ALL_RCS = "INCLUDE ALL RCs";

}
