package com.zuora.neo.engine.jobs.transferaccounting.db.mapper;

import com.zuora.neo.engine.jobs.transferaccounting.db.api.RcSchedMinRecord;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class RcSchedMinRecordMapper implements RowMapper<RcSchedMinRecord> {
    @Override
    public RcSchedMinRecord map(ResultSet rs, StatementContext ctx) throws SQLException {

        return new RcSchedMinRecord(rs.getLong(1), rs.getLong(2), rs.getDouble(3),
                rs.getString(4), rs.getString(5), rs.getString(6),
                rs.getDouble(7), rs.getDouble(8), rs.getInt(9));
    }
}
