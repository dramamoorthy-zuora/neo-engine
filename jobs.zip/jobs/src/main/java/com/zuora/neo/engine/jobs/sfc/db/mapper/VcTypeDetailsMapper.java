package com.zuora.neo.engine.jobs.sfc.db.mapper;

import com.zuora.neo.engine.jobs.sfc.db.api.VcTypeDetails;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class VcTypeDetailsMapper implements RowMapper<VcTypeDetails>  {

    @Override
    public VcTypeDetails map(ResultSet rs, StatementContext ctx) throws SQLException {
        return new VcTypeDetails(rs.getLong("id"), rs.getString("dr_acctg_flag"), rs.getString("cr_acctg_flag"),
                rs.getString("income_stmt_flag"), rs.getString("accrual_upon_billing_flag"));
    }
}
