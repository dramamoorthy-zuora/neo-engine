package com.zuora.neo.engine.jobs.transferaccounting.workflow;

import com.zuora.neo.engine.annotations.workflow.WorkflowImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.activities.AccountingActivities;
import com.zuora.neo.engine.jobs.transferaccounting.activities.closeprocess.CloseProcessActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.copy.GlCopyRoundActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.filedownload.DownloadActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.split.SplitActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.stagehandler.StageHandlerActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.support.SupportActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.transfer.TransferActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.update.UpdateActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.validation.ValidateActivity;
import com.zuora.neo.engine.jobs.transferaccounting.api.ChunkRecord;
import com.zuora.neo.engine.jobs.transferaccounting.api.OrgBookStatus;
import com.zuora.neo.engine.jobs.transferaccounting.api.ThreadDetails;
import com.zuora.neo.engine.jobs.transferaccounting.common.ActivityType;
import com.zuora.neo.engine.jobs.transferaccounting.common.ThreadExecutor;
import com.zuora.neo.engine.jobs.transferaccounting.common.TransferUtility;
import com.zuora.neo.engine.jobs.transferaccounting.config.ConfigProperties;
import com.zuora.neo.engine.jobs.transferaccounting.constants.StageHandlerType;
import com.zuora.neo.engine.jobs.transferaccounting.constants.TransferStatus;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.ChunkStatus;
import com.zuora.neo.engine.jobs.transferaccounting.retry.RetryActivity;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.workflows.LoggerWorkflowImpl;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.workflow.Promise;
import io.temporal.workflow.Workflow;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@Component
@WorkflowImplementation
public class AccountingRetryWorkflowImpl extends LoggerWorkflowImpl implements AccountingRetryWorkflow {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CrDrWorkflowImpl.class);
    private static final String CUSTOM_API_ERR = "ERROR: During custom stage processor:";
    private static final String TRANSFER_ERR = "Error in Transfer";
    private static final String UPDATE_ERR = "Error in Update";
    private static final String NO_BATCH = "Post Batch ID attempted for retry not found in schedules table";
    private static final String COPY_ERR = "Copy Activity failed to push to GL";

    private final RetryActivity retryActivity = Workflow.newActivityStub(RetryActivity.class);
    private final AccountingActivities accountingActivity = Workflow.newActivityStub(AccountingActivities.class);
    private final UpdateActivity updateActivity = Workflow.newActivityStub(UpdateActivity.class);
    private final SplitActivity splitActivity = Workflow.newActivityStub(SplitActivity.class);
    private final TransferActivity transferActivity = Workflow.newActivityStub(TransferActivity.class);
    private final DownloadActivity downloadActivity = Workflow.newActivityStub(DownloadActivity.class);
    private final CloseProcessActivity closeActivity = Workflow.newActivityStub(CloseProcessActivity.class);
    private final ValidateActivity validateActivity = Workflow.newActivityStub(ValidateActivity.class);
    private final StageHandlerActivity handlerActivity = Workflow.newActivityStub(StageHandlerActivity.class);
    private final GlCopyRoundActivity copyActivity = Workflow.newActivityStub(GlCopyRoundActivity.class);
    private final SupportActivity supportActivity = Workflow.newActivityStub(SupportActivity.class);
    private final StageHandlerActivity stageHandlerActivity = Workflow.newActivityStub(StageHandlerActivity.class);

    @Autowired
    private ConfigProperties configProperties;

    @Override
    public WorkflowResponse performRetry() {
        Long postBatchId = retryActivity.getBatchDetails();
        LOGGER.info("starting retry workflow for: " + postBatchId);
        OrgBookStatus orgStatus = retryActivity.getTransferStatus();
        String orgId = orgStatus.getOrgId();
        accountingActivity.acquireLock(postBatchId,orgId); //release lock again if previous execution failed
        String transferStatus = orgStatus.getStatus();
        ThreadedAccountingResult result = new ThreadedAccountingResult();
        result.setPostBatchId(postBatchId);
        result.setBookId(orgStatus.getBookId());
        ThreadDetails threadDetails = accountingActivity.getNumThreadAndBatches(result, orgId); //get batch info from rpro_batch_split table
        if (threadDetails.getSplitBatchIds().isEmpty()) { //get from history(rpro_batch_split_h) if some other run came and archived batch info
            threadDetails = splitActivity.getBatchDetailFromHist(result, orgId);
            //copy hist table data to main table and delete hist table
            splitActivity.moveHistToMainBatch(postBatchId, orgId);
        }
        final Integer totalThreads = threadDetails.getNumThreads();
        List<ChunkRecord> batchIds = threadDetails.getSplitBatchIds();
        ThreadExecutor threadExecutor = new ThreadExecutor(updateActivity, transferActivity, validateActivity);
        int maxRetry = configProperties.getMaxRetryCount();
        int count = 0;
        Boolean exists = supportActivity.checkBatchExists(postBatchId); //check if batch id exists in rpro_rc_schd table
        if (!exists && !((ActivityType.UPDATE + " - " + TransferStatus.IN_PROGRESS.getTransferStatus()).equals(transferStatus))) {
            //in update-in-progress the post batch id won't be present in rpro_rc_schd table
            return new WorkflowResponse(RevenueJobStatus.COMPLETED, NO_BATCH);
        }
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        if ((ActivityType.UPDATE + " - " + TransferStatus.IN_PROGRESS.getTransferStatus()).equals(transferStatus)) { // update fails
            supportActivity.updateHeaderForRetry(postBatchId, request.getUser());
            if (totalThreads == 1) {
                result = TransferUtility.performActivitiesForSingleThread(result, batchIds, orgId, handlerActivity, updateActivity,
                        validateActivity, transferActivity, splitActivity);
            } else { // run from update activity again
                result = executeUpdate(result, orgId, batchIds, count, maxRetry, threadExecutor, totalThreads);
            }
            WorkflowResponse response = runPostTransferActivities(result, orgId);
            if (response != null) {
                return response;
            }
        } else if (TransferStatus.UPDATED.getTransferStatus().equals(transferStatus)) { // update is success but validate or other activity fails
            supportActivity.resetErrorMsgOnRetry(postBatchId, request.getUser());
            if (totalThreads == 1) {
                result = executeFromValidationSingle(result, orgId, batchIds);
            } else {
                result = executeFromValidation(result, batchIds, orgId, threadExecutor, totalThreads, transferActivity, handlerActivity);
            }
            WorkflowResponse response = runPostTransferActivities(result, orgId);
            if (response != null) {
                return response;
            }
        } else if ((ActivityType.TRANSFER + " - " + TransferStatus.IN_PROGRESS.getTransferStatus()).equals(transferStatus)) {
            supportActivity.resetErrorMsgOnRetry(postBatchId, request.getUser());
            List<ChunkStatus> chunkTransferStatuses = splitActivity.getAllChunkStatus(result); // either all chunks failed or only few
            HashSet<String> uniqueStatusSet = TransferUtility.getUniqueChunkStatuses(result, splitActivity);
            if (uniqueStatusSet.size() > 1 && uniqueStatusSet.contains(TransferStatus.ERROR.getTransferStatus())) { //mix
                batchIds.clear();
                for (ChunkStatus chunkStatus : chunkTransferStatuses) {
                    if (chunkStatus.getStatus().equals(TransferStatus.ERROR.getTransferStatus())) {
                        Long chunkId = chunkStatus.getChunkId();
                        batchIds.add(new ChunkRecord(postBatchId, chunkId));
                    }
                }
                result = handleTransfer(totalThreads, result, orgId, threadExecutor, batchIds);
            }
            if (uniqueStatusSet.size() == 1 && uniqueStatusSet.contains(TransferStatus.ERROR.getTransferStatus())) { //all errors
                result = handleTransfer(totalThreads, result, orgId, threadExecutor, batchIds);
            } // continue rest of the steps for all chunks
            WorkflowResponse response = runPostTransferActivities(result, orgId);
            if (response != null) {
                return response;
            }
        } else if (TransferStatus.READY_TO_TRANSFER.getTransferStatus().equals(transferStatus)
                || TransferStatus.TRANSFERRED.getTransferStatus().equals(transferStatus)) {
            supportActivity.resetErrorMsgOnRetry(postBatchId, request.getUser());
            runAfterTransferFailures(result, closeActivity, orgId); //if batch is READY_TO_TRANSFER we don't want to do all over again
        } else if (TransferStatus.ERROR.getTransferStatus().equals(transferStatus)) { //TODO: verify all errors are handled
            String errMsg = retryActivity.getErrorDetails();
            return handleErrorStatus(errMsg, totalThreads, result, orgId, batchIds, count, maxRetry, threadExecutor, postBatchId);
        }
        return new WorkflowResponse(RevenueJobStatus.COMPLETED, "");
    }

    private void runAfterTransferFailures(ThreadedAccountingResult accountingResult, CloseProcessActivity summaryActivity, String org) {
        //download file
        downloadActivity.fileDownload(accountingResult);
        //close process
        summaryActivity.doSummaryAnalysis(accountingResult, org);
    }

    private ThreadedAccountingResult handleTransfer(Integer totalThreads, ThreadedAccountingResult result, String orgId,
            ThreadExecutor threadExecutor, List<ChunkRecord> batchIds) { //run from transfer activity again
        if (totalThreads == 1) {
            result = executeFromTransferSingle(result, batchIds, orgId, transferActivity, handlerActivity);
        } else {
            result = executeFromTransfer(result, batchIds, orgId, threadExecutor, totalThreads, transferActivity, handlerActivity);
        }
        return result;
    }

    private WorkflowResponse handleErrorStatus(String errMsg, int totalThreads, ThreadedAccountingResult result,
            String orgId, List<ChunkRecord> batchIds, int count, int maxRetry, ThreadExecutor threadExecutor, Long postBatchId) {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        if (errMsg != null && errMsg.contains(TRANSFER_ERR)) { //transfer errors
            supportActivity.resetErrorMsgOnRetry(postBatchId, request.getUser());
            if (totalThreads == 1) {
                result = executeFromTransferSingle(result, batchIds, orgId, transferActivity, handlerActivity);
            } else {
                result = executeFromTransfer(result, batchIds, orgId, threadExecutor, totalThreads, transferActivity, handlerActivity);
            }
            WorkflowResponse response = runPostTransferActivities(result, orgId);
            if (response != null) {
                return response;
            }
        } else if (errMsg != null && errMsg.contains(COPY_ERR)) { //failed at copy activity
            supportActivity.resetErrorMsgOnRetry(postBatchId, request.getUser());
            return executeAfterThreadFailures(result, orgId);
        } else if (errMsg != null && errMsg.contains(UPDATE_ERR)) { //update errors
            supportActivity.updateHeaderForRetry(postBatchId, request.getUser());
            if (totalThreads == 1) {
                result = TransferUtility.performActivitiesForSingleThread(result, batchIds, orgId, handlerActivity, updateActivity,
                        validateActivity, transferActivity, splitActivity);
            } else {
                result = executeUpdate(result, orgId, batchIds, count, maxRetry, threadExecutor, totalThreads);
            }
            WorkflowResponse response = runPostTransferActivities(result, orgId);
            if (response != null) {
                return response;
            }
        } else if (errMsg != null && errMsg.contains(CUSTOM_API_ERR)) { //stage handler errors
            Boolean glDataExists = supportActivity.glDataExists(result.getPostBatchId());
            if (glDataExists && errMsg.contains(StageHandlerType.AFTER_POST.getStageHandlerType())) { //after post stage handler
                supportActivity.resetErrorMsgOnRetry(postBatchId, request.getUser());
                result.setStageHandlerType(StageHandlerType.AFTER_POST);
                if (result.getStageHandlerType() == StageHandlerType.AFTER_POST) {
                    result = stageHandlerActivity.executeCustomCodeStageHandler(result, orgId);
                }
                if (result.getTransferMessage() != null && result.getTransferMessage().contains(CUSTOM_API_ERR)) {
                    return new WorkflowResponse(RevenueJobStatus.ERROR, CUSTOM_API_ERR);
                }
                result.setTransferStatus(TransferStatus.READY_TO_TRANSFER.getTransferStatus());
                splitActivity.updateTransferStatus(result);

                if (result.getTransferStatus().equals(TransferStatus.READY_TO_TRANSFER.getTransferStatus())
                        || result.getTransferStatus().equals(TransferStatus.TRANSFERRED.getTransferStatus())) {
                    runAfterTransferFailures(result, closeActivity, orgId);
                }
            } else if (errMsg.contains(StageHandlerType.BEFORE_UPDATE.getStageHandlerType())) {
                result.setStageHandlerType(StageHandlerType.BEFORE_UPDATE);
                result = stageHandlerActivity.executeCustomCodeStageHandler(result, orgId);
                supportActivity.updateHeaderForRetry(postBatchId, request.getUser());
                result = executeUpdate(result, orgId, batchIds, count, maxRetry, threadExecutor, totalThreads);
                WorkflowResponse response = runPostTransferActivities(result, orgId);
                if (response != null) {
                    return response;
                }
            }  else if (errMsg.contains(StageHandlerType.AFTER_UPDATE.getStageHandlerType())
                    || errMsg.contains(StageHandlerType.BEFORE_POST.getStageHandlerType())) {
                supportActivity.resetErrorMsgOnRetry(postBatchId, request.getUser());
                result = executeUpdate(result, orgId, batchIds, count, maxRetry, threadExecutor, totalThreads);
                //result = executeFromValidation(result, batchIds, org, threadExecutor, totalThreads, transferActivity, stageHandlerActivity);
                WorkflowResponse response = runPostTransferActivities(result, orgId);
                if (response != null) {
                    return response;
                }
            }
        }
        return new WorkflowResponse(RevenueJobStatus.COMPLETED, "");
    }

    private ThreadedAccountingResult executeUpdate(ThreadedAccountingResult result, String orgId, List<ChunkRecord> batchIds,
            int count, int maxRetry, ThreadExecutor threadExecutor, int totalThreads) {
        result = TransferUtility.performActivitiesForMultipleThread(result, batchIds, orgId, count, maxRetry, threadExecutor,
                totalThreads, transferActivity, splitActivity, handlerActivity, updateActivity);
        return result;
    }

    private WorkflowResponse executeAfterThreadFailures(ThreadedAccountingResult result, String orgId) {
        result = TransferUtility.performAfterPostActivities(result, orgId, handlerActivity, splitActivity, copyActivity,
                downloadActivity, closeActivity, supportActivity);
        WorkflowResponse response = supportActivity.handleCustomApiErrors(result);
        if (response != null) {
            splitActivity.updateTransferStatus(result);
            return response;
        }
        return new WorkflowResponse(RevenueJobStatus.COMPLETED, "");
    }

    private WorkflowResponse runPostTransferActivities(ThreadedAccountingResult result, String orgId) {
        result = TransferUtility.performAfterPostActivities(result, orgId, handlerActivity, splitActivity,
                copyActivity, downloadActivity, closeActivity, supportActivity);
        WorkflowResponse response = supportActivity.handleCustomApiErrors(result);
        if (response != null) {
            splitActivity.updateTransferStatus(result);
            return response;
        }
        return null;
    }

    private ThreadedAccountingResult executeFromValidation(ThreadedAccountingResult accountingResult, List<ChunkRecord> batchIds, String org,
            ThreadExecutor threadExecutor, int totalThreads, TransferActivity transferActivity, StageHandlerActivity stageHandlerActivity) {
        List<Promise<ThreadedAccountingResult>> promiseValidateList = new ArrayList<>();
        List<Promise<ThreadedAccountingResult>> promiseTransferList = new ArrayList<>();

        //Run validate activity in parallel based on number of threads and split batches
        threadExecutor.executeThreadedSteps(totalThreads, accountingResult, org, promiseValidateList, ActivityType.VALIDATE.name(), batchIds);
        //run the after update and before post stage handlers outside of the chunk logic
        accountingResult.setStageHandlerType(StageHandlerType.AFTER_UPDATE);
        stageHandlerActivity.executeCustomCodeStageHandler(accountingResult, org);
        if (accountingResult.getTransferMessage() != null && accountingResult.getTransferMessage().contains(CUSTOM_API_ERR)) {
            return accountingResult;
        }
        accountingResult.setStageHandlerType(StageHandlerType.BEFORE_POST);
        stageHandlerActivity.executeCustomCodeStageHandler(accountingResult, org);
        if (accountingResult.getTransferMessage() != null && accountingResult.getTransferMessage().contains(CUSTOM_API_ERR)) {
            return accountingResult;
        }
        //update main batch to in-progress
        transferActivity.updateStatusToProgress(accountingResult.getPostBatchId());
        //execute TRANSFER activity in parallel based on number of threads and split batches
        accountingResult = threadExecutor.executeThreadedSteps(totalThreads, accountingResult, org, promiseTransferList,
                ActivityType.TRANSFER.name(), batchIds);
        return accountingResult;
    }

    private ThreadedAccountingResult executeFromTransfer(ThreadedAccountingResult accountingResult, List<ChunkRecord> batchIds, String org,
            ThreadExecutor threadExecutor, int totalThreads, TransferActivity transferActivity, StageHandlerActivity stageHandlerActivity) {
        List<Promise<ThreadedAccountingResult>> promiseTransferList = new ArrayList<>();

        accountingResult.setStageHandlerType(StageHandlerType.BEFORE_POST);
        stageHandlerActivity.executeCustomCodeStageHandler(accountingResult, org);
        if (accountingResult.getTransferMessage() != null && accountingResult.getTransferMessage().contains(CUSTOM_API_ERR)) {
            return accountingResult;
        }
        //update main batch to in-progress
        transferActivity.updateStatusToProgress(accountingResult.getPostBatchId());
        //execute TRANSFER activity in parallel based on number of threads and split batches
        accountingResult = threadExecutor.executeThreadedSteps(totalThreads, accountingResult, org, promiseTransferList,
                ActivityType.TRANSFER.name(), batchIds);
        return accountingResult;
    }

    private ThreadedAccountingResult executeFromTransferSingle(ThreadedAccountingResult accountingResult, List<ChunkRecord> batchIds, String org,
            TransferActivity transferActivity, StageHandlerActivity stageHandlerActivity) {
        accountingResult.setStageHandlerType(StageHandlerType.BEFORE_POST);
        if (accountingResult.getStageHandlerType() == StageHandlerType.BEFORE_POST) {
            accountingResult = stageHandlerActivity.executeCustomCodeStageHandler(accountingResult, org);
        }
        if (accountingResult.getTransferMessage() != null && accountingResult.getTransferMessage().contains(CUSTOM_API_ERR)) {
            return accountingResult;
        }
        //update main batch to in-progress
        transferActivity.updateStatusToProgress(accountingResult.getPostBatchId());
        for (ChunkRecord record : batchIds) {
            accountingResult.setChunkId(record.getChunkId());
            //call transfer activity
            accountingResult = transferActivity.doTransferProcess(accountingResult, org);
        }
        return accountingResult;
    }

    private ThreadedAccountingResult executeFromValidationSingle(ThreadedAccountingResult accountingResult, String org,
            List<ChunkRecord> batchIds) {
        //call validation
        for (ChunkRecord record : batchIds) {
            accountingResult.setChunkId(record.getChunkId());
            accountingResult = validateActivity.validateAccountingProcess(accountingResult, org);
        }
        if (accountingResult.getStageHandlerType() == StageHandlerType.AFTER_UPDATE) {
            accountingResult = handlerActivity.executeCustomCodeStageHandler(accountingResult, org);
        }
        if (accountingResult.getTransferMessage() != null && accountingResult.getTransferMessage().contains(CUSTOM_API_ERR)) {
            return accountingResult;
        }
        accountingResult.setStageHandlerType(StageHandlerType.BEFORE_POST);
        if (accountingResult.getStageHandlerType() == StageHandlerType.BEFORE_POST) {
            accountingResult = handlerActivity.executeCustomCodeStageHandler(accountingResult, org);
        }
        if (accountingResult.getTransferMessage() != null && accountingResult.getTransferMessage().contains(CUSTOM_API_ERR)) {
            return accountingResult;
        }
        //update main batch to in-progress
        transferActivity.updateStatusToProgress(accountingResult.getPostBatchId());
        for (ChunkRecord record : batchIds) {
            accountingResult.setChunkId(record.getChunkId());
            //call transfer activity
            accountingResult = transferActivity.doTransferProcess(accountingResult, org);
        }

        return accountingResult;
    }
}
