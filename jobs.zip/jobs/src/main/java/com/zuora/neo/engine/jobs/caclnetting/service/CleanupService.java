package com.zuora.neo.engine.jobs.caclnetting.service;

import com.zuora.neo.engine.common.ScheduleTypes;
import com.zuora.neo.engine.jobs.caclnetting.config.CaclProperties;
import com.zuora.neo.engine.jobs.caclnetting.constants.NettingReversalFlags;
import com.zuora.neo.engine.jobs.caclnetting.db.dao.CaclNettingDao;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import com.google.common.annotations.VisibleForTesting;

import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class CleanupService {

    final NeoWorkflowLogger neoWorkflowLogger;
    final CaclProperties caclProperties;

    static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CleanupService.class);

    public CleanupService(NeoWorkflowLogger neoWorkflowLogger, CaclProperties caclProperties) {
        this.neoWorkflowLogger = neoWorkflowLogger;
        this.caclProperties = caclProperties;
    }

    public void deleteNetRc(CaclNettingDao nettingDao, BigDecimal batchId) {
        // deletes from rpro_cacl_net_rc using batchId

        nettingDao.deleteNetRc(batchId, caclProperties.getCaclNetRc(), caclProperties.getBookId(),
                caclProperties.getClientId(), caclProperties.getOrgId());

    }

    /**
     * Will remove existing HEAD_PERIOD entries in current period
    */
    @VisibleForTesting
    void removeHeaderEntries(CaclNettingDao nettingDao, BigDecimal batchId) {
        long prdId = caclProperties.getPeriodDetails().getCurrentPeriodId();
        int removedNettingEntries = nettingDao.removeNettingHeaders(batchId, prdId, caclProperties.getCaclNetRc(),
                caclProperties.getHeadPeriod(), caclProperties.getBookId(), caclProperties.getClientId(), caclProperties.getOrgId());
        LOGGER.info("Removed {} netting header entries", removedNettingEntries);
    }

    @VisibleForTesting
    void removeIntermediateEntries(CaclNettingDao nettingDao, BigDecimal batchId) {
        long prdId = caclProperties.getPeriodDetails().getCurrentPeriodId();
        int cleanedIntermediateEntries = nettingDao.cleanIntermediateEntries(prdId, batchId,
                caclProperties.getCaclNetRc(), caclProperties.getBookId(),
                caclProperties.getClientId(), caclProperties.getOrgId());
        LOGGER.info("Removed {} intermediate entries", cleanedIntermediateEntries);
    }

    @VisibleForTesting
    void removeScheduleEntries(CaclNettingDao nettingDao, BigDecimal batchId) {
        long prdId = caclProperties.getPeriodDetails().getCurrentPeriodId();
        long nextPeriodId = caclProperties.getPeriodDetails().getNextPeriodId();

        int resultCount;

        resultCount = nettingDao.deleteUnpostedSchedules(batchId, prdId, nextPeriodId,
                ScheduleTypes.NETTING.getScheduleType(), NettingReversalFlags.REVERSAL.getFlag(),
                caclProperties.getCaclNetRc(), caclProperties.getScheduleTable(),
                caclProperties.getBookId(), caclProperties.getClientId(), caclProperties.getOrgId());

        LOGGER.info("Deleted {} unposted schedules", resultCount);

        String flag = "INTERFACED:N#REVERSAL:";
        String postedNettingReversal = flag + NettingReversalFlags.POSTED_NETTING_REVERSAL.getFlag();
        String postedReversalOfReversal = flag + NettingReversalFlags.POSTED_REVERSAL_OF_REVERSAL.getFlag();

        resultCount = nettingDao.reversePostedSchedules(batchId, prdId, nextPeriodId,
                ScheduleTypes.NETTING.getScheduleType(), NettingReversalFlags.REVERSAL.getFlag(),
                caclProperties.getScheduleSequence(), postedNettingReversal, postedReversalOfReversal,
                caclProperties.getCaclNetRc(), caclProperties.getScheduleTable(), caclProperties.getUser(),
                caclProperties.getBookId(), caclProperties.getClientId(), caclProperties.getOrgId());

        LOGGER.info("Reversed {} posted schedules", resultCount);

        flag = "REVERSAL:";
        String postedNettingUpdate = flag + NettingReversalFlags.POSTED_NETTING_UPDATE.getFlag();
        String postedReversalUpdate = flag + NettingReversalFlags.POSTED_REVERSAL_UPDATE.getFlag();

        resultCount = nettingDao.updatePostedSchedules(batchId, prdId, nextPeriodId,
                ScheduleTypes.NETTING.getScheduleType(), NettingReversalFlags.REVERSAL.getFlag(),
                postedNettingUpdate, postedReversalUpdate,
                caclProperties.getCaclNetRc(), caclProperties.getScheduleTable(),
                caclProperties.getUser(), caclProperties.getBookId(), caclProperties.getClientId(), caclProperties.getOrgId());

        LOGGER.info("Updated {} posted schedules", resultCount);
    }

    public void cleanCurrentPeriodData(CaclNettingDao nettingDao, BigDecimal batchId) {
        removeIntermediateEntries(nettingDao, batchId);
        removeHeaderEntries(nettingDao, batchId);
        removeScheduleEntries(nettingDao, batchId);
    }


}
