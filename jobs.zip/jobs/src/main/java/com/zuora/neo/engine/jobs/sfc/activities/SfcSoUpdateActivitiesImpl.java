package com.zuora.neo.engine.jobs.sfc.activities;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.common.util.CommonUtils;
import com.zuora.neo.engine.db.api.Account;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.sfc.SfcResult;
import com.zuora.neo.engine.jobs.sfc.config.SfcConfigProperties;
import com.zuora.neo.engine.jobs.sfc.constants.SfcConstants;
import com.zuora.neo.engine.jobs.sfc.constants.SfcStatus;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;
import com.zuora.neo.engine.jobs.sfc.db.mapper.SfcStatusValuesMapper;
import com.zuora.neo.engine.jobs.sfc.service.SfcDbCacheContextService;
import com.zuora.neo.engine.jobs.sfc.service.SoUpdateService;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.result.ResultIterable;
import org.jdbi.v3.core.statement.OutParameters;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@ActivityImplementation
@Component
public class SfcSoUpdateActivitiesImpl implements SfcSoUpdateActivities {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcSoUpdateActivitiesImpl.class);

    @Autowired
    SoUpdateService soUpdateService;
    @Autowired
    SfcDbCacheContextService sfcDbCacheContextService;
    @Autowired
    private SfcConfigProperties sfcConfigProperties;

    /*
        Activity Method called from the Workflow.
        This method queries the SFC Table to get all records with the following status and process it.
        - Ripped
        - SO Updated
        - Payment Details Updated
        This processes by batch by calling SoUpdateService to process the records whose SO is updated.
     */
    @Override
    public SfcResult soUpdateSfc(SfcResult sfcResult) {

        LOGGER.debug("SO Update SFC Activity initiated");
        int batchSize = sfcConfigProperties.getBatchSize();
        int fetchSize = sfcConfigProperties.getFetchSize();
        Jdbi jdbi = DbContext.getConnection();
        WorkflowContext context = WorkflowContextManager.getWorkflowContext();
        WorkflowRequest request = context.getRequest();
        jdbi.useTransaction(handle -> {
            List<String> sfcSoUpdateStatusValues = new ArrayList<>();
            sfcSoUpdateStatusValues.add(SfcStatus.RIPPED.getStatus());
            sfcSoUpdateStatusValues.add(SfcStatus.SO_UPDATED.getStatus());
            sfcSoUpdateStatusValues.add(SfcStatus.PAYMENT_UPDATED.getStatus());

            CommonDao commonDao = handle.attach(CommonDao.class);

            SfcDbCacheContext sfcDbCacheContext = sfcDbCacheContextService.fetchCommonDetailsFromDb(handle);
            List<Account> accountTableList = commonDao.getAccountTable();
            if (accountTableList.isEmpty()) {
                NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, SfcConstants.NO_ACCOUNTS_PRESENT);
            }
            sfcDbCacheContext.setAccountTableList(accountTableList);

            ResultIterable iterable = handle.createQuery(SfcConstants.SFC_STATUS_LIST_QUERY)
                    .bindList("status", sfcSoUpdateStatusValues)
                    .setFetchSize(fetchSize)
                    .map(new SfcStatusValuesMapper());
            Iterator<SfcStatusValues> iterator = iterable.iterator();
            while (iterator.hasNext()) {
                List<SfcStatusValues> sfcStatusValuesList = CommonUtils.chunk(iterator, batchSize);
                if (!sfcStatusValuesList.isEmpty()) {
                    LOGGER.debug("Executing SFC SO Update Process for first " + sfcStatusValuesList.size() + " lines");
                    soUpdateService.processUpdatedSo(sfcStatusValuesList, sfcDbCacheContext, sfcResult, handle);
                } else {
                    break;
                }
            }
        });

        jdbi.useTransaction(handle -> {
            SfcDao sfcDao = handle.attach(SfcDao.class);
            OutParameters outParameters = sfcDao.callRealTimeSummarization(request.getOrgId(), request.getClientId());
            Integer returnCode = outParameters.getInt("p_retcode");
            String errMsg = outParameters.getString("p_errbuf");
            LOGGER.debug("After calling call_realtime_summ proc errMsg is " + errMsg + " returnCode is " + returnCode);
        });

        return sfcResult;
    }
}
