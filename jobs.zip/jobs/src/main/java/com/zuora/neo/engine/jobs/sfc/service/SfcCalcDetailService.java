package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.PreparedBatch;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Service
public class SfcCalcDetailService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcCalcDetailService.class);

    private static final String INSERT_SFC_CALC_DET_QUERY =
            "INSERT INTO rpro_sfc_calc_det (id, rc_id, line_id, receivable_begin, receivable_end, npv_receivable, interest,"
                    + " prd_id, client_id, crtd_prd_id, sec_atr_val, book_id, crtd_by, crtd_dt, updt_by, updt_dt, "
                    + " indicators, start_date, end_date) VALUES "
                    + " (rpro_utility_pkg.generate_id ('RPRO_SFC_CALC_DET_ID_S', :client_id), :rc_id, :line_id, :receivable_begin,"
                    + " :receivable_end, :npv_receivable, :interest, :prd_id, "
                    + " :client_id, :crtd_prd_id, :sec_atr_val, :book_id, :crtd_by, :crtd_dt, :updt_by, :updt_dt, :indicators,"
                    + " :start_date, :end_date )";

    private static final String INSERT_SFC_CALC_DET_H_QUERY =
            "INSERT INTO rpro_sfc_calc_det_h (id, rc_id, line_id, receivable_begin, receivable_end, npv_receivable, interest,"
                    + " prd_id, client_id, crtd_prd_id, sec_atr_val, book_id, crtd_by, crtd_dt, updt_by, updt_dt, "
                    + " indicators, start_date, end_date) VALUES "
                    + " (rpro_utility_pkg.generate_id ('RPRO_SFC_CALC_DET_ID_S', :client_id), :rc_id, :line_id, :receivable_begin,"
                    + " :receivable_end, :npv_receivable, :interest, :prd_id, "
                    + " :client_id, :crtd_prd_id, :sec_atr_val, :book_id, :crtd_by, :crtd_dt, :updt_by, :updt_dt, :indicators,"
                    + " :start_date, :end_date )";

    public SfcCalcDetails populateSfcCalcDetail(WorkflowRequest request, List<RcLineDetails> rcLineDetails,
            CalendarDetails calendarDetail, BigDecimal rebBegin, BigDecimal rebEndAfInt, BigDecimal npvReb, BigDecimal interest, long createdPeriodId,
            Date scheduleStartDate, Date scheduleEndDate) {

        SfcCalcDetails sfcCalcDetail = new SfcCalcDetails(request.getClientId());
        sfcCalcDetail.setRcId(rcLineDetails.get(0).getRcId());
        sfcCalcDetail.setLineId(rcLineDetails.get(0).getId());
        sfcCalcDetail.setReceivableBegin(rebBegin);
        sfcCalcDetail.setReceivableEnd(rebEndAfInt);
        sfcCalcDetail.setNpvReceivable(npvReb);
        sfcCalcDetail.setInterest(interest);
        sfcCalcDetail.setPeriodId(calendarDetail.getId());
        sfcCalcDetail.setClientId(rcLineDetails.get(0).getClientId());
        sfcCalcDetail.setCreatedPeriodId(createdPeriodId);
        sfcCalcDetail.setSecAtrVal(rcLineDetails.get(0).getSecAtrVal());
        sfcCalcDetail.setBookId(rcLineDetails.get(0).getBookId());
        sfcCalcDetail.setIndicators("NNNNNNNNNNNNNNNNNNNN");
        sfcCalcDetail.setStartDate(scheduleStartDate);
        sfcCalcDetail.setEndDate(scheduleEndDate);

        return sfcCalcDetail;
    }

    public void insertSfcCalcDetailsBatch(List<SfcCalcDetails> sfcCalcDetailsBatch, Handle handle) {

        PreparedBatch insertSfcCalcDetailsBatch = handle.prepareBatch(INSERT_SFC_CALC_DET_QUERY);

        for (SfcCalcDetails sfcCalcDetail : sfcCalcDetailsBatch) {
            bindSfcCalcDetailsForInsert(insertSfcCalcDetailsBatch, sfcCalcDetail);
        }
        doBulkInsertSfcCalcDetails(insertSfcCalcDetailsBatch);

    }

    public void insertSfcCalcDetailsHistoryBatch(List<SfcCalcDetails> sfcCalcDetailsHistoryBatch, Handle handle) {

        PreparedBatch insertSfcCalcDetailsBatch = handle.prepareBatch(INSERT_SFC_CALC_DET_H_QUERY);
        for (SfcCalcDetails sfcCalcDetail : sfcCalcDetailsHistoryBatch) {
            bindSfcCalcDetailsForInsert(insertSfcCalcDetailsBatch, sfcCalcDetail);
        }

        doBulkInsertSfcCalcDetails(insertSfcCalcDetailsBatch);

    }

    public void doBulkInsertSfcCalcDetails(PreparedBatch insertSfcCalcDetailsBatch) {

        LOGGER.info("Insert SFC Calc Data Batch Size : " + insertSfcCalcDetailsBatch.size());
        int[] insertCount = insertSfcCalcDetailsBatch.execute();
        LOGGER.info("Number of Records updated Rc Line Pa Data Batch Size : " + insertCount.length);

    }

    public void bindSfcCalcDetailsForInsert(PreparedBatch insertSfcCalcDetailsBatch, SfcCalcDetails sfcCalcDetail) {
        insertSfcCalcDetailsBatch.bind("rc_id", sfcCalcDetail.getRcId())
                .bind("line_id", sfcCalcDetail.getLineId())
                .bind("receivable_begin", sfcCalcDetail.getReceivableBegin())
                .bind("receivable_end", sfcCalcDetail.getReceivableEnd())
                .bind("npv_receivable", sfcCalcDetail.getNpvReceivable())
                .bind("interest", sfcCalcDetail.getInterest())
                .bind("prd_id", sfcCalcDetail.getPeriodId())
                .bind("client_id", sfcCalcDetail.getClientId())
                .bind("crtd_prd_id", sfcCalcDetail.getCreatedPeriodId())
                .bind("sec_atr_val", sfcCalcDetail.getSecAtrVal())
                .bind("book_id", sfcCalcDetail.getBookId())
                .bind("crtd_by", sfcCalcDetail.getCreatedBy())
                .bind("crtd_dt", sfcCalcDetail.getCreatedDate())
                .bind("updt_by", sfcCalcDetail.getUpdatedBy())
                .bind("updt_dt", sfcCalcDetail.getUpdatedDate())
                .bind("indicators", sfcCalcDetail.getIndicators())
                .bind("start_date", sfcCalcDetail.getStartDate())
                .bind("end_date", sfcCalcDetail.getEndDate()).add();
    }
}
