package com.zuora.neo.engine.jobs.archival.activities;

import static com.zuora.neo.engine.jobs.archival.common.Constants.Observability.ARCHIVAL_RECORDS_COPY_PER_TABLE_PREFIX;
import static com.zuora.neo.engine.jobs.archival.common.Constants.Observability.ARCHIVAL_RECORDS_COPY_STATS_PER_TABLE_PREFIX;
import static com.zuora.neo.engine.jobs.archival.common.Constants.Observability.ARCHIVAL_RECORDS_COPY_TIME_PER_TABLE_PREFIX;
import static com.zuora.neo.engine.jobs.archival.common.Constants.Observability.ARCHIVAL_RECORDS_DELETE_PER_TABLE_PREFIX;
import static com.zuora.neo.engine.jobs.archival.common.Constants.Observability.ARCHIVAL_RECORDS_DELETE_STATS_PER_TABLE_PREFIX;
import static com.zuora.neo.engine.jobs.archival.common.Constants.Observability.ARCHIVAL_RECORDS_DELETE_TIME_PER_TABLE_PREFIX;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.common.util.CommonUtils;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.jobs.archival.ArchivalResult;
import com.zuora.neo.engine.jobs.archival.common.ArchivalMetrics;
import com.zuora.neo.engine.jobs.archival.common.ConfProperties;
import com.zuora.neo.engine.jobs.archival.common.Constants.Observability;
import com.zuora.neo.engine.jobs.archival.common.QueryLogger;
import com.zuora.neo.engine.jobs.archival.db.model.ArchivalSettingsEntity;
import com.zuora.neo.engine.jobs.archival.db.model.DataArchivalTable;
import com.zuora.neo.engine.jobs.archival.enums.ArchivalStatus;
import com.zuora.neo.engine.jobs.archival.enums.BatchStatus;
import com.zuora.neo.engine.jobs.archival.exceptions.ArchivalException;
import com.zuora.neo.engine.jobs.archival.service.ArchivalTableService;

import com.uber.m3.tally.Scope;
import com.uber.m3.tally.Stopwatch;
import io.temporal.activity.Activity;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.Update;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * @author Zuora Implementation of {@link MirrorActivity}
 */

@ActivityImplementation
@Component
public class MirrorActivityImpl implements MirrorActivity {

    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(MirrorActivityImpl.class);

    private String revproSchemaName;

    private List<DataArchivalTable> archivalOrDeletableTables;

    private ArchivalSettingsEntity archivalSettings;

    private ArchivalResult result;

    private ArchivalMetrics archivalMetrics;

    private int failureCount = 0;
    private final StringBuilder batchFailureMessage = new StringBuilder();

    private final ArchivalTableService archivalTableService;

    private  final QueryLogger queryLogger;

    private Scope metricsScope;
    @Autowired
    private ConfProperties confProperties;


    MirrorActivityImpl(ArchivalTableService archivalTableService, QueryLogger queryLogger) {
        this.archivalTableService = archivalTableService;
        this.queryLogger = queryLogger;
    }

    @Override
    public ArchivalResult processArchivalRecords() {
        logger.debug("Started executing mirror workflow.");

        result = new ArchivalResult();

        int totalExpiredRcs;
        long batchId = WorkflowContextManager.getWorkflowContext().getRequest().getRequestId();
        int jobMonitorCount = 0;

        setTaggedScope();

        List<Long> expiredRcs;
        Jdbi jdbi = DbContext.getConnection();
        jdbi.setSqlLogger(queryLogger);

        try (Handle h = jdbi.open()) {
            if (!archivalTableService.isArchivalEnabled(h)) {
                result.setStatus(ArchivalStatus.ARCHIVAL_NOT_ENABLED);
                result.setMessage("Archival is not enabled for this tenant.");
                result.isRetryPossible(false);
                return result;
            }
            archivalSettings = archivalTableService.getArchivalSettings(h, "DATA_ARCHIVE");
            this.queryLogger.setLogQuery(archivalSettings.isLogQuery());
            int unProcessedEntriesCount = archivalTableService.clearUnProcessedEntriesFromPreviousBatch(h);
            if (unProcessedEntriesCount > 0) {
                logger.info("Removed " + unProcessedEntriesCount + " unprocessed entry/es from the rc-head-g table");
            }
            archivalOrDeletableTables = archivalTableService.fetchArchivalTables(h);
            if (archivalOrDeletableTables.isEmpty()) {
                result.setStatus(ArchivalStatus.DATA_ERROR);
                result.setMessage("Archival Meta data table is empty");
                result.isRetryPossible(false);
                return result;
            }
            logger.debug("Calling SP to update copy Query");
            archivalTableService.updateCopyQueryInDaTable(h);
            revproSchemaName = archivalTableService.getSchemaName(h);
            logger.debug("SchemaName::" + revproSchemaName);
            logger.info("Total number of archival or deletable tables : " + archivalOrDeletableTables.size());

            totalExpiredRcs = archivalTableService.insertHeadGDetails(h, archivalSettings);
            expiredRcs = archivalTableService.getExpiredRcs(h, batchId, BatchStatus.NEW.label, archivalSettings.getBatchSize());
            if (expiredRcs.isEmpty()) {
                result.setStatus(ArchivalStatus.EMPTY_BATCH);
                result.setMessage("No expired rc's found to migrate");
                result.isRetryPossible(false);
                return result;
            }

            archivalMetrics = new ArchivalMetrics(archivalOrDeletableTables.stream().map(DataArchivalTable::getName).collect(Collectors.toList()));

            AtomicInteger currentFailureCount = new AtomicInteger();
            while (!expiredRcs.isEmpty()) {
                if (pendingJobExistsInQueue(h, batchId)) {
                    if (jobMonitorCount <= confProperties.getMaxCount()) {
                        logger.info("Archival process is in sleep mode.");
                        Thread.sleep(confProperties.getTimeout());
                        jobMonitorCount++;
                        continue;
                    }
                    result.isRetryPossible(false);
                    result.setStatus(ArchivalStatus.PARTIAL_COPIED);
                    result.setMessage("The batch execution was halted due to interference from another long-running job.");
                    return result;
                }
                updateQueryLogging(h);
                final List<Long> finalExpiredRcs = expiredRcs;
                if (CommonUtils.isActivityCancelled(logger)) {
                    result.setStatus(ArchivalStatus.ACTIVITY_CANCELLED);
                    result.setMessage("Activity is cancelled by the temporal cluster ");
                    result.isRetryPossible(false);
                    return result;
                }
                Stopwatch batchTimer = metricsScope.timer(Observability.ARCHIVAL_BATCH_TIMER).start();
                boolean continueBatch = performCopyAndDelete(batchId, h, currentFailureCount, finalExpiredRcs, totalExpiredRcs);
                batchTimer.stop();
                if (!continueBatch) {
                    return result;
                }
                expiredRcs = archivalTableService.getExpiredRcs(h,batchId, BatchStatus.NEW.label, archivalSettings.getBatchSize());
            }
            if (failureCount > 0) {
                result.isRetryPossible(false);
                result.setStatus(ArchivalStatus.PARTIAL_COPIED);
                result.setMessage("Batch failed " + failureCount + " time/s and the cause is " + batchFailureMessage);
                return result;
            }
            return result;
        } catch (InterruptedException e) {
            result.isRetryPossible(false);
            result.setStatus(ArchivalStatus.PARTIAL_COPIED);
            result.setMessage("Batch execution has been interrupted and the cause is " + batchFailureMessage);
            return result;
        }
    }

    private void setTaggedScope() {
        Map<String, String> tags = new HashMap<>();
        tags.put("tenantId", WorkflowContextManager.getWorkflowContext().getRequest().getTenantId());
        metricsScope = Activity.getExecutionContext().getMetricsScope().tagged(tags);
    }

    private boolean performCopyAndDelete(long batchId, Handle h, AtomicInteger currentFailureCount, List<Long> finalExpiredRcs, int totalExpiredRcs) {
        try {
            h.useTransaction(handle -> {
                Stopwatch copyTimer = metricsScope.timer(Observability.ARCHIVAL_BATCH_TIMER_COPY).start();
                int copiedRecordsCount = copyBatch(handle, finalExpiredRcs);
                copyTimer.stop();
                Stopwatch deleteTimer = metricsScope.timer(Observability.ARCHIVAL_BATCH_TIMER_DELETE).start();
                int deletedRecordsCount = deleteBatch(handle, finalExpiredRcs);
                deleteTimer.stop();
                currentFailureCount.set(0);
                logger.info("Total number of records copied " + copiedRecordsCount + " and deleted "
                        + deletedRecordsCount + " for batch " + batchId);
                metricsScope.counter(Observability.ARCHIVAL_TOTAL_RECORDS_COPY).inc(copiedRecordsCount);
            });
            return true;
        } catch (Exception e) {
            failureCount++;
            batchFailureMessage.append(failureCount + ":" + e.getMessage() + "\n");
            logger.error("Error while processing the records::" + e.getMessage());
            markBatchAsFailed(h,currentFailureCount,finalExpiredRcs);
            if ((currentFailureCount.get() > archivalSettings.getSuccessiveBatchUpdateFailureThreshold())
                    || (maxFailureThresholdExceeded(totalExpiredRcs, failureCount))) {
                logger.error("Successive batch failed for more than " + failureCount + " times. " + e.getMessage());
                result.setStatus(ArchivalStatus.COPY_FAILED);
                result.isRetryPossible(false);
                result.setMessage("Successive batch failed for more than " + failureCount + " times. Reason :" + e.getMessage());
                return false;
            }
            return true;
        }
    }

    private boolean maxFailureThresholdExceeded(int totalRcs, int failureCount) {
        int batches = Math.floorDiv(totalRcs, archivalSettings.getBatchSize());
        int maxFailureCount = (int) Math.floor(batches * archivalSettings.getMaxFailureAttemptsInPercentage());
        return failureCount > maxFailureCount;
    }

    private int copyBatch(Handle handle, List<Long> expiredRcs) {
        int copiedRecordsCount = 0;
        String tableName = "";
        try {
            for (DataArchivalTable table : archivalOrDeletableTables) {
                tableName = table.getName();
                String copyFilterQuery = table.getCopyFilterQuery().replace("l_revpro_schema",revproSchemaName);
                Update update = handle.createUpdate(copyFilterQuery);
                update.bindList("rcIds", expiredRcs);
                Stopwatch watch = metricsScope.timer(ARCHIVAL_RECORDS_COPY_TIME_PER_TABLE_PREFIX + tableName).start();
                int count =  update.execute();
                watch.stop();
                logger.debug("Copied " + count + " records from " + tableName);
                metricsScope.counter(ARCHIVAL_RECORDS_COPY_PER_TABLE_PREFIX + tableName).inc(count);
                metricsScope.gauge(ARCHIVAL_RECORDS_COPY_STATS_PER_TABLE_PREFIX + tableName)
                        .update(archivalMetrics.updateCopyCountersForTable(tableName, (double) count));
                copiedRecordsCount += count;
            }

            archivalTableService.insertRcMapping(handle, expiredRcs);
            int copyStatusCount = archivalTableService.updateBatchStatus(handle, BatchStatus.COPIED.label, expiredRcs);
            logger.debug("Copy status count::" + copyStatusCount);
            return copiedRecordsCount;

        } catch (RuntimeException e) {
            logger.error("Failed to copy the data for table " + tableName + " " + e.getMessage() + " rc ids" + expiredRcs);
            throw new ArchivalException("Failed to perform copy to Mirror for table " + tableName + " " + e.getMessage(), e);
        }

    }

    private int deleteBatch(Handle handle, List<Long> expiredRcs) {
        int deletedRecordsCount = 0;
        String tableName = "";
        try {
            for (DataArchivalTable table : archivalOrDeletableTables) {

                String deleteQuery = table.getDeleteFilterQuery();
                tableName = table.getName();
                Update statement = handle.createUpdate(deleteQuery);
                statement.bindList("rcIds", expiredRcs);
                Stopwatch watch = metricsScope.timer(ARCHIVAL_RECORDS_DELETE_TIME_PER_TABLE_PREFIX + tableName).start();
                int count =  statement.execute();
                watch.stop();
                logger.debug("Deleted " + count + " records from " + tableName + " in : " + watch);
                metricsScope.counter(ARCHIVAL_RECORDS_DELETE_PER_TABLE_PREFIX + tableName).inc(count);
                metricsScope.gauge(ARCHIVAL_RECORDS_DELETE_STATS_PER_TABLE_PREFIX + tableName)
                        .update(archivalMetrics.updateDeleteCountersForTable(tableName, (double) count));
                deletedRecordsCount += count;
            }
            archivalTableService.updateBatchStatus(handle,BatchStatus.MOVED.label, expiredRcs);
            return deletedRecordsCount;
        } catch (RuntimeException e) {
            logger.error("Failed to delete  the data for table " + tableName + " " + e.getMessage() + " rc ids" + expiredRcs);
            throw new ArchivalException("Failed while deleting the records from original schema", e);
        }

    }

    private void markBatchAsFailed(Handle h, AtomicInteger failureCount, List<Long> finalExpiredRcs) {
        try {
            h.useTransaction(handle -> archivalTableService.updateBatchStatus(handle,BatchStatus.EXCEPTION.label, finalExpiredRcs));
        } catch (Exception ex) {
            logger.error("Setting the batch status failed as well", ex);
            failureCount.incrementAndGet();
        }
    }

    private void updateQueryLogging(Handle h) {
        ArchivalSettingsEntity newSettings = archivalTableService.getArchivalSettings(h, "DATA_ARCHIVE");
        archivalSettings.setLogQuery(newSettings.isLogQuery());
        this.queryLogger.setLogQuery(newSettings.isLogQuery());
    }

    private boolean pendingJobExistsInQueue(Handle h, long batchId) {
        return archivalTableService.checkIfJobIsRunning(h, batchId);
    }
}
