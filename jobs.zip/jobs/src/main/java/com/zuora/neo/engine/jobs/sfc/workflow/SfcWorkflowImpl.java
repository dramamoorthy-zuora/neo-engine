package com.zuora.neo.engine.jobs.sfc.workflow;

import com.zuora.neo.engine.annotations.workflow.WorkflowImplementation;
import com.zuora.neo.engine.jobs.sfc.SfcResult;
import com.zuora.neo.engine.jobs.sfc.activities.SfcNpvCalculationActivities;
import com.zuora.neo.engine.jobs.sfc.activities.SfcPaymentProcessActivities;
import com.zuora.neo.engine.jobs.sfc.activities.SfcPostProcessActivities;
import com.zuora.neo.engine.jobs.sfc.activities.SfcPreProcessActivities;
import com.zuora.neo.engine.jobs.sfc.activities.SfcSoUpdateActivities;
import com.zuora.neo.engine.jobs.sfc.constants.SfcConstants;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.workflow.Workflow;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@WorkflowImplementation
public class SfcWorkflowImpl implements SfcWorkflow {


    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcWorkflowImpl.class);

    private final SfcSoUpdateActivities sfcSoUpdateActivity = Workflow.newActivityStub(SfcSoUpdateActivities.class);
    private final SfcPreProcessActivities sfcPreProcessActivity = Workflow.newActivityStub(SfcPreProcessActivities.class);
    private final SfcPaymentProcessActivities sfcPaymentProcessActivity = Workflow.newActivityStub(SfcPaymentProcessActivities.class);
    private final SfcNpvCalculationActivities sfcNpvCalculationActivity = Workflow.newActivityStub(SfcNpvCalculationActivities.class);
    private final SfcPostProcessActivities sfcPostProcessActivity = Workflow.newActivityStub(SfcPostProcessActivities.class);

    @Override
    public WorkflowResponse processSfc() {
        LOGGER.debug("SFC Workflow initiated");
        SfcResult sfcResult = new SfcResult();
        SfcResult sfcSoUpdateResult = sfcSoUpdateActivity.soUpdateSfc(sfcResult);
        SfcResult sfcPreProcessResult = sfcPreProcessActivity.preProcessSfc(sfcSoUpdateResult);
        SfcResult sfcPaymentProcessResult = sfcPaymentProcessActivity.paymentProcessSfc(sfcPreProcessResult);
        SfcResult sfcNpvCalculationResult = sfcNpvCalculationActivity.calculateNpvInterest(sfcPaymentProcessResult);
        SfcResult sfcPostProcessResult = sfcPostProcessActivity.postProcessSfc(sfcNpvCalculationResult);

        if (sfcPostProcessResult.getWarningCount() > 0) {
            return new WorkflowResponse(RevenueJobStatus.WARNING, SfcConstants.WARNING_RESPONSE_SFC);
        }

        return new WorkflowResponse(RevenueJobStatus.COMPLETED, "");
    }

}
