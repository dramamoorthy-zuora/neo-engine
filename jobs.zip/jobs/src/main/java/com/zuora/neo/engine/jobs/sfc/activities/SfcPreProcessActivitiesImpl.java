package com.zuora.neo.engine.jobs.sfc.activities;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.common.util.CommonUtils;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.jobs.sfc.SfcResult;
import com.zuora.neo.engine.jobs.sfc.config.SfcConfigProperties;
import com.zuora.neo.engine.jobs.sfc.constants.SfcConstants;
import com.zuora.neo.engine.jobs.sfc.constants.SfcStatus;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.mapper.SfcStatusValuesMapper;
import com.zuora.neo.engine.jobs.sfc.service.SfcBatchProcessingService;
import com.zuora.neo.engine.jobs.sfc.service.SfcDbCacheContextService;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.result.ResultIterable;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.List;

@ActivityImplementation
@Component
public class SfcPreProcessActivitiesImpl implements  SfcPreProcessActivities {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcPreProcessActivitiesImpl.class);

    @Autowired
    SfcBatchProcessingService sfcBatchProcessingService;

    @Autowired
    private SfcConfigProperties sfcConfigProperties;

    @Autowired
    private SfcDbCacheContextService sfcDbCacheContextService;

    /*
        Activity Method called from the Workflow.
        This method queries the SFC Table to get all records with Ready for SFC Status and process it
        by batch by calling SfcBatchProcessingService to pre process the records.
     */
    @Override
    public SfcResult preProcessSfc(SfcResult sfcResult) {
        LOGGER.debug("Pre Process SFC Activity initiated");
        int batchSize = sfcConfigProperties.getBatchSize();
        int fetchSize = sfcConfigProperties.getFetchSize();

        Jdbi jdbi = null;
        WorkflowContext context = WorkflowContextManager.getWorkflowContext();
        WorkflowRequest request = context.getRequest();
        jdbi = DbContext.getConnection();
        jdbi.useTransaction(handle -> {
            SfcDbCacheContext sfcDbCacheContext = sfcDbCacheContextService.fetchCommonDetailsFromDb(handle);

            ResultIterable iterable = handle.createQuery(SfcConstants.SFC_STATUS_TABLE_QUERY_ONE_STATUS)
                    .bind("status", SfcStatus.READY_FOR_SFC.getStatus())
                    .setFetchSize(fetchSize)
                    .map(new SfcStatusValuesMapper());
            Iterator<SfcStatusValues> iterator = iterable.iterator();
            while (iterator.hasNext()) {
                List<SfcStatusValues> sfcStatusValuesList = CommonUtils.chunk(iterator, batchSize);
                if (!sfcStatusValuesList.isEmpty()) {
                    LOGGER.debug("Executing SFC Process for first " + sfcStatusValuesList.size() + " lines");
                    sfcBatchProcessingService.processSfcForBatch(sfcStatusValuesList, sfcDbCacheContext, sfcResult, request, handle);
                } else {
                    break;
                }
            }
        });

        return sfcResult;
    }
}
