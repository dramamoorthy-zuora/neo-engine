package com.zuora.neo.engine.jobs.rtp.constants;

public class RtpConstants {

    public static final String RTP_WI_HEADERS_BATCH_QUERY =  "UPDATE rpro_rtp_wi_header SET batch_id = :batch_id, status = :to_status WHERE "
            +   "sec_atr_val = :sec_atr_val AND status = :status %s AND ROWNUM <= :batch_size";

    public static final String RTP_WI_HEADERS_QUERY_RC_ID_WHERE_CLAUSE = " AND rc_id IN (<rc_ids>)";

    public static final int RTP_WI_HEADERS_MAX_RETRY_COUNT = 5;

    public static final String REALTIME_PROCESS = "REALTIME PROCESS";

    public static final String REALTIME_PROCESS_IN_PROGRESS = "Real-time process in progress";

    public static final String RTP_DISABLED = "RTP workflow is disabled";

    public static final String UNABLE_TO_LOCK = "Unable to lock application - ";

    public static final String INVALID_STEP_ID = "Invalid step id - ";

}
