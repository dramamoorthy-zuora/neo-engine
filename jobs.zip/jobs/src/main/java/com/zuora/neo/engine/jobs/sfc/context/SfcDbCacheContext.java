package com.zuora.neo.engine.jobs.sfc.context;

import com.zuora.neo.engine.db.api.Account;
import com.zuora.neo.engine.db.api.AccountValue;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;

import java.util.List;
import java.util.Map;

public class SfcDbCacheContext {

    Map<String, Integer> currencyMap;
    List<FinanceTypeValues> financeTypeValuesList;
    Map<String, String> paramsMap;
    List<AccountValue> accountValuesList;
    List<Account> accountTableList;
    List<CalendarDetails> calendarDetailsCache;
    List<CalendarDetails> calendarDetails;
    long bookId;
    long currentPeriodId;
    String segmentDelimiter;

    public Map<String, Integer> getCurrencyMap() {
        return currencyMap;
    }

    public void setCurrencyMap(Map<String, Integer> currencyMap) {
        this.currencyMap = currencyMap;
    }

    public List<FinanceTypeValues> getFinanceTypeValuesList() {
        return financeTypeValuesList;
    }

    public void setFinanceTypeValuesList(List<FinanceTypeValues> financeTypeValuesList) {
        this.financeTypeValuesList = financeTypeValuesList;
    }

    public Map<String, String> getParamsMap() {
        return paramsMap;
    }

    public void setParamsMap(Map<String, String> paramsMap) {
        this.paramsMap = paramsMap;
    }

    public List<AccountValue> getAccountValuesList() {
        return accountValuesList;
    }

    public void setAccountValuesList(List<AccountValue> accountValuesList) {
        this.accountValuesList = accountValuesList;
    }

    public List<Account> getAccountTableList() {
        return accountTableList;
    }

    public void setAccountTableList(List<Account> accountTableList) {
        this.accountTableList = accountTableList;
    }

    public List<CalendarDetails> getCalendarDetailsCache() {
        return calendarDetailsCache;
    }

    public void setCalendarDetailsCache(List<CalendarDetails> calendarDetailsCache) {
        this.calendarDetailsCache = calendarDetailsCache;
    }

    public List<CalendarDetails> getCalendarDetails() {
        return calendarDetails;
    }

    public void setCalendarDetails(List<CalendarDetails> calendarDetails) {
        this.calendarDetails = calendarDetails;
    }

    public long getBookId() {
        return bookId;
    }

    public void setBookId(long bookId) {
        this.bookId = bookId;
    }

    public long getCurrentPeriodId() {
        return currentPeriodId;
    }

    public void setCurrentPeriodId(long currentPeriodId) {
        this.currentPeriodId = currentPeriodId;
    }

    public String getSegmentDelimiter() {
        return segmentDelimiter;
    }

    public void setSegmentDelimiter(String segmentDelimiter) {
        this.segmentDelimiter = segmentDelimiter;
    }
}
