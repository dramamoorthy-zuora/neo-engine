package com.zuora.neo.engine.jobs.sfc.exception;

public class NoDetailsFoundException extends Exception {

    public NoDetailsFoundException(Throwable cause) {
        this(null, cause);
    }

    public NoDetailsFoundException(String message) {
        this(message, (Throwable) null);
    }

    public NoDetailsFoundException(String message, Throwable cause) {
        super(message, cause);
    }

}
