package com.zuora.neo.engine.jobs.archival.workflow.parent;

import com.zuora.neo.engine.temporal.workflows.BaseWorkflow;

import io.temporal.workflow.WorkflowInterface;

/**
 * @author tkrishnakumar
 */
@WorkflowInterface
public interface ArchivalWorkflow extends BaseWorkflow {
}
