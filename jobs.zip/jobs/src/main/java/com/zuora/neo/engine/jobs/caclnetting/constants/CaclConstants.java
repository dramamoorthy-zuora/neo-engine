package com.zuora.neo.engine.jobs.caclnetting.constants;

public class CaclConstants {

    public static final String HEAD_PERIOD_DEFAULT_INDICATOR = "NNNNNNNNNNNNNNNNNNNN";
    public static final String SCHEDULES_DEFAULT_INDICATOR = "NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI";
    public static final String CACL_NET_RC = "RPRO_CACL_NET_RC";
    public static final String CACL_NET_RC_H = "RPRO_CACL_NET_RC_H";
    public static final String RC_HEAD_PERIOD = "RPRO_RC_HEAD_PERIOD";
    public static final String RC_SCHD = "RPRO_RC_SCHD";
    public static final String SHADOW_TABLE_SUFFIX = "_SHADOW";
}
