package com.zuora.neo.engine.jobs.sweep.activities.rco;

import java.sql.Timestamp;

public class RcoData {

    private RcoEventType rcoEventType;
    private long bookId;
    private Timestamp createdDate;
    private String additionalParams;

    public long getBookId() {
        return bookId;
    }

    public void setBookId(long bookId) {
        this.bookId = bookId;
    }

    public Timestamp getCreatedDate() {
        return new Timestamp(createdDate.getTime());
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = new Timestamp(createdDate.getTime());
    }

    public String getAdditionalParams() {
        return additionalParams;
    }

    public void setAdditionalParams(String additionalParams) {
        this.additionalParams = additionalParams;
    }

    public RcoEventType getRcoEventType() {
        return rcoEventType;
    }

    public void setRcoEventType(RcoEventType rcoEventType) {
        this.rcoEventType = rcoEventType;
    }
}
