package com.zuora.neo.engine.jobs.transferaccounting.constants;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum ScheduleParams {
    ALLOC_ENTRY("A"),
    REVENUE_ENTRY("R"),
    COST_ENTRY("C"),
    MJE_ENTRY("M"),
    VC_ENTRY("V"),
    VC_CLR_ENTRY("Z"),
    NETT_ENTRY("D"),
    RORD_ENTRY("G"),
    IMPAIR_ENTRY("I"),
    MJE_RCLINK_ENTRY("T");

    private final String scheduleParam;

    @JsonValue
    public String getScheduleParam() {
        return scheduleParam;
    }

    ScheduleParams(String scheduleParam) {
        this.scheduleParam = scheduleParam;
    }

    private static final Map<String, ScheduleParams> LOOKUP =
            Arrays.stream(ScheduleParams.values()).collect(Collectors.toMap(ScheduleParams::getScheduleParam, Function.identity()));

    @JsonCreator
    public static ScheduleParams fromScheduleParam(String scheduleParam) {
        return LOOKUP.get(scheduleParam);
    }
}
