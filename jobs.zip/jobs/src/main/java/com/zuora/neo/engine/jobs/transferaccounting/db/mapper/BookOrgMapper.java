package com.zuora.neo.engine.jobs.transferaccounting.db.mapper;

import com.zuora.neo.engine.jobs.transferaccounting.db.api.BookOrgRecord;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class BookOrgMapper implements RowMapper<BookOrgRecord> {

    @Override
    public BookOrgRecord map(ResultSet rs, StatementContext ctx) throws SQLException {
        return new BookOrgRecord(rs.getLong(1), rs.getString(2));
    }
}
