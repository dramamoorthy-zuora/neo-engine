package com.zuora.neo.engine.common.lookup;

import org.jdbi.v3.core.Handle;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LookupService {
    public  <T> T  fetchLookupData(Handle handle, String lookKey, LookupMapper<T> mapper) {
        LookupDataDao lookupDataDao = handle.attach(LookupDataDao.class);
        List<LookupEntity> data = lookupDataDao.findByLkpName(lookKey);
        return mapper.map(data);
    }
}
