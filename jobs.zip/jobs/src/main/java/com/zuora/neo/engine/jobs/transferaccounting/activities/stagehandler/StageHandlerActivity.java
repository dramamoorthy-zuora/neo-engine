package com.zuora.neo.engine.jobs.transferaccounting.activities.stagehandler;

import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface StageHandlerActivity {
    ThreadedAccountingResult executeCustomCodeStageHandler(ThreadedAccountingResult accountingResult, String orgId);
}
