package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.jobs.sfc.SfcResult;
import com.zuora.neo.engine.jobs.sfc.constants.SfcStatus;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.PrincipleWeightageColumn;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;
import com.zuora.neo.engine.jobs.sfc.exception.NoDetailsFoundException;

import org.jdbi.v3.core.Handle;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class SfcBatchProcessingService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcBatchProcessingService.class);
    @Autowired
    NpvCalculationService npvCalculationService;
    @Autowired
    AccrualEntryService accrualEntryService;
    @Autowired
    SfcScheduleCreationService sfcScheduleCreationService;
    @Autowired
    RcLinePaDataService rcLinePaDataService;
    @Autowired
    PrincipleAmountCalculationService principleAmountCalculationService;
    @Autowired
    SoUpdateProcessingService soUpdateProcessingService;
    @Autowired
    SfcTablesBatchInsertUpdateService sfcTablesBatchInsertUpdateService;
    @Autowired
    RcLineDetailsService rcLineDetailsService;

    public static List<RcLinePaData> getRcLinePaDataFromDB(SfcDao sfcDao, long lineId, long financeTypeId) {
        LOGGER.debug("Fetching RC Line PA Data Table for the line Id : " + lineId);
        List<RcLinePaData> rcLinePaDataList = sfcDao.getRcLinePaDataForLineId(lineId, financeTypeId);
        return rcLinePaDataList;
    }

    /*
       Service Method to get Finance Type Details for RC Line.

       Input Args :
       financeTypeValuesList - Values in rpro_financ_type table
       rcLineDetails - rc line details for that particular line
       calendarDetails -> has values from rpro_calendar

       Output :
       Returns Finance Type Values
    */
    public static List<FinanceTypeValues> getFinanceTypeDetailsForRcLine(List<FinanceTypeValues> financeTypeValuesList, RcLineDetails rcLineDetails,
            CalendarDetails calendarDetails) {
        LOGGER.debug("Fetching Finance Type Value for Rc Line Id : " + rcLineDetails.getId());
        Date docDate = rcLineDetails.getDocDate();
        Date currentPeriodEndDate = calendarDetails.getEndDate();
        List<FinanceTypeValues> financeTypeValueForRcLine = new ArrayList<>();
        for (FinanceTypeValues financeTypeValue : financeTypeValuesList) {
            Date startDate = financeTypeValue.getStartDate();
            Date endDate = financeTypeValue.getEndDate() == null ? currentPeriodEndDate : financeTypeValue.getEndDate();
            if ((docDate.compareTo(startDate) >= 0
                    && docDate.compareTo(endDate) <= 0)) {
                financeTypeValueForRcLine.add(financeTypeValue);
            }
        }

        Collections.sort(financeTypeValueForRcLine, (o1, o2) -> {
            if (o1.getSeq() == o2.getSeq()) {
                return 0;
            }
            return o1.getSeq() < o2.getSeq() ? -1 : 1;
        });

        return financeTypeValueForRcLine;
    }

    public void updateSfcStatusAndAddWarningCount(SfcResult sfcResult, SfcStatusValues sfcStatusValue, String errMsg) {
        sfcStatusValue.setErrMsg(errMsg);
        sfcResult.addWarningCount();
    }

    /*
       Service Method to get RC Line Pa Record for Finance Type Id

       Input Args :
       sfcDao - Dao for SFC Db operations
       rcId - rcId for the particular line
       sfcDbCacheContext -> Has common details such as data from rpro_account, rpro_currency, rpro_financ_typ and rpro_calendar

       Output :
       Returns RC Line Pa Data
    */
    public static List<RcLinePaData> getRcLinePaRecordForFinanceId(SfcDao sfcDao, long rcId, SfcDbCacheContext sfcDbCacheContext) {
        long financeTypeId = sfcDbCacheContext.getFinanceTypeValuesList().get(0).getId();
        List<RcLinePaData> rcLinePaDataList = getRcLinePaDataFromDB(sfcDao, rcId, financeTypeId);
        return rcLinePaDataList;
    }

    public static RcLinePaData getRcLinePaRecordForLineId(Map<Long, RcLinePaData> rcLinePaDataByLineIdMap, long lineId) {
        return rcLinePaDataByLineIdMap.get(lineId);
    }

    /*
       Method called from Activity to calculate principle amount from rc details for each line in the batch.
       This method also gets the weightage column from rpro_financ_type table and calls the principle amount calculation service.

       Input :
       sfcStatusValuesList : Lines from Sfc Status Table
       sfcDbCacheContext : Has common details such as data from rpro_account, rpro_currency, rpro_financ_typ and rpro_calendar
       rcLineDetailsBatchMap : Map with key as doc line id and rc line details for that line
       rcLineDetailsByDocNumMap : Map with key as doc num and rc line details for that doc num with sum of amounts
       sfcResult : Sfc Result object
       request : Request
       handle : JDBI Handle
     */
    public void calculatePrincipleAmt(List<SfcStatusValues> sfcStatusValuesList,
            Map<String, RcLineDetails> rcLineDetailsBatchMap, Map<String, RcLineDetails> rcLineDetailsByDocNumMap,
            SfcDbCacheContext sfcDbCacheContext, Map<Long, RcLinePaData> rcLinePaDataByLineIdMap, SfcResult sfcResult, WorkflowRequest request, Handle handle) {
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();
        List<FinanceTypeValues> financeTypeValuesList = sfcDbCacheContext.getFinanceTypeValuesList();
        List<CalendarDetails> calendarDetailsList = sfcDbCacheContext.getCalendarDetails();
        CalendarDetails calendarDetails = calendarDetailsList.get(0);
        Map<String, Integer> currencyMap = sfcDbCacheContext.getCurrencyMap();
        for (SfcStatusValues sfcStatusValue : sfcStatusValuesList) {
            if (sfcStatusValue != null && sfcStatusValue.getDocLineId() != null) {
                sfcStatusValue.setErrMsg(null);
                List<RcLineDetails> rcLineDetails = Arrays.asList(rcLineDetailsBatchMap.get(sfcStatusValue.getDocLineId()));
                if (rcLineDetails.isEmpty()) {
                    LOGGER.error("RC Line Details are empty for doc line Id " + sfcStatusValue.getDocLineId());
                    updateSfcStatusAndAddWarningCount(sfcResult, sfcStatusValue, SfcStatus.ERROR_PROCESSING_SFC.getStatus());
                    continue;
                }
                /*List<RcLinePaData> rcLinePaDataRecord = getRcLinePaRecordForFinanceId(sfcDao, rcLineDetails.get(0).getId(),
                        sfcDbCacheContext);
                         //TODO SFC Flag 'Y' filter for Finance Type List before this
                 */
                RcLineDetails rcLineDetail = rcLineDetails.get(0);
                RcLinePaData rcLinePaDataRecord = getRcLinePaRecordForLineId(rcLinePaDataByLineIdMap, rcLineDetails.get(0).getId());
                List<FinanceTypeValues> financeTypeValueForRcLine = null;
                if (rcLinePaDataRecord != null) {
                    financeTypeValueForRcLine = financeTypeValuesList.stream()
                            .filter(financeTypeValue -> financeTypeValue.getVersion() == rcLinePaDataRecord.getFncTypeVersion())
                            .collect(Collectors.toList());
                } else {
                    financeTypeValueForRcLine = getFinanceTypeDetailsForRcLine(financeTypeValuesList, rcLineDetails.get(0),
                            calendarDetails);
                }
                if (financeTypeValueForRcLine.isEmpty()) {
                    LOGGER.error("Finance Type Table is not available for doc line id " + sfcStatusValue.getDocLineId());
                    updateSfcStatusAndAddWarningCount(sfcResult, sfcStatusValue, SfcStatus.SETUP_NOT_AVAILABLE.getStatus());
                    continue;
                }
                Integer currRound = currencyMap.get(request.getTenantId() + ":" + rcLineDetails.get(0).getCurrencyCode());
                if (rcLineDetail.getPrincipleAmount() == null || rcLineDetail.getPrincipleAmount().compareTo(BigDecimal.ZERO) == 0) {
                    PrincipleWeightageColumn principleWeightageColumn = principleAmountCalculationService
                            .determineWeightageMethod(financeTypeValueForRcLine);
                    try {
                        principleAmountCalculationService.calculatePrincipleAmount(rcLineDetail,
                                rcLineDetailsByDocNumMap, principleWeightageColumn, currRound);
                    } catch (NoDetailsFoundException e) {
                        LOGGER.error("One or more details null/not found during principle amount calculation");
                        updateSfcStatusAndAddWarningCount(sfcResult, sfcStatusValue, SfcStatus.ERROR_PROCESSING_SFC.getStatus());
                        continue;
                    }
                    LOGGER.debug("Updating the RC Line Table with Principle Amount for docLine Id : " + rcLineDetail.getDocLineId());
                    rcLineDetailsList.addAll(rcLineDetails);
                }
                sfcStatusValue.setStatus(SfcStatus.PRINCIPLE_AMOUNT_CALCULATED.getStatus());
            }

        }
        sfcTablesBatchInsertUpdateService.batchUpdateSfcStatusTable(sfcStatusValuesList, handle);
        LOGGER.info("SFC Status Table updated with Status");
        rcLineDetailsService.updatePrincipleAmountToRcLineDetailsBatch(handle,rcLineDetailsList);
        LOGGER.info("RC Line table updated with Principle Amounts");
    }

    /*
       Method called from Activity to pre-process SFC records for a batch. This method gets data
       from rpro_rc_line and rpro_rc_line_pa table and calls method to calculate principle amount.

       Input :
       sfcStatusValuesList : Lines from Sfc Status Table
       sfcDbCacheContext : Has common details such as data from rpro_account, rpro_currency, rpro_financ_typ and rpro_calendar
       sfcResult : Sfc Result object
       request : Request
       handle : JDBI Handle
     */
    public void processSfcForBatch(List<SfcStatusValues> sfcStatusValuesList, SfcDbCacheContext sfcDbCacheContext,
            SfcResult sfcResult, WorkflowRequest request, Handle handle) {

        SfcDao sfcDao = handle.attach(SfcDao.class);

        List<String> sfcDocLineIds = sfcStatusValuesList.stream().map(SfcStatusValues::getDocLineId).collect(Collectors.toList());
        List<String> sfcDocNums = sfcStatusValuesList.stream().map(SfcStatusValues::getDocNum).collect(Collectors.toList())
                        .stream().distinct().collect(Collectors.toList());

        LOGGER.info("Fetching RC Line Table details for batch..");
        List<RcLineDetails> rcLineDetailsBatch = sfcDao.getRcLineDetailsByDocLineIdList(sfcDocLineIds);
        List<RcLineDetails> rcLineDetailsByDocNum = sfcDao.getRcLineDetailsByDocNum(sfcDocNums);

        List<Long> rcLineIds = rcLineDetailsBatch.stream().map(RcLineDetails::getId).collect(Collectors.toList());
        List<RcLinePaData> rcLinePaRecordListForBatch = sfcDao.getRcLinePaDataForLineIdBatch(rcLineIds,
                sfcDbCacheContext.getFinanceTypeValuesList().get(0).getId());

        Map<String, RcLineDetails> rcLineDetailsBatchMap = rcLineDetailsBatch.stream().collect(Collectors.toMap(RcLineDetails::getDocLineId,
                rcLineDetails -> rcLineDetails));
        Map<String, RcLineDetails> rcLineDetailsByDocNumMap = rcLineDetailsByDocNum.stream().collect(
                Collectors.toMap(RcLineDetails::getDocNum, rcLineDetails -> rcLineDetails));
        Map<Long, RcLinePaData> rcLinePaDataByLineIdMap = rcLinePaRecordListForBatch.stream().collect(
                Collectors.toMap(RcLinePaData::getLineId, rcLinePaData -> rcLinePaData));

        calculatePrincipleAmt(sfcStatusValuesList, rcLineDetailsBatchMap, rcLineDetailsByDocNumMap, sfcDbCacheContext,
                rcLinePaDataByLineIdMap, sfcResult, request, handle);
    }
}
