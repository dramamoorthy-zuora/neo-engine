package com.zuora.neo.engine.jobs.transferaccounting.activities.gllink;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.JobsMetadata;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.transferaccounting.config.Properties;
import com.zuora.neo.engine.jobs.transferaccounting.constants.AccountingObjectType;
import com.zuora.neo.engine.jobs.transferaccounting.constants.AccountingParams;
import com.zuora.neo.engine.jobs.transferaccounting.constants.TransferStatus;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.BookOrgRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.GlIntegrationMap;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.AccountingDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.ErrorDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.GeneralLedgerDao;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@ActivityImplementation
@Component
public class GlLinkingActivityImpl implements GlLinkingActivity {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(GlLinkingActivityImpl.class);
    private static final String BATCH_ID_ERR = "Post batch Id can't be null";
    private static final String ORG_ID_ERR = "Org Id can't be null";

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;
    @Autowired
    Properties properties;
    @Autowired
    ParseProgramParameters parseProgramParameters;

    /*
        We have 2 types of posting - summary and detailed.
            In detailed level posting all the lines matching the criteria from schedules table are posted to the rpro_gl_int_stage table.
            If say we have 10 lines in rpro_rc_schd_g table, we split them in 2 lines - 1 for CR and other for DR and total 20 lines are posted
            In summary level posting however either we can sum up all the lines into 1 line and post that amount one as CR and other as DR
            or we may have different criteria based on which we can summarize the lines.
            Hence we need to know which amount corresponds to which and hence we create the GL linking.
            In case of summary posting. This will give the details of the schedules for corresponding summary entry.
            CR_LINK_ID and DR_LINK_ID will be populated in rpro_rc_schd_g.
     */
    @Override
    public void updateGlLink() {
        //neoWorkflowLogger.log("GlLinkingActivity called");
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Map<String, String> paramsMap;
        String orgId = null;
        Long postBatchId = null;
        if (request.getProgramId() == JobsMetadata.CR_DR_LINK.getId()) {
            //neoWorkflowLogger.log("job id called: " + request.getProgramId());
            paramsMap = parseProgramParameters.parseParamString(request.getTenantId(), request.getProgramId(), request.getParameterText());
            orgId = paramsMap.get(AccountingParams.ORG);
            //neoWorkflowLogger.log("orgId passed: " + orgId);
            if (orgId == null) {
                NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, ORG_ID_ERR);
            }
            String postBatchIdStr = paramsMap.get(AccountingParams.POST_BATCH_ID);
            postBatchId =  Long.valueOf(postBatchIdStr);
            //neoWorkflowLogger.log("postBatchId passed: " + orgId);
            if (postBatchId == null) {
                NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, BATCH_ID_ERR);
            }
        }

        Jdbi jdbi = DbContext.getConnection();

        Long finalPostBatchId = postBatchId;
        String finalOrgId = orgId;
        jdbi.useHandle(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            ErrorDao errorDao = handle.attach(ErrorDao.class);
            CommonDao commonDao = handle.attach(CommonDao.class);
            properties.load(commonDao, request.getTenantId());
            String summaryTransfer = properties.getSummaryTransferEnabled() ? "Y" : "N";
            String mjeSummaryTransfer = properties.getMjeSummaryTransferEnabled() ? "Y" : "N";
            String postSchedule = properties.getPostScheduleEnabled() ? "Y" : "N";
            String postManualJeSchedule = properties.getPostManualJeScheduleEnabled() ? "Y" : "N";
            String enableGlLink = properties.getGlLinkEnabled() ? "Y" : "N";

            if ("Y".equals(summaryTransfer) || "Y".equals(mjeSummaryTransfer)) {
                //neoWorkflowLogger.log("summaryTransfer or mjeSummaryTransfer is enabled ");
                if ("Y".equals(accountingDao.getPostableFlag()) && ("Y".equals(postSchedule) || "Y".equals(postManualJeSchedule))) {
                    if ("Y".equals(postSchedule) && "Y".equals(enableGlLink)) {
                        //neoWorkflowLogger.log("postSchedule and enableGlLink is enabled ");
                        try {
                            doGlLinkInTransaction(AccountingObjectType.GENERAL_LEDGER.getObjectTypeType(),
                                    finalPostBatchId, handle, properties);
                        } catch (Exception e) {
                            handleGlLinkErr(accountingDao, finalPostBatchId, request, finalOrgId, errorDao, e);
                        }
                    }
                    if ("Y".equals(postManualJeSchedule) && "Y".equals(enableGlLink)) {
                        //neoWorkflowLogger.log("postManualJeSchedule and enableGlLink is enabled ");
                        try {
                            doGlLinkInTransaction(AccountingObjectType.MANUAL_JE.getObjectTypeType(),
                                    finalPostBatchId, handle, properties);
                        } catch (Exception e) {
                            handleGlLinkErr(accountingDao, finalPostBatchId, request, finalOrgId, errorDao, e);
                        }
                    }
                }
            }
        });
    }

    private void doGlLinkInTransaction(String objectType, Long postBatchId, Handle handle, Properties properties) {
        //neoWorkflowLogger.log("inside actual gl linking logic ");
        GeneralLedgerDao ledgerDao = handle.attach(GeneralLedgerDao.class);
        String summaryTransfer = properties.getSummaryTransferEnabled() ? "Y" : "N";
        String mjeSummaryTransfer = properties.getMjeSummaryTransferEnabled() ? "Y" : "N";
        StringBuilder updateStmt = new StringBuilder();
        if (AccountingObjectType.GENERAL_LEDGER.getObjectTypeType().equals(objectType) && "Y".equals(summaryTransfer)) {
            updateStmt.append("MERGE INTO rpro_rc_schd schd USING (SELECT /*+ no_expand use_hash(s,v) */ v.schd_id, min(s.cr_link_id) cr_link_id, "
                    + "min(s.dr_link_id) dr_link_id FROM rpro_post_v v, rpro_gl_int_stage s");
        } else if (AccountingObjectType.MANUAL_JE.getObjectTypeType().equals(objectType) && "Y".equals(mjeSummaryTransfer)) {
            updateStmt.append("MERGE INTO rpro_rc_schd schd USING (SELECT /*+ no_expand use_hash(s,v) index(v.rrs.schd.schd, rpro_rc_schd_f2) "
                    + " use_nl(v.rrs.schd.schd, v.rjl, v.rjh) index( v.rjl rpro_je_line_u1 rpro_je_line_n2) */"
                    + " v.schd_id, min(s.cr_link_id) cr_link_id, min(s.dr_link_id) dr_link_id FROM rpro_je_post_v v, rpro_gl_int_stage s");
        }
        updateStmt.append(" WHERE s.batch_id = ").append(postBatchId).append(" AND s.object_type = '").append(objectType)
                .append("' AND s.batch_id = v.schd_post_batch_id AND ");

        if (updateStmt.toString().isEmpty()) {
            neoWorkflowLogger.log("Conditions did not meet " + objectType + " MJE Summary Transfer " + mjeSummaryTransfer
                    + " Summary transfer " + summaryTransfer);
            LOGGER.warn("Conditions did not meet " + objectType + " MJE Summary Transfer " + mjeSummaryTransfer
                    + " Summary transfer " + summaryTransfer);
            return;
        }

        List<GlIntegrationMap> glMapList = ledgerDao.getGlIntegrationMap(objectType);
        for (GlIntegrationMap glMap : glMapList) {
            if (glMap.getSourceFrom().equals("DYNAMIC") || glMap.getSourceFrom().equals("CONSTANT")
                    || glMap.getSourceFrom().equals("EXPRESSION")) {
                continue;
            } else {
                if ((glMap.getSourceValue().contains("CR") && glMap.getSourceValue().contains("AMOUNT")
                        && glMap.getSourceValue().indexOf("CR") < glMap.getSourceValue().indexOf("AMOUNT"))
                        || (glMap.getSourceValue().contains("DR") && glMap.getSourceValue().contains("AMOUNT")
                        && glMap.getSourceValue().indexOf("DR") < glMap.getSourceValue().indexOf("AMOUNT"))) {
                    continue;
                }
                if (glMap.getSourceValue() != null && (glMap.getSourceValue().equals("CR_LINK_ID")
                        || glMap.getSourceValue().equals("DR_LINK_ID"))) {
                    continue;
                }
                updateStmt.append("(v.").append(glMap.getSourceValue()).append(" = s.").append(glMap.getFieldName())
                        .append(" OR s.").append(glMap.getFieldName()).append(" IS NULL) AND ");
            }
        }

        StringBuilder updateStatement = new StringBuilder(updateStmt.substring(0, updateStmt.length() - 5));
        updateStatement.append(" group by v.schd_id) src on ( schd.id = src.schd_id ) WHEN MATCHED THEN "
                + "UPDATE SET cr_link_id = src.cr_link_id, dr_link_id = src.dr_link_id ");
        neoWorkflowLogger.log("CR DR link merge query for: "  + objectType + " is: " + updateStatement);
        long startTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        Integer rowsMerged = handle.createUpdate(updateStatement.toString()).execute();
        long endTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        neoWorkflowLogger.log("Time Taken for Merge query for: " + objectType + " is: " + (endTime - startTime));
        LOGGER.debug("GL Linking - number of CR/DR records merged for: " + objectType + rowsMerged);
        neoWorkflowLogger.log("GL Linking - number of CR/DR records merged: " + objectType + " is: " + rowsMerged);
    }

    private void handleGlLinkErr(AccountingDao accountingDao, Long postBatchId, WorkflowRequest request,
            String orgId, ErrorDao errorDao, Exception e) {
        BookOrgRecord rec = accountingDao.getBookIdForBatch(postBatchId).get(0);
        Long bookId = null;
        if (rec != null) {
            bookId = rec.getBookId();
        }
        String errMsg = "Error: Update GL Link failed,";
        accountingDao.updateTransferStatusMsg(TransferStatus.ERROR.getTransferStatus(),errMsg, request.getUser(), postBatchId);
        errMsg = e.getCause().getMessage() != null ? errMsg + e.getCause().getMessage() : errMsg;
        errorDao.insertError(postBatchId, errMsg, request.getUser(), request.getClientId(), bookId, orgId, null);
    }

}
