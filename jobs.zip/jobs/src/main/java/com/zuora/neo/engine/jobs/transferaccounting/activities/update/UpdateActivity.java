package com.zuora.neo.engine.jobs.transferaccounting.activities.update;

import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface UpdateActivity {
    ThreadedAccountingResult doUpdateProcess(ThreadedAccountingResult accountingResult, String orgId);

    void resetNoOfSchedules(Long postBatchId);

    void updateStatusToInProgress(Long postBatchId);
}
