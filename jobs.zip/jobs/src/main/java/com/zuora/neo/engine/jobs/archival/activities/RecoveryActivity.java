package com.zuora.neo.engine.jobs.archival.activities;

import com.zuora.neo.engine.jobs.archival.ArchivalResult;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface RecoveryActivity {
    ArchivalResult recoverRecords();
}
