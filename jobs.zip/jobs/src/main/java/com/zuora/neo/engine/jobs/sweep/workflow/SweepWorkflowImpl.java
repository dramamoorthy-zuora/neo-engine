package com.zuora.neo.engine.jobs.sweep.workflow;

import com.zuora.neo.engine.annotations.workflow.WorkflowImplementation;
import com.zuora.neo.engine.jobs.sweep.SweepResult;
import com.zuora.neo.engine.jobs.sweep.activities.SweepActivities;
import com.zuora.neo.engine.jobs.sweep.activities.rco.RcoActivities;
import com.zuora.neo.engine.jobs.sweep.activities.summarization.SweepSummarization;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.workflows.LoggerWorkflowImpl;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.workflow.Workflow;
import org.springframework.stereotype.Component;

//https://community.temporal.io/t/temporal-with-springboot/2734/11
@Component
@WorkflowImplementation
public class SweepWorkflowImpl extends LoggerWorkflowImpl implements SweepWorkflow {

    /**
     * Use a Temporal provided logger thats Replayaware
     *
     * @see {@link io.temporal.internal.logging.ReplayAwareLogger}
     */
    private static final org.slf4j.Logger logger = Workflow.getLogger(SweepWorkflowImpl.class);
    private final SweepActivities sweepActivity = Workflow.newActivityStub(SweepActivities.class);
    private final RcoActivities rcoActivity = Workflow.newActivityStub(RcoActivities.class);
    private final SweepSummarization sweepSummarizationActivity = Workflow.newActivityStub(SweepSummarization.class);


    @Override
    public WorkflowResponse execute() {
        SweepResult sweepResult = sweepActivity.sweep();

        if (sweepResult.getRowsUpdated() == 0 && sweepResult.getSummaryRecords() == 0) {
            logger.debug("No records to process for sweep");
            return new WorkflowResponse(RevenueJobStatus.WARNING, "No RC's eligible for Sweep Process/RC doesn't exist");
        } else {

            //call Sweep Summarization
            sweepSummarizationActivity.summarize(sweepResult);

            //call RCO
            rcoActivity.createRcoJob(sweepResult);

            return new WorkflowResponse(RevenueJobStatus.COMPLETED, "");

        }

    }
}
