package com.zuora.neo.engine.jobs.transferaccounting.activities.validation;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.config.Properties;
import com.zuora.neo.engine.jobs.transferaccounting.constants.StageHandlerType;
import com.zuora.neo.engine.jobs.transferaccounting.constants.TransferStatus;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.AccountSegment;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.RcHeadRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.SplitBatchRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.AccountingDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.ErrorDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.ScheduleDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.SplitDao;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.OutParameters;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@ActivityImplementation
@Component
public class ValidateActivityImpl implements ValidateActivity {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(ValidateActivityImpl.class);
    private static final String validationProcName = "TRANSFER_ACC_VALIDATE";
    private static final String cvValidationProcName = "VALIDATE_CV_TOTALS";
    private static final String acctValidationProcName = "VALIDATE_ACCT_SEGMENTS";
    private static final String applyHoldProcName = "APPLY_HOLD_ON_ERRORS";
    private static final String splitType = "RC_ID";
    private static final String batchType = "TRANSFER";
    private static final String VALIDATION_ERR = "Tansfer Validation Failed!";

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;
    @Autowired
    Properties properties;

    /*
        This activity validates the RCs during the update flow of the transfer accounting process
        Main validations done are:
        1) carved amount equals to 0
        2) accounting segments are correct as per setup
    */
    @Override
    public ThreadedAccountingResult validateAccountingProcess(ThreadedAccountingResult accountingResult, String orgId) {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Long bookId = accountingResult.getBookId();
        Long postBatchId = accountingResult.getPostBatchId();
        Jdbi jdbi = DbContext.getConnection();

        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            ErrorDao errorDao = handle.attach(ErrorDao.class);
            SplitDao splitDao = handle.attach(SplitDao.class);
            properties.load(commonDao, request.getTenantId());
            //by this time all chunks have either been updated or if retry logic fails we will stop execution
            //update the main batch to UPDATED
            accountingDao.updateTransferStatusMsg(TransferStatus.UPDATED.getTransferStatus(), "", request.getUser(), postBatchId);
            String chunkTransferStatus = splitDao.getChunkTransferStatus(postBatchId, accountingResult.getChunkId());
            String validationEnabled = properties.getTransferValidationEnabled() ? "Y" : "N";
            if (chunkTransferStatus.equals(TransferStatus.UPDATED.getTransferStatus()) && validationEnabled.equals("Y")) {
                SplitBatchRecord batch = splitDao.getSplitBatchById(postBatchId, splitType, bookId, batchType, accountingResult.getChunkId());
                accountingResult.setMinRcId(Long.valueOf(batch.getMinValue()));
                accountingResult.setMaxRcId(Long.valueOf(batch.getMaxValue()));
                LOGGER.info("** MIN RC ID" + accountingResult.getMinRcId().toString());
                LOGGER.info("** MAX RC ID" + accountingResult.getMaxRcId().toString());
                doAccountingValidationInTransaction(accountingDao, commonDao, postBatchId, request,
                        bookId, handle, errorDao, accountingResult, orgId, properties);
            }
        });

        return accountingResult;
    }

    private ThreadedAccountingResult doAccountingValidationInTransaction(AccountingDao accountingDao, CommonDao commonDao,Long postBatchId,
            WorkflowRequest request, Long bookId, Handle handle, ErrorDao errorDao, ThreadedAccountingResult accountingResult,
            String orgId, Properties properties) {
        LOGGER.info("Procedure: " + validationProcName + " Log: Start time: " + Timestamp.valueOf(LocalDateTime.now()));
        //neoWorkflowLogger.log("Procedure: " + validationProcName + " Log: Start time: " + Timestamp.valueOf(LocalDateTime.now()));

        Long periodId = commonDao.getCrtdPeriodId(bookId, orgId);
        validateCvTotals(errorDao, postBatchId, request, bookId, periodId, accountingResult, properties);
        validateAccountSegments(accountingDao, commonDao, request, postBatchId, periodId, bookId, errorDao, accountingResult, orgId, properties);
        accountingResult = applyHoldOnErrors(accountingDao, postBatchId, request, errorDao, handle, bookId, accountingResult, orgId, properties);

        LOGGER.info("Procedure: " + validationProcName + " Log: Completion time: " + Timestamp.valueOf(LocalDateTime.now()));
        //neoWorkflowLogger.log("Procedure: " + validationProcName + " Log: Completion time: " + Timestamp.valueOf(LocalDateTime.now()));

        accountingResult.setStageHandlerType(StageHandlerType.AFTER_UPDATE);

        return accountingResult;
    }

    /*
        checks Allocation amount is netting zero
     */
    private void validateCvTotals(ErrorDao errorDao, Long postBatchId,
            WorkflowRequest request, Long bookId, Long periodId, ThreadedAccountingResult accountingResult, Properties properties) {
        String errMsg = "Sum of Carveout amount for the arrangement is not 0 : ";
        String enableAllocation = properties.getAllocationsEnabled() ? "Y" : "N";
        if ("Y".equals(enableAllocation)) {
            long startTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
            int rowCount = errorDao.insertCvValidateErrors(postBatchId, accountingResult.getChunkId(), errMsg, request.getUser(), request.getClientId(),
                    periodId, bookId, accountingResult.getMinRcId(), accountingResult.getMaxRcId());
            LOGGER.info("Rows inserted for validate CV:: " + rowCount + " for request id:: " + request.getRequestId());
            if (rowCount > 0) {
                String errorMsg = "Mismatch in CarveOut amount!";
                LOGGER.info("Procedure: " + cvValidationProcName + " validation failed " + errorMsg);
            }
            long endTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
            LOGGER.info("Time Taken to do validateCvTotals is: " + (endTime - startTime));
        }
    }

    /*
        validates if accounting segments are correct
     */
    private void validateAccountSegments(AccountingDao accountingDao, CommonDao commonDao, WorkflowRequest request,
            Long postBatchId, Long periodId, Long bookId, ErrorDao errorDao, ThreadedAccountingResult accountingResult, String orgId, Properties properties) {
        long startTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        String ccValWithOracle = "N";
        String validSegment;

        List<AccountSegment> accountSegments = accountingDao.getAccountSegments(postBatchId, accountingResult.getMinRcId(), accountingResult.getMaxRcId());
        if (!accountSegments.isEmpty()) {
            for (AccountSegment accountSegment : accountSegments) {
                OutParameters outParameters = accountingDao.validateAcctSegment(accountSegment.getScheduleAccountSegments(), ccValWithOracle, null);
                validSegment = outParameters.getString("p_valid_seg");
                if ("E".equals(validSegment)) {
                    int rowCount = errorDao.insertAccountSegValidateErrors(postBatchId, accountingResult.getChunkId(), request.getUser(), request.getClientId(),
                            periodId, bookId, orgId, accountSegment.getScheduleAccountSegments(),
                            accountingResult.getMinRcId(), accountingResult.getMaxRcId());
                    LOGGER.info("Rows inserted for validate segment:: " + rowCount + " for request id:: " + request.getRequestId());
                    if (rowCount > 0) {
                        String errMsg = "Invalid Accounting Segments!";
                        LOGGER.info("Procedure: " + acctValidationProcName + " validation failed " + errMsg);
                    }
                }
            }
        }
        long endTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        LOGGER.info("Time Taken to do validateAccountSegments is: " + (endTime - startTime));
    }

    /*
        During validation if fails we apply Transfer Hold naming “Accounting Transfer Error”.
        We have the profile STOP_BATCH_ON_ERROR based on which If enabled then any one of RCs in validation error then system will
        not allow to post the entire transfer accounting batch if else only respective RCs will not be allowed.
     */
    private ThreadedAccountingResult applyHoldOnErrors(AccountingDao accountingDao, Long postBatchId, WorkflowRequest request,
            ErrorDao errorDao, Handle handle, Long bookId, ThreadedAccountingResult accountingResult, String orgId, Properties properties) {
        ScheduleDao scheduleDao = handle.attach(ScheduleDao.class);
        SplitDao splitDao = handle.attach(SplitDao.class);
        String holdName = "Accounting Transfer Error";
        String postBatchName = accountingDao.getPostBatchName(postBatchId);
        Integer holdId = accountingDao.getHoldId(holdName);
        String stopBatchOnErr = properties.getStopBatchOnErrEnabled() ? "Y" : "N";
        Integer errors = 0;
        List<RcHeadRecord> records = null;
        if ("N".equals(stopBatchOnErr)) {
            LOGGER.info("apply hold with stop batch flag: " + stopBatchOnErr);
            records = accountingDao.getRcHeaderRec(postBatchId, accountingResult.getMinRcId(), accountingResult.getMaxRcId());
            for (RcHeadRecord rec : records) {
                errors++;
                scheduleDao.resetRcSchedule(request.getUser(), postBatchId, rec.getRcId(), rec.getBookId());
                if (holdId != null) {
                    String errorMessage = accountingDao.getErrorMessage(accountingResult.getPostBatchId(),accountingResult.getChunkId());
                    String holdComment;
                    if (errorMessage != null && errorMessage.contains("Carve")) {
                        holdComment = "Transfer Validation Failed! for batch " + postBatchName + " - " + "Mismatch in CarveOut amount!";
                    } else {
                        holdComment = "Transfer Validation Failed! for batch " + postBatchName + " - " + errorMessage;
                    }

                    accountingDao.applyHolds(request.getUser(), holdId, holdComment, rec.getRcId(), null, null,
                            rec.getObjectVersion(), rec.getBookId(), "Y");
                }
            }
            //neoWorkflowLogger.log("No of records on hold:: " + errors + " for request id:: " + request.getRequestId());
        } else {
            LOGGER.info("apply hold with stop batch flag: " + stopBatchOnErr);
            errors = errorDao.getValidationErrCount(postBatchId, accountingResult.getChunkId());
            //neoWorkflowLogger.log("No of records on hold:: " + errors + " for request id:: " + request.getRequestId());
        }
        String transferStatus = null;
        String transferMsg = null;
        if (errors > 0) {
            if ("Y".equals(stopBatchOnErr)) {
                transferStatus = TransferStatus.ERROR.getTransferStatus();
                transferMsg = VALIDATION_ERR;
            } else {
                transferStatus = TransferStatus.WARNING.getTransferStatus();
                transferMsg = "Some validations failed and applied RC holds";
                splitDao.updateTransferStatusChunk(transferStatus, transferMsg, request.getUser(), postBatchId, accountingResult.getChunkId());
                accountingDao.updateTransferStatusMsg(transferStatus, transferMsg, request.getUser(), postBatchId);
                accountingResult.setTransferStatus(transferStatus);
                accountingResult.setTransferMessage(null);
            }
        }
        if (transferStatus != null && transferStatus.equals(TransferStatus.ERROR.getTransferStatus())) {
            splitDao.updateTransferStatusChunk(TransferStatus.ERROR.getTransferStatus(), transferMsg, request.getUser(),
                    postBatchId, accountingResult.getChunkId());
            errorDao.insertError(postBatchId, transferMsg, request.getUser(), request.getClientId(),bookId,orgId, accountingResult.getChunkId());
            accountingDao.updateTransferStatusMsg(TransferStatus.ERROR.getTransferStatus(), transferMsg, request.getUser(), postBatchId);
            String text = "Error message: " + transferMsg + "~ error count " + errors + "~ Stop batch on error: " + stopBatchOnErr;
            LOGGER.error("Procedure: " + applyHoldProcName + " validation failed: " + text);
            accountingResult.setTransferStatus(transferStatus);
            accountingResult.setTransferMessage(transferMsg);
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, VALIDATION_ERR);
        }

        return accountingResult;
    }

}
