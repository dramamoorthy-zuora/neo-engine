package com.zuora.neo.engine.jobs.sweep.activities;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.sweep.SweepResult;
import com.zuora.neo.engine.jobs.sweep.TestEvaluator;
import com.zuora.neo.engine.jobs.sweep.constants.SweepParams;
import com.zuora.neo.engine.jobs.sweep.db.api.CurrentPeriod;
import com.zuora.neo.engine.jobs.sweep.db.api.NextPeriod;
import com.zuora.neo.engine.jobs.sweep.db.dao.SweepDao;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

//https://community.temporal.io/t/temporal-with-springboot/2734/11
@ActivityImplementation
@Component
public class SweepActivitiesImpl implements SweepActivities {

    public static final String INVALID_BOOKNAME_MESSAGE = "Sweep Process Failed. Book Name Incorrect";

    public static final String INVALID_PERIOD_MESSAGE = "pending/open Period id not found";

    public static final String TRANSACTION_ERROR_MESSAGE = "Transaction Error";
    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(SweepActivitiesImpl.class);
    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;
    @Autowired
    ParseProgramParameters parseProgramParameters;

    @Override
    public SweepResult sweep() {
        Jdbi jdbi = null;
        jdbi = DbContext.getConnection();

        SweepResult sweepResult = new SweepResult();

        jdbi.useTransaction(handle -> {
            sweepInternal(handle, sweepResult);
        });

        return sweepResult;
    }

    private void sweepInternal(Handle handle, SweepResult sweepResult) {

        logger.info("Enters sweepInternal method");
        WorkflowContext context = WorkflowContextManager.getWorkflowContext();
        CommonDao commonDao = handle.attach(CommonDao.class);
        SweepDao sweepDao = handle.attach(SweepDao.class);
        //get current date
        //get period id
        //get book id
        //execute the update query
        //update job status
        //TODO all sql queries should point to views once we set revenue context

        WorkflowRequest request = context.getRequest();
        Map<String, String> paramsMap = parseProgramParameters.parseParamString(request.getTenantId(), request.getProgramId(), request.getParameterText());
        String bookName = paramsMap.get(SweepParams.BOOK_NAME);
        String orgId = paramsMap.get(SweepParams.ORG_ID);
        Long clientId = request.getClientId();
        BigDecimal rcId = null;
        if (paramsMap.containsKey(SweepParams.RC_ID)) {
            String rcIdStr = paramsMap.get(SweepParams.RC_ID);
            //revpro ui checks for rc id data type
            rcId = rcIdStr != null ? new BigDecimal(rcIdStr) : null;
        }

        String updateBy = request.getUser();

        Long bookId = commonDao.getBookId(bookName, clientId);
        if (bookId == null) {
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, INVALID_BOOKNAME_MESSAGE);
        }
        sweepResult.setBookId(bookId);
        sweepResult.setOrgId(orgId);
        Long periodId = commonDao.getPeriodId(bookId, orgId);
        periodId = TestEvaluator.evaluateForInvalidPeriod(periodId);
        if (periodId == null) {
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.WARNING, INVALID_PERIOD_MESSAGE);
        }
        NextPeriod nextPeriod = sweepDao.getNextPeriodDetails(periodId, clientId);
        CurrentPeriod currentPeriod = sweepDao.getCurrentPeriodDetails(periodId, clientId);

        int rowsUpdated = 0;

        if (currentPeriod.getCurrentQuarterDate().equals(nextPeriod.getNextQuarterDate())) {
            sweepResult.setSweepType("P");
        } else if (nextPeriod.getNextQuarterDate().equals(nextPeriod.getNextYearDate())) {
            sweepResult.setSweepType("Y");
        } else {
            sweepResult.setSweepType("Q");
        }

        String sweepSummarizationEnabled = commonDao.getProfileValue("DO_SWEEP_SUMMARIZATION", "N");

        if (sweepSummarizationEnabled.equals("Y")) {

            long startTime = System.nanoTime();
            int count = insertDataForSweepSummary(handle, request.getRequestId(), periodId, bookId, orgId, clientId, rcId);
            long estimatedTime = System.nanoTime() - startTime;
            logger.info("insertDataForSweepSummary - estimatedTime (nano) ::" + estimatedTime);
            logger.info("insertDataForSweepSummary - estimatedTime (milli) ::" + TimeUnit.MILLISECONDS.convert(estimatedTime, TimeUnit.NANOSECONDS));
            neoWorkflowLogger.log("No of rows inserted for summarization:: " + count + " for the requested id:: " + request.getRequestId());
            logger.info("No of rows inserted for summarization:: " + count + " for the requested id:: " + request.getRequestId());

            startTime = System.nanoTime();
            // updating any leftover summarization records  sweep_batch_id to current sweep_batch_id, those will be picked for the summarization
            int summaryCount = updateSweepBatchId(handle, request.getRequestId());
            estimatedTime = System.nanoTime() - startTime;
            logger.info("updateSweepBatchId - estimatedTime (nano) ::" + estimatedTime);
            logger.info("updateSweepBatchId - estimatedTime (milli) ::" + TimeUnit.MILLISECONDS.convert(estimatedTime, TimeUnit.NANOSECONDS));

            neoWorkflowLogger.log("No of rows for summarization :: " + (count + summaryCount) + " for the requested id:: " + request.getRequestId());
            logger.info("No of rows  for summarization:: " + (count + summaryCount) + " for the requested id:: " + request.getRequestId());

            sweepResult.setSummaryRecords(count + summaryCount);
        }

        if (TestEvaluator.evaluateForTransactionError()) {
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, TRANSACTION_ERROR_MESSAGE);
        }

        long startTime = System.nanoTime();

        if (rcId != null) {

            rowsUpdated = sweepDao.sweepUpdateForRC(nextPeriod.getNextPeriodId(), currentPeriod.getCurrentQuarterDate(), nextPeriod.getNextQuarterDate(),
                    nextPeriod.getNextYearDate(), updateBy, nextPeriod.getNextPeriodId(), periodId, bookId, orgId, rcId);
        } else {

            rowsUpdated = sweepDao.sweepUpdate(nextPeriod.getNextPeriodId(), currentPeriod.getCurrentQuarterDate(), nextPeriod.getNextQuarterDate(),
                    nextPeriod.getNextYearDate(), updateBy, nextPeriod.getNextPeriodId(), periodId, bookId, orgId);
        }
        long estimatedTime = System.nanoTime() - startTime;
        logger.info("sweepUpdate - estimatedTime (nano) ::" + estimatedTime);
        logger.info("sweepUpdate - estimatedTime (milli) ::" + TimeUnit.MILLISECONDS.convert(estimatedTime, TimeUnit.NANOSECONDS));
        neoWorkflowLogger.log("rows updated " + rowsUpdated);
        logger.info("rows updated {}", rowsUpdated);
        sweepResult.setRowsUpdated(rowsUpdated);
        logger.info("Exists sweepInternal method");

    }

    private int insertDataForSweepSummary(Handle handle, Long sweepBatchId, Long postPeriodId, Long bookId, String orgId, Long clientId, BigDecimal rcId) {

        logger.info("Enters insertDataForSweepSummary method");

        String insertStatementSub =
                "insert into RPRO_RC_SCHD_SWEEP_SUMMARY(ATR5 ,ATR3,POST_BATCH_ID,ATR4,ATR1,ATR2,LINE_ID, RORD_INV_REF,AMOUNT,INDICATORS,CLIENT_ID,"
                        + "REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,DR_LINK_ID ,CRTD_BY,ID,JE_BATCH_ID,BLD_FX_DT,REL_PCT,CRTD_PRD_ID,DIST_ID,BLD_FX_RATE,"
                        + "CR_SEGMENTS,F_EX_RATE,CURR, ORIG_LINE_ID,POST_PRD_ID,CR_LINK_ID,RC_VER,UPDT_DT,SCHD_ADDL_ID,"
                        + "UPDT_PRD_ID,RC_ID ,POB_ID,PQ_AMT,MODEL_ID,SEC_ATR_VAL,G_EX_RATE,POST_DATE,JE_BATCH_NAME,EX_RATE_DATE,"
                        + "CRTD_DT ,PRD_ID,PY_AMT,UPDT_BY,DR_SEGMENTS,REL_ID,PP_AMT,SWEEP_BATCH_ID) select ATR5 ,ATR3,POST_BATCH_ID,ATR4,ATR1,ATR2,"
                        + "LINE_ID, RORD_INV_REF,AMOUNT,INDICATORS,CLIENT_ID,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,DR_LINK_ID"
                        + ",CRTD_BY,ID,JE_BATCH_ID,BLD_FX_DT,REL_PCT,CRTD_PRD_ID,DIST_ID,BLD_FX_RATE,CR_SEGMENTS,F_EX_RATE,CURR"
                        + ",ORIG_LINE_ID,POST_PRD_ID,CR_LINK_ID,RC_VER,UPDT_DT,SCHD_ADDL_ID,UPDT_PRD_ID,RC_ID"
                        + ",POB_ID,PQ_AMT,MODEL_ID,SEC_ATR_VAL,G_EX_RATE,POST_DATE,JE_BATCH_NAME,EX_RATE_DATE,CRTD_DT"
                        + ",PRD_ID,PY_AMT,UPDT_BY,DR_SEGMENTS,REL_ID,PP_AMT , ${sweepBatchId} from RPRO_RC_SCHD RPRO_RC_SCHD "
                        + " WHERE post_prd_id = ${postPeriodId} AND book_id = ${bookId} AND rpro_rc_schd_pkg.get_interfaced_flag(indicators)='N'"
                        + " AND sec_atr_val = ${orgId} AND CLIENT_ID = ${clientId} AND "
                        + " not exists (SELECT 1 FROM RPRO_RC_SCHD_SWEEP_SUMMARY  RPRO_RC_SCHD_SWEEP_SUMMARY  "
                        + " where RPRO_RC_SCHD_SWEEP_SUMMARY.id = RPRO_RC_SCHD.id and RPRO_RC_SCHD_SWEEP_SUMMARY.CLIENT_ID = RPRO_RC_SCHD.CLIENT_ID  )";

        String rcCondition = " AND root_line_id IN ( SELECT id FROM rpro_rc_line WHERE rc_id = ${rcId} ) ";

        Map<String, String> values = new HashMap<>();
        values.put("${sweepBatchId}", String.valueOf(sweepBatchId));
        values.put("${postPeriodId}", String.valueOf(postPeriodId));
        values.put("${bookId}", String.valueOf(bookId));
        values.put("${orgId}", orgId);
        values.put("${clientId}", String.valueOf(clientId));
        values.put("${rcId}", String.valueOf(rcId));

        if (rcId != null) {
            insertStatementSub = insertStatementSub + rcCondition;
        }

        for (Map.Entry<String, String> entrySet : values.entrySet()) {
            insertStatementSub = insertStatementSub.replace(entrySet.getKey(), entrySet.getValue());
        }
        int rowsUpdated = handle.createUpdate(insertStatementSub).execute();
        logger.info("Exits insertDataForSweepSummary method");
        return rowsUpdated;
    }

    private int updateSweepBatchId(Handle handle, Long requestId) {

        String updateStatement = "UPDATE rpro_rc_schd_sweep_summary SET sweep_batch_id = " + requestId + "WHERE sweep_batch_id !=" + requestId;
        return handle.createUpdate(updateStatement).execute();
    }
}
