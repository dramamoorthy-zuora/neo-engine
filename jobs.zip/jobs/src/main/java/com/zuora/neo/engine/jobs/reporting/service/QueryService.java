package com.zuora.neo.engine.jobs.reporting.service;

public interface QueryService {




}
