package com.zuora.neo.engine.common;

public enum ScheduleTypes {
    NETTING("D"),
    REVENUE("R"),
    ALLOCATION("A"),
    INTER_COMPANY("I"),
    VARIABLE_CONSIDERATION("V"),
    MJE("T"),
    RORD_CONTRA("G");

    private final String scheduleType;
    ScheduleTypes(String scheduleType) {
        this.scheduleType = scheduleType;
    }

    public String getScheduleType() {
        return scheduleType;
    }
}
