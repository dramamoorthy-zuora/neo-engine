package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.api.AccountValue;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.common.DbCommonUtils;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.sfc.constants.SfcConstants;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;

import org.jdbi.v3.core.Handle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class SfcDbCacheContextService {

    @Autowired
    ParseProgramParameters parseProgramParameters;

    public SfcDbCacheContext fetchCommonDetailsFromDb(Handle handle) {

        CommonDao commonDao = handle.attach(CommonDao.class);
        SfcDao sfcDao = handle.attach(SfcDao.class);

        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();

        Map<String, Integer> currencyMap = DbCommonUtils.getCurrencyMap(request.getTenantId(), commonDao);
        currencyMap.put(request.getTenantId() + ":" + SfcConstants.DEFAULT_PARAM, 2);
        List<FinanceTypeValues> financeTypeValuesList = sfcDao.getFinanceTypeDetailsForSfc();
        if (financeTypeValuesList.isEmpty()) {
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.WARNING, SfcConstants.NO_SFC_TYPE_AVAILABLE);
        }

        Map<String, String> paramsMap = parseProgramParameters.parseParamString(request.getTenantId(), request.getProgramId(),
                request.getParameterText());
        String bookName = paramsMap.get(SfcConstants.BOOK_NAME_PARAM);
        Long clientId = request.getClientId();
        Long bookId = commonDao.getBookId(bookName, clientId);
        if (bookId == null) {
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, SfcConstants.INVALID_BOOKNAME_MESSAGE);
        }

        List<AccountValue> accountValuesList = commonDao.getAccountValues();

        long currentPeriodId = commonDao.getPeriodId(bookId, request.getOrgId());
        List<CalendarDetails> calendarDetailsCache = commonDao.cacheCalendarDetails();
        List<CalendarDetails> calendarDetails = commonDao.getPeriodDetailsById(currentPeriodId);
        if (calendarDetails == null) {
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, SfcConstants.CALENDAR_DETAILS_NOT_PRESENT);
        }

        String segmentDelimiter = commonDao.getProfileValue("SEGMENT_DELIMITER", ":");

        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();
        sfcDbCacheContext.setBookId(bookId);
        sfcDbCacheContext.setCalendarDetails(calendarDetails);
        sfcDbCacheContext.setCalendarDetailsCache(calendarDetailsCache);
        sfcDbCacheContext.setCurrentPeriodId(currentPeriodId);
        sfcDbCacheContext.setParamsMap(paramsMap);
        sfcDbCacheContext.setAccountValuesList(accountValuesList);
        sfcDbCacheContext.setFinanceTypeValuesList(financeTypeValuesList);
        sfcDbCacheContext.setCurrencyMap(currencyMap);
        sfcDbCacheContext.setSegmentDelimiter(segmentDelimiter);

        return sfcDbCacheContext;

    }
}
