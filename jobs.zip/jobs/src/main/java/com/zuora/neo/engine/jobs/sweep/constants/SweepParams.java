package com.zuora.neo.engine.jobs.sweep.constants;

public final class SweepParams {

    public static final String BOOK_NAME = "BOOK NAME";
    public static final String ORG_ID = "ORG ID";
    public static final String RC_ID = "RC ID";
}
