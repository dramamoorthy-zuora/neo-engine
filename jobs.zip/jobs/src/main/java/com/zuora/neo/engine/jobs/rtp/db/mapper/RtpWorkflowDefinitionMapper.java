package com.zuora.neo.engine.jobs.rtp.db.mapper;

import com.zuora.neo.engine.jobs.rtp.api.RtpStep;
import com.zuora.neo.engine.jobs.rtp.api.RtpWorkflowDefinition;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class RtpWorkflowDefinitionMapper implements RowMapper<RtpWorkflowDefinition> {

    @Override
    public RtpWorkflowDefinition map(ResultSet rs, StatementContext ctx) throws SQLException {
        return new RtpWorkflowDefinition(
                new RtpStep(rs.getInt("step_id"), rs.getString("step_name")),
                rs.getInt("execution_order")
        );
    }
}
