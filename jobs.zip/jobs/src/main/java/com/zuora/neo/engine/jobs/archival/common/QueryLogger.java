package com.zuora.neo.engine.jobs.archival.common;

import org.jdbi.v3.core.statement.SqlLogger;

import org.jdbi.v3.core.statement.StatementContext;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Component
public class QueryLogger implements SqlLogger {

    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(QueryLogger.class);

    private boolean logQuery = false;

    @Override
    public void logAfterExecution(StatementContext context) {
        if (!logQuery) {
            return;
        }
        Instant startTime = context.getExecutionMoment();
        Instant endTime = context.getCompletionMoment();
        if (endTime != null && startTime != null) {
            long milliSeconds = startTime.until(endTime, ChronoUnit.MILLIS);
            logger.info("(" + Thread.currentThread().getId() + ") " + "Query execution time : " + milliSeconds + "ms. " + context.getRawSql());
        } else {
            logger.error("end time is null. SKIPPING SQL LOGGING");
        }

    }

    public boolean isLogQuery() {
        return logQuery;
    }

    public void setLogQuery(boolean logQuery) {
        this.logQuery = logQuery;
    }
}
