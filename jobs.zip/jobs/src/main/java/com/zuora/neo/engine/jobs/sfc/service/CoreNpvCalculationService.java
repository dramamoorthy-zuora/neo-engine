package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;
import com.zuora.neo.engine.jobs.sfc.exception.NoDetailsFoundException;

import org.jdbi.v3.core.statement.OutParameters;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class CoreNpvCalculationService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CoreNpvCalculationService.class);

    public static BigDecimal calculateFinalInterestRate(BigDecimal interestRate) {
        return (interestRate.divide(BigDecimal.valueOf(100.00))).add(BigDecimal.valueOf(1.00));
    }

    /*
       Method to Calculate Interest Rates for the amount of Regular and Leap Days

       Input :
       regDays : number of regular days in the time period
       leapDays : number of leap days in the time period
       regIntRate : Interest Rate for regular days
       leapIntRate : Interest Rate for leap days

       Output :
       intRate : Total Interest Rate
     */
    public static BigDecimal calculateInterestRates(BigDecimal regDays, BigDecimal leapDays, BigDecimal regIntRate, BigDecimal leapIntRate) {
        BigDecimal finalRegIntRate = calculateFinalInterestRate(regIntRate);
        BigDecimal finalLeapIntRate = calculateFinalInterestRate(leapIntRate);
        LOGGER.debug("Final Regular Days Interest Rate: " + finalRegIntRate + " Final Regular Days Interest Rate: " + finalLeapIntRate);
        BigDecimal intRate = finalRegIntRate.pow(regDays.intValue()).multiply(finalLeapIntRate.pow(leapDays.intValue()));
        LOGGER.debug("Final Interest Rate : " + intRate);
        return intRate;
    }

    /*
        Service Method to Calculate Net NPV
        This method calculates the Net NPV and Interest accrual for each line using payments and dates.
        It also creates an entry in the VC Table.

        Input Args :
        sfcDao -> Dao for SFC DB Operations
        commonDao -> Dao for DB Operations
        sfcStatusValues -> Line from Sfc Status Table
        sfcPaymentDetails -> Payment details for the doc line
        rcLineDetails -> Rc Line Details for the doc line
        currencyMap -> Currency Map for Rounding Details for each currency. Default is 2.
        lineId -> Line Id for the doc line
        vcTypeId -> Finance Type Id
        rcId -> RC Id for the doc line
        bookId -> Book Id for the Rc Line
        financeTypeValueForRcLine -> Finance Type Value from Finance Table for the RC Line
        request -> Request
     */
    public void calculateNetNpv(SfcDao sfcDao, CommonDao commonDao, SfcStatusValues sfcStatusValue, List<SfcPaymentDetails> sfcPaymentDetails,
            List<RcLineDetails> rcLineDetails, Map<String, Integer> currencyMap, long lineId, long vcTypeId, long rcId, long bookId,
            List<FinanceTypeValues> financeTypeValueForRcLine, WorkflowRequest request) throws NoDetailsFoundException {
        Date paymntStartDate = null;
        BigDecimal regDays = BigDecimal.valueOf(0.0);
        BigDecimal leapDays = BigDecimal.valueOf(0.0);
        BigDecimal regIntRate = BigDecimal.valueOf(0.0);
        BigDecimal leapIntRate = BigDecimal.valueOf(0.0);
        Integer currRound = 0;
        BigDecimal netNpvIntAccrual = BigDecimal.valueOf(0.0);
        BigDecimal netNpvAmt = BigDecimal.valueOf(0.0);

        List<BigDecimal> netPaymentValueList = new ArrayList<>();
        List<BigDecimal> interestAccrualList = new ArrayList<>();
        List<Date> paymntStartDateList = new ArrayList<>();
        List<Long> ids = new ArrayList<>();

        if (!rcLineDetails.isEmpty()) {
            regIntRate = rcLineDetails.get(0).getnpvInterestRate().divide(BigDecimal.valueOf(365), 20, RoundingMode.HALF_EVEN);
            leapIntRate = rcLineDetails.get(0).getnpvInterestRate().divide(BigDecimal.valueOf(366), 20, RoundingMode.HALF_EVEN);
            String currencyCode = rcLineDetails.get(0).getCurrencyCode() == null ? "Default" : rcLineDetails.get(0).getCurrencyCode();
            currRound = currencyMap.get(request.getTenantId() + ":" + currencyCode);
        }

        for (SfcPaymentDetails sfcPaymentDetail : sfcPaymentDetails) {
            if (sfcPaymentDetail.getPaymtAmt() == null) {
                throw new NoDetailsFoundException("Payment Amount is null/not found for line " + sfcStatusValue.getDocLineId());
            }
            LOGGER.info("Doc line id ~ " + sfcPaymentDetail.getDocLineId() + "Payment Amt ~ "
                    + sfcPaymentDetail.getPaymtAmt());
            Date paymntDate = (Date) sfcPaymentDetail.getPaymtDate();
            Date paymntEndDate = (Date) sfcPaymentDetail.getPaymtEndDate();
            Date lineStartDate = (Date) rcLineDetails.get(0).getStartDate();
            if (paymntStartDate == null) {
                if (lineStartDate != null) {
                    paymntStartDate = lineStartDate;
                } else {
                    paymntStartDate = (Date) sfcPaymentDetail.getPaymtDate();
                }
                sfcPaymentDetail.setPaymtStartDate(paymntStartDate);
            } else {
                paymntEndDate = (Date) sfcPaymentDetail.getPaymtStartDate();
                paymntEndDate = new Date(paymntEndDate.getTime() - (24 * 60 * 60 * 1000));
                LOGGER.info("For Doc line id : " + sfcStatusValue.getDocLineId()
                        + " Payment Start Date : " + paymntStartDate + " Payment Date : " + paymntDate + "paymntEndDate" + paymntEndDate);
                OutParameters totalDaysOut = commonDao.getTotalDays(new java.sql.Date(paymntStartDate.getTime()), new java.sql.Date(paymntEndDate.getTime()));
                Double dregDays = totalDaysOut.getDouble("p_regular_days");
                Double dleapDays = totalDaysOut.getDouble("p_leap_days");
                if (dregDays != null) {
                    regDays = BigDecimal.valueOf(dregDays);
                }
                if (dleapDays != null) {
                    leapDays = BigDecimal.valueOf(dleapDays);
                }
                LOGGER.info("For Payment Id " + sfcPaymentDetail.getId() + " Regular Days : " + regDays + " Leap Days : " + leapDays);
            }
            BigDecimal intRate = calculateInterestRates(regDays, leapDays, regIntRate, leapIntRate);
            BigDecimal netPaymentValue = sfcPaymentDetail.getPaymtAmt().divide(intRate, currRound, RoundingMode.HALF_EVEN);
            BigDecimal interestAccrual = sfcPaymentDetail.getPaymtAmt().subtract(netPaymentValue);
            netPaymentValue = netPaymentValue.setScale(currRound, RoundingMode.HALF_EVEN);
            interestAccrual = interestAccrual.setScale(currRound, RoundingMode.HALF_EVEN);
            netNpvAmt = netNpvAmt.add(netPaymentValue);
            netNpvIntAccrual = netNpvIntAccrual.add(interestAccrual);
            LOGGER.info("Net NPV Amount  for doc line id " + sfcStatusValue.getDocLineId() + " Payment Id " + sfcPaymentDetail.getId() + " is " + netNpvAmt);
            LOGGER.info("Net NPV Interest Accrual for doc line id " + sfcStatusValue.getDocLineId() + " Payment Id "
                    + sfcPaymentDetail.getId() + " is " + netNpvIntAccrual);

            //To Update tables
            netPaymentValueList.add(netPaymentValue);
            interestAccrualList.add(interestAccrual);
            paymntStartDateList.add(sfcPaymentDetail.getPaymtStartDate());
            ids.add(sfcPaymentDetail.getId());
        }

        sfcDao.updatePaymentBatchById(netPaymentValueList, interestAccrualList, paymntStartDateList, ids);

        //Call Vc Create Wrapper Program
        if (lineId != 0 && rcId != 0) {
            LOGGER.info("For doc line id : " + sfcStatusValue.getDocLineId() + " calling createVc procedure");
            OutParameters totalDaysOut = commonDao.createVc(lineId, rcId, bookId, vcTypeId, netNpvIntAccrual, "SFC VC");
            String errMsg = totalDaysOut.getString("p_err_msg");
            Integer errCode = totalDaysOut.getInt("p_err_code");
            LOGGER.debug("For Doc line id : " + sfcStatusValue.getDocLineId()
                    + " After calling  createVc proc errMsg is " + errMsg + " errCode is " + errCode);
            sfcDao.updateRcLinePaTableWithFncTypeVersion(financeTypeValueForRcLine.get(0).getVersion(), lineId, vcTypeId);
        }

        sfcStatusValue.setNetNpvAmt(netNpvAmt);
        sfcStatusValue.setNetInterestAccrual(netNpvIntAccrual);
    }
}
