package com.zuora.neo.engine.jobs.sfc;

import com.google.common.base.MoreObjects;

public class SfcResult {

    int warningCount;

    public int getWarningCount() {
        return warningCount;
    }

    public void setWarningCount(int warningCount) {
        this.warningCount = warningCount;
    }

    public void addWarningCount() {
        this.warningCount = this.warningCount + 1;
    }

    public SfcResult() {
        this.warningCount = 0;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("warningCount", warningCount)
                .toString();
    }
}
