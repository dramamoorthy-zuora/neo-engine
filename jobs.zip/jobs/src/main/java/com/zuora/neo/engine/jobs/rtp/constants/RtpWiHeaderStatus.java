package com.zuora.neo.engine.jobs.rtp.constants;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum RtpWiHeaderStatus {

    NEW("NEW"),
    IN_PROGRESS("IN PROGRESS"),
    ERROR("ERROR"),
    COMPLETED("COMPLETED");

    private final String headerStatus;

    RtpWiHeaderStatus(String headerStatus) {
        this.headerStatus = headerStatus;
    }

    @JsonValue
    public String getHeaderStatus() {
        return headerStatus;
    }

    private static final Map<String, RtpWiHeaderStatus> LOOKUP =
            Arrays.stream(RtpWiHeaderStatus.values()).collect(
                    Collectors.toMap(RtpWiHeaderStatus::getHeaderStatus, Function.identity()));

    @JsonCreator
    public static RtpWiHeaderStatus fromHeaderStatus(String headerStatus) {
        return LOOKUP.get(headerStatus);
    }

}
