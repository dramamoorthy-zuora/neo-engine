package com.zuora.neo.engine.jobs.transferaccounting.db.api;

public class GlIntegrationMap {
    private Long id;
    private String fieldName;
    private String objectType;
    private String sourceFrom;
    private String sourceValue;
    private String indicators;
    private Integer clientId;
    private Long currentPeriodId;
    private Integer displaySequence;
    private String displayLabel;

    public GlIntegrationMap(Long id, String fieldName, String objectType, String sourceFrom, String sourceValue, String indicators, Integer clientId,
            Long currentPeriodId, Integer displaySequence, String displayLabel) {
        this.id = id;
        this.fieldName = fieldName;
        this.objectType = objectType;
        this.sourceFrom = sourceFrom;
        this.sourceValue = sourceValue;
        this.indicators = indicators;
        this.clientId = clientId;
        this.currentPeriodId = currentPeriodId;
        this.displaySequence = displaySequence;
        this.displayLabel = displayLabel;
    }

    public GlIntegrationMap(Long id, String fieldName, String objectType, String sourceFrom, String sourceValue) {
        this.id = id;
        this.fieldName = fieldName;
        this.objectType = objectType;
        this.sourceFrom = sourceFrom;
        this.sourceValue = sourceValue;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFieldName() {
        return fieldName;
    }

    public String getObjectType() {
        return objectType;
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    public String getSourceFrom() {
        return sourceFrom;
    }

    public String getSourceValue() {
        return sourceValue;
    }

    public String getIndicators() {
        return indicators;
    }

    public void setIndicators(String indicators) {
        this.indicators = indicators;
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public Long getCurrentPeriodId() {
        return currentPeriodId;
    }

    public Integer getDisplaySequence() {
        return displaySequence;
    }

    public String getDisplayLabel() {
        return displayLabel;
    }

    @Override
    public String toString() {
        return "GlIntegrationMap{"
                + "fieldName='" + fieldName + '\''
                + ", objectType='" + objectType + '\''
                + ", sourceFrom='" + sourceFrom + '\''
                + ", sourceValue='" + sourceValue + '\''
                + ", displaySequence=" + displaySequence
                + ", displayLabel='" + displayLabel + '\''
                + '}';
    }
}
