package com.zuora.neo.engine.jobs.transferaccounting.constants;

public class AccountingParams {
    //master job params for job id 149
    public static final String CRITERIA_NAME = "CRITERIA NAME";
    public static final String CRITERIA_VALUE = "CRITERIA VALUE";
    public static final String EXCLUDE_FLAG = "EXCLUDE FLAG";

    //UI workflow related params for job id 6
    public static final String BATCH_ID = "POST BATCH ID";
    public static final String TYPE = "TYPE";

    //org specific job for job id 475
    public static final String CRI_NAME = "p_cri_name";
    public static final String CRI_VAL = "p_cri_val";
    public static final String ORG_ID = "p_sec_atr_val";
    public static final String EXC_FLAG = "p_excld_flag";

    //CR DR Link
    public static final String POST_BATCH_ID = "Post Batch ID";
    public static final String ORG = "Org Id";
}
