package com.zuora.neo.engine.jobs.transferaccounting;

import com.zuora.neo.engine.jobs.transferaccounting.constants.StageHandlerType;

import com.google.common.base.MoreObjects;

/*
This class stores the results that are needed by subsequent activities
both for a normal(like status and message) as well as in the
multi-threaded flow(like min, max RC id, chunk id etc.)
 */
public class ThreadedAccountingResult {
    String transferStatus;
    String transferMessage;
    Long bookId;
    Long postBatchId;

    Long minRcId;
    Long maxRcId;
    Long chunkId;
    Integer noOfThreads;

    StageHandlerType stageHandlerType;
    String orgId;

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getTransferStatus() {
        return transferStatus;
    }

    public void setTransferStatus(String transferStatus) {
        this.transferStatus = transferStatus;
    }

    public String getTransferMessage() {
        return transferMessage;
    }

    public void setTransferMessage(String transferMessage) {
        this.transferMessage = transferMessage;
    }

    public Long getBookId() {
        return bookId;
    }

    public void setBookId(Long bookId) {
        this.bookId = bookId;
    }

    public Long getPostBatchId() {
        return postBatchId;
    }

    public void setPostBatchId(Long postBatchId) {
        this.postBatchId = postBatchId;
    }

    public Long getMinRcId() {
        return minRcId;
    }

    public void setMinRcId(Long minRcId) {
        this.minRcId = minRcId;
    }

    public Long getMaxRcId() {
        return maxRcId;
    }

    public void setMaxRcId(Long maxRcId) {
        this.maxRcId = maxRcId;
    }

    public Long getChunkId() {
        return chunkId;
    }

    public void setChunkId(Long chunkId) {
        this.chunkId = chunkId;
    }

    public Integer getNoOfThreads() {
        return noOfThreads;
    }

    public void setNoOfThreads(Integer noOfThreads) {
        this.noOfThreads = noOfThreads;
    }

    public StageHandlerType getStageHandlerType() {
        return stageHandlerType;
    }

    public void setStageHandlerType(StageHandlerType stageHandlerType) {
        this.stageHandlerType = stageHandlerType;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("transferStatus", transferStatus)
                .add("postBatchId", postBatchId)
                .add("transferMessage", transferMessage)
                .toString();
    }
}
