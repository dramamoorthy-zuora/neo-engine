package com.zuora.neo.engine.jobs.transferaccounting.db.api;

public class ChunkStatus {
    private Long chunkId;
    private String status;

    public Long getChunkId() {
        return chunkId;
    }

    public void setChunkId(Long chunkId) {
        this.chunkId = chunkId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ChunkStatus(Long chunkId, String status) {
        this.chunkId = chunkId;
        this.status = status;
    }

    public ChunkStatus() {
    }
}
