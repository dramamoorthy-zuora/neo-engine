package com.zuora.neo.engine.jobs.sweep.activities.rco;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.sweep.SweepResult;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@ActivityImplementation
@Component
public class RcoActivitiesImpl implements RcoActivities {

    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(RcoActivitiesImpl.class);

    ObjectMapper mapper = new ObjectMapper();

    @Override
    public void createRcoJob(SweepResult sweepResult) {

        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Jdbi jdbi = DbContext.getConnection();
        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            String closeProcessEnabled = commonDao.getProfileValue("ENABLE_CLOSE_PROCESS_API", "Y");
            if (closeProcessEnabled.equals("Y")) {
                String additionalParams = builAdditionalParams(sweepResult);
                RcoData analysisRcoData = buildRcoData(sweepResult, RcoEventType.ACCOUNT_ANALYSIS, additionalParams);
                RcoData unPostedRcoData = buildRcoData(sweepResult, RcoEventType.UNPOSTED_SCHEDULES, additionalParams);

                logger.info(" create RcoJob for the requested id:: {} is started", request.getRequestId());
                createRcoJob(commonDao, analysisRcoData);
                createRcoJob(commonDao, unPostedRcoData);
                logger.info(" create RcoJob for the requested id:: {} is completed", request.getRequestId());
            }
        });
    }

    private void createRcoJob(CommonDao commonDao, RcoData rcoData) {
        commonDao.createRcoJob(rcoData.getRcoEventType().getType(), rcoData.getBookId(), rcoData.getCreatedDate(), rcoData.getAdditionalParams());
    }

    private String builAdditionalParams(SweepResult sweepResult) {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        ObjectNode additionalParams = mapper.createObjectNode();
        additionalParams.put("ORG_ID", request.getOrgId());
        additionalParams.put("BOOK_ID", sweepResult.getBookId());
        additionalParams.put("REQUEST_ID", request.getRequestId());
        try {
            return mapper.writeValueAsString(additionalParams);
        } catch (JsonProcessingException e) {
            logger.error("error in writing json for Rco", e);
            throw new NonRetryableActivityException(e);
        }
    }

    private RcoData buildRcoData(SweepResult sweepResult, RcoEventType eventType, String additionalParams) {
        RcoData rcoData = new RcoData();
        rcoData.setRcoEventType(eventType);
        rcoData.setBookId(sweepResult.getBookId());
        rcoData.setAdditionalParams(additionalParams);
        rcoData.setCreatedDate(Timestamp.valueOf(LocalDateTime.now()));
        return rcoData;
    }

}
