package com.zuora.neo.engine.jobs.rtp.service;

import com.zuora.neo.engine.jobs.rtp.api.RtpBatchContext;
import com.zuora.neo.engine.jobs.rtp.config.RtpProperties;
import com.zuora.neo.engine.jobs.rtp.db.doa.RtpDao;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RtpCleanupService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(RtpCleanupService.class);

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;

    @Autowired
    RtpProperties rtpProperties;

    public void cleanupRtpStaleData(RtpDao rtpDao, String secAtrVal) {
        rtpDao.moveErrorWiToHistory(secAtrVal, rtpProperties.getMaxRetryCount());
        rtpDao.deleteErrorWi(secAtrVal, rtpProperties.getMaxRetryCount());
        int noOfRtpHeadersUpdated = rtpDao.cleanupRtpHeaderStaleData(secAtrVal, rtpProperties.getMaxRetryCount());
        neoWorkflowLogger.log("No.of Rtp Headers cleaned up - " + noOfRtpHeadersUpdated);
        LOGGER.info("No.of Rtp Headers cleaned up - " + noOfRtpHeadersUpdated);
    }

    public void moveCompletedHeaderToHistory(RtpDao rtpDao, RtpBatchContext batchContext) {
        Integer noOfHeadersMoved = rtpDao.moveCompletedHeaderToHistory(batchContext.getSecAtrVal(), batchContext.getBatchId());
        LOGGER.info("No.of Rtp Headers moved to history - " + noOfHeadersMoved);
    }

    public void deleteCompletedHeader(RtpDao rtpDao, RtpBatchContext batchContext) {
        Integer noOfHeadersDeleted = rtpDao.deleteCompletedHeader(batchContext.getSecAtrVal(), batchContext.getBatchId());
        LOGGER.info("No.of Rtp Headers deleted - " + noOfHeadersDeleted);
    }

    public void moveCompletedWiToHistory(RtpDao rtpDao, RtpBatchContext batchContext) {
        Integer noOfHeadersMoved = rtpDao.moveCompletedWiToHistory(batchContext.getSecAtrVal(), batchContext.getBatchId());
        LOGGER.info("No.of Rtp Wis moved to history - " + noOfHeadersMoved);
    }

    public void deleteCompletedWi(RtpDao rtpDao, RtpBatchContext batchContext) {
        Integer noOfHeadersDeleted = rtpDao.deleteCompletedWi(batchContext.getSecAtrVal(), batchContext.getBatchId());
        LOGGER.info("No.of Rtp Wis deleted - " + noOfHeadersDeleted);
    }

    public void postProcessCleanup(RtpDao rtpDao, RtpBatchContext batchContext) {
        moveCompletedWiToHistory(rtpDao, batchContext);
        deleteCompletedWi(rtpDao, batchContext);
        moveCompletedHeaderToHistory(rtpDao, batchContext);
        deleteCompletedHeader(rtpDao, batchContext);
    }
}
