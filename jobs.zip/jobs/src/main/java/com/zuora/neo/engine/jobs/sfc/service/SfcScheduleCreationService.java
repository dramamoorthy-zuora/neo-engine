package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.common.util.CommonUtils;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.jobs.sfc.api.SfcSegmentsFlagsVersions;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.context.SfcPostProcessDetailsContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SchdIndicator;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SfcScheduleCreationService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcScheduleCreationService.class);
    @Autowired
    RcScheduleService rcScheduleService;
    @Autowired
    SfcCalcDetailService sfcCalcDetailService;
    @Autowired
    AccountValService accountValService;

    public static long calculateDurationForPaymentPeriods(SfcPaymentDetails sfcPaymentDetail, CalendarDetails calendarDetail,
            Map<String, Date> scheduleDates) {
        long noOfDays;
        //payment Start Date between period start date and period end date
        //paymtStartDate >= periodStartDate && paymtStartDate <= periodEndDate
        if ((sfcPaymentDetail.getPaymtStartDate().compareTo(calendarDetail.getStartDate()) > 0
                || sfcPaymentDetail.getPaymtStartDate().compareTo(calendarDetail.getStartDate()) == 0)
                && (sfcPaymentDetail.getPaymtStartDate().compareTo(calendarDetail.getEndDate()) < 0
                || sfcPaymentDetail.getPaymtStartDate().compareTo(calendarDetail.getEndDate()) == 0)) {
            noOfDays = CommonUtils.getNumberOfDays(sfcPaymentDetail.getPaymtStartDate(), calendarDetail.getEndDate());
            scheduleDates.put("startDate", sfcPaymentDetail.getPaymtStartDate());
            scheduleDates.put("endDate", calendarDetail.getEndDate());
        } else if ((sfcPaymentDetail.getPaymtEndDate().compareTo(calendarDetail.getStartDate()) > 0
                || sfcPaymentDetail.getPaymtEndDate().compareTo(calendarDetail.getStartDate()) == 0)
                && (sfcPaymentDetail.getPaymtEndDate().compareTo(calendarDetail.getEndDate()) < 0
                || sfcPaymentDetail.getPaymtEndDate().compareTo(calendarDetail.getEndDate()) == 0)) {
            //payment End Date between period Start date and period End date
            noOfDays = CommonUtils.getNumberOfDays(calendarDetail.getStartDate(), sfcPaymentDetail.getPaymtEndDate());
            scheduleDates.put("startDate", calendarDetail.getStartDate());
            scheduleDates.put("endDate", sfcPaymentDetail.getPaymtEndDate());
        } else {
            //no payment in between period
            noOfDays = CommonUtils.getNumberOfDays(calendarDetail.getStartDate(), calendarDetail.getEndDate());
            scheduleDates.put("startDate", calendarDetail.getStartDate());
            scheduleDates.put("endDate", calendarDetail.getEndDate());
        }
        return noOfDays;
    }

    public static BigDecimal getNpvValueFromDailyInterest(BigDecimal rebEndBfInt, BigDecimal dailyInt, long noOfDays) {
        BigDecimal dailyInterestAddOne = dailyInt.add(BigDecimal.valueOf(1));
        BigDecimal npvAmount = rebEndBfInt.multiply(dailyInterestAddOne.pow((int) noOfDays));
        LOGGER.debug("NPV Amount Calculated after Rounding " + npvAmount);
        return npvAmount;
    }

    public List<CalendarDetails> getPeriodsBetweenStartEndDate(SfcDbCacheContext sfcDbCacheContext, Date startDate, Date endDate) {
        List<CalendarDetails> calendarDetailsCache = sfcDbCacheContext.getCalendarDetailsCache();
        List<CalendarDetails> calendarDetailsList = new ArrayList<>();
        for (CalendarDetails calendarDetail : calendarDetailsCache) {
            boolean startDateBetweenPeriod = startDate.compareTo(calendarDetail.getStartDate()) >= 0
                    && startDate.compareTo(calendarDetail.getEndDate()) <= 0;
            boolean endDateBetweenPeriod = endDate.compareTo(calendarDetail.getStartDate()) >= 0
                    && endDate.compareTo(calendarDetail.getEndDate()) <= 0;
            boolean periodWithinStartAndEndDate = calendarDetail.getStartDate().compareTo(startDate) >= 0
                    && calendarDetail.getEndDate().compareTo(endDate) <= 0;

            if (startDateBetweenPeriod || endDateBetweenPeriod || periodWithinStartAndEndDate) {
                calendarDetailsList.add(calendarDetail);
            }
        }
        return calendarDetailsList;
    }

    public void createSfcSchedule(SfcStatusValues sfcStatusValue, List<RcLinePaData> rcLinePaDataRecord,
            List<FinanceTypeFlagDetails> financeTypeFlagDetailsList, long openPeriodId, SchdIndicator schdIndicator, SfcDbCacheContext sfcDbCacheContext,
            SfcPostProcessDetailsContext sfcPostProcessDetailsContext, SfcSegmentsFlagsVersions sfcSegmentsFlagsVersions) {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        BigDecimal paymentAmount;
        BigDecimal principleAmount = BigDecimal.valueOf(0.0);
        BigDecimal npvInt = BigDecimal.valueOf(0.0);
        BigInteger yearDays;
        BigDecimal totalInterestAmount = BigDecimal.valueOf(0.0);
        List<SfcCalcDetails> sfcCalcDetailsList = new ArrayList<>();
        List<RcScheduleRecord> rcScheduleRecordList = new ArrayList<>();
        List<SfcPaymentDetails> sfcPaymentDetails = sfcPostProcessDetailsContext.getSfcPaymentDetailsBatchMap().get(sfcStatusValue.getDocLineId());
        List<RcLineDetails> rcLineDetails = sfcPostProcessDetailsContext.getRcLineDetailsBatchMap()
                .get(sfcStatusValue.getDocLineId());
        List<RcScheduleRecord> rcScheduleRecordBatch = sfcPostProcessDetailsContext.getRcScheduleRecordBatch();
        List<SfcCalcDetails> sfcCalcDetailsBatch = sfcPostProcessDetailsContext.getSfcCalcDetailsBatch();
        Map<String, Integer> currencyMap = sfcDbCacheContext.getCurrencyMap();
        long rcVersion = sfcSegmentsFlagsVersions.getRcVersion();

        if (!rcLineDetails.isEmpty()) {
            principleAmount = rcLineDetails.get(0).getPrincipleAmount();
            npvInt = rcLineDetails.get(0).getnpvInterestRate();
        }

        BigDecimal rebBegin = null;
        BigDecimal rebEndBfInt = null;
        BigDecimal rebEndAfInt = null;
        // To recalculate start date for each run
        rcLinePaDataRecord.get(0).setStartDate(null);

        for (SfcPaymentDetails sfcPaymentDetail : sfcPaymentDetails) {
            paymentAmount = sfcPaymentDetail.getPaymtAmt();
            Integer currRound;
            List<CalendarDetails> calendarDetailsList = getPeriodsBetweenStartEndDate(sfcDbCacheContext, sfcPaymentDetail.getPaymtStartDate(),
                    sfcPaymentDetail.getPaymtEndDate());
            for (int calendarIndex = 0; calendarIndex < calendarDetailsList.size(); calendarIndex++) {

                CalendarDetails calendarDetail = calendarDetailsList.get(calendarIndex);
                long noOfDays;
                Map<String, Date> scheduleDates = new HashMap<>();
                currRound = currencyMap.get(request.getTenantId() + ":" + rcLineDetails.get(0).getCurrencyCode());
                if (rebBegin == null) {
                    rebBegin = principleAmount.subtract(sfcStatusValue.getNetInterestAccrual());
                } else {
                    if (rebEndAfInt != null) {
                        rebBegin = rebEndAfInt;
                    }
                }

                rebEndBfInt = rebBegin.subtract(paymentAmount);
                paymentAmount = BigDecimal.valueOf(0.0);
                yearDays = BigInteger.valueOf(CommonUtils.getNumberOfDays(calendarDetail.getYearStartDate(), calendarDetail.getYearEndDate()));
                if (yearDays == null || yearDays.compareTo(BigInteger.valueOf(0)) == 0) {
                    yearDays = BigInteger.valueOf(365);
                }
                BigDecimal dailyInt = (npvInt.divide(BigDecimal.valueOf(100.00))).divide(new BigDecimal(yearDays), 20, RoundingMode.HALF_EVEN);
                noOfDays = calculateDurationForPaymentPeriods(sfcPaymentDetail, calendarDetail, scheduleDates);
                Date scheduleStartDate = scheduleDates.get("startDate");
                Date scheduleEndDate = scheduleDates.get("endDate");

                BigDecimal npvReb = getNpvValueFromDailyInterest(rebEndBfInt, dailyInt, noOfDays);
                BigDecimal interest = npvReb.subtract(rebEndBfInt);
                interest = interest.setScale(currRound, RoundingMode.HALF_EVEN);
                rebEndAfInt = npvReb;
                if (totalInterestAmount.add(interest).compareTo(sfcStatusValue.getNetInterestAccrual()) == 0
                        || totalInterestAmount.add(interest).compareTo(sfcStatusValue.getNetInterestAccrual()) > 0) {
                    interest = sfcStatusValue.getNetInterestAccrual().subtract(totalInterestAmount);
                }
                checkForLastScheduleResidualInterest(calendarIndex, sfcStatusValue, sfcPaymentDetail, calendarDetailsList, sfcPaymentDetails,
                        sfcCalcDetailsList, rcScheduleRecordList, interest, totalInterestAmount);
                if (interest.equals(BigDecimal.valueOf(0)) && interest.compareTo(BigDecimal.valueOf(0)) < 0) {
                    rcLinePaDataRecord.get(0).setEndDate(scheduleStartDate);
                    break;
                }
                rcLinePaDataRecord.get(0).setEndDate(scheduleStartDate);

                SfcCalcDetails sfcCalcDetail = sfcCalcDetailService.populateSfcCalcDetail(request, rcLineDetails, calendarDetail, rebBegin,
                        rebEndAfInt, npvReb, interest, openPeriodId, scheduleStartDate, scheduleEndDate);
                if (rcLinePaDataRecord.get(0).getStartDate() == null) {
                    rcLinePaDataRecord.get(0).setStartDate(scheduleStartDate);
                }
                sfcCalcDetailsList.add(sfcCalcDetail);

                totalInterestAmount = totalInterestAmount.add(interest);

                LOGGER.debug("Interest Amount for Period " + calendarDetail.getId() + " - " + interest);
                LOGGER.debug("Total Interest Amount for Period " + calendarDetail.getId() + " - " + totalInterestAmount);

                schdIndicator.setCrAcctgFlag(financeTypeFlagDetailsList.get(0).getIncomeStmtFlag().charAt(0));
                schdIndicator.setDrAcctgFlag(financeTypeFlagDetailsList.get(0).getCrAcctgFlag().charAt(0));
                schdIndicator.setIntialRepEntryFlag('N');
                RcScheduleRecord rcScheduleRecord = rcScheduleService.populateRcScheduleRecord(rcLineDetails, rcLinePaDataRecord, calendarDetail, request,
                        interest, rcVersion, openPeriodId, sfcSegmentsFlagsVersions.getCrAcctSeg(),
                        sfcSegmentsFlagsVersions.getIncomeAcctSeg(), schdIndicator);
                rcScheduleRecordList.add(rcScheduleRecord);
            }
        }
        rcScheduleRecordBatch.addAll(rcScheduleRecordList);
        sfcCalcDetailsBatch.addAll(sfcCalcDetailsList);
    }

    public void checkForLastScheduleResidualInterest(int currentIndex, SfcStatusValues sfcStatusValue, SfcPaymentDetails sfcPaymentDetail,
            List<CalendarDetails> calendarDetailsList, List<SfcPaymentDetails> sfcPaymentDetails,
            List<SfcCalcDetails> sfcCalcDetailsList, List<RcScheduleRecord> rcScheduleRecordList, BigDecimal interest, BigDecimal totalInterestAmount) {
        if ((currentIndex == calendarDetailsList.size() - 1 && sfcPaymentDetails.get(sfcPaymentDetails.size() - 1) == sfcPaymentDetail)
                && totalInterestAmount.add(interest).compareTo(sfcStatusValue.getNetInterestAccrual()) < 0) {
            interest = sfcStatusValue.getNetInterestAccrual().subtract(totalInterestAmount);

            SfcCalcDetails sfcCalcDetailsLast = sfcCalcDetailsList.get(sfcCalcDetailsList.size() - 1);
            sfcCalcDetailsLast.setInterest(sfcCalcDetailsLast.getInterest().add(interest));
            sfcCalcDetailsList.remove(sfcCalcDetailsList.size() - 1);
            sfcCalcDetailsList.add(sfcCalcDetailsLast);

            RcScheduleRecord rcScheduleRecordLast = rcScheduleRecordList.get(rcScheduleRecordList.size() - 1);
            rcScheduleRecordLast.setAmount(rcScheduleRecordLast.getAmount().add(interest));
            rcScheduleRecordList.remove(rcScheduleRecordList.size() - 1);
            rcScheduleRecordList.add(rcScheduleRecordLast);
        }
    }

}
