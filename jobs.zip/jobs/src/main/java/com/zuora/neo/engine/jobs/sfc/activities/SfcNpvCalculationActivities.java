package com.zuora.neo.engine.jobs.sfc.activities;

import com.zuora.neo.engine.jobs.sfc.SfcResult;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface SfcNpvCalculationActivities {
    SfcResult calculateNpvInterest(SfcResult sfcResult);
}
