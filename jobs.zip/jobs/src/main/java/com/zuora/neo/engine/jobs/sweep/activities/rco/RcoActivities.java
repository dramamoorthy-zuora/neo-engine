package com.zuora.neo.engine.jobs.sweep.activities.rco;

import com.zuora.neo.engine.jobs.sweep.SweepResult;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface RcoActivities {

    void createRcoJob(SweepResult sweepResult);
}
