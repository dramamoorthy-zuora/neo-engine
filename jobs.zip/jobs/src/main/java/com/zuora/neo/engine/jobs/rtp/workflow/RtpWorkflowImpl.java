package com.zuora.neo.engine.jobs.rtp.workflow;

import com.zuora.neo.engine.annotations.workflow.WorkflowImplementation;
import com.zuora.neo.engine.jobs.rtp.activities.RtpActivities;
import com.zuora.neo.engine.temporal.workflows.LoggerWorkflowImpl;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.workflow.Workflow;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@WorkflowImplementation
public class RtpWorkflowImpl extends LoggerWorkflowImpl implements RtpWorkflow {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(RtpWorkflowImpl.class);

    private final RtpActivities rtpActivities = Workflow.newActivityStub(RtpActivities.class);

    @Override
    public WorkflowResponse execute() {
        LOGGER.info("RTP workflow initiated");
        WorkflowResponse workflowResponse = rtpActivities.performRtp();
        return workflowResponse;
    }

}
