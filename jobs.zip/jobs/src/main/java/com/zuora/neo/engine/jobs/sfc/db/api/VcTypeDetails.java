package com.zuora.neo.engine.jobs.sfc.db.api;


public class VcTypeDetails {

    private long  vcTypeId;
    private String   drAcctgFlag;
    private String   crAcctgFlag;
    private String   incomeStmtFlag;
    private String   accrualUponBillFlag;

    public VcTypeDetails(long vcTypeId, String drAcctgFlag, String crAcctgFlag, String incomeStmtFlag, String accrualUponBillFlag) {
        this.vcTypeId = vcTypeId;
        this.drAcctgFlag = drAcctgFlag;
        this.crAcctgFlag = crAcctgFlag;
        this.incomeStmtFlag = incomeStmtFlag;
        this.accrualUponBillFlag = accrualUponBillFlag;
    }


    public static VcTypeDetails.Builder builder() {
        return new VcTypeDetails.Builder();
    }

    public long getVcTypeId() {
        return vcTypeId;
    }

    public void setVcTypeid(long vcTypeId) {
        this.vcTypeId = vcTypeId;
    }

    public String getDrAcctgFlag() {
        return drAcctgFlag;
    }

    public void setDrAcctgFlag(String drAcctgFlag) {
        this.drAcctgFlag = drAcctgFlag;
    }

    public String getCrAcctgFlag() {
        return crAcctgFlag;
    }

    public void setCrAcctgFlag(String crAcctgFlag) {
        this.crAcctgFlag = crAcctgFlag;
    }

    public String getIncomeStmtFlag() {
        return incomeStmtFlag;
    }

    public void setIncomeStmtFlag(String incomeStmtFlag) {
        this.incomeStmtFlag = incomeStmtFlag;
    }

    public String getAccrualUponBillFlag() {
        return accrualUponBillFlag;
    }

    public void setAccrualUponBillFlag(String accrualUponBillFlag) {
        this.accrualUponBillFlag = accrualUponBillFlag;
    }

    @Override
    public String toString() {
        return "VcTypeDetails{"
                + "vcTypeid='" + vcTypeId + '\''
                + ", drAcctgFlag='" + drAcctgFlag + '\''
                + ", crAcctgFlag=" + crAcctgFlag
                + ", incomeStmtFlag=" + incomeStmtFlag
                + ", accrualUponBillFlag=" + accrualUponBillFlag
                + '}';
    }

    public static class Builder {

        private long vcTypeId;
        private String drAcctgFlag;
        private String crAcctgFlag;
        private String incomeStmtFlag;
        private String accrualUponBillFlag;


        private Builder() {
        }

        public VcTypeDetails.Builder withVcTypeId(long vcTypeId) {
            this.vcTypeId = vcTypeId;
            return this;
        }

        public VcTypeDetails.Builder withDrAcctgFlag(String drAcctgFlag) {
            this.drAcctgFlag = drAcctgFlag;
            return this;
        }

        public VcTypeDetails.Builder withCrAcctgFlag(String crAcctgFlag) {
            this.crAcctgFlag = crAcctgFlag;
            return this;
        }

        public VcTypeDetails.Builder withIncomeStmtFlag(String incomeStmtFlag) {
            this.incomeStmtFlag = incomeStmtFlag;
            return this;
        }

        public VcTypeDetails.Builder withAccrualUponBillFlag(String accrualUponBillFlag) {
            this.accrualUponBillFlag = accrualUponBillFlag;
            return this;
        }


        public VcTypeDetails build() {
            return new VcTypeDetails(vcTypeId, drAcctgFlag, crAcctgFlag, incomeStmtFlag, accrualUponBillFlag);
        }
    }
}
