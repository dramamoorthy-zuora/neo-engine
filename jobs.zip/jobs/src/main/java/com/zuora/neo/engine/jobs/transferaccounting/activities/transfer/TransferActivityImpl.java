package com.zuora.neo.engine.jobs.transferaccounting.activities.transfer;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.TransferAccountingTestEvaluator;
import com.zuora.neo.engine.jobs.transferaccounting.api.GlInsertBuilder;
import com.zuora.neo.engine.jobs.transferaccounting.common.ActivityType;
import com.zuora.neo.engine.jobs.transferaccounting.config.ConfigProperties;
import com.zuora.neo.engine.jobs.transferaccounting.config.Properties;
import com.zuora.neo.engine.jobs.transferaccounting.constants.AccountingObjectType;
import com.zuora.neo.engine.jobs.transferaccounting.constants.TransferStatus;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.GlIntegrationMap;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.RcSchedMinRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.SplitBatchRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.AccountingDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.ErrorDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.GeneralLedgerDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.ScheduleDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.SplitDao;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@ActivityImplementation
@Component
public class TransferActivityImpl implements TransferActivity {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(TransferActivityImpl.class);
    private static final String SPLIT_TYPE = "RC_ID";
    private static final String BATCH_TYPE = "TRANSFER";
    private static final String GL_INSERT_ERR = "Inserting into GL Staging";
    private static  final String GL_INTERFACE_ERR = "GL Interface failed. Verify the Interface Mapping. It creates syntactical errors.";
    private static final String DYNAMIC_SQL_ERR = "Dynamic SQL IN GL MAPPING failed";
    private static final String TRANSFER_ERROR = "Error in Transfer : ";
    private static HashMap<Long,List<Long>> retryChunks = new HashMap<>();
    @Autowired
    Properties properties;
    @Autowired
    private ConfigProperties configProperties;

    /*
            Main things done as part of the transfer process are:
            1) Use the post batch id from rpro_rc_schd_g and insert data into rpro_gl_int_stage as batch id.
                    rpro_gl_int_stage: Final output table for schedules to be posted.
            2) Updates the interface flag
            3) Calls rpro_ri_pre_summ_pkg to update Unposted to Posted
            Below items can be done as separate flow and hence moved to separate activities.
            4) Create an outbound file. This can be either downloaded directly via the RIA Rest api passing batch ID
            or a signed S3 url is received to download the file
            5) Close dashboard call to schedule the RCO job
    */

    @Override
    public void resetRetryChunks(ThreadedAccountingResult accountingResult) {
        retryChunks.remove(accountingResult.getPostBatchId());
    }

    @Override
    public HashMap<Long, List<Long>> getRetryChunks() {
        return retryChunks;
    }

    @Override
    public ThreadedAccountingResult doTransferProcess(ThreadedAccountingResult accountingResult, String orgId) {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Long bookId = accountingResult.getBookId();
        Long postBatchId = accountingResult.getPostBatchId();
        Jdbi jdbi = DbContext.getConnection();

        jdbi.useTransaction(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            SplitDao splitDao = handle.attach(SplitDao.class);
            CommonDao commonDao = handle.attach(CommonDao.class);
            String chunkStatus = splitDao.getChunkTransferStatus(postBatchId, accountingResult.getChunkId());
            String batchStatus = accountingDao.getTransferStatus(postBatchId);
            //If main batch status from validate activity is either updated or warning
            if ((batchStatus.equals(TransferStatus.UPDATED.getTransferStatus())
                    || batchStatus.equals(ActivityType.TRANSFER + " - " + TransferStatus.IN_PROGRESS.getTransferStatus())
                    || batchStatus.equals(TransferStatus.WARNING.getTransferStatus()))
                    //if chunk status is either updated(happy path), warning(from validate activity) or error(from transfer failure)
                    && (chunkStatus.equals(TransferStatus.UPDATED.getTransferStatus())
                    || chunkStatus.equals(TransferStatus.WARNING.getTransferStatus())
                    || chunkStatus.equals(TransferStatus.ERROR.getTransferStatus()))) {
                String transferStatus = ActivityType.TRANSFER + " - " + TransferStatus.IN_PROGRESS.getTransferStatus();
                //update chunks to in-progress
                splitDao.updateTransferStatusChunk(transferStatus, "", request.getUser(), postBatchId, accountingResult.getChunkId());

                SplitBatchRecord batch = splitDao.getSplitBatchById(postBatchId, SPLIT_TYPE, bookId, BATCH_TYPE, accountingResult.getChunkId());
                accountingResult.setMinRcId(Long.valueOf(batch.getMinValue()));
                accountingResult.setMaxRcId(Long.valueOf(batch.getMaxValue()));
                properties.load(commonDao, request.getTenantId());

                doTransferInTransaction(accountingDao, postBatchId, request, bookId, accountingResult, handle, orgId, properties);
                chunkStatus = splitDao.getChunkTransferStatus(postBatchId, accountingResult.getChunkId());
                accountingResult.setTransferStatus(chunkStatus);
            }
        });
        return accountingResult;
    }

    @Override
    public void updateStatusToProgress(Long postBatchId) {
        String transferStatus = ActivityType.TRANSFER + " - " + TransferStatus.IN_PROGRESS.getTransferStatus();
        Jdbi jdbi = DbContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
            //update main batch to in-progress
            accountingDao.updateTransferStatusMsg(transferStatus, "", request.getUser(), postBatchId);
        });
    }

    ThreadedAccountingResult doTransferInTransaction(AccountingDao accountingDao, Long postBatchId,
            WorkflowRequest request, Long bookId, ThreadedAccountingResult accountingResult, Handle handle, String orgId, Properties properties) {
        String objectType = "";
        String postFlag = accountingDao.getPostableFlag();
        if ("N".equals(postFlag)) { //no need to insert into GL table
            updatePostStatus(postBatchId, accountingDao, request.getUser(), null,
                    bookId, orgId, handle, accountingResult, properties);
        }
        if ("Y".equals(postFlag)) {
            String localPostFlag = properties.getPostScheduleEnabled() ? "Y" : "N";
            if ("Y".equals(localPostFlag)) {
                objectType = AccountingObjectType.GENERAL_LEDGER.getObjectTypeType();
                try {
                    accountingResult = transferAccountingGlStage(postBatchId, objectType, handle, accountingResult, properties, orgId);
                } catch (Exception e) {
                    if (e.getMessage() != null && !e.getMessage().contains(GL_INTERFACE_ERR) && !e.getMessage().contains(DYNAMIC_SQL_ERR)) {
                        accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
                        accountingResult.setTransferMessage(GL_INSERT_ERR);
                        NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, TRANSFER_ERROR + GL_INSERT_ERR);
                    }
                    throw e;
                }
                updatePostStatus(postBatchId, accountingDao, request.getUser(), objectType,
                        bookId, orgId, handle, accountingResult, properties);
            }
            String mjeFlag = properties.getMjeEnabled() ? "Y" : "N";
            if ("Y".equals(mjeFlag)) {
                objectType = AccountingObjectType.MANUAL_JE.getObjectTypeType();
                try {
                    accountingResult = transferAccountingGlStage(postBatchId, objectType, handle, accountingResult, properties, orgId);
                } catch (Exception e) {
                    if (e.getMessage() != null && !e.getMessage().contains(GL_INTERFACE_ERR) && !e.getMessage().contains(DYNAMIC_SQL_ERR)) {
                        accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
                        accountingResult.setTransferMessage(GL_INSERT_ERR);
                        NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, TRANSFER_ERROR + GL_INSERT_ERR);
                    }
                    throw e;
                }
                updatePostStatus(postBatchId, accountingDao, request.getUser(), objectType,
                        bookId, orgId, handle, accountingResult, properties);
            }
        }
        Integer updateCount = accountingDao.updateRcHeadPosted(request.getUser(), postBatchId, accountingResult.getMinRcId(), accountingResult.getMaxRcId());
        LOGGER.info("Rows updated for RC HEAD:: " + updateCount + " for request id:: "
                + request.getRequestId() + " and chunk: " + accountingResult.getChunkId());
        SplitDao splitDao = handle.attach(SplitDao.class);
        String transferStatus = splitDao.getChunkTransferStatus(postBatchId, accountingResult.getChunkId());
        String webserviceEnabled = properties.getWebserviceEnabled() ? "Y" : "N";
        if (!(transferStatus.equals(TransferStatus.TRANSFERRED.getTransferStatus())
                || transferStatus.equals(TransferStatus.READY_TO_TRANSFER.getTransferStatus())
                || transferStatus.equals(TransferStatus.PUSH_GL.getTransferStatus())
                || transferStatus.equals(TransferStatus.POST_WEB_SERVICE.getTransferStatus())
                || transferStatus.equals(TransferStatus.ERROR.getTransferStatus()))) { //Todo: check with current PQ-SQL
            if ("Y".equals(webserviceEnabled)) {
                splitDao.updateTransferStatusChunk(TransferStatus.POST_WEB_SERVICE.getTransferStatus(), "",
                        request.getUser(), postBatchId, accountingResult.getChunkId());
            } else {
                splitDao.updateTransferStatusChunk(TransferStatus.PUSH_GL.getTransferStatus(), "",
                        request.getUser(), postBatchId, accountingResult.getChunkId());
            }
        }
        try {
            if (TransferAccountingTestEvaluator.evaluateForTransferRetryLogic() >= 0) {
                //we can't throw exception here to test our retry logic since it goes to Temporal retry not custom one
                //change status of the chunk to error to test accounting retry logic
                splitDao.updateTransferStatusChunk(TransferStatus.ERROR.getTransferStatus(), "", request.getUser(),
                        postBatchId, accountingResult.getChunkId());
            }
            accountingDao.updatePostUnpost(postBatchId); //change unposted flag to posted
        } catch (Exception e) {
            LOGGER.error("Error changing unposted flag to posted with: " + e.getMessage());
            splitDao.updateTransferStatusChunk(TransferStatus.ERROR.getTransferStatus(), e.getMessage(), request.getUser(),
                    postBatchId, accountingResult.getChunkId());
            throw e;
        }

        transferStatus = splitDao.getChunkTransferStatus(postBatchId, accountingResult.getChunkId());
        if (!TransferStatus.ERROR.getTransferStatus().equals(transferStatus)) {
            if ("N".equals(webserviceEnabled)) {
                splitDao.updateTransferStatusChunk(TransferStatus.POST_TRANSFER.getTransferStatus(), "",
                        request.getUser(), postBatchId, accountingResult.getChunkId());
            } else if ("Y".equals(webserviceEnabled)) {
                splitDao.updateTransferStatusChunk(TransferStatus.POST_WEB_SERVICE.getTransferStatus(), "",
                        request.getUser(), postBatchId, accountingResult.getChunkId());
            }
        }
        transferStatus = splitDao.getChunkTransferStatus(postBatchId, accountingResult.getChunkId());
        if (TransferStatus.POST_TRANSFER.getTransferStatus().equals(transferStatus)) {
            transferStatus = TransferStatus.TRANSFERRED.getTransferStatus();
        } else if (TransferStatus.POST_WEB_SERVICE.getTransferStatus().equals(transferStatus)) {
            transferStatus = TransferStatus.READY_TO_TRANSFER.getTransferStatus();
        }
        splitDao.updateTransferStatusChunk(transferStatus, "", request.getUser(), postBatchId, accountingResult.getChunkId());
        return accountingResult;
    }

    /*
        This method updates the interface flag for both object type GL and Manual Je
     */
    private void updatePostStatus(Long postBatchId, AccountingDao accountingDao, String user,
            String objectType, Long bookId, String orgId, Handle handle, ThreadedAccountingResult accountingResult, Properties properties) {
        ScheduleDao scheduleDao = handle.attach(ScheduleDao.class);
        GeneralLedgerDao ledgerDao = handle.attach(GeneralLedgerDao.class);
        CommonDao commonDao = handle.attach(CommonDao.class);
        String postFlag = accountingDao.getPostableFlag();
        Integer glIntStageExist;
        String summaryTransfer = properties.getSummaryTransferEnabled() ? "Y" : "N";
        String mjeSummaryTransfer = properties.getMjeSummaryTransferEnabled() ? "Y" : "N";
        String postSchedules = properties.getPostScheduleEnabled() ? "Y" : "N";
        String postMjeSchedules = properties.getPostManualJeScheduleEnabled() ? "Y" : "N";
        String schdFlag = "APPLICATION".equals(properties.getNettingLevel()) ? "D" : "X";
        Integer rowCount = 0;
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Long createdPeriodId = commonDao.getCrtdPeriodId(accountingResult.getBookId(), orgId);
        try {
            if ("N".equals(postFlag)) {
                scheduleDao.updateRcPostDetails(user, bookId, orgId, postBatchId,
                        accountingResult.getMinRcId(), accountingResult.getMaxRcId());
                List<RcSchedMinRecord> records = scheduleDao.getRcSchdRecord(postBatchId, accountingResult.getMinRcId(), accountingResult.getMaxRcId());
                for (RcSchedMinRecord rec : records) {
                    accountingDao.insertRcSchdData(rec.getLineId(), rec.getRootLineId(), rec.getAmount(), rec.getIndicators(),
                            rec.getCrSegments(), rec.getDrSegments(), rec.getForeignExRate(), rec.getGlobalExRate(), rec.getPostPeriodId());
                }
            } else if (AccountingObjectType.GENERAL_LEDGER.getObjectTypeType().equals(objectType)) {
                glIntStageExist = 0;
                if ("Y".equals(summaryTransfer)) {
                    glIntStageExist = ledgerDao.getGlIntStage(postBatchId, objectType, accountingResult.getChunkId());
                }
                try {
                    rowCount = scheduleDao.updateRcPostDetailsGl(user, createdPeriodId, bookId, orgId, postBatchId,
                            accountingResult.getMinRcId(), accountingResult.getMaxRcId(),
                            schdFlag, postSchedules, glIntStageExist, summaryTransfer, objectType);
                    scheduleDao.insertGlobalRcSchdGlData(postBatchId, accountingResult.getMinRcId(), accountingResult.getMaxRcId(), schdFlag);
                    if (rowCount > 0) {
                        LOGGER.info("updating interface flag for GL for chunk: " + accountingResult.getChunkId());
                    }
                } catch (Exception e) {
                    glIntStageExist = 0;
                }
            } else if (AccountingObjectType.MANUAL_JE.getObjectTypeType().equals(objectType)) {
                glIntStageExist = 0;
                if ("Y".equals(mjeSummaryTransfer)) {
                    glIntStageExist = ledgerDao.getGlIntStage(postBatchId, objectType, accountingResult.getChunkId());
                }
                try {
                    rowCount = scheduleDao.updateRcPostDetailsMje(user, createdPeriodId, bookId, orgId, postBatchId,accountingResult.getMinRcId(),
                            accountingResult.getMaxRcId(), postMjeSchedules, glIntStageExist, mjeSummaryTransfer, objectType);
                    if (rowCount > 0) {
                        LOGGER.info("updating interface flag for MJE for chunk: " + accountingResult.getChunkId());
                    }
                    scheduleDao.insertGlobalRcSchdMjeData(postBatchId, accountingResult.getMinRcId(), accountingResult.getMaxRcId());
                } catch (Exception e) {
                    glIntStageExist = 0;
                }
            }
            LOGGER.info("Rows updated for interface flag:: " + rowCount + " for request id:: "
                    + request.getRequestId() + " and chunk: " + accountingResult.getChunkId());
        } catch (Exception e) {
            SplitDao splitDao = handle.attach(SplitDao.class);
            LOGGER.error("Updating the interface flag failed with : " + e.getMessage());
            splitDao.updateTransferStatusChunk(TransferStatus.ERROR.getTransferStatus(), e.getMessage(),
                    request.getUser(), postBatchId, accountingResult.getChunkId());
            throw e;
        }
    }

    /*
        This method is to get the GL mapping for both GL and manual JE and build the insert statement
        to insert into the RPRO_GL_INT_STAGE table
     */
    private ThreadedAccountingResult transferAccountingGlStage(Long postBatchId, String objectType,
            Handle handle, ThreadedAccountingResult result, Properties properties, String orgId) {
        GeneralLedgerDao ledgerDao = handle.attach(GeneralLedgerDao.class);
        ErrorDao errorDao = handle.attach(ErrorDao.class);
        SplitDao splitDao = handle.attach(SplitDao.class);
        StringBuilder insertStmt = new StringBuilder("INSERT INTO RPRO_GL_INT_STAGE_TEMP");
        StringBuilder insertSelect = new StringBuilder("(SELECT ");
        String summaryTransfer = properties.getSummaryTransferEnabled() ? "Y" : "N";
        String mjeSummaryTransfer = properties.getMjeSummaryTransferEnabled() ? "Y" : "N";
        String schdType = properties.getNettingLevel();
        String schdTypeStr = "";
        if ("APPLICATION".equals(schdType)) {
            schdTypeStr = " AND schd_type_flag != 'D'";
        }
        if (AccountingObjectType.MANUAL_JE.getObjectTypeType().equals(objectType)) {
            if ("N".equals(mjeSummaryTransfer)) {
                insertStmt.append("(OBJECT_TYPE, TRANS_ID,SCHEDULE_ID,BATCH_ID, CHUNK_ID");
                insertSelect.append("'MANUAL-JE', line_id, schd_id,:postBatchId, :chunkId");
            } else if ("Y".equals(mjeSummaryTransfer)) {
                insertStmt.append("(OBJECT_TYPE, BATCH_ID, CHUNK_ID");
                insertSelect.append("'MANUAL-JE',:postBatchId, :chunkId");
            }
        } else if (AccountingObjectType.GENERAL_LEDGER.getObjectTypeType().equals(objectType)) {
            if ("N".equals(summaryTransfer)) {
                insertStmt.append("(OBJECT_TYPE, TRANS_ID, SCHEDULE_ID, BATCH_ID, CHUNK_ID");
                insertSelect.append("'GL', line_rc_id, schd_id,:postBatchId, :chunkId");
            } else if ("Y".equals(summaryTransfer)) {
                insertStmt.append("(OBJECT_TYPE, BATCH_ID, CHUNK_ID");
                insertSelect.append("'GL', :postBatchId, :chunkId");
            }
        }
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        List<GlIntegrationMap> glMapList = ledgerDao.getGlIntegrationMap(objectType);
        GlInsertBuilder glInsertBuilder = null;
        StringBuilder groupByStr = new StringBuilder();
        for (int i = 0; i < glMapList.size(); ++i) {
            GlIntegrationMap glMap = glMapList.get(i);
            try {
                glInsertBuilder = GlInsertBuilder.formGlInsertFromMap(glMap, objectType, handle, groupByStr, summaryTransfer,
                        mjeSummaryTransfer, insertStmt, insertSelect, i, glMapList.size(), configProperties.isRoundingEnable());
            } catch (Exception e) {
                String errMsg = "Dynamic SQL IN GL MAPPING failed. Verify the: " + objectType + " Interface Mapping. Error: " + e.getCause().getMessage();
                errorDao.insertError(postBatchId, errMsg, request.getUser(), request.getClientId(),
                        result.getBookId(), orgId, result.getChunkId());
                splitDao.updateTransferStatusChunk(TransferStatus.ERROR.getTransferStatus(), "", request.getUser(), postBatchId, result.getChunkId());
                result.setTransferMessage(errMsg);
                if (configProperties.isRetryEnable()) {
                    addToRetryChunks(result);
                }
                NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, TRANSFER_ERROR + errMsg, new Throwable(errMsg));
            }
        }
        if (glInsertBuilder != null) {
            insertStmt = glInsertBuilder.getInsertStmt();
            insertStmt.append(", CR_DR_FLAG");
            insertSelect = glInsertBuilder.getInsertSelect();
            groupByStr = glInsertBuilder.getGroupByStr();
        }
        insertSelect.append(", case when SIGN(SCHD_CR_AMOUNT) <> 0 THEN 'CR' ELSE 'DR' END CR_DR_FLAG");
        if (AccountingObjectType.MANUAL_JE.getObjectTypeType().equals(objectType) && "Y".equals(mjeSummaryTransfer)) {
            insertSelect.append(" FROM rpro_je_post_v WHERE 1 = 1 AND interfaced_flag = 'N' AND schd_post_batch_id =")
                    .append(postBatchId).append(" AND SCHD_RC_ID BETWEEN :minRcId AND :maxRcId ");
        } else if (AccountingObjectType.MANUAL_JE.getObjectTypeType().equals(objectType) && "N".equals(mjeSummaryTransfer)) {
            insertSelect.append(" FROM rpro_je_post_v WHERE 1 = 1 AND interfaced_flag = 'N' AND schd_post_batch_id =")
                    .append(postBatchId).append(" AND SCHD_RC_ID BETWEEN :minRcId AND :maxRcId ");
        } else {
            insertSelect.append(" FROM rpro_post_v WHERE 1 = 1 AND interfaced_flag = 'N' AND schd_post_batch_id =").append(postBatchId)
                    .append(" AND SCHD_RC_ID BETWEEN :minRcId AND :maxRcId ").append(schdTypeStr);
        }
        if (groupByStr != null && (objectType.equals(AccountingObjectType.GENERAL_LEDGER.getObjectTypeType()) && summaryTransfer.equals("Y")
                || AccountingObjectType.MANUAL_JE.getObjectTypeType().equals(objectType) && mjeSummaryTransfer.equals("Y"))) {
            StringBuilder tempGrp = new StringBuilder("SIGN(SCHD_CR_AMOUNT), SIGN(SCHD_DR_AMOUNT)");
            groupByStr = tempGrp.append(groupByStr);
            insertSelect.append(" GROUP BY ").append(groupByStr).append(" HAVING NVL(SUM(SCHD_CR_AMOUNT),0) <> 0 OR NVL(SUM(SCHD_DR_AMOUNT),0) <> 0");
        }
        insertSelect.append(") ");
        insertStmt.append(") ").append(insertSelect);
        LOGGER.info("GL insert query for type:: " + objectType + " is: " + insertStmt + " for request id:: " + request.getRequestId());
        Integer rowCount = 0;
        try {
            rowCount = handle.createUpdate(insertStmt.toString())
                    .bind("postBatchId", result.getPostBatchId()).bind("chunkId", result.getChunkId())
                    .bind("minRcId", result.getMinRcId()).bind("maxRcId", result.getMaxRcId()).execute();
            LOGGER.info(" Transferred number of records for type:: " + objectType  + " with count: " + rowCount);
        } catch (Exception e) {
            errorDao.insertError(postBatchId, GL_INTERFACE_ERR, request.getUser(), request.getClientId(), result.getBookId(),
                    orgId, result.getChunkId());
            splitDao.updateTransferStatusChunk(TransferStatus.ERROR.getTransferStatus(), "", request.getUser(), postBatchId, result.getChunkId());
            handleGlInterfaceException(result);
        }
        String transferStatus = updateTransferStatus(postBatchId, handle, rowCount, result, properties);
        result.setTransferStatus(transferStatus);
        return result;
    }

    private void addToRetryChunks(ThreadedAccountingResult accountingResult) {
        if (retryChunks.containsKey(accountingResult.getPostBatchId())) {
            if (!retryChunks.get(accountingResult.getPostBatchId()).contains(accountingResult.getChunkId())) {
                retryChunks.get(accountingResult.getPostBatchId()).add(accountingResult.getChunkId());
            }
        } else {
            retryChunks.put(accountingResult.getPostBatchId(),new ArrayList<>());
            retryChunks.get(accountingResult.getPostBatchId()).add(accountingResult.getChunkId());
        }
    }

    void handleGlInterfaceException(ThreadedAccountingResult accountingResult) {
        accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());

        accountingResult.setTransferMessage(GL_INTERFACE_ERR);
        addToRetryChunks(accountingResult);
        NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR,
                TRANSFER_ERROR + GL_INTERFACE_ERR, new Throwable(GL_INTERFACE_ERR));
    }

    public enum SourceFrom {
        CONSTANT, TRANSACTION, EXPRESSION, DYNAMIC
    }

    private String updateTransferStatus(Long postBatchId, Handle handle,
            Integer rowCount, ThreadedAccountingResult result, Properties properties) {
        SplitDao splitDao = handle.attach(SplitDao.class);
        String transferStatus = splitDao.getChunkTransferStatus(postBatchId, result.getChunkId());

        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        String webserviceEnabled = properties.getWebserviceEnabled() ? "Y" : "N";
        if (!(transferStatus.equals(TransferStatus.TRANSFERRED.getTransferStatus())
                && transferStatus.equals(TransferStatus.READY_TO_TRANSFER.getTransferStatus())
                && transferStatus.equals(TransferStatus.PUSH_GL.getTransferStatus())
                && transferStatus.equals(TransferStatus.POST_WEB_SERVICE.getTransferStatus()))) {
            if (rowCount > 0 && "Y".equals(webserviceEnabled)) {
                transferStatus = TransferStatus.POST_WEB_SERVICE.getTransferStatus();
            } else if (rowCount > 0 && "N".equals(webserviceEnabled)) {
                transferStatus = TransferStatus.PUSH_GL.getTransferStatus();
            } else {
                transferStatus = TransferStatus.NOT_TRANSFERRED.getTransferStatus();
            }
            splitDao.updateTransferStatusChunk(transferStatus, "", request.getUser(), postBatchId, result.getChunkId());
        }
        return transferStatus;
    }

}
