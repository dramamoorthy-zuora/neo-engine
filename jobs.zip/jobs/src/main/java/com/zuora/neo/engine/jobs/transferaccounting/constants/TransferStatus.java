package com.zuora.neo.engine.jobs.transferaccounting.constants;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum TransferStatus {
    NEW("NEW"),
    IN_PROGRESS("IN PROGRESS"),
    ERROR("ERRORS"),
    UPDATED("UPDATED"),
    NO_DATA("NO DATA FOUND"),
    TRANSFERRED("TRANSFERRED"),
    NOT_TRANSFERRED("NO RECORDS TRANSFERRED"),
    READY_TO_TRANSFER("READY TO TRANSFER"),
    PUSH_GL("PUSH TO GL"),
    POST_TRANSFER("POST TRANSFER STAGE HANDLER"),
    POST_WEB_SERVICE("POST WEB SERVICE STAGE HANDLER"),
    WARNING("WARNING");

    private final String transferStatus;

    @JsonValue
    public String getTransferStatus() {
        return transferStatus;
    }

    TransferStatus(String transferStatus) {
        this.transferStatus = transferStatus;
    }

    private static final Map<String, TransferStatus> LOOKUP =
            Arrays.stream(TransferStatus.values()).collect(Collectors.toMap(TransferStatus::getTransferStatus, Function.identity()));

    @JsonCreator
    public static TransferStatus fromTransferStatus(String transferStatus) {
        return LOOKUP.get(transferStatus);
    }
}
