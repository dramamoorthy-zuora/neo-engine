package com.zuora.neo.engine.jobs.rtp.constants;

public class RtpProfiles {

    public static final String ENABLE_REALTIME_PROCESSING = "ENABLE_REALTIME_PROCESSING";

    public static final String ENABLE_REALTIME_PROCESSING_SHADOW_MODE = "ENABLE_REALTIME_PROCESSING_SHADOW_MODE";

    public static final String RTP_BATCH_SIZE = "RTP_BATCH_SIZE";
}
