package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.sfc.SfcResult;
import com.zuora.neo.engine.jobs.sfc.api.SfcSegmentsFlagsVersions;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeIndicator;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SfcServiceUtils {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcServiceUtils.class);

    @Autowired
    SfcAcctSegmentsService sfcAcctSegmentsService;

    public void updateSfcStatusAndAddWarningCount(SfcResult sfcResult, SfcStatusValues sfcStatusValue, String status) {
        sfcStatusValue.setErrMsg(status);
        sfcResult.addWarningCount();
    }

    public Boolean validSfcLine(SfcStatusValues sfcStatusValue, List<SfcPaymentDetails> sfcPaymentDetails,
            List<RcLineDetails> rcLineDetails, List<FinanceTypeValues> financeTypeValueForRcLine) {

        if (financeTypeValueForRcLine.isEmpty()) {
            LOGGER.error("Doc Date for this RC Line does not match with the start and end date of Finance Type Table for " + sfcStatusValue.getDocLineId());
            sfcStatusValue.setErrMsg("SFC Setup is not available");
            return false;
        }
        if (sfcPaymentDetails == null || sfcPaymentDetails.isEmpty()) {
            sfcStatusValue.setErrMsg("Payment not uploaded");
            return false;
        } else if (rcLineDetails != null && !rcLineDetails.isEmpty()) {
            if (rcLineDetails.get(0).getnpvInterestRate() == null) {
                sfcStatusValue.setErrMsg("Interest not Populated");
                return false;
            } else if (rcLineDetails.get(0).getRelPct() == null || rcLineDetails.get(0).getRelPct().compareTo(BigDecimal.valueOf(0.0)) == 0) {
                sfcStatusValue.setErrMsg("Revenue Not recognised");
                return false;
            } else if (rcLineDetails.get(0).getPrincipleAmount() == null || rcLineDetails.get(0).getPrincipleAmount().compareTo(BigDecimal.valueOf(0)) == 0) {
                sfcStatusValue.setErrMsg("Principle Amount Null/Zero");
                return false;
            }
        } else {
            sfcStatusValue.setErrMsg("Error");
            return false;
        }
        return true;
    }

    public List<FinanceTypeValues> getFinanceTypeForRcLine(List<RcLinePaData> rcLinePaDataRecordBeforeProcessing,
            SfcDbCacheContext sfcDbCacheContext, List<RcLineDetails> rcLineDetails) {
        List<FinanceTypeValues> financeTypeValuesList = sfcDbCacheContext.getFinanceTypeValuesList();
        List<CalendarDetails> calendarDetails = sfcDbCacheContext.getCalendarDetails();
        List<FinanceTypeValues> financeTypeValueForRcLine = null;
        if (!rcLinePaDataRecordBeforeProcessing.isEmpty()) {
            financeTypeValueForRcLine = financeTypeValuesList.stream()
                    .filter(financeTypeValue -> financeTypeValue.getVersion() == rcLinePaDataRecordBeforeProcessing.get(0).getFncTypeVersion())
                    .collect(Collectors.toList());
        } else {
            financeTypeValueForRcLine = SfcBatchProcessingService.getFinanceTypeDetailsForRcLine(financeTypeValuesList, rcLineDetails.get(0),
                    calendarDetails.get(0));
        }
        return financeTypeValueForRcLine;
    }

    public SfcSegmentsFlagsVersions getSegmentsFlagsVersions(List<FinanceTypeValues> financeTypeValueForRcLine,
            List<FinanceTypeFlagDetails> financeTypeFlagDetailsList, List<RcLineDetails> rcLineDetails, long vcTypeId, long bookId, long lineId,
            SfcDbCacheContext sfcDbCacheContext, CommonDao commonDao, SfcDao sfcDao) {
        String drAcctFlag = String.valueOf(FinanceTypeIndicator.valueOf(financeTypeValueForRcLine.get(0).getIndicators()).getAccrualDrAcctgFlag());
        String crAcctFlag = String.valueOf(FinanceTypeIndicator.valueOf(financeTypeValueForRcLine.get(0).getIndicators()).getAccrualCrAcctgFlag());
        String incomeStmtFlag = String.valueOf(FinanceTypeIndicator.valueOf(
                financeTypeValueForRcLine.get(0).getIndicators()).getIncomeStatementDrAcctgFlag());
        String accrualUponBillingFlag = String.valueOf(FinanceTypeIndicator.valueOf(
                financeTypeValueForRcLine.get(0).getIndicators()).getAccrualUponBillingFlag());
        String impairmentAccountFlag = String.valueOf(FinanceTypeIndicator.valueOf(
                financeTypeValueForRcLine.get(0).getIndicators()).getImpairmentAccountFlag());
        String contractImpairmentAccountFlag = String.valueOf(FinanceTypeIndicator.valueOf(
                financeTypeValueForRcLine.get(0).getIndicators()).getContractImpairmentAccountFlag());
        String contractLiabilityFlag = String.valueOf(FinanceTypeIndicator.valueOf(
                financeTypeValueForRcLine.get(0).getIndicators()).getContractLiabilityFlag());
        long financeTypeVersion = financeTypeValueForRcLine.get(0).getVersion();
        long rcVersion = commonDao.getVersionFromRcId(rcLineDetails.get(0).getRcId());
        financeTypeFlagDetailsList.add(new FinanceTypeFlagDetails(vcTypeId, drAcctFlag, crAcctFlag, incomeStmtFlag,
                accrualUponBillingFlag, contractLiabilityFlag));
        SfcSegmentsFlagsVersions sfcSegments = sfcAcctSegmentsService.getSfcAcct(lineId, incomeStmtFlag, drAcctFlag, crAcctFlag, bookId,
                impairmentAccountFlag, contractImpairmentAccountFlag, contractLiabilityFlag, rcLineDetails.get(0), sfcDbCacheContext, sfcDao);
        /*OutParameters sfcSegment = sfcDao.getSfcAcct(lineId, incomeStmtFlag, drAcctFlag, crAcctFlag, bookId,
                impairmentAccountFlag, contractImpairmentAccountFlag); */
        //:p_int_imp_flag, :p_cont_imp_flag,
        /*
        String drAcctSeg = sfcSegment.getString("p_accrual_dr_acctg_segment");
        String crAcctSeg = sfcSegment.getString("p_accrual_cr_acctg_segment");
        String incomeAcctSeg = sfcSegment.getString("p_income_stmt_dr_acctg_segment");
        String incomeImpairmentSeg = sfcSegment.getString("p_inc_imp_segment");
        String contractImpairmentSeg = sfcSegment.getString("p_cont_imp_acctg_segment");

         */
        String drAcctSeg = sfcSegments.getDrAcctSeg();
        String crAcctSeg = sfcSegments.getCrAcctSeg();
        String incomeAcctSeg = sfcSegments.getIncomeAcctSeg();
        String incomeImpairmentSeg = sfcSegments.getIncomeImpairmentSeg();
        String contractImpairmentSeg = sfcSegments.getContractImparimentSeg();
        String contractLiabilitySeg = sfcSegments.getContractLiabilitySeg();
        LOGGER.debug("After calling  getSfcAcct proc drAcctSeg is " + drAcctSeg + " crAcctSeg is " + crAcctSeg
                + " incomeAcctSeg is " + incomeAcctSeg);

        SfcSegmentsFlagsVersions sfcSegmentsFlagsVersions = new SfcSegmentsFlagsVersions(drAcctFlag, crAcctFlag, incomeStmtFlag,
                accrualUponBillingFlag, financeTypeVersion, rcVersion, drAcctSeg, crAcctSeg, incomeAcctSeg, impairmentAccountFlag,
                contractImpairmentAccountFlag, incomeImpairmentSeg, contractImpairmentSeg);
        sfcSegmentsFlagsVersions.setFinanceTypeFlagDetailsList(financeTypeFlagDetailsList);
        sfcSegmentsFlagsVersions.setContractLiabilitySeg(contractLiabilitySeg);
        return sfcSegmentsFlagsVersions;
    }

}
