package com.zuora.neo.engine.jobs.sfc.constants;

public enum SfcStatus {
    RIPPED("Ripped"),
    COMPLETED("Completed"),
    READY_FOR_SFC("Ready for SFC"),
    ERROR_PROCESSING_SFC("Error in Processing SFC"),
    SETUP_NOT_AVAILABLE("SFC Setup is not available"),
    SO_UPDATED("SO Updated"),
    PAYMENT_UPDATED("Payment Details Updated"),
    NPV_INTEREST_CALCULATED("NPV Interest Calculated"),
    PRINCIPLE_AMOUNT_CALCULATED("Principle Amount Calculated");

    private String status;

    SfcStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return this.status;
    }
}
