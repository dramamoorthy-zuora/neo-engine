package com.zuora.neo.engine.jobs.sweep.activities.summarization;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.sweep.SweepResult;
import com.zuora.neo.engine.jobs.sweep.api.ErrorBufferWithCode;
import com.zuora.neo.engine.jobs.sweep.db.dao.SweepDao;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.OutParameters;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@ActivityImplementation
@Component
public class SweepSummarizationImpl implements SweepSummarization {

    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(SweepSummarizationImpl.class);

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;

    @Override
    public void summarize(SweepResult sweepResult) {

        logger.info("Enters summarize method");
        Jdbi jdbi = DbContext.getConnection();

        long startTime = System.nanoTime();
        ErrorBufferWithCode result = jdbi.withHandle(handle -> {
            ErrorBufferWithCode errorBufferWithCode = null;
            CommonDao commonDao = handle.attach(CommonDao.class);
            String sweepSummarizationEnabled = commonDao.getProfileValue("DO_SWEEP_SUMMARIZATION", "N");
            if (sweepSummarizationEnabled.equals("Y")) {

                errorBufferWithCode = createSweepSummarizationJob(sweepResult);
            }
            return errorBufferWithCode;
        });
        long estimatedTime = System.nanoTime() - startTime;
        logger.info("insertDataForSweepSummary - estimatedTime (nano) ::" + estimatedTime);
        logger.info("insertDataForSweepSummary - estimatedTime (milli) ::" + TimeUnit.MILLISECONDS.convert(estimatedTime, TimeUnit.NANOSECONDS));


        if (result.getReturnCode() != 0) {
            logger.error("Sweep summarization failed with return code: " + result.getReturnCode() + ", error: " + result.getErrorBuffer());
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, result.getErrorBuffer());
        }

        WorkflowContext context = WorkflowContextManager.getWorkflowContext();
        WorkflowRequest request = context.getRequest();

        //delete records from sweep summary table - after successful summarization
        Integer deletedRows = jdbi.withHandle(handle -> {
            SweepDao sweepDao = handle.attach(SweepDao.class);
            return sweepDao.deleteSweepSummaryRecords(request.getRequestId());
        });

        logger.info("deleted " + deletedRows + " records from SweepSummary table for the request id::" + request.getRequestId());
        neoWorkflowLogger.log("deleted " + deletedRows + " records from SweepSummary table for the request id::" + request.getRequestId());
        logger.info("Exits summarize method");


    }

    private ErrorBufferWithCode createSweepSummarizationJob(SweepResult sweepResult) {

        Jdbi jdbi = DbContext.getConnection();
        return jdbi.withHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            SweepDao sweepDao = handle.attach(SweepDao.class);

            WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
            SweepSummarizationData sweepSummarizationData = new SweepSummarizationData();

            String sweepType = sweepResult.getSweepType();
            long bookId = sweepResult.getBookId();
            String orgId = sweepResult.getOrgId();
            long periodId = commonDao.getPeriodId(bookId, orgId);
            long nextPeriodId = sweepDao.getNextPeriodDetails(periodId, request.getClientId()).getNextPeriodId();

            sweepSummarizationData.setBookId(bookId);
            sweepSummarizationData.setOrgId(orgId);
            sweepSummarizationData.setPeriodId(periodId);
            sweepSummarizationData.setNextPeriodId(nextPeriodId);
            sweepSummarizationData.setSweepType(sweepType);
            sweepSummarizationData.setSweepBatchId(request.getRequestId());

            logger.info("sweep summarization for the requested id:: {} is started", request.getRequestId());

            OutParameters outParameters = sweepDao.sweepSummarization(sweepSummarizationData.getBookId(), sweepSummarizationData.getPeriodId(),
                    sweepSummarizationData.getNextPeriodId(),
                    sweepSummarizationData.getOrgId(), sweepSummarizationData.getSweepType(), sweepSummarizationData.getSweepBatchId());
            String errorBuffer = outParameters.getString("errorBuffer");
            Integer retCode = outParameters.getInt("retCode");

            logger.info("sweep summarization for the requested id:: {} is completed", request.getRequestId());

            return new ErrorBufferWithCode(errorBuffer, retCode);
        });
    }
}
