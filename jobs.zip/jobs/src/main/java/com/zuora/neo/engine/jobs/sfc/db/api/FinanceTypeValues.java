package com.zuora.neo.engine.jobs.sfc.db.api;

import java.math.BigDecimal;
import java.util.Date;

public class FinanceTypeValues {

    private long id;
    private String name;
    private String description;
    private long version;
    private String revRecType;
    private BigDecimal interestRate;
    private String eligibilityColumn;
    private String eligibilityValue;
    private String prnclWeightageColumn;
    private Date startDate;
    private Date endDate;
    private long clientId;
    private long crtdPrdId;
    private String crtdBy;
    private Date crdtDt;
    private String updtBy;
    private Date updtDt;
    private long seq;
    private String indicators;

    public FinanceTypeValues(long id, String name, String description, long version, String revRecType, BigDecimal interestRate, String eligibilityColumn,
            String eligibilityValue, String prnclWeightageColumn, Date startDate, Date endDate, long clientId, long crtdPrdId, String crtdBy, Date crdtDt,
            String updtBy, Date updtDt, long seq, String indicators) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.version = version;
        this.revRecType = revRecType;
        this.interestRate = interestRate;
        this.eligibilityColumn = eligibilityColumn;
        this.eligibilityValue = eligibilityValue;
        this.prnclWeightageColumn = prnclWeightageColumn;
        this.startDate = startDate == null ? null : new Date(startDate.getTime());
        this.endDate = endDate == null ? null : new Date(endDate.getTime());
        this.clientId = clientId;
        this.crtdPrdId = crtdPrdId;
        this.crtdBy = crtdBy;
        this.crdtDt = crdtDt == null ? null : new Date(crdtDt.getTime());
        this.updtBy = updtBy;
        this.updtDt = updtDt == null ? null : new Date(updtDt.getTime());
        this.seq = seq;
        this.indicators = indicators;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getVersion() {
        return version;
    }

    public void setVersion(long version) {
        this.version = version;
    }

    public String getRevRecType() {
        return revRecType;
    }

    public void setRevRecType(String revRecType) {
        this.revRecType = revRecType;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

    public String getEligibilityColumn() {
        return eligibilityColumn;
    }

    public void setEligibilityColumn(String eligibilityColumn) {
        this.eligibilityColumn = eligibilityColumn;
    }

    public String getEligibilityValue() {
        return eligibilityValue;
    }

    public void setEligibilityValue(String eligibilityValue) {
        this.eligibilityValue = eligibilityValue;
    }

    public String getPrnclWeightageColumn() {
        return prnclWeightageColumn;
    }

    public void setPrnclWeightageColumn(String prnclWeightageColumn) {
        this.prnclWeightageColumn = prnclWeightageColumn;
    }

    public Date getStartDate() {
        return startDate == null ? null : new Date(startDate.getTime());
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate == null ? null : new Date(startDate.getTime());
    }

    public Date getEndDate() {
        return endDate == null ? null : new Date(endDate.getTime());
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate == null ? null : new Date(endDate.getTime());
    }

    public long getClientId() {
        return clientId;
    }

    public void setClientId(long clientId) {
        this.clientId = clientId;
    }

    public long getCrtdPrdId() {
        return crtdPrdId;
    }

    public void setCrtdPrdId(long crtdPrdId) {
        this.crtdPrdId = crtdPrdId;
    }

    public String getCrtdBy() {
        return crtdBy;
    }

    public void setCrtdBy(String crtdBy) {
        this.crtdBy = crtdBy;
    }

    public Date getCrdtDt() {
        return crdtDt == null ? null : new Date(crdtDt.getTime());
    }

    public void setCrdtDt(Date crdtDt) {
        this.crdtDt = crdtDt == null ? null : new Date(crdtDt.getTime());
    }

    public String getUpdtBy() {
        return updtBy;
    }

    public void setUpdtBy(String updtBy) {
        this.updtBy = updtBy;
    }

    public Date getUpdtDt() {
        return updtDt == null ? null : new Date(updtDt.getTime());
    }

    public void setUpdtDt(Date updtDt) {
        this.updtDt = updtDt == null ? null : new Date(updtDt.getTime());
    }

    public long getSeq() {
        return seq;
    }

    public void setSeq(long seq) {
        this.seq = seq;
    }

    public String getIndicators() {
        return indicators;
    }

    public void setIndicators(String indicators) {
        this.indicators = indicators;
    }
}
