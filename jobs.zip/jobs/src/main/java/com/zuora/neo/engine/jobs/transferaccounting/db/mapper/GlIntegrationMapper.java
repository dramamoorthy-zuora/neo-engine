package com.zuora.neo.engine.jobs.transferaccounting.db.mapper;

import com.zuora.neo.engine.jobs.transferaccounting.db.api.GlIntegrationMap;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class GlIntegrationMapper implements RowMapper<GlIntegrationMap> {
    @Override
    public GlIntegrationMap map(ResultSet rs, StatementContext ctx) throws SQLException {

        return new GlIntegrationMap(rs.getLong(1), rs.getString(2), rs.getString(3),
                rs.getString(4), rs.getString(5));

    }
}
