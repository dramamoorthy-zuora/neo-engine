package com.zuora.neo.engine.jobs.sweep.db.mapper;

import com.zuora.neo.engine.jobs.sweep.db.api.CurrentPeriod;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CurrentPeriodMapper implements RowMapper<CurrentPeriod> {

    @Override
    public CurrentPeriod map(ResultSet rs, StatementContext ctx) throws SQLException {
        return new CurrentPeriod(rs.getDate(1), rs.getDate(2));
    }
}
