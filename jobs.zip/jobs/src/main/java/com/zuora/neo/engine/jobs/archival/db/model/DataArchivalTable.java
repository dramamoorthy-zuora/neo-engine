package com.zuora.neo.engine.jobs.archival.db.model;

import java.util.Date;

/**
 * @author tkrishnakumar
 */
public class DataArchivalTable {

    private Integer id;
    private String name;
    private String type;
    private String archival;
    private String deletable;
    private String archiveGroup;
    private String filterQuery;
    private Integer orderBy;
    private String createdBy;
    private String updatedBy;
    private Date createdDate;
    private Date updatedDate;
    private String deleteFilterQuery;
    private String archivalFilterQuery;
    private String updateFilterQuery;
    private String copyFilterQuery;
    private String deleteMirrorQuery;
    private String recoverFilterQuery;
    private String deleteAfterRecover;

    public DataArchivalTable() {
    }

    public DataArchivalTable(Integer id, String name, String type, String archival, String deletable, String archiveGroup, String filterQuery,
            Integer orderBy, String createdBy, String updatedBy, Date createdDate, Date updatedDate, String deleteFilterQuery, String archivalFilterQuery,
            String updateFilterQuery, String copyFilterQuery, String deleteMirrorQuery,  String recoverFilterQuery, String deleteAfterRecover) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.archival = archival;
        this.deletable = deletable;
        this.archiveGroup = archiveGroup;
        this.filterQuery = filterQuery;
        this.orderBy = orderBy;
        this.createdBy = createdBy;
        this.updatedBy = updatedBy;
        this.createdDate = createdDate == null ? null : new Date(createdDate.getTime());
        this.updatedDate = updatedDate == null ? null : new Date(updatedDate.getTime());
        this.deleteFilterQuery = deleteFilterQuery;
        this.archivalFilterQuery = archivalFilterQuery;
        this.updateFilterQuery = updateFilterQuery;
        this.copyFilterQuery = copyFilterQuery;
        this.deleteMirrorQuery = deleteMirrorQuery;
        this.recoverFilterQuery = recoverFilterQuery;
        this.deleteAfterRecover = deleteAfterRecover;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getArchival() {
        return archival;
    }

    public void setArchival(String archival) {
        this.archival = archival;
    }

    public String getDeletable() {
        return deletable;
    }

    public void setDeletable(String deletable) {
        this.deletable = deletable;
    }

    public String getArchiveGroup() {
        return archiveGroup;
    }

    public void setArchiveGroup(String archiveGroup) {
        this.archiveGroup = archiveGroup;
    }

    public String getFilterQuery() {
        return filterQuery;
    }

    public void setFilterQuery(String filterQuery) {
        this.filterQuery = filterQuery;
    }

    public Integer getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(Integer orderBy) {
        this.orderBy = orderBy;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {

        this.updatedBy = updatedBy;
    }

    public Date getCreatedDate() {
        return createdDate == null ? null : new Date(createdDate.getTime());
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate == null ? null : new Date(createdDate.getTime());
    }

    public Date getUpdatedDate() {
        return updatedDate == null ? null : new Date(updatedDate.getTime());
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate == null ? null : new Date(updatedDate.getTime());
    }

    public String getDeleteFilterQuery() {
        return deleteFilterQuery;
    }

    public void setDeleteFilterQuery(String deleteFilterQuery) {
        this.deleteFilterQuery = deleteFilterQuery;
    }

    public String getArchivalFilterQuery() {
        return archivalFilterQuery;
    }

    public void setArchivalFilterQuery(String archivalFilterQuery) {
        this.archivalFilterQuery = archivalFilterQuery;
    }

    public String getUpdateFilterQuery() {
        return updateFilterQuery;
    }

    public void setUpdateFilterQuery(String updateFilterQuery) {
        this.updateFilterQuery = updateFilterQuery;
    }

    public String getCopyFilterQuery() {
        return copyFilterQuery;
    }

    public void setCopyFilterQuery(String copyFilterQuery) {
        this.copyFilterQuery = copyFilterQuery;
    }

    public String getDeleteMirrorQuery() {
        return deleteMirrorQuery;
    }

    public void setDeleteMirrorQuery(String deleteMirrorQuery) {
        this.deleteMirrorQuery = deleteMirrorQuery;
    }

    public String getRecoverFilterQuery() {
        return recoverFilterQuery;
    }

    public void setRecoverFilterQuery(String recoverFilterQuery) {
        this.recoverFilterQuery = recoverFilterQuery;
    }

    public String getDeleteAfterRecover() {
        return deleteAfterRecover;
    }

    public void setDeleteAfterRecover(String deleteAfterRecover) {
        this.deleteAfterRecover = deleteAfterRecover;
    }


}
