package com.zuora.neo.engine.jobs.sfc.activities;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.common.util.CommonUtils;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.jobs.sfc.SfcResult;
import com.zuora.neo.engine.jobs.sfc.config.SfcConfigProperties;
import com.zuora.neo.engine.jobs.sfc.constants.SfcConstants;
import com.zuora.neo.engine.jobs.sfc.constants.SfcStatus;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.mapper.SfcStatusValuesMapper;
import com.zuora.neo.engine.jobs.sfc.service.NpvCalculationService;
import com.zuora.neo.engine.jobs.sfc.service.SfcDbCacheContextService;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.result.ResultIterable;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.List;

@ActivityImplementation
@Component
public class SfcNpvCalculationActivitiesImpl implements SfcNpvCalculationActivities {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcNpvCalculationActivitiesImpl.class);

    @Autowired
    private NpvCalculationService npvCalculationService;
    @Autowired
    private SfcDbCacheContextService sfcDbCacheContextService;
    @Autowired
    private SfcConfigProperties sfcConfigProperties;

    /*
        Activity Method called from the Workflow.
        This method queries the SFC Table to get all records with Principle Amount Calculated Status and process it
        by batch by calling NpvCalculationService.
     */
    @Override
    public SfcResult calculateNpvInterest(SfcResult sfcResult) {

        LOGGER.debug("NPV Calculation SFC Activity initiated");


        int batchSize = sfcConfigProperties.getBatchSize();
        int fetchSize = sfcConfigProperties.getFetchSize();
        Jdbi jdbi = DbContext.getConnection();
        jdbi.useTransaction(handle -> {

            SfcDbCacheContext sfcDbCacheContext = sfcDbCacheContextService.fetchCommonDetailsFromDb(handle);

            ResultIterable iterable = handle.createQuery(SfcConstants.SFC_STATUS_TABLE_QUERY_ONE_STATUS)
                    .bind("status", SfcStatus.PRINCIPLE_AMOUNT_CALCULATED.getStatus())
                    .setFetchSize(fetchSize)
                    .map(new SfcStatusValuesMapper());
            Iterator<SfcStatusValues> iterator = iterable.iterator();
            while (iterator.hasNext()) {
                List<SfcStatusValues> sfcStatusValuesList = CommonUtils.chunk(iterator, batchSize);
                if (!sfcStatusValuesList.isEmpty()) {
                    LOGGER.debug("Executing SFC NPV Calculation Process for first " + sfcStatusValuesList.size() + " lines");
                    npvCalculationService.calculateNpvInterestForBatch(sfcStatusValuesList, sfcDbCacheContext, sfcResult, handle);
                } else {
                    break;
                }
            }
        });

        return sfcResult;
    }
}
