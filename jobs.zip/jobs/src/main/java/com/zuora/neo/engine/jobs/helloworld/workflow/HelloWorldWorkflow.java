package com.zuora.neo.engine.jobs.helloworld.workflow;

import com.zuora.neo.engine.temporal.workflows.BaseWorkflow;

import io.temporal.workflow.WorkflowInterface;


@WorkflowInterface
public interface HelloWorldWorkflow extends BaseWorkflow {

}
