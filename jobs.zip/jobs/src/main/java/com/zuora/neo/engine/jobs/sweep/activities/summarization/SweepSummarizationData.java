package com.zuora.neo.engine.jobs.sweep.activities.summarization;

public class SweepSummarizationData {

    private long bookId;
    private String orgId;
    private long periodId;
    private long nextPeriodId;
    private String sweepType;
    private long sweepBatchId;

    public long getBookId() {
        return bookId;
    }

    public void setBookId(long bookId) {
        this.bookId = bookId;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public long getPeriodId() {
        return periodId;
    }

    public void setPeriodId(long periodId) {
        this.periodId = periodId;
    }

    public long getNextPeriodId() {
        return nextPeriodId;
    }

    public void setNextPeriodId(long nextPeriodId) {
        this.nextPeriodId = nextPeriodId;
    }

    public String getSweepType() {
        return sweepType;
    }

    public void setSweepType(String sweepType) {
        this.sweepType = sweepType;
    }

    public long getSweepBatchId() {
        return sweepBatchId;
    }

    public void setSweepBatchId(long sweepBatchId) {
        this.sweepBatchId = sweepBatchId;
    }
}
