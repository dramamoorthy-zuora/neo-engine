package com.zuora.neo.engine.jobs.transferaccounting.activities.gllink;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface GlLinkingActivity {
    void updateGlLink();
}
