package com.zuora.neo.engine.jobs.transferaccounting.api;

import java.util.List;

/*
This class stores information related to num of threads
and chunk information needed for a multi-threaded flow
 */
public class ThreadDetails {
    Integer numThreads;
    List<ChunkRecord> splitBatchIds;

    public Integer getNumThreads() {
        return numThreads;
    }

    public List<ChunkRecord> getSplitBatchIds() {
        return splitBatchIds;
    }

    public ThreadDetails(Integer numThreads, List<ChunkRecord> batchIds) {
        this.numThreads = numThreads;
        this.splitBatchIds = batchIds;
    }

    public ThreadDetails(){
    }
}
