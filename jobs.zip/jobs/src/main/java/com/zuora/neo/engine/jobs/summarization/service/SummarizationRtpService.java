package com.zuora.neo.engine.jobs.summarization.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.jobs.rtp.WorkItemResult;
import com.zuora.neo.engine.jobs.rtp.service.RtpService;

import com.zuora.neo.engine.jobs.summarization.db.doa.SummarizationDao;

import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.OutParameters;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class SummarizationRtpService implements RtpService {

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SummarizationRtpService.class);

    @Override
    public WorkItemResult process(String secAtrVal, BigDecimal rtpBatchId) {
        LOGGER.info("--------- Summarization - batchId to process - " + rtpBatchId);

        Jdbi jdbi = DbContext.getConnection();

        return jdbi.withHandle(handle -> {
            SummarizationDao summarizationDao = handle.attach(SummarizationDao.class);
            WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();

            // populate rtp summarization input entries
            Integer noOfRecordsInserted = summarizationDao.populateSummarizationInputEntries(rtpBatchId, request.getUser());
            LOGGER.info("No.of Summarization input records inserted - " + noOfRecordsInserted);

            // call run_time_summ_wrapper procedure
            OutParameters outParameters = summarizationDao.callSummarization(secAtrVal, rtpBatchId);

            LOGGER.info("########## Returning from Summarization service ########");
            return new WorkItemResult(outParameters.getString("p_errbuf"), outParameters.getInt("p_retcode"));
        });
    }
}
