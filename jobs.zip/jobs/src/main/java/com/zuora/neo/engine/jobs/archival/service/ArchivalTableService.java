package com.zuora.neo.engine.jobs.archival.service;

import static com.zuora.neo.engine.jobs.archival.common.Constants.ProfileConstants.DEFAULT_PROFILE_VALUE;
import static com.zuora.neo.engine.jobs.archival.common.Constants.ProfileConstants.PROFILE_ENABLED;

import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.common.lookup.LookupEntity;
import com.zuora.neo.engine.common.lookup.LookupService;
import com.zuora.neo.engine.jobs.archival.common.Constants;
import com.zuora.neo.engine.jobs.archival.db.dao.DataArchivableTablesDao;
import com.zuora.neo.engine.jobs.archival.db.model.ArchivalSettingsEntity;
import com.zuora.neo.engine.jobs.archival.db.model.DataArchivalTable;
import com.zuora.neo.engine.jobs.archival.exceptions.ArchivalException;
import com.zuora.neo.engine.scheduler.dao.ScheduledProgramDao;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.result.NoResultsException;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * @author tkrishnakumar Service which retrieves data from RPRO_DATA_ARCHIVE_TABLES
 */
@Service
public class ArchivalTableService {

    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(ArchivalTableService.class);

    private final LookupService lkpSvc;

    public ArchivalTableService(LookupService lkpSvc) {
        this.lkpSvc = lkpSvc;
    }

    public  List<DataArchivalTable> fetchArchivalTables(Handle handle) {
        List<DataArchivalTable> tables;
        DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
        tables =  dataArchivableTablesDao.getArchivalTableList();

        return tables;
    }

    public String getSchemaName(Handle handle) {
        DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
        return dataArchivableTablesDao.getSchemaName();
    }

    public void insertRcMapping(Handle handle, List<Long> rcIds) {
        DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
        int result = dataArchivableTablesDao.insertRcMapping(rcIds);
        logger.debug("Total number of inserted records in RC mapping : " + result);
    }

    public void updateCopyQueryInDaTable(Handle handle) {
        DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
        dataArchivableTablesDao.updateCopyQuery();
    }

    public int clearUnProcessedEntriesFromPreviousBatch(Handle handle) {
        try {
            return handle.inTransaction(h -> h.attach(DataArchivableTablesDao.class).clearUnProcessedEntriesFromPreviousBatch());
        } catch (NoResultsException e) {
            logger.info("No dangling entries in the rc_head_g");
            return 0;
        }
    }

    public int insertHeadGDetails(Handle handle, ArchivalSettingsEntity archivalSettingsEntity) {
        return handle.inTransaction(h -> {
            DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
            long batchId;

            batchId = WorkflowContextManager.getWorkflowContext().getRequest().getRequestId();
            int keepMonthOfData = archivalSettingsEntity.getKeepMonthsOfData();
            logger.debug("Batch id is : " + batchId);
            int insertResult = dataArchivableTablesDao.insertHeadGDetails(batchId, "SYSADMIN",keepMonthOfData,
                    getCurrentOpenPrdId(handle),getMinOfClosedPrdId(handle));
            logger.info("Number of expired RCs inserted: " + insertResult);
            return insertResult;
        });
    }

    public ArchivalSettingsEntity getArchivalSettings(Handle h, String key) {
        ArchivalSettingsEntity archivalSettingsEntity = new ArchivalSettingsEntity();
        return lkpSvc.fetchLookupData(h, key, (settings) -> {
            for (LookupEntity setting : settings) {
                switch (setting.getKey()) {
                    case "BATCH_SIZE":
                        if (Integer.parseInt(setting.getValue()) <= 1000) {
                            archivalSettingsEntity.setBatchSize(Integer.parseInt(setting.getValue()));
                        }
                        break;
                    case "FETCH_SIZE":
                        archivalSettingsEntity.setFetchSize(Integer.parseInt(setting.getValue()));
                        break;
                    case "KEEP_MONTHS_OF_DATA":
                        if (Integer.parseInt(setting.getValue()) >= 24) {
                            archivalSettingsEntity.setKeepMonthsOfData(Integer.parseInt(setting.getValue()));
                        }
                        break;
                    case "SUCCESSIVE_BATCH_UPDATE_FAILURE_COUNT":
                        archivalSettingsEntity.setSuccessiveBatchUpdateFailureThreshold(Integer.parseInt(setting.getValue()));
                        break;
                    case "MAX_FAILURE_ATTEMPT_PERCENTAGE":
                        archivalSettingsEntity.setMaxFailureAttemptsInPercentage(Double.parseDouble(setting.getValue()));
                        break;
                    case "LOG_QUERY":
                        archivalSettingsEntity.setLogQuery(setting.getValue().equalsIgnoreCase("Y"));
                        break;
                    default:
                        break;
                }
            }
            return archivalSettingsEntity;
        });
    }

    public List<Long> getExpiredRcs(Handle handle, long batchId, String processedFlag, int batchSize) {
        logger.debug("Fetching getExpiredRcs based on batch size");
        DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
        return dataArchivableTablesDao.getExpiredRcs(batchSize,batchId, processedFlag);

    }

    public int updateBatchStatus(Handle handle,String processStatus, List<Long> rcIds) {
        DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
        return dataArchivableTablesDao.updateCopyAndDeleteStatus(processStatus,rcIds);
    }

    private int getCurrentOpenPrdId(Handle handle) {
        DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
        int openPeriod = dataArchivableTablesDao.getCurrentOpenPrdId();
        if (openPeriod == 0) {
            throw new ArchivalException("Failed: No Open Period id found. Open period :" + openPeriod);
        }
        return openPeriod;
    }

    private int getMinOfClosedPrdId(Handle handle) {
        DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
        int closePeriod =  dataArchivableTablesDao.getMinOfClosedPrdId();
        if (closePeriod == 0) {
            throw new ArchivalException("Failed: No Closed Period id found. Close period :" + closePeriod);
        }
        return closePeriod;
    }

    public boolean isArchivalEnabled(Handle handle) {
        DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
        String archivalEnabled = dataArchivableTablesDao.checkArchivalEnabled(Constants.ProfileConstants.PROFILE_KEY, DEFAULT_PROFILE_VALUE);
        return archivalEnabled.equals(PROFILE_ENABLED);
    }

    public boolean checkIfJobIsRunning(Handle handle, long batchId) {
        ScheduledProgramDao scheduledProgramDao = handle.attach(ScheduledProgramDao.class);
        return scheduledProgramDao.checkIfJobIsRunning(batchId) != 0;
    }

    public void insertHeadGDetailsRecovery(Handle handle, List<Long> recoverableRCs) {
        handle.inTransaction(h -> {
            DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
            long batchId;

            batchId = WorkflowContextManager.getWorkflowContext().getRequest().getRequestId();
            logger.debug("Batch id is : " + batchId);
            recoverableRCs.forEach(rcId -> dataArchivableTablesDao.insertHeadGDetailsRecovery(batchId, rcId,"SYSADMIN"));
            return null;
        });
    }


    public void deleteRcMapping(Handle handle, List<Long> rcIds) {
        DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
        int result = dataArchivableTablesDao.deleteRcMapping(rcIds);
        logger.debug("Total number of deleted records from RC mapping : " + result);
    }

    public List<Long> fetchRecoverableRCs(Handle handle, long batchId, String processedFlag, int batchSize) {
        logger.debug("Fetching recoverable RCs based on batch size");
        DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
        return dataArchivableTablesDao.fetchRecoverableRcs(batchSize,batchId, processedFlag);

    }

    public void updateIdOfInsertedRCs(Handle handle, long requestId) {
        DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
        dataArchivableTablesDao.updateIdOfInsertedRCs(requestId);
    }

    public int updateRecoveryStatus(Handle handle,String processStatus, List<Long> rcIds) {
        DataArchivableTablesDao dataArchivableTablesDao = handle.attach(DataArchivableTablesDao.class);
        return dataArchivableTablesDao.updateRecoveryStatus(processStatus,rcIds);
    }
}
