package com.zuora.neo.engine.jobs.rtp.factory;

import com.zuora.neo.engine.jobs.caclnetting.service.CaclNettingRtpService;
import com.zuora.neo.engine.jobs.ltst.service.LtstRtpService;
import com.zuora.neo.engine.jobs.rtp.constants.RtpConstants;
import com.zuora.neo.engine.jobs.rtp.service.RtpService;
import com.zuora.neo.engine.jobs.summarization.service.SummarizationRtpService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RtpWorkflowFactory {

    @Autowired
    CaclNettingRtpService caclNettingRtpService;

    @Autowired
    LtstRtpService ltstRtpService;

    @Autowired
    SummarizationRtpService summarizationRtpService;

    public RtpService getService(Integer id) {
        switch (id) {
            case 1:
                return caclNettingRtpService;
            case 2:
                return ltstRtpService;
            case 3:
                return summarizationRtpService;
            default:
                throw new IllegalArgumentException(RtpConstants.INVALID_STEP_ID + id);
        }
    }
}
