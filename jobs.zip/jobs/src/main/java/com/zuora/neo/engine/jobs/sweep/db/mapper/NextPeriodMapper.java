package com.zuora.neo.engine.jobs.sweep.db.mapper;

import com.zuora.neo.engine.jobs.sweep.db.api.NextPeriod;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class NextPeriodMapper implements RowMapper<NextPeriod> {

    @Override
    public NextPeriod map(ResultSet rs, StatementContext ctx) throws SQLException {

        return new NextPeriod(rs.getLong(1), rs.getDate(2), rs.getDate(3));
    }
}
