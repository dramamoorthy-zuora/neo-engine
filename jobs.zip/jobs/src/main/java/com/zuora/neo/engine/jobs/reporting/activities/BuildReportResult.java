package com.zuora.neo.engine.jobs.reporting.activities;

public class BuildReportResult {

    int noOfCols;
    int noOfRows;

    BuildReportResult(int row, int col) {
        noOfRows = row;
        noOfCols = col;
    }

    void updateRowsAndColumns(int row, int col) {
        noOfCols = col;
        noOfRows = row;
    }

    int getRows() {
        return noOfRows;
    }

    int getCols() {
        return noOfCols;
    }
}
