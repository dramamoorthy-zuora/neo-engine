package com.zuora.neo.engine.jobs.transferaccounting.db.api;

public class AccountSegment {
    private String scheduleAccountSegments;
    //private Long sobId;

    public AccountSegment(String scheduleAccountSegments) {
        this.scheduleAccountSegments = scheduleAccountSegments;
        //this.sobId = sobId;
    }

    public String getScheduleAccountSegments() {
        return scheduleAccountSegments;
    }
}
