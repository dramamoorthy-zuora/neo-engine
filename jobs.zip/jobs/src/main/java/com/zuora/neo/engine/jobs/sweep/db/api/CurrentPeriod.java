package com.zuora.neo.engine.jobs.sweep.db.api;

import java.util.Date;

public class CurrentPeriod {

    private Date currentQuarterDate;
    private Date currentYearDate;

    public CurrentPeriod(Date currentQuarterDate, Date currentYearDate) {
        this.currentQuarterDate = new Date(currentQuarterDate.getTime());
        this.currentYearDate = new Date(currentYearDate.getTime());
    }

    public Date getCurrentQuarterDate() {
        return new Date(currentQuarterDate.getTime());
    }


    public Date getCurrentYearDate() {
        return new Date(currentYearDate.getTime());
    }

}
