package com.zuora.neo.engine.jobs.transferaccounting.constants;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum AccountTypeParams {
    REVENUE_ID("R"),
    ASSETS_ID("A"),
    LIABILITY_ID("L"),
    DUMMY_ACCT_ID("Z"),
    UNBILLED_ID("U"),
    VC_ADJUSTMENT("V"),
    ADJUSTMENT_LIABILITY("W"),
    ADJUSTMENT_REVENUE("X"),
    RCOG_ID("C"),
    DCOG_ID("D"),
    REVENUE_OFFSET("S"),
    DEFERRAL_OFFSET("P"),
    RO_CONTRA("T"),
    IMPAIRMENT("M"),
    INTER_COMP("I"),
    CONTRA_INVENTORY_COST("K");

    private final String accountTypeParam;

    @JsonValue
    public String getAccountTypeParam() {
        return accountTypeParam;
    }

    AccountTypeParams(String accountTypeParam) {
        this.accountTypeParam = accountTypeParam;
    }

    private static final Map<String, AccountTypeParams> LOOKUP =
            Arrays.stream(AccountTypeParams.values()).collect(Collectors.toMap(AccountTypeParams::getAccountTypeParam, Function.identity()));

    @JsonCreator
    public static AccountTypeParams fromAccountTypeParam(String accountTypeParam) {
        return LOOKUP.get(accountTypeParam);
    }
}
