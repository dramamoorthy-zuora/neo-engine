package com.zuora.neo.engine.jobs.transferaccounting.db.dao;

import com.zuora.neo.engine.jobs.transferaccounting.db.api.StageHandlerTable;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.StageHandlerMapper;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.UseRowMapper;

import java.util.List;

public interface StageHandlerDao {
    @SqlQuery("SELECT ps.name Procedure_Name "
            + "  FROM rpro_proc_stage ps, rpro_proc_head ph "
            + " WHERE rpro_proc_head_pkg.get_enabled_flag (ph.indicators) = 'Y' "
            + "   AND rpro_proc_stage_pkg.get_enabled_flag (ps.indicators) = 'Y' "
            + "   AND ps.processor_id = ph.id "
            + "   AND UPPER (ps.stage_name)= :stageName "
            + "   AND ph.TYPE = :stageType " //like 'MANUAL_JOURNAL', 'TRANSFER'
            + " ORDER BY ps.processor_id, ps.seq ")
    @UseRowMapper(StageHandlerMapper.class)
    List<StageHandlerTable> getStageHandlerProcedureName(@Bind("stageName") String stageName, @Bind("stageType") String stageType);
}





