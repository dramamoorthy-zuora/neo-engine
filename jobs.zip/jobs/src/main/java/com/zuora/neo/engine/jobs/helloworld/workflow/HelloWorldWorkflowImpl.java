package com.zuora.neo.engine.jobs.helloworld.workflow;

import com.zuora.neo.engine.annotations.workflow.WorkflowImplementation;

import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.jobs.helloworld.activities.HelloWorldActivities;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.workflows.LoggerWorkflowImpl;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.workflow.Workflow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@WorkflowImplementation
public class HelloWorldWorkflowImpl extends LoggerWorkflowImpl implements HelloWorldWorkflow {

    private static final org.slf4j.Logger LOGGER = Workflow.getLogger(HelloWorldWorkflowImpl.class);

    private final HelloWorldActivities helloWorldActivities = Workflow.newActivityStub(HelloWorldActivities.class);

    @Autowired
    ParseProgramParameters parseProgramParameters;

    @Override
    public WorkflowResponse execute() {
        LOGGER.info("Inside HelloWorld workflow");
        helloWorldActivities.hello();
        return new WorkflowResponse(RevenueJobStatus.COMPLETED, "");
    }
}
