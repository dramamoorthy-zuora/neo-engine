package com.zuora.neo.engine.jobs.transferaccounting.api;

import com.zuora.neo.engine.jobs.transferaccounting.activities.AccountingActivitiesImpl;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.BatchCriteria;

import org.slf4j.LoggerFactory;

import java.util.Locale;

public class BatchCriteriaCondition {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AccountingActivitiesImpl.class);

    private StringBuilder scheduleWhereClause;
    private StringBuilder bookWhereClause;
    private StringBuilder mjtWhereClause;
    private StringBuilder prdWhereClause;
    private StringBuilder nonSchWhereClause;
    private Integer rcFilerCount;
    private Integer mjtFilerCount;
    private Integer rrsFilerCount;

    public StringBuilder getScheduleWhereClause() {
        return scheduleWhereClause;
    }

    public void setScheduleWhereClause(StringBuilder scheduleWhereClause) {
        this.scheduleWhereClause = scheduleWhereClause;
    }

    public StringBuilder getBookWhereClause() {
        return bookWhereClause;
    }

    public void setBookWhereClause(StringBuilder bookWhereClause) {
        this.bookWhereClause = bookWhereClause;
    }

    public StringBuilder getMjtWhereClause() {
        return mjtWhereClause;
    }

    public void setMjtWhereClause(StringBuilder mjtWhereClause) {
        this.mjtWhereClause = mjtWhereClause;
    }

    public StringBuilder getPrdWhereClause() {
        return prdWhereClause;
    }

    public void setPrdWhereClause(StringBuilder prdWhereClause) {
        this.prdWhereClause = prdWhereClause;
    }

    public StringBuilder getNonSchWhereClause() {
        return nonSchWhereClause;
    }

    public void setNonSchWhereClause(StringBuilder nonSchWhereClause) {
        this.nonSchWhereClause = nonSchWhereClause;
    }

    public Integer getRcFilerCount() {
        return rcFilerCount;
    }

    public void setRcFilerCount(Integer rcFilerCount) {
        this.rcFilerCount = rcFilerCount;
    }

    public Integer getMjtFilerCount() {
        return mjtFilerCount;
    }

    public void setMjtFilerCount(Integer mjtFilerCount) {
        this.mjtFilerCount = mjtFilerCount;
    }

    public Integer getRrsFilerCount() {
        return rrsFilerCount;
    }

    public void setRrsFilerCount(Integer rrsFilerCount) {
        this.rrsFilerCount = rrsFilerCount;
    }


    public static BatchCriteriaCondition createBatchCondition(BatchCriteria criteria, StringBuilder scheduleWhereClause,
                                       StringBuilder bookWhereClause, StringBuilder mjtWhereClause, Integer rcFilerCount,
                                       StringBuilder prdWhereClause, StringBuilder nonSchWhereClause, Integer mjtFilerCount, Integer rrsFilerCount) {
        LOGGER.debug("inside createBatchCondition");
        if ("RRS".equals(criteria.getAlias())) {
            scheduleWhereClause = scheduleWhereClause.append(" AND ").append("NVL (").append(criteria.getFieldValue())
                    .append(", rrs.").append(criteria.getFieldName()).append(") ").append(criteria.getOperator())
                    .append(" '").append(criteria.getOperand()).append("' ");
            rrsFilerCount = rrsFilerCount + 1;
        } else if ("RB".equals(criteria.getAlias())) {
            bookWhereClause = bookWhereClause.append(" AND rrs.book_id IN ( SELECT rb.id FROM rpro_book rb "
                    + " WHERE rpro_book_pkg.get_enabled_flag (rb.indicators) = 'Y' AND SYSDATE BETWEEN NVL (rb.start_date, SYSDATE) "
                    + " AND NVL (rb.end_date, SYSDATE + 1)");
            if (criteria.getFieldValue() != null) {
                bookWhereClause.append(" AND NVL (").append(criteria.getFieldValue()).append(", rb.name ) ").append(criteria.getOperator())
                        .append(" '").append(criteria.getOperand()).append("') ");
            } else {
                bookWhereClause.append(')');
            }
        } else if ("RJH".equals(criteria.getAlias())) {
            mjtWhereClause = mjtWhereClause.append(" AND NVL ( ").append(criteria.getFieldValue()).append(",rjh.").append(criteria.getFieldName())
                    .append(") ").append(criteria.getOperator()).append(" '").append(criteria.getOperand()).append("' ");
            mjtFilerCount = mjtFilerCount + 1;
        } else if ("RJL".equals(criteria.getAlias())) {
            mjtWhereClause = mjtWhereClause.append(" AND NVL ( ").append(criteria.getFieldValue()).append(",rjl.").append(criteria.getFieldName())
                    .append(") ").append(criteria.getOperator()).append(" '").append(criteria.getOperand()).append("' ");
            mjtFilerCount = mjtFilerCount + 1;
        } else if ("RC".equals(criteria.getAlias())) {
            prdWhereClause = prdWhereClause.append(" AND rrs.post_prd_id IN ( SELECT id FROM rpro_calendar rc WHERE 1=1 AND NVL (")
                    .append(criteria.getFieldValue()).append(", rc.").append(criteria.getFieldName())
                    .append(") ").append(criteria.getOperator()).append(" '").append(criteria.getOperand()).append("'");
            if (criteria.getFieldValue() != null) {
                prdWhereClause.append(" AND NVL (").append(criteria.getFieldValue()).append(", rc.").append(criteria.getFieldName())
                        .append(") ").append(criteria.getOperator()).append(" '").append(criteria.getOperand()).append("' )");
            } else {
                prdWhereClause.append(" )");
            }
        } else {
            nonSchWhereClause = nonSchWhereClause.append(" AND ").append(criteria.getAlias().toLowerCase(Locale.ENGLISH)).append(".")
                    .append(criteria.getFieldName()).append(" ").append(criteria.getOperator()).append(" '").append(criteria.getOperand()).append("'");
            rcFilerCount = rcFilerCount + 1;
        }

        BatchCriteriaCondition batchCriteriaCondition = new BatchCriteriaCondition();
        batchCriteriaCondition.setBookWhereClause(bookWhereClause);
        batchCriteriaCondition.setMjtFilerCount(mjtFilerCount);
        batchCriteriaCondition.setMjtWhereClause(mjtWhereClause);
        batchCriteriaCondition.setRcFilerCount(rcFilerCount);
        batchCriteriaCondition.setNonSchWhereClause(nonSchWhereClause);
        batchCriteriaCondition.setPrdWhereClause(prdWhereClause);
        batchCriteriaCondition.setRrsFilerCount(rrsFilerCount);
        batchCriteriaCondition.setScheduleWhereClause(scheduleWhereClause);

        LOGGER.debug("inside createBatchCondition batchCriteriaCondition: " + batchCriteriaCondition.getMjtWhereClause());

        return batchCriteriaCondition;
    }
}
