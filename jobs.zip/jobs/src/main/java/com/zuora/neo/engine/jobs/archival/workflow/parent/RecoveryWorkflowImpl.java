package com.zuora.neo.engine.jobs.archival.workflow.parent;

import com.zuora.neo.engine.annotations.workflow.WorkflowImplementation;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.archival.ArchivalResult;
import com.zuora.neo.engine.jobs.archival.activities.RecoveryActivity;
import com.zuora.neo.engine.jobs.archival.common.Constants;
import com.zuora.neo.engine.jobs.archival.enums.ArchivalStatus;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.workflows.LoggerWorkflowImpl;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.activity.ActivityOptions;
import io.temporal.common.RetryOptions;
import io.temporal.workflow.Workflow;
import org.springframework.stereotype.Component;

import java.time.Duration;

@WorkflowImplementation
@Component
public class RecoveryWorkflowImpl extends LoggerWorkflowImpl implements RecoveryWorkflow {

    private static final org.slf4j.Logger logger = Workflow.getLogger(RecoveryWorkflowImpl.class);


    private final RecoveryActivity recoveryActivity = Workflow.newActivityStub(RecoveryActivity.class,
            ActivityOptions.newBuilder()
                    .setScheduleToCloseTimeout(Duration.ofHours(24 * 30))
                    .setHeartbeatTimeout(Duration.ofMinutes(5))
                    .setRetryOptions(RetryOptions.newBuilder()
                            .setMaximumAttempts(3)
                            .setInitialInterval(Duration.ofMinutes(1))
                            .setMaximumInterval(Duration.ofMinutes(20))
                            .setDoNotRetry(NonRetryableActivityException.class.getName())
                            .build())
                    .validateAndBuildWithDefaults());

    @Override
    public WorkflowResponse execute() {
        logger.info("Started executing recovery workflow.");

        ArchivalResult result = recoveryActivity.recoverRecords();

        ArchivalStatus status = result.getStatus();
        logger.info("Recovery workflow status : " + status);
        logger.info("Recovery workflow execution completed.");

        if (!status.equals(ArchivalStatus.RECOVERY_SUCCESS) && result.isRetryPossible()) {
            logger.error(result.getStatus().status + ":" + result.getMessage());
            NonRetryableActivityException.throwNonRetryableActivityException(
                    RevenueJobStatus.FAILED,
                    result.getMessage()
            );
        }

        return new WorkflowResponse(ArchivalStatus.getRevenueJobStatusFor(status), ArchivalStatus.getMessage(status));

    }
}
