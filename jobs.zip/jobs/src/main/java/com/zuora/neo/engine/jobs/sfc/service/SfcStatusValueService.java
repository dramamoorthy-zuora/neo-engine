package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.jobs.sfc.constants.SfcConstants;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.PreparedBatch;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SfcStatusValueService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcStatusValueService.class);

    public void updateSfcStatusWithNpvInterestBatch(List<SfcStatusValues> sfcStatusValuesList, Handle handle) {

        PreparedBatch updateSfcStatusWithNpvInterestBatch = handle.prepareBatch(SfcConstants.UPDATE_SFC_STATUS_NPV_INTEREST);

        for (SfcStatusValues sfcStatusValues : sfcStatusValuesList) {
            bindSfcStatusValuesForUpdate(updateSfcStatusWithNpvInterestBatch, sfcStatusValues);
        }
        doBulkUpdateSfcStatusValues(updateSfcStatusWithNpvInterestBatch);
    }

    public void doBulkUpdateSfcStatusValues(PreparedBatch updateSfcStatusWithNpvInterestBatch) {

        LOGGER.info("Update SFC Status Batch Size : " + updateSfcStatusWithNpvInterestBatch.size());
        int[] updateCount = updateSfcStatusWithNpvInterestBatch.execute();
        LOGGER.info("Number of Records update SFC Status : " + updateCount.length);
    }

    public void bindSfcStatusValuesForUpdate(PreparedBatch updateSfcStatusWithNpvInterestBatch, SfcStatusValues sfcStatusValues) {

        updateSfcStatusWithNpvInterestBatch.bind("status", sfcStatusValues.getStatus())
                .bind("netNpvAmount", sfcStatusValues.getNetNpvAmt())
                .bind("netInterestAccrual", sfcStatusValues.getNetInterestAccrual())
                .bind("docLineId", sfcStatusValues.getDocLineId())
                .bind("ripAmt", sfcStatusValues.getRipAmt())
                .bind("indicators", sfcStatusValues.getIndicators())
                .bind("errMsg", sfcStatusValues.getErrMsg()).add();
    }
}
