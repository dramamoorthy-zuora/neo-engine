package com.zuora.neo.engine.jobs.sweep.db.api;

import java.util.Date;

public class NextPeriod {

    private long nextPeriodId;
    private Date nextQuarterDate;
    private Date nextYearDate;

    public NextPeriod(long nextPeriodId, Date nextQuarterDate, Date nextYearDate) {
        this.nextPeriodId = nextPeriodId;
        this.nextQuarterDate = new Date(nextQuarterDate.getTime());
        this.nextYearDate = new Date(nextYearDate.getTime());
    }

    public long getNextPeriodId() {
        return nextPeriodId;
    }


    public Date getNextQuarterDate() {
        return new Date(nextQuarterDate.getTime());
    }


    public Date getNextYearDate() {
        return new Date(nextYearDate.getTime());
    }

}
