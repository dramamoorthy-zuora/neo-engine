package com.zuora.neo.engine.jobs.caclnetting.constants;

public enum NettingReversalFlags {

    /*
        Refer to https://docs.google.com/spreadsheets/d/1qBf8vpGJ_S2IhbztsV6U-GpHqUz7Rrry9P-x9WmJjwE/edit?usp=sharing
        for detailed scenarios for reversal flags
     */

    // final reversal entry
    REVERSAL("L"),
    // reversal flag of posted schedule's reversal
    POSTED_NETTING_REVERSAL("Y"),
    // updated posted flag
    POSTED_NETTING_UPDATE("O"),
    // reversal flag of reversal of reversal
    POSTED_REVERSAL_OF_REVERSAL("R"),
    // updated posted reversal flag
    POSTED_REVERSAL_UPDATE("P");

    private final String flag;

    public String getFlag() {
        return flag;
    }

    NettingReversalFlags(String flag) {
        this.flag = flag;
    }


}
