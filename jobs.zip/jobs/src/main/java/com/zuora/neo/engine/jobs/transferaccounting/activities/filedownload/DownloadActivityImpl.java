package com.zuora.neo.engine.jobs.transferaccounting.activities.filedownload;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.config.Properties;
import com.zuora.neo.engine.jobs.transferaccounting.constants.TransferStatus;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.AccountingDao;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.OutParameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@ActivityImplementation
@Component
public class DownloadActivityImpl implements DownloadActivity {
    @Autowired
    Properties properties;

    /*
    After the schedules are moved to the GL int stage table
    we can download the GL records as a single file. Once multi-threaded
    model is brought may need changes how to break into multiple files.
     */
    @Override
    public Long fileDownload(ThreadedAccountingResult accountingResult) {
        Long postBatchId = accountingResult.getPostBatchId();
        Jdbi jdbi = DbContext.getConnection();
        final Long[] requestId = {null};

        jdbi.useHandle(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            CommonDao commonDao = handle.attach(CommonDao.class);
            WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
            properties.load(commonDao, request.getTenantId());

            String transferStatus = accountingDao.getTransferStatus(postBatchId);
            String genFileTransfer = properties.getFileTransferEnabled() ? "Y" : "N";

            /*
            Only when the transfer status is "READY TO TRANSFER" and "GENERATE_FILE_TRNSFR_BATCH"
            is enabled file download starts.
             */
            if (TransferStatus.READY_TO_TRANSFER.getTransferStatus().equals(transferStatus)
                    && "Y".equals(genFileTransfer)) {
                OutParameters outParameters = accountingDao.submitFileDownload(postBatchId);
                requestId[0] = outParameters.getLong("out_request_id");
                accountingDao.updateFileIdHeader(requestId[0], postBatchId);
            }

        });
        return requestId[0];
    }
}
