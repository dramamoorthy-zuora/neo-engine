package com.zuora.neo.engine.common.lookup;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class LookupDataValueMapper  implements RowMapper<LookupEntity> {
    @Override
    public LookupEntity map(ResultSet rs, StatementContext ctx) throws SQLException {
        return new LookupEntity(rs.getString("key"), rs.getString("value"));
    }
}
