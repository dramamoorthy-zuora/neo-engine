package com.zuora.neo.engine.jobs.rtp.activities;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.db.dao.LockDao;
import com.zuora.neo.engine.jobs.rtp.config.RtpProperties;
import com.zuora.neo.engine.jobs.rtp.db.doa.RtpDao;

import com.zuora.neo.engine.jobs.rtp.service.RtpBatchCreatorService;
import com.zuora.neo.engine.jobs.rtp.service.RtpCleanupService;
import com.zuora.neo.engine.jobs.rtp.service.RtpInitializerService;
import com.zuora.neo.engine.jobs.rtp.service.RtpWorkflowService;

import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.scheduler.dao.ScheduledProgramDao;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.OutParameters;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;


@ActivityImplementation
@Component
public class RtpActivitiesImpl implements RtpActivities {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(RtpActivitiesImpl.class);

    @Autowired
    RtpWorkflowService rtpWorkflowService;

    @Autowired
    RtpProperties rtpProperties;

    @Autowired
    RtpInitializerService rtpInitializerService;

    @Autowired
    RtpCleanupService rtpCleanupService;

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;

    @Override
    public WorkflowResponse performRtp() {
        Jdbi jdbi = DbContext.getConnection();
        return jdbi.withHandle(handle -> {

            CommonDao commonDao = handle.attach(CommonDao.class);
            rtpInitializerService.initialize(commonDao);

            RtpDao rtpDao = handle.attach(RtpDao.class);
            ScheduledProgramDao programDao = handle.attach(ScheduledProgramDao.class);
            LockDao lockDao = handle.attach(LockDao.class);
            WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
            List<String> orgIds = rtpDao.getOrgIdsToProcessRtp();

            if (orgIds.isEmpty()) {
                neoWorkflowLogger.log("No WorkItem Headers present for any org to perform RTP");
                return new WorkflowResponse(RevenueJobStatus.COMPLETED, "");
            }

            for (String orgId : orgIds) {

                OutParameters lockOutParameters = null;
                neoWorkflowLogger.log("Processing orgId - " + orgId);
                LOGGER.info("Processing orgId - " + orgId);

                try {
                    // should not acquire lock in case of shadow mode
                    if (!rtpProperties.isShadowMode()) {
                        lockOutParameters = rtpWorkflowService.acquireLock(lockDao, orgId);
                        LOGGER.info("Lock acquired for org {} lockOutParameters {}", orgId, lockOutParameters.toString());
                    }

                    rtpCleanupService.cleanupRtpStaleData(rtpDao, orgId);

                    BigDecimal batchId = rtpDao.getRtpBatchId(request.getClientId());
                    RtpBatchCreatorService.setBatchId(batchId);
                    long noOfRtpHeadersProcessed = rtpWorkflowService.performRtp(handle, rtpDao, programDao, orgId);
                    neoWorkflowLogger.log("No.of Rtp Headers processed - " + noOfRtpHeadersProcessed);

                    List<String> batchExecutionStats = rtpDao.getBatchExecutionStats(batchId);
                    neoWorkflowLogger.log("Run Stat - " + String.join(", ", batchExecutionStats));

                } finally {
                    if (!rtpProperties.isShadowMode() && lockOutParameters != null && lockOutParameters.getString("p_result").equals("TRUE")) {
                        rtpWorkflowService.removeLock(lockDao, orgId);
                        LOGGER.info("Lock removed for org {}", orgId);
                    }
                }

            }
            return new WorkflowResponse(RevenueJobStatus.COMPLETED, "");
        });
    }
}
