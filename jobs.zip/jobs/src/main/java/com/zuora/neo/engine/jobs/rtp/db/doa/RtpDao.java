package com.zuora.neo.engine.jobs.rtp.db.doa;

import com.zuora.neo.engine.jobs.rtp.api.RtpWiHeader;
import com.zuora.neo.engine.jobs.rtp.api.RtpWorkflowDefinition;
import com.zuora.neo.engine.jobs.rtp.db.mapper.RtpWiHeaderMapper;
import com.zuora.neo.engine.jobs.rtp.db.mapper.RtpWorkflowDefinitionMapper;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.statement.UseRowMapper;

import java.math.BigDecimal;
import java.util.List;

public interface RtpDao {

    @SqlQuery("SELECT * FROM rpro_rtp_wi_header WHERE batch_id = :batch_id")
    @UseRowMapper(RtpWiHeaderMapper.class)
    List<RtpWiHeader> getRtpWiHeader(@Bind("batch_id") BigDecimal batchId);

    @SqlUpdate("UPDATE RPRO_RTP_WI_HEADER SET status = :status, updt_by = :user, updt_dt = SYSDATE WHERE batch_id = :batch_id AND status = 'IN PROGRESS'")
    Integer updateHeaderStatus(@Bind("batch_id") BigDecimal batchId,
                            @Bind("status") String status,
                            @Bind("user") String user);

    @SqlUpdate("UPDATE RPRO_RTP_WI SET status = :status, updt_dt = SYSDATE WHERE header_id in ("
            +   "select id from rpro_rtp_wi_header where batch_id = :batch_id and status = 'IN PROGRESS') and step_id = :step_id")
    Integer updateWiStatus(@Bind("batch_id") BigDecimal batchId, @Bind("status") String status, @Bind("step_id") Integer stepId);

    @SqlUpdate("UPDATE RPRO_RTP_WI SET status = :status, message = :error, updt_dt = SYSDATE WHERE header_id in ("
            +   "select id from rpro_rtp_wi_header where batch_id = :batch_id and status = 'IN PROGRESS') and step_id = :step_id")
    Integer updateWiStatusWithMessage(@Bind("batch_id") BigDecimal batchId, @Bind("error") String error,
                                      @Bind("status") String status, @Bind("step_id") Integer stepId);

    @SqlQuery("SELECT a.step_id, a.execution_order, b.step_name FROM RPRO_RTP_WF_DEFN a, RPRO_RTP_STEPS b "
             +  "WHERE a.step_id = b.id And a.wf_id = :wf_id order by a.execution_order")
    @UseRowMapper(RtpWorkflowDefinitionMapper.class)
    List<RtpWorkflowDefinition> getRtpWorkflowDefinition(@Bind("wf_id") Integer wfId);

    @SqlQuery("SELECT RPRO_UTILITY_PKG.GENERATE_ID('RPRO_RTP_WI_HEADER_BATCH_ID_S', :client_id) FROM DUAL")
    BigDecimal getRtpBatchId(@Bind("client_id") Long clientId);

    @SqlUpdate("INSERT INTO rpro_rtp_wi (id, header_id, step_id, prd_id, book_id, sec_atr_val, client_id, status, message, "
            +   "crtd_by, crtd_dt, updt_by, updt_dt)"
            +   " SELECT RPRO_RTP_WI_ID_S_1.nextval, id, :step_id, prd_id, book_id, sec_atr_val, client_id, :status, NULL, :user, SYSDATE, "
            +   ":user, SYSDATE  FROM rpro_rtp_wi_header WHERE batch_id = :batch_id and status = 'IN PROGRESS'")
    Integer createRtpWiEntries(@Bind("batch_id") BigDecimal batchId,
                               @Bind("status") String status,
                               @Bind("step_id") Integer stepId,
                               @Bind("user") String user);

    @SqlUpdate("UPDATE rpro_rtp_wi_header SET retry_count = (retry_count + 1), retry_reason = status, status = 'NEW'"
            +   " WHERE status IN ('ERROR', 'IN PROGRESS') AND retry_count < :max_retry_count AND sec_atr_val = :sec_atr_val")
    Integer cleanupRtpHeaderStaleData(@Bind("sec_atr_val") String secAtrVal, @Bind("max_retry_count") Integer maxRetryCount);

    @SqlUpdate("INSERT INTO rpro_rtp_wi_h SELECT wi.* FROM rpro_rtp_wi wi, rpro_rtp_wi_header header WHERE wi.header_id = header.id AND "
            +   "header.sec_atr_val = :sec_atr_val AND header.status IN ('ERROR', 'IN PROGRESS') AND retry_count < :max_retry_count")
    Integer moveErrorWiToHistory(@Bind("sec_atr_val") String secAtrVal, @Bind("max_retry_count") Integer maxRetryCount);

    @SqlUpdate("DELETE FROM rpro_rtp_wi WHERE header_id IN (SELECT id FROM rpro_rtp_wi_header where sec_atr_val = :sec_atr_val "
            +   "AND retry_count < :max_retry_count AND status IN ('ERROR', 'IN PROGRESS'))")
    Integer deleteErrorWi(@Bind("sec_atr_val") String secAtrVal, @Bind("max_retry_count") Integer maxRetryCount);

    @SqlQuery("SELECT DISTINCT sec_atr_val FROM rpro_rtp_wi_header WHERE status != 'COMPLETED'")
    List<String> getOrgIdsToProcessRtp();

    @SqlUpdate("UPDATE rpro_rtp_wi_header SET status = 'SKIPPED' WHERE id IN ("
            +   "SELECT x.id FROM ("
            +   "SELECT id, ROW_NUMBER() OVER (PARTITION BY rc_id ORDER BY id) seq FROM rpro_rtp_wi_header "
            +   "WHERE sec_atr_val = :sec_atr_val AND batch_id = :batch_id) x "
            +   "WHERE x.seq != 1)")
    Integer skipDuplicateRcIdsInBatch(@Bind("sec_atr_val") String secAtrVal, @Bind("batch_id") BigDecimal batchId);

    @SqlUpdate("INSERT INTO rpro_rtp_wi_header_h SELECT * FROM rpro_rtp_wi_header "
            +   "WHERE sec_atr_val = :sec_atr_val AND batch_id = :batch_id AND status IN ('SKIPPED','COMPLETED')")
    Integer moveCompletedHeaderToHistory(@Bind("sec_atr_val") String secAtrVal, @Bind("batch_id") BigDecimal batchId);

    @SqlUpdate("DELETE FROM rpro_rtp_wi_header WHERE sec_atr_val = :sec_atr_val AND batch_id = :batch_id AND status IN ('SKIPPED','COMPLETED')")
    Integer deleteCompletedHeader(@Bind("sec_atr_val") String secAtrVal, @Bind("batch_id") BigDecimal batchId);

    @SqlUpdate("INSERT INTO rpro_rtp_wi_h SELECT wi.* FROM rpro_rtp_wi wi, rpro_rtp_wi_header header WHERE wi.header_id = header.id AND "
            +   "header.sec_atr_val = :sec_atr_val AND header.batch_id = :batch_id AND header.status IN ('SKIPPED','COMPLETED')")
    Integer moveCompletedWiToHistory(@Bind("sec_atr_val") String secAtrVal, @Bind("batch_id") BigDecimal batchId);

    @SqlUpdate("DELETE FROM rpro_rtp_wi WHERE header_id IN (SELECT id FROM rpro_rtp_wi_header where sec_atr_val = :sec_atr_val "
            +   "AND batch_id = :batch_id AND status IN ('SKIPPED','COMPLETED'))")
    Integer deleteCompletedWi(@Bind("sec_atr_val") String secAtrVal, @Bind("batch_id") BigDecimal batchId);

    @SqlQuery("SELECT 'step ' || step.id || ' - ' || (SELECT SUM(round((MAX(b.updt_dt) - MAX(b.crtd_dt)) * 60 * 24, 2)) "
            +   " FROM rpro_rtp_wi_header_h a, rpro_rtp_wi_h b WHERE a.id = b.header_id AND batch_id > round(:batch_id, 0)"
            +   " AND batch_id < ( round(:batch_id, 0) + 1 ) AND step_id = step.id GROUP BY batch_id, step_id) mins FROM rpro_rtp_steps step")
    List<String> getBatchExecutionStats(@Bind("batch_id") BigDecimal batchId);

}
