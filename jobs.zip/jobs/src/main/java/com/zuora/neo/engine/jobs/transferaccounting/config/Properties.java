package com.zuora.neo.engine.jobs.transferaccounting.config;

import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.transferaccounting.TransferAccountingTestEvaluator;
import com.zuora.neo.engine.jobs.transferaccounting.constants.AccountingProfiles;

import org.springframework.stereotype.Component;

import java.util.HashMap;

@Component
public class Properties {
    private static final String profileEnabledValue = "Y";

    private HashMap<String, Boolean> tenantLoaded;
    private Integer noOfThreads;
    private Long splitBatchSize;
    //add all the accounting profiles here
    private Boolean customCodeAllowed;
    private String nettingLevel;
    private Boolean mjeSummaryTransferEnabled;
    private Boolean summaryTransferEnabled;
    private Boolean postScheduleEnabled;
    private Boolean postManualJeScheduleEnabled;
    private Boolean glLinkEnabled;
    private Boolean mjeEnabled;
    private Boolean transferValidationEnabled;
    private Boolean fileTransferEnabled;
    private Boolean closeProcessEnabled;
    private Boolean adjustCrDrEnabled;
    private Boolean webserviceEnabled;
    private Boolean stopBatchOnErrEnabled;
    private Boolean allocationsEnabled;
    private Boolean scheduleValidationEnabled;
    private String language;

    public Integer getNoOfThreads() {
        return noOfThreads;
    }

    public void setNoOfThreads(Integer noOfThreads) {
        this.noOfThreads = noOfThreads;
    }

    public Long getSplitBatchSize() {
        return splitBatchSize;
    }

    public void setSplitBatchSize(Long splitBatchSize) {
        this.splitBatchSize = splitBatchSize;
    }

    public Boolean getCustomCodeAllowed() {
        return customCodeAllowed;
    }

    public void setCustomCodeAllowed(String customCodeAllowed) {
        this.customCodeAllowed = profileEnabledValue.equals(customCodeAllowed);
    }

    public Boolean getMjeSummaryTransferEnabled() {
        return mjeSummaryTransferEnabled;
    }

    public void setMjeSummaryTransferEnabled(String mjeSummaryTransferEnabled) {
        this.mjeSummaryTransferEnabled = profileEnabledValue.equals(mjeSummaryTransferEnabled);
    }

    public Boolean getSummaryTransferEnabled() {
        return summaryTransferEnabled;
    }

    public void setSummaryTransferEnabled(String summaryTransferEnabled) {
        this.summaryTransferEnabled = profileEnabledValue.equals(summaryTransferEnabled);
    }

    public Boolean getPostScheduleEnabled() {
        return postScheduleEnabled;
    }

    public void setPostScheduleEnabled(String postScheduleEnabled) {
        this.postScheduleEnabled = profileEnabledValue.equals(postScheduleEnabled);
    }

    public Boolean getPostManualJeScheduleEnabled() {
        return postManualJeScheduleEnabled;
    }

    public void setPostManualJeScheduleEnabled(String postManualJeScheduleEnabled) {
        this.postManualJeScheduleEnabled = profileEnabledValue.equals(postManualJeScheduleEnabled);
    }

    public Boolean getGlLinkEnabled() {
        return glLinkEnabled;
    }

    public void setGlLinkEnabled(String glLinkEnabled) {
        this.glLinkEnabled = profileEnabledValue.equals(glLinkEnabled);
    }

    public Boolean getMjeEnabled() {
        return mjeEnabled;
    }

    public void setMjeEnabled(String mjeEnabled) {
        this.mjeEnabled = profileEnabledValue.equals(mjeEnabled);
    }

    public Boolean getTransferValidationEnabled() {
        return transferValidationEnabled;
    }

    public void setTransferValidationEnabled(String transferValidationEnabled) {
        this.transferValidationEnabled = profileEnabledValue.equals(transferValidationEnabled);
    }

    public Boolean getFileTransferEnabled() {
        return fileTransferEnabled;
    }

    public void setFileTransferEnabled(String fileTransferEnabled) {
        this.fileTransferEnabled = profileEnabledValue.equals(fileTransferEnabled);
    }

    public Boolean getCloseProcessEnabled() {
        return closeProcessEnabled;
    }

    public void setCloseProcessEnabled(String closeProcessEnabled) {
        this.closeProcessEnabled = profileEnabledValue.equals(closeProcessEnabled);
    }

    public Boolean getAdjustCrDrEnabled() {
        return adjustCrDrEnabled;
    }

    public void setAdjustCrDrEnabled(String adjustCrDrEnabled) {
        this.adjustCrDrEnabled = profileEnabledValue.equals(adjustCrDrEnabled);
    }

    public Boolean getWebserviceEnabled() {
        return webserviceEnabled;
    }

    public void setWebserviceEnabled(String webserviceEnabled) {
        this.webserviceEnabled = profileEnabledValue.equals(webserviceEnabled);
    }

    public Boolean getStopBatchOnErrEnabled() {
        return stopBatchOnErrEnabled;
    }

    public void setStopBatchOnErrEnabled(String stopBatchOnErrEnabled) {
        this.stopBatchOnErrEnabled = profileEnabledValue.equals(stopBatchOnErrEnabled);
    }

    public Boolean getAllocationsEnabled() {
        return allocationsEnabled;
    }

    public void setAllocationsEnabled(String allocationsEnabled) {
        this.allocationsEnabled = profileEnabledValue.equals(allocationsEnabled);
    }

    public Boolean getScheduleValidationEnabled() {
        return scheduleValidationEnabled;
    }

    public void setScheduleValidationEnabled(String scheduleValidationEnabled) {
        this.scheduleValidationEnabled = profileEnabledValue.equals(scheduleValidationEnabled);
    }

    public String getNettingLevel() {
        return nettingLevel;
    }

    public void setNettingLevel(String nettingLevel) {
        this.nettingLevel = nettingLevel;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }


    public void load(CommonDao commonDao, String tenantId) {
        if (tenantLoaded != null && tenantLoaded.containsKey(tenantId)) {
            return;
        }

        setCustomCodeAllowed(commonDao.getProfileValue(AccountingProfiles.CUSTOM_CODE_ALLOWED, "N"));
        setSummaryTransferEnabled(commonDao.getProfileValue(AccountingProfiles.SUMMARY_TRANSFER, "N"));
        setMjeSummaryTransferEnabled(commonDao.getProfileValue(AccountingProfiles.MJE_SUMMARY_TRANSFER, "N"));
        setPostScheduleEnabled(commonDao.getProfileValue(AccountingProfiles.POST_SCHEDULES, "N"));
        setPostManualJeScheduleEnabled(commonDao.getProfileValue(AccountingProfiles.POST_MANUAL_JE_SCHEDULES, "N"));
        setGlLinkEnabled(commonDao.getProfileValue(AccountingProfiles.ENABLE_GL_LINK, "N"));
        setMjeEnabled(commonDao.getProfileValue(AccountingProfiles.MJE_ENABLED, "N"));
        setTransferValidationEnabled(commonDao.getProfileValue(AccountingProfiles.DO_TRANSFER_VALIDATION, "Y"));
        setFileTransferEnabled(commonDao.getProfileValue(AccountingProfiles.FILE_TRNSFR_BATCH, "Y"));
        setCloseProcessEnabled(commonDao.getProfileValue(AccountingProfiles.ENABLE_CLOSE_PROCESS, "Y"));
        setAdjustCrDrEnabled(commonDao.getProfileValue(AccountingProfiles.ADJUST_CR_DR, "N"));
        setWebserviceEnabled(commonDao.getProfileValue(AccountingProfiles.WEBSERVICE_ENABLED, "N"));
        setStopBatchOnErrEnabled(commonDao.getProfileValue(AccountingProfiles.STOP_BATCH_ON_ERR, "Y"));
        setAllocationsEnabled(commonDao.getProfileValue(AccountingProfiles.ENABLE_ALLOCATIONS, "N"));
        setScheduleValidationEnabled(commonDao.getProfileValue(AccountingProfiles.SCHD_VALIDATION, "N"));
        setNettingLevel(commonDao.getProfileValue(AccountingProfiles.NETTING_PROCESS, ""));
        setLanguage(commonDao.getProfileValue(AccountingProfiles.LANGUAGE, "en"));
        if (TransferAccountingTestEvaluator.multiThreadSetup()) {
            setNoOfThreads(2);
            setSplitBatchSize(Long.valueOf(5L));
        } else if (TransferAccountingTestEvaluator.singleThreadSetup()) {
            setNoOfThreads(1);
            setSplitBatchSize(Long.valueOf(5L));
        } else {
            setNoOfThreads(commonDao.getProfileValue(AccountingProfiles.NUM_THREADS, 1));
            setSplitBatchSize(Long.valueOf(commonDao.getProfileValue(AccountingProfiles.BATCH_SIZE, 10000)));
        }

        if (tenantLoaded != null) {
            tenantLoaded.put(tenantId, true);
        }

    }

    public void resetLoadedFlag(String tenantId) {
        tenantLoaded.remove(tenantId);
    }

    public Properties() {
        tenantLoaded = new HashMap<>();
    }
}
