package com.zuora.neo.engine.jobs.transferaccounting.config;

import com.zuora.neo.engine.config.YamlPropertySourceFactory;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ConfigurationProperties(prefix = "ta")
@PropertySource(value = "classpath:ta.yml", factory = YamlPropertySourceFactory.class)
public class ConfigProperties {
    private int maxRetryCount;

    private int maxRetryTestCount;
    private boolean retryEnable;
    private boolean roundingEnable;

    public int getMaxRetryTestCount() {
        return maxRetryTestCount;
    }

    public void setMaxRetryTestCount(int maxRetryTestCount) {
        this.maxRetryTestCount = maxRetryTestCount;
    }

    public int getMaxRetryCount() {
        return maxRetryCount;
    }

    public void setMaxRetryCount(int maxRetryCount) {
        this.maxRetryCount = maxRetryCount;
    }

    public boolean isRetryEnable() {
        return retryEnable;
    }

    public void setRetryEnable(boolean retryEnable) {
        this.retryEnable = retryEnable;
    }

    public boolean isRoundingEnable() {
        return roundingEnable;
    }

    public void setRoundingEnable(boolean roundingEnable) {
        this.roundingEnable = roundingEnable;
    }

}
