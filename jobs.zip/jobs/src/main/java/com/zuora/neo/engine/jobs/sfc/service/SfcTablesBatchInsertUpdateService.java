package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.db.api.AccountValue;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;

import org.jdbi.v3.core.Handle;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SfcTablesBatchInsertUpdateService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcTablesBatchInsertUpdateService.class);

    @Autowired
    RcScheduleService rcScheduleService;

    @Autowired
    SfcCalcDetailService sfcCalcDetailService;

    @Autowired
    AccountValService accountValService;

    @Autowired
    SfcStatusValueService sfcStatusValueService;

    public void batchInsertSfcTables(List<RcScheduleRecord> rcScheduleRecordBatch, List<SfcCalcDetails> sfcCalcDetailsBatch,
            List<AccountValue> accountValueList, long openPeriodId, Handle handle) {

        LOGGER.info("Inserting RC schedule, SFC schedule and account segments for this batch");

        try {
            rcScheduleService.insertRcScheduleRecordsBatch(rcScheduleRecordBatch, handle);
        } catch (Exception e) {
            LOGGER.error("Error in processing SFC. Error occurred during batch insert on RC Schedule Table" + e);
        }
        try {
            sfcCalcDetailService.insertSfcCalcDetailsBatch(sfcCalcDetailsBatch, handle);
        } catch (Exception e) {
            LOGGER.error("Error in processing SFC. Error occurred during batch insert on SFC Calc Detail Table" + e);
        }
        try {
            accountValService.insertAccountSegmentsBatch(rcScheduleRecordBatch, accountValueList, openPeriodId, handle);
        } catch (Exception e) {
            LOGGER.error("Error in inserting account segments");
        }

    }

    public void batchUpdateSfcStatusTable(List<SfcStatusValues> sfcStatusValuesList, Handle handle) {
        LOGGER.info("Updating SFC Status Table for this batch");
        try {
            sfcStatusValueService.updateSfcStatusWithNpvInterestBatch(sfcStatusValuesList,handle);
        } catch (Exception e) {
            LOGGER.info("Error in processing SFC. Error occurred during batch update of SFC Status Table" + e);
        }
    }
}
