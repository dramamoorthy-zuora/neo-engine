package com.zuora.neo.engine.common.lookup;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.UseRowMapper;

import java.util.List;

public interface LookupDataDao {
    @SqlQuery("SELECT lookup_value key,lookup_code value"
            + "   FROM rpro_lkp a, rpro_lkp_val b"
            + "  WHERE a.id =b.lookup_id"
            + "    AND active_flag='Y'"
            + "    AND a.name  = :lookupName")
    @UseRowMapper(LookupDataValueMapper.class)
    List<LookupEntity> findByLkpName(@Bind("lookupName") String lookupName);

}
