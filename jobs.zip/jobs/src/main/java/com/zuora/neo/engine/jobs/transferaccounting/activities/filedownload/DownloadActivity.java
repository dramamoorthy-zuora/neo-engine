package com.zuora.neo.engine.jobs.transferaccounting.activities.filedownload;

import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface DownloadActivity {
    Long fileDownload(ThreadedAccountingResult accountingResult);
}
