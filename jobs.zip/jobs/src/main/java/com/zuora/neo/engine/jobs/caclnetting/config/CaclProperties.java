package com.zuora.neo.engine.jobs.caclnetting.config;

import com.zuora.neo.engine.common.ScheduleTypes;
import com.zuora.neo.engine.common.util.CommonUtils;
import com.zuora.neo.engine.db.api.PeriodDetails;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.caclnetting.constants.CaclConstants;

import com.google.common.annotations.VisibleForTesting;

import lombok.Data;

import org.springframework.stereotype.Component;

@Data
@Component
public class CaclProperties {

    private boolean nettingEnabled;
    private boolean nettingRcMje;
    private String nettingLevel;
    private boolean shadowMode;
    private Long prevNettingPeriodId;
    private PeriodDetails periodDetails;
    private String caclNetRc;
    private String caclNetRcH;
    private String headPeriod;
    private String scheduleTable;
    private String headPeriodSequence;
    private String scheduleSequence;
    private String orgId;
    private Long clientId;
    private long bookId;
    private String user;
    private String schdTypes;

    public CaclProperties() {
        nettingEnabled = false;
        nettingRcMje = false;

        schdTypes = "";
    }

    public void loadProperties(CommonDao commonDao, long bookId, long clientId, String orgId, String user) {

        this.bookId = bookId;
        this.clientId = clientId;
        this.orgId = orgId;
        this.user = user;
        nettingEnabled = CommonUtils.isProfileEnabled(commonDao.getProfileValueFromTable("ALLOW_NETTING_PROCESS", "N"));
        nettingRcMje = CommonUtils.isProfileEnabled(commonDao.getProfileValueFromTable("NETTING_RC_MJE", "N"));
        nettingLevel = commonDao.getProfileValueFromTable("NETTING_PROCESS_LEVEL", "TRANSACTION");
        shadowMode = CommonUtils.isProfileEnabled(commonDao.getProfileValueFromTable("ENABLE_REALTIME_PROCESSING_SHADOW_MODE", "Y"));

        schdTypes = "";
        schdTypes += "'" + ScheduleTypes.ALLOCATION.getScheduleType() + "'";
        schdTypes += ",'" + ScheduleTypes.INTER_COMPANY.getScheduleType() + "'";
        schdTypes += ",'" + ScheduleTypes.VARIABLE_CONSIDERATION.getScheduleType() + "'";

        if (!CommonUtils.isProfileEnabled(commonDao.getProfileValue("NETTING_ALLOC_ONLY", "N"))) {
            schdTypes += ",'" + ScheduleTypes.REVENUE.getScheduleType() + "'";
        }

        if (CommonUtils.isProfileEnabled(commonDao.getProfileValue("NETTING_RC_MJE", "N"))) {
            schdTypes += ",'" + ScheduleTypes.MJE.getScheduleType() + "'";
        }

        caclNetRc = generateTableName(CaclConstants.CACL_NET_RC, shadowMode);
        caclNetRcH = generateTableName(CaclConstants.CACL_NET_RC_H, shadowMode);
        headPeriod = generateTableName(CaclConstants.RC_HEAD_PERIOD, shadowMode);
        scheduleTable = generateTableName(CaclConstants.RC_SCHD, shadowMode);

        headPeriodSequence = generateSequence(headPeriod);
        scheduleSequence = generateSequence(scheduleTable);
    }

    @VisibleForTesting
    String generateTableName(String table, boolean shadowMode) {
        if (shadowMode) {
            return table.concat(CaclConstants.SHADOW_TABLE_SUFFIX);
        }
        return table;
    }

    private String generateSequence(String table) {
        return table.concat("_ID_S");
    }
}
