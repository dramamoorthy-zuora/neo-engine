package com.zuora.neo.engine.jobs.sweep.db.dao;

import com.zuora.neo.engine.jobs.sweep.db.api.CurrentPeriod;
import com.zuora.neo.engine.jobs.sweep.db.api.NextPeriod;
import com.zuora.neo.engine.jobs.sweep.db.mapper.CurrentPeriodMapper;
import com.zuora.neo.engine.jobs.sweep.db.mapper.NextPeriodMapper;

import org.jdbi.v3.core.statement.OutParameters;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.OutParameter;
import org.jdbi.v3.sqlobject.statement.SqlCall;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.statement.UseRowMapper;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.Date;

public interface SweepDao {


    @SqlUpdate("UPDATE rpro_rc_schd set post_prd_id = :nextPeriodId, pp_amt = CASE  WHEN (:l_cur_qt_dt  = :l_nxt_qt_dt)  THEN "
            + "amount - (NVL(pq_amt,0) + NVL(py_amt,0)) ELSE 0 END , "
            + "pq_amt = CASE  WHEN (:l_cur_qt_dt  = :l_nxt_qt_dt)  THEN pq_amt WHEN (:l_nxt_qt_dt  = :l_nxt_yr_dt)  THEN 0 ELSE amount - NVL(py_amt,0) END ,"
            + "py_amt = CASE when (:l_nxt_qt_dt  = :l_nxt_yr_dt)  THEN amount ELSE py_amt END ," + " updt_dt = sysdate, updt_by = :updt_by, "
            + "updt_prd_id = :updatePeriodId WHERE post_prd_id = :postPeriodId AND book_id = :bookId AND  rpro_rc_schd_pkg.get_interfaced_flag(indicators)='N' "
            + " AND sec_atr_val = :orgId")
    Integer sweepUpdate(@Bind("nextPeriodId") long nextPeriodId, @Bind("l_cur_qt_dt") Date currentQuarterDate, @Bind("l_nxt_qt_dt") Date nextQuarterDate,
            @Bind("l_nxt_yr_dt") Date nextYearDate, @Bind("updt_by") String updtBy,
            @Bind("updatePeriodId") long updatePeriodId, @Bind("postPeriodId") long postPeriodId, @Bind("bookId") long bookId, @Bind("orgId") String orgId);


    @SqlUpdate("UPDATE rpro_rc_schd set post_prd_id = :nextPeriodId, pp_amt = CASE  WHEN (:l_cur_qt_dt  = :l_nxt_qt_dt)  THEN "
            + "amount - (NVL(pq_amt,0) + NVL(py_amt,0)) ELSE 0 END , "
            + "pq_amt = CASE  WHEN (:l_cur_qt_dt  = :l_nxt_qt_dt)  THEN pq_amt WHEN (:l_nxt_qt_dt  = :l_nxt_yr_dt)  THEN 0 ELSE amount - NVL(py_amt,0) END ,"
            + "py_amt = CASE when (:l_nxt_qt_dt  = :l_nxt_yr_dt)  THEN amount ELSE py_amt END ," + " updt_dt = sysdate, updt_by = :updt_by, "
            + "updt_prd_id = :updatePeriodId WHERE post_prd_id = :postPeriodId AND book_id = :bookId AND  rpro_rc_schd_pkg.get_interfaced_flag(indicators)='N' "
            + " AND sec_atr_val = :orgId AND root_line_id IN (SELECT id FROM rpro_rc_line WHERE rc_id = :rcId)")
    Integer sweepUpdateForRC(@Bind("nextPeriodId") long nextPeriodId, @Bind("l_cur_qt_dt") Date currentQuarterDate, @Bind("l_nxt_qt_dt") Date nextQuarterDate,
            @Bind("l_nxt_yr_dt") Date nextYearDate, @Bind("updt_by") String updtBy,
            @Bind("updatePeriodId") long updatePeriodId, @Bind("postPeriodId") long postPeriodId, @Bind("bookId") long bookId, @Bind("orgId") String orgId,
            @Bind("rcId") BigDecimal rcId);


    @SqlQuery("SELECT id, qtr_start_dt, year_start_dt FROM  rpro_calendar "
            + " WHERE start_date = (SELECT end_date + 1 FROM rpro_calendar WHERE id = :periodId AND  client_id = :clientId AND ROWNUM = 1) "
            + " AND  client_id = :clientId AND ROWNUM = 1")
    @UseRowMapper(NextPeriodMapper.class)
    NextPeriod getNextPeriodDetails(@Bind("periodId") long periodId, @Bind("clientId") long clientId);


    @SqlQuery("SELECT qtr_start_dt, year_start_dt  FROM  rpro_calendar WHERE  id = :periodId AND  client_id = :clientId")
    @UseRowMapper(CurrentPeriodMapper.class)
    CurrentPeriod getCurrentPeriodDetails(@Bind("periodId") long periodId, @Bind("clientId") long clientId);

    @SqlCall("{call rpro_sweep_pkg.rc_schd_prd_sweep_summarize(:errorBuffer, :retCode,:bookId, :periodId, :nextPeriodId, :orgId, :sweepType, :sweepBatchId)}")
    @OutParameter(name = "errorBuffer", sqlType = Types.VARCHAR)
    @OutParameter(name = "retCode", sqlType = Types.INTEGER)
    OutParameters sweepSummarization(@Bind("bookId") long bookId, @Bind("periodId") long periodId, @Bind("nextPeriodId") long nextPeriodId,
            @Bind("orgId") String orgId, @Bind("sweepType") String sweepType, @Bind("sweepBatchId") long sweepBatchId);

    @SqlUpdate("delete from rpro_rc_schd_sweep_summary where sweep_batch_id = :sweepBatchId ")
    Integer deleteSweepSummaryRecords(@Bind("sweepBatchId") long sweepBatchId);
}
