package com.zuora.neo.engine.jobs.transferaccounting.constants;

public enum Actions {
    UPDATE,
    TRANSFER,
    DELETE,
    CANCEL,
    REGENERATE
}
