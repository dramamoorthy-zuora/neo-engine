package com.zuora.neo.engine.jobs.reporting.activities;

import org.json.JSONObject;

public class ReportConfig {
    String query;
    JSONObject config;
    String qsurl;

    ReportConfig(String query, JSONObject config, String qsurl) {
        this.query = query;
        this.config = config;
        this.qsurl = qsurl;
    }

    String getQuery() {
        return query;
    }

    JSONObject getConfig() {
        return config;
    }

    String getQsurl() {
        return qsurl;
    }

}
