package com.zuora.neo.engine.jobs.transferaccounting.workflow;

import com.zuora.neo.engine.annotations.workflow.WorkflowImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.TransferAccountingTestEvaluator;
import com.zuora.neo.engine.jobs.transferaccounting.activities.AccountingActivities;
import com.zuora.neo.engine.jobs.transferaccounting.activities.closeprocess.CloseProcessActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.copy.GlCopyRoundActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.delete.DeleteActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.filedownload.DownloadActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.split.SplitActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.stagehandler.StageHandlerActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.support.SupportActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.transfer.TransferActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.update.UpdateActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.validation.ValidateActivity;
import com.zuora.neo.engine.jobs.transferaccounting.api.ChunkRecord;
import com.zuora.neo.engine.jobs.transferaccounting.api.ThreadDetails;
import com.zuora.neo.engine.jobs.transferaccounting.common.ActivityType;
import com.zuora.neo.engine.jobs.transferaccounting.common.ThreadExecutor;
import com.zuora.neo.engine.jobs.transferaccounting.common.TransferUtility;
import com.zuora.neo.engine.jobs.transferaccounting.config.ConfigProperties;
import com.zuora.neo.engine.jobs.transferaccounting.constants.Actions;
import com.zuora.neo.engine.jobs.transferaccounting.constants.StageHandlerType;
import com.zuora.neo.engine.jobs.transferaccounting.constants.TransferStatus;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.workflows.LoggerWorkflowImpl;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.workflow.Promise;
import io.temporal.workflow.Workflow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@Component
@WorkflowImplementation
public class TransferAccountingUiWorkflowImpl extends LoggerWorkflowImpl implements TransferAccountingUiWorkflow {
    private static final String UPDATE_ERR = "Update failed. Please contact support";
    private static final String WRONG_BATCH = "Batch should not contain criteria from both arrangement and manual journal level";
    private static final String INCORRECT_BATCH_SETUP = "Batch criteria setup is incorrect";
    private static final String CRITERIA_ERR = "Batch Criteria Field does not exist in the lookup TRANSFER_BATCH_CRITERIA OR Alias is NULL";
    private static final String VALIDATION_ERR = "Tansfer Validation Failed!";
    private static final String TRANSFER_ERRORS = "Error in Transfer :";
    private static final String NO_DATA = "NO DATA FOUND";
    private static final String RETRY_TRANSFER_VALIDATE_ERR = "Transfer failed even after max retry, please validate";
    private static final String COPY_ERR = "Copy Activity failed to push data from Temp table to GL stage";

    private final AccountingActivities accountingActivity = Workflow.newActivityStub(AccountingActivities.class);
    private final UpdateActivity updateActivity = Workflow.newActivityStub(UpdateActivity.class);
    private final SplitActivity splitActivity = Workflow.newActivityStub(SplitActivity.class);
    private final TransferActivity transferActivity = Workflow.newActivityStub(TransferActivity.class);
    private final DownloadActivity downloadActivity = Workflow.newActivityStub(DownloadActivity.class);
    private final CloseProcessActivity summaryActivity = Workflow.newActivityStub(CloseProcessActivity.class);
    private final ValidateActivity validateActivity = Workflow.newActivityStub(ValidateActivity.class);
    private final StageHandlerActivity stageHandlerActivity = Workflow.newActivityStub(StageHandlerActivity.class);
    private final GlCopyRoundActivity copyActivity = Workflow.newActivityStub(GlCopyRoundActivity.class);
    private final DeleteActivity deleteActivity = Workflow.newActivityStub(DeleteActivity.class);
    private final SupportActivity supportActivity = Workflow.newActivityStub(SupportActivity.class);

    @Autowired
    private ConfigProperties configProperties;

    @Override
    public WorkflowResponse performAccountingUiFlow() {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        String action = supportActivity.getDeleteAction(request);
        String org = null;
        ThreadedAccountingResult accountingResult = null;
        if (!Actions.DELETE.name().equals(action)) {
            accountingResult = accountingActivity.processTransferAccounting(null);
            org = accountingResult.getOrgId();
        }

        final Integer totalThreads = accountingActivity.getNumberOfThreads();
        if (totalThreads == 1) {
            return doUiActionSingleThreaded(action, accountingResult, org);
        } else {
            return doUiActionMultiThreaded(action, accountingResult, org, totalThreads);
        }
    }

    private WorkflowResponse doUiActionMultiThreaded(String action, ThreadedAccountingResult accountingResult, String org,
            Integer totalThreads) {
        List<ChunkRecord> batchIds;
        ThreadDetails threadDetails;
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        ThreadExecutor threadExecutor = new ThreadExecutor(updateActivity, transferActivity, validateActivity);
        List<Promise<ThreadedAccountingResult>> promiseUpdateList = new ArrayList<>();
        List<Promise<ThreadedAccountingResult>> promiseValidateList = new ArrayList<>();
        List<Promise<ThreadedAccountingResult>> promiseTransferList = new ArrayList<>();
        if (Actions.UPDATE.name().equals(action)) {
            try {
                accountingActivity.resetBatchDetailsForUpdateUI(accountingResult.getPostBatchId());
                threadDetails = splitActivity.getThreadDetails(accountingResult, org);
                batchIds = threadDetails.getSplitBatchIds();
                if (batchIds.isEmpty()) {
                    accountingResult.setTransferStatus(TransferStatus.NO_DATA.getTransferStatus());
                    splitActivity.updateTransferStatus(accountingResult);
                    return new WorkflowResponse(RevenueJobStatus.WARNING, NO_DATA);
                }
                accountingResult.setStageHandlerType(StageHandlerType.BEFORE_UPDATE);
                accountingResult = stageHandlerActivity.executeCustomCodeStageHandler(accountingResult, org);
                WorkflowResponse response = supportActivity.handleCustomApiErrors(accountingResult);
                if (response != null) {
                    return response;
                }
                updateActivity.updateStatusToInProgress(accountingResult.getPostBatchId());
                accountingResult = threadExecutor.executeThreadedSteps(totalThreads, accountingResult, org, promiseUpdateList,
                        ActivityType.UPDATE.name(), batchIds);
                response = supportActivity.handleIncorrectBatchSetup(accountingResult);
                if (response != null) {
                    return response;
                }
                retryUpdate(accountingResult, org, totalThreads, threadExecutor, batchIds, promiseUpdateList);
                //Run validate activity in parallel based on number of threads and split batches
                accountingResult = threadExecutor.executeThreadedSteps(totalThreads, accountingResult, org, promiseValidateList,
                        ActivityType.VALIDATE.name(), batchIds);
                if (accountingResult.getTransferMessage() != null
                        && accountingResult.getTransferMessage().contains(VALIDATION_ERR)) {
                    return new WorkflowResponse(RevenueJobStatus.ERROR, accountingResult.getTransferMessage());
                }
                //run the after update and before post stage handlers outside of the chunk logic
                accountingResult.setStageHandlerType(StageHandlerType.AFTER_UPDATE);
                accountingResult = stageHandlerActivity.executeCustomCodeStageHandler(accountingResult, org);
                response = supportActivity.handleCustomApiErrors(accountingResult);
                if (response != null) {
                    return response;
                }
            } catch (Exception e) {
                if (e.getCause() != null && e.getCause().getMessage().contains(CRITERIA_ERR)) {
                    return new WorkflowResponse(RevenueJobStatus.ERROR, "Error: In Update for Batch ID: "
                            + accountingResult.getPostBatchId() + ". ERROR: " + CRITERIA_ERR);
                } else if (e.getCause() != null && e.getCause().getMessage().contains(INCORRECT_BATCH_SETUP)) {
                    return new WorkflowResponse(RevenueJobStatus.ERROR, "Error: In Update for Batch ID: "
                            + accountingResult.getPostBatchId() + ". ERROR: " + INCORRECT_BATCH_SETUP);
                }
            } finally {
                cleanUp(request, org);
            }
        } else if (Actions.TRANSFER.name().equals(action)) {
            threadDetails = accountingActivity.getNumThreadAndBatches(accountingResult, org);
            batchIds = threadDetails.getSplitBatchIds();
            accountingResult.setStageHandlerType(StageHandlerType.BEFORE_POST);
            stageHandlerActivity.executeCustomCodeStageHandler(accountingResult, org);
            WorkflowResponse response = supportActivity.handleCustomApiErrors(accountingResult);
            if (response != null) {
                return response;
            } //execute TRANSFER activity in parallel based on number of threads and split batches
            transferActivity.updateStatusToProgress(accountingResult.getPostBatchId());
            try {
                accountingResult = threadExecutor.executeThreadedSteps(totalThreads, accountingResult, org, promiseTransferList,
                        ActivityType.TRANSFER.name(), batchIds);
            } catch (Exception e) {
                if (e.getCause() != null && e.getCause().getMessage().contains(TRANSFER_ERRORS)) { //if we fail at the transfer step retry only failed chunks
                    int maxRetry = TransferAccountingTestEvaluator.multiThreadSetup() ? configProperties.getMaxRetryTestCount()
                            : configProperties.getMaxRetryCount();
                    WorkflowResponse transferRetryResponse = handleTransferRetry(accountingResult, org, maxRetry, e.getCause().getMessage());
                    if (transferRetryResponse != null) {
                        return transferRetryResponse;
                    }
                }
            } //since we need 1 single outfile below activities needs to be done by the main thread without parallelism and chunk
            TransferUtility.performAfterPostActivities(accountingResult, org, stageHandlerActivity, splitActivity,
                    copyActivity, downloadActivity, summaryActivity, supportActivity);
            if (accountingResult.getTransferMessage() != null && accountingResult.getTransferMessage().contains(COPY_ERR)) {
                return new WorkflowResponse(RevenueJobStatus.ERROR, COPY_ERR);
            }
            response = supportActivity.handleCustomApiErrors(accountingResult);
            if (response != null) {
                return response;
            }
            cleanUp(request, org);
        } else if (Actions.DELETE.name().equals(action)) {
            runDelete();
        }
        return new WorkflowResponse(RevenueJobStatus.COMPLETED, "");
    }

    private void retryUpdate(ThreadedAccountingResult result, String org, Integer totalThreads, ThreadExecutor threadExecutor,
            List<ChunkRecord> batchIds, List<Promise<ThreadedAccountingResult>> promiseUpdateList) {
        //if we fail at the update step retry from start
        int count = 0;
        int maxRetry = configProperties.getMaxRetryCount();
        HashSet<String> uniqueStatusSet = TransferUtility.getUniqueChunkStatuses(result, splitActivity);
        if (uniqueStatusSet.contains(TransferStatus.ERROR.getTransferStatus())) {
            while (count < maxRetry) {
                updateActivity.resetNoOfSchedules(result.getPostBatchId());
                if (uniqueStatusSet.contains(TransferStatus.ERROR.getTransferStatus())) {
                    count++;
                } else {
                    break;
                } //execute UPDATE activity in parallel based on number of threads and split batches
                result = threadExecutor.executeThreadedSteps(totalThreads, result, org, promiseUpdateList,
                        ActivityType.UPDATE.name(), batchIds);
                uniqueStatusSet = TransferUtility.getUniqueChunkStatuses(result, splitActivity);
            }
        }
        // even after max retry if update fails throw exception
        uniqueStatusSet = TransferUtility.getUniqueChunkStatuses(result, splitActivity);
        if (count == maxRetry && uniqueStatusSet.contains(TransferStatus.ERROR.getTransferStatus())) {
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, UPDATE_ERR);
        }
    }

    private void cleanUp(WorkflowRequest request, String org) {
        accountingActivity.cleanupActivities(org, request);

    }

    private void runDelete() {
        ThreadedAccountingResult accountingResult = new ThreadedAccountingResult();
        runDeleteAction(accountingResult);
    }

    WorkflowResponse handleTransferRetry(ThreadedAccountingResult accountingResult, String org, int maxRetry, String errorMsg) {
        if (configProperties.isRetryEnable()) {
            try {
                TransferUtility.retryTransfer(accountingResult, org, maxRetry, splitActivity, transferActivity);
            } catch (Exception e) {
                if (e.getMessage().contains(RETRY_TRANSFER_VALIDATE_ERR)) {
                    splitActivity.updateTransferStatus(accountingResult);
                    return new WorkflowResponse(RevenueJobStatus.ERROR, accountingResult.getTransferMessage());
                }
            }
        } else {
            accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
            String[] errMsg = errorMsg.split("type");
            String[] msg = errMsg[0].split("=");
            accountingResult.setTransferMessage(msg[1] + " '");
            splitActivity.updateTransferStatus(accountingResult);
            splitActivity.insertTransferError(accountingResult, org, msg[1] + " '");
            return new WorkflowResponse(RevenueJobStatus.ERROR, accountingResult.getTransferMessage());
        }
        return null;
    }

    private void runDeleteAction(ThreadedAccountingResult accountingResult) {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Long postBatchId = supportActivity.getPostBatchId(request);
        accountingResult.setPostBatchId(postBatchId);
        deleteActivity.performBatchDeletion(accountingResult);
    }

    private WorkflowResponse doUiActionSingleThreaded(String action, ThreadedAccountingResult accountingResult, String org) {
        List<ChunkRecord> batchIds;
        ThreadDetails threadDetails;
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        if (Actions.UPDATE.name().equals(action)) {
            try {
                accountingActivity.resetBatchDetailsForUpdateUI(accountingResult.getPostBatchId());
                threadDetails = splitActivity.getThreadDetails(accountingResult, org);
                batchIds = threadDetails.getSplitBatchIds();
                if (batchIds.isEmpty()) {
                    return new WorkflowResponse(RevenueJobStatus.WARNING, NO_DATA);
                }
                accountingResult.setStageHandlerType(StageHandlerType.BEFORE_UPDATE);
                accountingResult = stageHandlerActivity.executeCustomCodeStageHandler(accountingResult, org);
                WorkflowResponse response = supportActivity.handleCustomApiErrors(accountingResult);
                if (response != null) {
                    return response;
                }
                //update main batch to in-progress
                updateActivity.updateStatusToInProgress(accountingResult.getPostBatchId());
                for (ChunkRecord record : batchIds) {
                    accountingResult = TransferUtility.accountingChunkStepsPreUpdate(accountingResult, record, org, updateActivity,
                            validateActivity, splitActivity);
                    if (accountingResult.getTransferMessage() != null
                            && (accountingResult.getTransferMessage().contains(WRONG_BATCH)
                            || accountingResult.getTransferMessage().contains(INCORRECT_BATCH_SETUP)
                            || accountingResult.getTransferMessage().contains(CRITERIA_ERR)
                            || accountingResult.getTransferMessage().contains(VALIDATION_ERR))) {
                        return new WorkflowResponse(RevenueJobStatus.ERROR, accountingResult.getTransferMessage());
                    }
                }
                if (accountingResult.getStageHandlerType() == StageHandlerType.AFTER_UPDATE) {
                    stageHandlerActivity.executeCustomCodeStageHandler(accountingResult, org);
                }
                response = supportActivity.handleCustomApiErrors(accountingResult);
                if (response != null) {
                    return response;
                }
            } catch (Exception e) {
                if (e.getCause() != null && e.getCause().getMessage().contains(CRITERIA_ERR)) {
                    return new WorkflowResponse(RevenueJobStatus.ERROR, "Error: In Update for Batch ID: "
                            + accountingResult.getPostBatchId() + ". ERROR: " + CRITERIA_ERR);
                } else if (e.getCause() != null && e.getCause().getMessage().contains(INCORRECT_BATCH_SETUP)) {
                    return new WorkflowResponse(RevenueJobStatus.ERROR, "Error: In Update for Batch ID: "
                            + accountingResult.getPostBatchId() + ". ERROR: " + INCORRECT_BATCH_SETUP);
                }

            } finally {
                accountingActivity.cleanupActivities(org, request);
            }
        } else if (Actions.TRANSFER.name().equals(action)) {
            threadDetails = accountingActivity.getNumThreadAndBatches(accountingResult, org);
            batchIds = threadDetails.getSplitBatchIds();
            accountingResult.setStageHandlerType(StageHandlerType.BEFORE_POST);
            stageHandlerActivity.executeCustomCodeStageHandler(accountingResult, org);
            WorkflowResponse response = supportActivity.handleCustomApiErrors(accountingResult);
            if (response != null) {
                return response;
            }
            transferActivity.updateStatusToProgress(accountingResult.getPostBatchId());
            for (ChunkRecord record : batchIds) {
                try {
                    TransferUtility.accountingChunkStepsPostUpdate(accountingResult, record, org, transferActivity, splitActivity);
                } catch (Exception e) {
                    if (e.getCause() != null && e.getCause().getMessage().contains(TRANSFER_ERRORS)) { //Transfer activity related exceptions
                        accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
                        //if we fail at the transfer step retry only failed chunks
                        int maxRetry = TransferAccountingTestEvaluator.multiThreadSetup() ? configProperties.getMaxRetryTestCount()
                                : configProperties.getMaxRetryCount();
                        response = handleTransferRetry(accountingResult, org, maxRetry, e.getCause().getMessage());
                        if (response != null) {
                            return response;
                        } else {
                            break;
                        }
                    }
                }
            }
            //since we need 1 single outfile below activities needs to be done by the main thread without parallelism and chunk
            TransferUtility.performAfterPostActivities(accountingResult, org, stageHandlerActivity, splitActivity,
                    copyActivity, downloadActivity, summaryActivity, supportActivity);
            if (accountingResult.getTransferMessage() != null && accountingResult.getTransferMessage().contains(COPY_ERR)) {
                return new WorkflowResponse(RevenueJobStatus.ERROR, COPY_ERR);
            }
            response = supportActivity.handleCustomApiErrors(accountingResult);
            if (response != null) {
                return response;
            }
            accountingActivity.cleanupActivities(org, request);
        } else if (Actions.DELETE.name().equals(action)) {
            accountingResult = new ThreadedAccountingResult();
            runDeleteAction(accountingResult);
        }

        return new WorkflowResponse(RevenueJobStatus.COMPLETED, "");
    }
}
