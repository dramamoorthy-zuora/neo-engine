package com.zuora.neo.engine.jobs.sfc.constants;

public class SfcConstants {

    public static final String SFC_STATUS_TABLE_QUERY_ONE_STATUS = "SELECT doc_num,doc_line_id,status,rc_id,line_id,net_npv_amt,"
            + "net_interest_accrual,rip_date,error_msg,rip_amt,indicators FROM rpro_sfc_status where status = :status";
    public static final String SFC_STATUS_LIST_QUERY = "SELECT doc_num,doc_line_id,status,rc_id,line_id,net_npv_amt,"
            + "net_interest_accrual,rip_date,error_msg,rip_amt,indicators FROM rpro_sfc_status where status in (<status>)";
    public static final String SFC_CALC_TABLE_BY_DOC_LINE = "SELECT id, rc_id, line_id, receivable_begin, receivable_end, npv_receivable,"
            + " interest, prd_id, client_id, crtd_prd_id, sec_atr_val, book_id, crtd_by, crtd_dt, updt_by, "
            + " updt_dt, indicators, crtd_by, crtd_dt, updt_by, updt_dt, indicators, start_date, end_date "
            + "FROM rpro_sfc_calc_det WHERE line_id = :lineId";
    public static final String SFC_RC_SCHD_RECORDS_LINE_ID_BY_PERIOD = "select prd_id, dr_segments, cr_segments, sum(amount) as amount from ( "
            + "SELECT case when prd_id <= :openPeriodId then :openPeriodId  else prd_id end prd_id, amount, dr_segments, cr_segments "
            + "from rpro_rc_schd WHERE line_id = :paId and rpro_rc_schd_pkg.get_schd_subtype_flag(indicators) = 'F' "
            + "and rpro_rc_schd_pkg.get_initial_rep_entry_flag(indicators) = 'N' "
            + "and prd_id >= :reversePeriodId) "
            + "GROUP BY prd_id,dr_segments, cr_segments ORDER BY prd_id DESC";
    public static final String UPDATE_SFC_STATUS_NPV_INTEREST = "UPDATE rpro_sfc_status set net_npv_amt = :netNpvAmount , "
            + "net_interest_accrual = :netInterestAccrual, "
            + "status = :status, rip_amt = :ripAmt, indicators = :indicators, error_msg = :errMsg where doc_line_id = :docLineId";

    public static final String SFC_PYMT_STG_SO_NUM_ID_NOT_EXISTS = "Either Sales Order Number (SO Num) or Sales Order Line ID (SO Line ID) does not exist "
            + "in the system. Please ensure the order data exist as part of a Revenue Contract.";
    public static final String SFC_PYMT_PRINC_AMT_NOT_CALCULATED = "Principal amount not available in the RC. Please review the data in the revenue contract.";
    public static final String INVALID_BOOKNAME_MESSAGE = "SFC Process Failed. Book Name Incorrect";
    public static final String BOOK_NAME_PARAM = "BOOK NAME";
    public static final String DEFAULT_PARAM = "Default";
    public static final String NO_SFC_TYPE_AVAILABLE = "No SFC Type Available";
    public static final String CALENDAR_DETAILS_NOT_PRESENT = "Calendar Details are not present";
    public static final String ERROR_PROCESSING_SFC = "Error in Processing SFC";
    public static final String WARNING_RESPONSE_SFC = "Error in processing one or more SFC lines";
    public static final String SFC_SETUP_NOT_AVAILABLE = "SFC Setup is not available";
    public static final String NO_ACCOUNTS_PRESENT = "No Accounts Present in Account Table";
}

