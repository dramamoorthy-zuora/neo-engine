package com.zuora.neo.engine.jobs.reporting.activities;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.exception.NonRetryableActivityException;

import io.temporal.workflow.Workflow;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @author achaudhary
 *         <p>
 *         Implementation of {@link GetReportConfig}
 */
@ActivityImplementation
@Component
public class SetReportStatusImpl implements SetReportStatus {

    private static final org.slf4j.Logger logger = Workflow.getLogger(GetReportConfig.class);

    @Override
    public String setRecords(String etagObject) {
        logger.info("set records started at " + (new Date()));
        Jdbi jdbi = DbContext.getConnection();
        WorkflowContext context = WorkflowContextManager.getWorkflowContext();
        WorkflowRequest request = context.getRequest();
        String parameterText = request.getParameterText();
        String user = request.getUser();
        String clientID = String.valueOf(request.getClientId());
        logger.info("Client id from the request " + clientID);
        try (Handle handle = jdbi.open()) {
            // Connection connection = handle.getConnection();
            logger.info(parameterText + " here is the parameter text");
            // parameterText="10781";

            String updateQuery = " update rpro_rep_schd_g set etag = ?"
                    + " , indicators = 'A' || substr(indicators, 2, length(indicators))"
                    + " , updt_dt = SYSDATE"
                    + " , updt_by = ?"
                    + " , row_num = ?"
                    + " , file_name = ?"
                    + " where id = ? and "
                    + " client_id = ?";
            JSONObject jsonObject = new JSONObject(etagObject);
            String etag = jsonObject.getString("etag");
            String finalFileName = jsonObject.getString("finalFileName");
            String[] splits = finalFileName.split("/");
            String actualFileName = splits[splits.length - 1];
            String rows = jsonObject.getString("rows");
            jsonObject.put("parameterText",parameterText);
            jsonObject.put("actualFileName",actualFileName);
            jsonObject.put("requestid",request.getRequestId());

            // PreparedStatement statement = connection.prepareStatement(updateQuery);
            handle.execute(updateQuery,etag,user,rows,actualFileName,parameterText,clientID);
            handle.close();
            return jsonObject.toString();

        } catch (Exception e) {
            logger.error("Exception caught inside. set Records Function" + e);
            throw new NonRetryableActivityException(e.getMessage(),e);
        }
    }

    @Override
    public String setErrorInDB(String error) {
        logger.info("inside set Error function Which catches all errors here " + (new Date()));
        Jdbi jdbi = DbContext.getConnection();
        WorkflowContext context = WorkflowContextManager.getWorkflowContext();
        WorkflowRequest request = context.getRequest();
        String parameterText = request.getParameterText();
        String user = request.getUser();

        String clientID = String.valueOf(request.getClientId());
        logger.info("Client id from the request " + clientID);
        try (Handle handle = jdbi.open()) {
            // Connection connection = handle.getConnection();
            logger.info(parameterText + " here is the parameter text" + error);
            String updateQuery = " update rpro_rep_schd_g set "
                    + " indicators = 'E' || substr(indicators, 2, length(indicators))"
                    + " , updt_dt = SYSDATE"
                    + " , updt_by = ?"
                    + " where id = ? and "
                    + " client_id = ?";
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("parameterText",parameterText);
            jsonObject.put("ErrorMsg",error);
            jsonObject.put("requestid",request.getRequestId());
            handle.execute(updateQuery,user,parameterText,clientID);
            handle.close();
            return jsonObject.toString();

        } catch (RuntimeException e) {
            logger.error("Non Retryable exception occurred in processing set Error function." + e);
            throw new NonRetryableActivityException("Error in set error records in db",e);
        }
    }

}
