package com.zuora.neo.engine.jobs.transferaccounting.db.api;

import java.util.Date;

public class GlIntRecord {
    private Long id;
    private Date accountingDate;
    private Date createdDate;
    private Long createdBy;
    private String actualFlag;
    private String userJeCategory;
    private String userJeSourceName;
    private String userCurrencyConvType;
    private Double currencyConversionRate;
    private Date transactionDate;
    private Long jeBatchId;
    private String status;
    private String segment1;
    private String segment2;
    private String segment3;
    private String segment4;
    private String segment5;
    private String segment6;
    private String segment7;
    private String segment8;
    private String segment9;
    private String segment10;
    private String segment11;
    private String segment12;
    private String segment13;
    private String segment14;
    private String segment15;
    private String segment16;
    private String segment17;
    private String segment18;
    private String segment19;
    private String segment20;
    private String segment21;
    private String segment22;
    private String segment23;
    private String segment24;
    private String segment25;
    private String segment26;
    private String segment27;
    private String segment28;
    private String segment29;
    private String segment30;

    private String objectType;
    private Long postBatchId;
    private Long sobId;
    private Long ledgerId;
    private String currencyCode;
    private String periodName;
    private Date currencyConversionDate;

    public GlIntRecord(String objectType, Long postBatchId, Long sobId, Long ledgerId, String currencyCode, String periodName,
            Date currencyConversionDate) {
        this.objectType = objectType;
        this.postBatchId = postBatchId;
        this.sobId = sobId;
        this.ledgerId = ledgerId;
        this.currencyCode = currencyCode;
        this.periodName = periodName;
        this.currencyConversionDate = currencyConversionDate == null ? null : new Date(currencyConversionDate.getTime());
    }

    public Long getId() {
        return id;
    }

    public Date getAccountingDate() {
        return accountingDate == null ? null : new Date(accountingDate.getTime());
    }

    public Date getCreatedDate() {
        return createdDate == null ? null : new Date(createdDate.getTime());
    }

    public Long getCreatedBy() {
        return createdBy;
    }

    public String getActualFlag() {
        return actualFlag;
    }

    public String getUserJeCategory() {
        return userJeCategory;
    }

    public String getUserJeSourceName() {
        return userJeSourceName;
    }

    public String getUserCurrencyConvType() {
        return userCurrencyConvType;
    }

    public Double getCurrencyConversionRate() {
        return currencyConversionRate;
    }

    public Date getTransactionDate() {
        return transactionDate == null ? null : new Date(transactionDate.getTime());
    }

    public Long getJeBatchId() {
        return jeBatchId;
    }

    public String getStatus() {
        return status;
    }

    public String getSegment1() {
        return segment1;
    }

    public String getSegment2() {
        return segment2;
    }

    public String getSegment3() {
        return segment3;
    }

    public String getSegment4() {
        return segment4;
    }

    public String getSegment5() {
        return segment5;
    }

    public String getSegment6() {
        return segment6;
    }

    public String getSegment7() {
        return segment7;
    }

    public String getSegment8() {
        return segment8;
    }

    public String getSegment9() {
        return segment9;
    }

    public String getSegment10() {
        return segment10;
    }

    public String getSegment11() {
        return segment11;
    }

    public String getSegment12() {
        return segment12;
    }

    public String getSegment13() {
        return segment13;
    }

    public String getSegment14() {
        return segment14;
    }

    public String getSegment15() {
        return segment15;
    }

    public String getSegment16() {
        return segment16;
    }

    public String getSegment17() {
        return segment17;
    }

    public String getSegment18() {
        return segment18;
    }

    public String getSegment19() {
        return segment19;
    }

    public String getSegment20() {
        return segment20;
    }

    public String getSegment21() {
        return segment21;
    }

    public String getSegment22() {
        return segment22;
    }

    public String getSegment23() {
        return segment23;
    }

    public String getSegment24() {
        return segment24;
    }

    public String getSegment25() {
        return segment25;
    }

    public String getSegment26() {
        return segment26;
    }

    public String getSegment27() {
        return segment27;
    }

    public String getSegment28() {
        return segment28;
    }

    public String getSegment29() {
        return segment29;
    }

    public String getSegment30() {
        return segment30;
    }

    public String getObjectType() {
        return objectType;
    }

    public Long getPostBatchId() {
        return postBatchId;
    }

    public Long getSobId() {
        return sobId;
    }

    public Long getLedgerId() {
        return ledgerId;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public String getPeriodName() {
        return periodName;
    }

    public Date getCurrencyConversionDate() {
        return currencyConversionDate == null ? null : new Date(currencyConversionDate.getTime());
    }
}
