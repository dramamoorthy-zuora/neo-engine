package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.jobs.sfc.api.SfcSegmentsFlagsVersions;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SchdIndicator;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;

import org.jdbi.v3.core.Handle;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class RippedLineProcessingService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(RippedLineProcessingService.class);

    @Autowired
    SoUpdateProcessingService soUpdateProcessingService;

    @Autowired
    AccrualEntryService accrualEntryService;

    /*
       Service Method to process ripped SFC line. It also calculates impairment amounts if any and creates an impairment entry to
       the rpro_rc_schd table

       Input :
       rcLinePaDataRecord -> record from rpro_rc_line_pa table
       sfcStatusValue -> Lines from Sfc Status Table
       rcLineDetails -> Rc Line Details for doc line
       vcTypeDetailsList -> Details from vc table
       sfcPaymentDetails -> Payment Details for the line
       openPeriodId -> Open Period Id
       sfcSegmentsFlagsVersions -> Has Accounting and Segment Details for the given line
       rcScheduleRecordBatch -> Records to be updated to schedule table for entire batch
       sfcCalcDetailsHistoryBatch -> Records to be updated to sfc calc details history table for entire batch
       schdIndicator -> Schedule Table Indicator
       handle -> Jdbi Handle object to perform DB operations
     */
    public void processRippedSfcLine(List<RcLinePaData> rcLinePaDataRecord, SfcStatusValues sfcStatusValue,
            List<RcLineDetails> rcLineDetails, List<FinanceTypeFlagDetails> financeTypeFlagDetailsList, List<SfcPaymentDetails> sfcPaymentDetails,
            long openPeriodId, SfcSegmentsFlagsVersions sfcSegmentsFlagsVersions, List<RcScheduleRecord> rcScheduleRecordBatch,
            List<SfcCalcDetails> sfcCalcDetailsHistoryBatch, SchdIndicator schdIndicator, Handle handle) {

        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();

        BigDecimal reversedAmount = soUpdateProcessingService.processSfcForUpdatedSoLine(handle, sfcStatusValue, rcLineDetails, financeTypeFlagDetailsList,
                sfcPaymentDetails, openPeriodId, request, sfcSegmentsFlagsVersions.getRcVersion(), sfcSegmentsFlagsVersions.getCrAcctSeg(),
                sfcSegmentsFlagsVersions.getIncomeAcctSeg(), rcLinePaDataRecord, rcScheduleRecordBatch, sfcCalcDetailsHistoryBatch, schdIndicator);
        BigDecimal postedAmount = sfcStatusValue.getNetInterestAccrual().subtract(reversedAmount);
        BigDecimal unRippedAmount = sfcStatusValue.getNetInterestAccrual().subtract(sfcStatusValue.getRipAmt());
        BigDecimal impairmentAmount = BigDecimal.ZERO;
        if (postedAmount.compareTo(unRippedAmount) > 0) {
            impairmentAmount = postedAmount.subtract(unRippedAmount);
        }

        LOGGER.info("For Doc Line ID : " + sfcStatusValue.getDocLineId() + " Posted Amount : " + postedAmount + " Impairment Amount : " + impairmentAmount);

        if (impairmentAmount.compareTo(BigDecimal.ZERO) != 0) {
            accrualEntryService.createImpairmentEntry(rcLineDetails, rcLinePaDataRecord, request,
                    sfcStatusValue.getRipAmt(), openPeriodId,
                    sfcSegmentsFlagsVersions.getRcVersion(), sfcSegmentsFlagsVersions.getCrAcctSeg(),
                    sfcSegmentsFlagsVersions.getContractImparimentSeg(), sfcSegmentsFlagsVersions.getContractImpairmentAccountFlag().charAt(0),
                    financeTypeFlagDetailsList.get(0).getCrAcctgFlag().charAt(0), schdIndicator, rcScheduleRecordBatch);
            accrualEntryService.createImpairmentEntry(rcLineDetails, rcLinePaDataRecord, request,
                    impairmentAmount, openPeriodId, sfcSegmentsFlagsVersions.getRcVersion(),
                    sfcSegmentsFlagsVersions.getIncomeImpairmentSeg(),
                    sfcSegmentsFlagsVersions.getCrAcctSeg(), financeTypeFlagDetailsList.get(0).getCrAcctgFlag().charAt(0),
                    sfcSegmentsFlagsVersions.getImpairmentAccountFlag().charAt(0), schdIndicator, rcScheduleRecordBatch);
        } else {
            accrualEntryService.createAccrualEntry(rcLineDetails, rcLinePaDataRecord, request,
                    sfcStatusValue.getRipAmt().multiply(new BigDecimal(-1)),
                    financeTypeFlagDetailsList.get(0).getDrAcctgFlag(), financeTypeFlagDetailsList.get(0).getContractLiabilityFlag(), openPeriodId,
                    sfcSegmentsFlagsVersions.getRcVersion(), sfcSegmentsFlagsVersions.getContractLiabilitySeg(),
                    sfcSegmentsFlagsVersions.getDrAcctSeg(), schdIndicator, rcScheduleRecordBatch, openPeriodId, 'N');

            accrualEntryService.createAccrualEntry(rcLineDetails, rcLinePaDataRecord, request,
                    sfcStatusValue.getRipAmt(), financeTypeFlagDetailsList.get(0).getCrAcctgFlag(),
                    financeTypeFlagDetailsList.get(0).getContractLiabilityFlag(), openPeriodId,
                    sfcSegmentsFlagsVersions.getRcVersion(), sfcSegmentsFlagsVersions.getContractLiabilitySeg(),
                    sfcSegmentsFlagsVersions.getCrAcctSeg(), schdIndicator, rcScheduleRecordBatch, openPeriodId, 'Y');
        }

    }
}
