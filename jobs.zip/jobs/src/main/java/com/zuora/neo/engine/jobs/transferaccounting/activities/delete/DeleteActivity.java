package com.zuora.neo.engine.jobs.transferaccounting.activities.delete;

import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface DeleteActivity {
    void performBatchDeletion(ThreadedAccountingResult result);
}
