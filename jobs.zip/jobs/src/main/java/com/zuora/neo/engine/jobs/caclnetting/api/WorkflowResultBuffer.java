package com.zuora.neo.engine.jobs.caclnetting.api;

import lombok.Data;

@Data
public class WorkflowResultBuffer {

    private int returnCode;
    private String messageBuffer;

}
