package com.zuora.neo.engine.jobs.sfc.api;

import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;

import java.util.List;

public class SfcSegmentsFlagsVersions {

    private String drAcctFlag;
    private String crAcctFlag;
    private String incomeStmtFlag;
    private String accrualUponBillingFlag;
    private long financeTypeVersion;
    private long rcVersion;
    private String drAcctSeg;
    private String crAcctSeg;
    private String incomeAcctSeg;
    private String impairmentAccountFlag;
    private String contractImpairmentAccountFlag;
    private String incomeImpairmentSeg;
    private String contractImparimentSeg;
    private String contractLiabilitySeg;
    private List<FinanceTypeFlagDetails> financeTypeFlagDetailsList;

    public SfcSegmentsFlagsVersions(String drAcctFlag, String crAcctFlag, String incomeStmtFlag, String accrualUponBillingFlag, long financeTypeVersion,
            long rcVersion, String drAcctSeg, String crAcctSeg, String incomeAcctSeg, String impairmentAccountFlag, String contractImpairmentAccountFlag,
            String incomeImpairmentSeg, String contractImparimentSeg) {
        this.drAcctFlag = drAcctFlag;
        this.crAcctFlag = crAcctFlag;
        this.incomeStmtFlag = incomeStmtFlag;
        this.accrualUponBillingFlag = accrualUponBillingFlag;
        this.financeTypeVersion = financeTypeVersion;
        this.rcVersion = rcVersion;
        this.drAcctSeg = drAcctSeg;
        this.crAcctSeg = crAcctSeg;
        this.incomeAcctSeg = incomeAcctSeg;
        this.impairmentAccountFlag = impairmentAccountFlag;
        this.contractImpairmentAccountFlag = contractImpairmentAccountFlag;
        this.incomeImpairmentSeg = incomeImpairmentSeg;
        this.contractImparimentSeg = contractImparimentSeg;
    }

    public SfcSegmentsFlagsVersions() {
    }

    public String getDrAcctFlag() {
        return drAcctFlag;
    }

    public void setDrAcctFlag(String drAcctFlag) {
        this.drAcctFlag = drAcctFlag;
    }

    public String getCrAcctFlag() {
        return crAcctFlag;
    }

    public void setCrAcctFlag(String crAcctFlag) {
        this.crAcctFlag = crAcctFlag;
    }

    public String getIncomeStmtFlag() {
        return incomeStmtFlag;
    }

    public void setIncomeStmtFlag(String incomeStmtFlag) {
        this.incomeStmtFlag = incomeStmtFlag;
    }

    public String getAccrualUponBillingFlag() {
        return accrualUponBillingFlag;
    }

    public void setAccrualUponBillingFlag(String accrualUponBillingFlag) {
        this.accrualUponBillingFlag = accrualUponBillingFlag;
    }

    public long getFinanceTypeVersion() {
        return financeTypeVersion;
    }

    public void setFinanceTypeVersion(long financeTypeVersion) {
        this.financeTypeVersion = financeTypeVersion;
    }

    public long getRcVersion() {
        return rcVersion;
    }

    public void setRcVersion(long rcVersion) {
        this.rcVersion = rcVersion;
    }

    public String getDrAcctSeg() {
        return drAcctSeg;
    }

    public void setDrAcctSeg(String drAcctSeg) {
        this.drAcctSeg = drAcctSeg;
    }

    public String getCrAcctSeg() {
        return crAcctSeg;
    }

    public void setCrAcctSeg(String crAcctSeg) {
        this.crAcctSeg = crAcctSeg;
    }

    public String getIncomeAcctSeg() {
        return incomeAcctSeg;
    }

    public void setIncomeAcctSeg(String incomeAcctSeg) {
        this.incomeAcctSeg = incomeAcctSeg;
    }

    public String getImpairmentAccountFlag() {
        return impairmentAccountFlag;
    }

    public void setImpairmentAccountFlag(String impairmentAccountFlag) {
        this.impairmentAccountFlag = impairmentAccountFlag;
    }

    public String getContractImpairmentAccountFlag() {
        return contractImpairmentAccountFlag;
    }

    public void setContractImpairmentAccountFlag(String contractImpairmentAccountFlag) {
        this.contractImpairmentAccountFlag = contractImpairmentAccountFlag;
    }

    public String getIncomeImpairmentSeg() {
        return incomeImpairmentSeg;
    }

    public void setIncomeImpairmentSeg(String incomeImpairmentSeg) {
        this.incomeImpairmentSeg = incomeImpairmentSeg;
    }

    public String getContractImparimentSeg() {
        return contractImparimentSeg;
    }

    public void setContractImparimentSeg(String contractImparimentSeg) {
        this.contractImparimentSeg = contractImparimentSeg;
    }


    public String getContractLiabilitySeg() {
        return contractLiabilitySeg;
    }

    public void setContractLiabilitySeg(String contractLiabilitySeg) {
        this.contractLiabilitySeg = contractLiabilitySeg;
    }

    public List<FinanceTypeFlagDetails> getFinanceTypeFlagDetailsList() {
        return financeTypeFlagDetailsList;
    }

    public void setFinanceTypeFlagDetailsList(List<FinanceTypeFlagDetails> financeTypeFlagDetailsList) {
        this.financeTypeFlagDetailsList = financeTypeFlagDetailsList;
    }
}
