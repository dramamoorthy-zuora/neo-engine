package com.zuora.neo.engine.jobs.transferaccounting.activities.copy;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.config.Properties;
import com.zuora.neo.engine.jobs.transferaccounting.constants.AccountingObjectType;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.AccountSegmentType;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.FxGainLossRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.GlIntRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.GlIntegrationMap;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.AccountingDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.GeneralLedgerDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.FxGainMapper;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.mapper.RowMapper;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@ActivityImplementation
@Component
public class GlCopyRoundActivityImpl implements GlCopyRoundActivity {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(GlCopyRoundActivityImpl.class);
    private static final String glIntStageIdSeq = "RPRO_GL_INT_STAGE_ID_S";

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;
    @Autowired
    Properties properties;

    @Override
    public void copyDataFromTempToStage(ThreadedAccountingResult accountingResult) {
        Long postBatchId = accountingResult.getPostBatchId();
        Jdbi jdbi = DbContext.getConnection();
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();

        jdbi.useHandle(handle -> {
            GeneralLedgerDao ledgerDao = handle.attach(GeneralLedgerDao.class);
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            CommonDao commonDao = handle.attach(CommonDao.class);
            properties.load(commonDao, request.getTenantId());
            String objectType = AccountingObjectType.GENERAL_LEDGER.getObjectTypeType();
            copyTempToStageTable(handle, postBatchId, ledgerDao, objectType, properties, accountingResult);

            objectType = AccountingObjectType.MANUAL_JE.getObjectTypeType();
            copyTempToStageTable(handle, postBatchId, ledgerDao, objectType, properties, accountingResult);

            updateSummaryFlag(accountingDao, properties, postBatchId);

        });
    }

    private void copyTempToStageTable(Handle handle, Long postBatchId, GeneralLedgerDao ledgerDao, String objectType,
            Properties properties, ThreadedAccountingResult accountingResult) {
        List<GlIntegrationMap> glMapList = ledgerDao.getGlIntegrationMap(objectType);
        StringBuilder groupBy = null;
        StringBuilder insertStatement = new StringBuilder("INSERT INTO RPRO_GL_INT_STAGE(OBJECT_TYPE,");
        StringBuilder insertSelectStatement = new StringBuilder("(SELECT OBJECT_TYPE,");
        Boolean isGroupByRequired = false;
        String val;
        String summaryTransfer = properties.getSummaryTransferEnabled() ? "Y" : "N";
        String mjeSummaryTransfer = properties.getMjeSummaryTransferEnabled() ? "Y" : "N";
        boolean customCrField = false;
        boolean customDrField = false;
        if (AccountingObjectType.MANUAL_JE.getObjectTypeType().equals(objectType) && "N".equals(mjeSummaryTransfer)
                || AccountingObjectType.GENERAL_LEDGER.getObjectTypeType().equals(objectType) && "N".equals(summaryTransfer)) {
            insertStatement.append(" TRANS_ID, SCHEDULE_ID, BATCH_ID, CR_DR_FLAG");
            insertSelectStatement.append(" TRANS_ID,SCHEDULE_ID,BATCH_ID, CR_DR_FLAG");
            groupBy = new StringBuilder("OBJECT_TYPE, TRANS_ID, SCHEDULE_ID, BATCH_ID, CR_DR_FLAG");
        } else if (AccountingObjectType.MANUAL_JE.getObjectTypeType().equals(objectType) && "Y".equals(mjeSummaryTransfer)
                || AccountingObjectType.GENERAL_LEDGER.getObjectTypeType().equals(objectType) && "Y".equals(summaryTransfer)) {
            insertStatement.append(" BATCH_ID, CR_DR_FLAG");
            insertSelectStatement.append(" BATCH_ID, CR_DR_FLAG");
            groupBy = new StringBuilder("OBJECT_TYPE, BATCH_ID, CR_DR_FLAG");
        }
        for (GlIntegrationMap glMap : glMapList) {
            if (glMap.getFieldName() != null && glMap.getFieldName().contains("CR") && glMap.getFieldName().contains("AMOUNT")
                    && glMap.getFieldName().indexOf("CR") < glMap.getFieldName().indexOf("AMOUNT")) {
                val = "SUM(" + glMap.getFieldName() + ") ";
            } else if (glMap.getFieldName() != null && glMap.getFieldName().contains("DR") && glMap.getFieldName().contains("AMOUNT")
                    && glMap.getFieldName().indexOf("DR") < glMap.getFieldName().indexOf("AMOUNT")) {
                val = "SUM(" + glMap.getFieldName() + ") ";
            } else if (glMap.getSourceValue() != null && glMap.getSourceValue().equals("CR_LINK_ID")
                    || glMap.getSourceValue() != null && glMap.getSourceValue().equals("DR_LINK_ID")) {
                continue;
            } else {
                val = glMap.getFieldName();
                isGroupByRequired = true;
            }
            if (isGroupByRequired) {
                if (groupBy == null) {
                    groupBy = new StringBuilder(glMap.getFieldName());
                } else {
                    groupBy.append(',').append(glMap.getFieldName());
                }
            }
            if (glMap.getSourceValue() != null && glMap.getSourceValue().equals("CR_LINK_ID")
                    || glMap.getSourceValue() != null && glMap.getSourceValue().equals("DR_LINK_ID")) {
                continue;
            } else {
                insertStatement.append(',').append(glMap.getFieldName());
            }
            if (val != null) {
                insertSelectStatement.append(',').append(val);
            } else {
                if (customCrField || customDrField) {
                    continue;
                }
                insertSelectStatement.append(", NULL");
            }
        }
        for (GlIntegrationMap glMap : glMapList) {
            if (glMap.getSourceValue() != null && glMap.getSourceValue().equals("CR_LINK_ID")) {
                insertStatement.append(',').append(glMap.getFieldName());
                customCrField = true;
            } else if (glMap.getSourceValue() != null && glMap.getSourceValue().equals("DR_LINK_ID")) {
                insertStatement.append(',').append(glMap.getFieldName());
                customDrField = true;
            }
        }
        insertStatement.append(",CR_LINK_ID, DR_LINK_ID) select a.*,");
        if (customCrField) {
            insertStatement.append(" case when CR_DR_FLAG = 'CR' THEN rownum ELSE TO_NUMBER(NULL) END, ");
        }
        if (customDrField) {
            insertStatement.append(" case when CR_DR_FLAG = 'DR' THEN rownum ELSE TO_NUMBER(NULL) END, ");
        }
        insertStatement.append(" case when CR_DR_FLAG = 'CR' THEN rownum ELSE TO_NUMBER(NULL) END, "
                        + "case when CR_DR_FLAG = 'DR' THEN rownum ELSE TO_NUMBER(NULL) END FROM ( ")
                .append(insertSelectStatement).append(" FROM RPRO_GL_INT_STAGE_TEMP WHERE BATCH_ID = ")
                .append(postBatchId).append(" AND object_type = '").append(objectType)
                .append("' GROUP BY ").append(groupBy).append(")) a");

        neoWorkflowLogger.log("Temp table to GL int stage table copy query for : " + objectType + " is: " + insertStatement);
        long startTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        Integer insertCount = handle.createUpdate(insertStatement.toString()).execute();
        long endTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        neoWorkflowLogger.log("Time Taken to copy from temp to gl int stage table for: " + objectType + " is: " + (endTime - startTime));
        LOGGER.info("Rows inserted: " + insertCount);
        neoWorkflowLogger.log("Rows inserted GL table: " + insertCount + " from temp table for: " + objectType);

        doFxRounding(accountingResult, objectType); //FX rounding

        startTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        Integer deleteCount = ledgerDao.deleteTempData(postBatchId,objectType);
        endTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        neoWorkflowLogger.log("Time Taken to delete temp table for: " + objectType + " is: " + (endTime - startTime));
        LOGGER.info("Rows deleted: " + deleteCount);
        neoWorkflowLogger.log("Rows deleted GL table: " + deleteCount + " from temp table for: " + objectType);
    }

    private void doFxRounding(ThreadedAccountingResult accountingResult, String objectType) {
        Long postBatchId = accountingResult.getPostBatchId();
        Jdbi jdbi = DbContext.getConnection();

        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            AccountingDao accountingDao = handle.attach(AccountingDao.class);

            String adjustCrDr = properties.getAdjustCrDrEnabled() ? "Y" : "N";
            if ("Y".equals(adjustCrDr)) {
                try {
                    fxGainLossInTransaction(accountingDao, objectType, handle, postBatchId, commonDao);
                } catch (Exception e) {
                    String errMsg = objectType + " Unbalanced Cr/Dr and FX_GAIN_LOSS to help to provide the details failed";
                    LOGGER.error(errMsg);
                    return;
                }
            }
        });
    }

    /*
        Foreign exchange gain or loss. Most of the customer posts in Transactional currency. However if the customer posts in functional currency
        then there is a chance of imbalance in the amounts.
        As part of Fx gain loss we check Credit and Debit amounts and if there is any delta then create an entry in rpro_gl_int_stage
        for the difference amount as part of the Fx Gain Loss Account.
        FX gain loss account id is 'O' in rpro_acct_type_g
     */
    private void fxGainLossInTransaction(AccountingDao accountingDao, String objectType, Handle handle, Long postBatchId, CommonDao commonDao) {
        try {
            GeneralLedgerDao ledgerDao = handle.attach(GeneralLedgerDao.class);
            String legalEntityAccount = accountingDao.getLegalEntitySegment();
            String accountType = "O";
            String companyAttr = null;
            String accountName = accountingDao.getAccountName(accountType);
            String accountTypeAttr;
            String accountNameAttr;
            String companyCode = null;
            StringBuilder sqlProjection = new StringBuilder("SET_OF_BOOKS_ID, LEDGER_ID, CURRENCY_CODE, PERIOD_NAME, CURRENCY_CONVERSION_DATE");
            StringBuilder sqlStatement = new StringBuilder("SELECT ");
            StringBuilder sqlStatement2 = new StringBuilder("SELECT * FROM rpro_gl_int_stage WHERE object_type = :p_obj_type");
            if (legalEntityAccount != null) {
                companyAttr = ledgerDao.getCompanyAttribute(objectType);
            }
            if (companyAttr != null) {
                sqlProjection.append(',').append(companyAttr);
            }
            accountTypeAttr = ledgerDao.getAccountTypeAttribute(objectType);
            accountNameAttr = ledgerDao.getAccountNameAttribute(objectType);
            sqlStatement.append(sqlProjection).append(" , NVL(SUM(entered_dr) - SUM(entered_cr), 0) ent_dif, "
                    + "NVL(SUM(accounted_dr) - SUM(accounted_cr), 0) acc_dif FROM rpro_gl_int_stage WHERE object_type = :p_obj_type"
                    + " AND batch_id = :p_post_batch_id GROUP BY ").append(sqlProjection).append(" HAVING (NVL(SUM(entered_dr) - SUM(entered_cr), 0) != 0 "
                    + "OR NVL(SUM(accounted_dr) - SUM(accounted_cr), 0) != 0)");
            //fetch the records eligible for fx rounding
            long startTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
            List<FxGainLossRecord> recs = fetchFxGainRecords(handle, sqlStatement.toString(), objectType, postBatchId).get();
            for (FxGainLossRecord rec : recs) {
                sqlStatement2.append(" AND batch_id = :p_post_batch_id AND SET_OF_BOOKS_ID = :l_sob_id AND NVL(LEDGER_ID, 0) = NVL(:l_led_id, 0)"
                        + " AND CURRENCY_CODE = :l_cur_cod AND PERIOD_NAME = :l_per_nam AND NVL(CURRENCY_CONVERSION_DATE,'01-JAN-1900') "
                        + " = NVL(:l_cur_con_dat,'01-JAN-1900')");

                if (companyAttr != null && companyCode != null) {
                    sqlStatement2.append(" AND ").append(companyAttr).append("= '").append(companyCode).append('\'');
                }
                sqlStatement2.append(" AND ROWNUM = 1");

                List<GlIntRecord> glRec = fetchGlIntRecords(handle, sqlStatement2.toString(), rec, objectType, postBatchId).get();
                WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
                Long glIntStageId = commonDao.getNextSequenceNumber(glIntStageIdSeq, request.getClientId());
                //insert an entry for fx gain account if we have records matching rounding issue
                ledgerDao.insertGlIntStage(glIntStageId, rec.getSobId(), glRec.get(0).getAccountingDate(),
                        rec.getCurrencyCode(),glRec.get(0).getCreatedDate(),glRec.get(0).getCreatedBy(),
                        glRec.get(0).getActualFlag(), glRec.get(0).getUserJeCategory(), glRec.get(0).getUserJeSourceName(),
                        rec.getCurrencyConversionDate(), glRec.get(0).getUserCurrencyConvType(), glRec.get(0).getCurrencyConversionRate(),
                        rec.getEntDiffAmount(), rec.getAccDiffAmount(), glRec.get(0).getTransactionDate(),
                        glRec.get(0).getJeBatchId(),rec.getPeriodName(), postBatchId, objectType, glRec.get(0).getLedgerId(),
                        glRec.get(0).getStatus(), glRec.get(0).getSegment1(),
                        glRec.get(0).getSegment2(), glRec.get(0).getSegment3(), glRec.get(0).getSegment4(),
                        glRec.get(0).getSegment5(), glRec.get(0).getSegment6(), glRec.get(0).getSegment7(), glRec.get(0).getSegment8(),
                        glRec.get(0).getSegment9(), glRec.get(0).getSegment10(), glRec.get(0).getSegment11(),glRec.get(0).getSegment12(),
                        glRec.get(0).getSegment13(), glRec.get(0).getSegment14(), glRec.get(0).getSegment15(), glRec.get(0).getSegment16(),
                        glRec.get(0).getSegment17(), glRec.get(0).getSegment18(), glRec.get(0).getSegment19(), glRec.get(0).getSegment20(),
                        glRec.get(0).getSegment21(), glRec.get(0).getSegment22(), glRec.get(0).getSegment23(),glRec.get(0).getSegment24(),
                        glRec.get(0).getSegment25(), glRec.get(0).getSegment26(), glRec.get(0).getSegment27(),
                        glRec.get(0).getSegment28(), glRec.get(0).getSegment29(), glRec.get(0).getSegment30());

                StringBuilder sqlBind = new StringBuilder();
                StringBuilder updateGL = new StringBuilder("UPDATE rpro_gl_int_stage SET ");
                List<AccountSegmentType> segments = accountingDao.getAccountSegmentPerType(accountType, legalEntityAccount);
                for (AccountSegmentType segmentRec : segments) {
                    sqlBind.append(segmentRec.getSegment()).append("='").append(segmentRec.getSourceValue()).append("',");
                }
                if (!segments.isEmpty()) {
                    updateGL.append("RTRIM(").append(sqlBind).append(", ',')");
                }
                if (accountTypeAttr != null) {
                    if (sqlBind.toString().isEmpty()) {
                        updateGL.append(accountTypeAttr).append("='").append(accountType).append('\'');
                    } else {
                        updateGL.append(',').append(accountTypeAttr).append("='").append(accountType).append('\'');
                    }
                }
                if (accountNameAttr != null) {
                    if (sqlBind.toString().isEmpty() && accountTypeAttr == null) {
                        updateGL.append(accountNameAttr).append("='").append(accountName).append('\'');
                    } else {
                        updateGL.append(',').append(accountNameAttr).append("='").append(accountName).append('\'');
                    }
                }
                if (companyAttr != null && companyCode != null) {
                    if (sqlBind.toString().isEmpty() && accountTypeAttr == null && accountNameAttr == null) {
                        updateGL.append(companyAttr).append("='").append(companyCode).append('\'');
                    } else {
                        updateGL.append(',').append(companyAttr).append("='").append(companyCode).append('\'');
                    }
                }
                updateGL.append(" WHERE ID = ").append(glIntStageId);
                neoWorkflowLogger.log("FX gain update query: " + updateGL);
                Integer updateCount = handle.createUpdate(updateGL.toString()).execute();
                long endTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
                neoWorkflowLogger.log("Time Taken to do fx rounding for: " + objectType + " is: " + (endTime - startTime));
                neoWorkflowLogger.log("FX gain update count: " + updateCount);
            }
        } catch (Exception e) {
            String errMsg = "Error - " + e.getMessage();
            LOGGER.error("FX_GAIN_LOSS failed with " + errMsg);
        }
    }

    private Optional<List<FxGainLossRecord>> fetchFxGainRecords(Handle handle, String selectStmt,
            String objectType, Long postBatchId) {
        FxGainMapper mapper = new FxGainMapper();
        neoWorkflowLogger.log("fx gain loss query: " + selectStmt);
        return Optional.ofNullable(handle.createQuery(selectStmt)
                .bind("p_obj_type", objectType)
                .bind("p_post_batch_id", postBatchId)
                .map(mapper).list());
    }

    private Optional<List<GlIntRecord>> fetchGlIntRecords(Handle handle, String selectStmt, FxGainLossRecord rec,
            String objectType, Long postBatchId) {
        RowMapper<GlIntRecord> glIntRecordRowMapperMapper =
                (rs, ctx) -> new GlIntRecord(objectType, postBatchId, rec.getSobId(), rec.getLedgerId(), rec.getCurrencyCode(),
                        rec.getPeriodName(), rec.getCurrencyConversionDate());
        LOGGER.info("fx gain loss GL insert query: " + selectStmt);
        neoWorkflowLogger.log("fx gain loss GL insert query: " + selectStmt);
        return Optional.ofNullable(handle.createQuery(selectStmt)
                .bind("p_obj_type", objectType)
                .bind("p_post_batch_id", postBatchId)
                .bind("l_sob_id", rec.getSobId())
                .bind("l_led_id", rec.getLedgerId())
                .bind("l_cur_cod", rec.getCurrencyCode())
                .bind("l_per_nam", rec.getPeriodName())
                .bind("l_cur_con_dat", rec.getCurrencyConversionDate())
                .map(glIntRecordRowMapperMapper).list());
    }

    private void updateSummaryFlag(AccountingDao accountingDao, Properties properties, Long postBatchId) {
        String summaryTransfer = properties.getSummaryTransferEnabled() ? "Y" : "N";
        String mjeSummaryTransfer = properties.getMjeSummaryTransferEnabled() ? "Y" : "N";
        if ("Y".equals(summaryTransfer) || "Y".equals(mjeSummaryTransfer)) {
            String defaultIndicator = "NNNNNNNNNNNNNNNNNNNN";
            accountingDao.updateHeaderSummaryFlag(defaultIndicator, postBatchId);
        }
    }
}
