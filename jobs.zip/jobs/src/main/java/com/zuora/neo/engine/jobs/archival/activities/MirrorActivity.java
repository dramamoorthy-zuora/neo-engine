package com.zuora.neo.engine.jobs.archival.activities;

import com.zuora.neo.engine.jobs.archival.ArchivalResult;

import io.temporal.activity.ActivityInterface;


/**
 * @author tkrishnakumar
 *
 * Activity which moves the data from Original Schema to Mirrored Schema
 */
@ActivityInterface
public interface MirrorActivity {

    ArchivalResult processArchivalRecords();

}
