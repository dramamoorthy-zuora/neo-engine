package com.zuora.neo.engine.jobs.reporting.activities;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;

public class FetchDataFromDb {

    public AmazonS3 s3() {

        // For local aws use MINIO setup and uncomment these
        // AWSCredentials awsCredentials =
        // new BasicAWSCredentials("admin", "password");
        // String endpoint = "http://127.0.0.1:9001";
        //// val client = AmazonS3ClientBuilder
        //// .standard()
        //// .withCredentials(cred)
        //// .withEndpointConfiguration(
        // // new EndpointConfiguration(
        //// endpoint,
        //// AwsHostNameUtils.parseRegion(endpoint, AmazonS3Client.S3_SERVICE_NAME)
        //// )
        //// )
        //// .build()
        //// .withRegion("ap-south-1")
        // return AmazonS3ClientBuilder
        // .standard()
        // .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
        // .withEndpointConfiguration(new
        // AwsClientBuilder.EndpointConfiguration(endpoint,"abcd"))
        // .build();

        // For Production need to replace these from fileservice billing aws.

        return AmazonS3ClientBuilder.standard()
                .withRegion("us-west-2").build();
    }
}
