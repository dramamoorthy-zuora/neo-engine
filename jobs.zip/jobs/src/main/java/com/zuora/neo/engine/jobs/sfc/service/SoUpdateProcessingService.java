package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.jobs.sfc.constants.SfcStatus;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SchdIndicator;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;

import org.jdbi.v3.core.Handle;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

@Service
public class SoUpdateProcessingService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SoUpdateProcessingService.class);

    @Autowired
    RcScheduleService rcScheduleService;

    @Autowired
    SfcCalcDetailService sfcCalcDetailService;

    @Autowired
    RcLinePaDataService rcLinePaDataService;

    /*
       Service Method to process updated SO line.

       Input :
       rcLinePaDataRecord -> record from rpro_rc_line_pa table
       sfcStatusValue -> Lines from Sfc Status Table
       rcLineDetails -> Rc Line Details for doc line
       vcTypeDetailsList -> Details from vc table
       sfcPaymentDetails -> Payment Details for the line
       openPeriodId -> Open Period Id
       request -> Workflow Request
       rcVersion -> Rc Version
       drAcctSeg -> Debit Account Segment
       crAcctSeg -> Credit Account Segment
       rcScheduleRecordBatch -> Records to be updated to schedule table for entire batch
       sfcCalcDetailsHistoryBatch -> Records to be updated to sfc calc details history table for entire batch
       schdIndicator -> Schedule Table Indicator
       handle -> Jdbi Handle object to perform DB operations

       Output:
       returns the sum of reversed amount.
     */
    public BigDecimal processSfcForUpdatedSoLine(Handle handle, SfcStatusValues sfcStatusValue,
            List<RcLineDetails> rcLineDetails, List<FinanceTypeFlagDetails> financeTypeFlagDetailsList, List<SfcPaymentDetails> sfcPaymentDetailsList,
            long openPeriodId, WorkflowRequest request, long rcVersion, String drAcctSeg, String crAcctSeg, List<RcLinePaData> rcLinePaDataRecord,
            List<RcScheduleRecord> rcScheduleRecordBatch, List<SfcCalcDetails> sfcCalcDetailsHistoryBatch, SchdIndicator schdIndicator) {

        SfcDao sfcDao = handle.attach(SfcDao.class);
        List<RcScheduleRecord> rcScheduleRecordList = getRcScheduleTableRecords(sfcDao, rcLinePaDataRecord.get(0), openPeriodId);
        List<RcScheduleRecord> rcScheduleRecordListNegative = new ArrayList<>();
        SfcPaymentDetails sfcFirstPaymentDetail = sfcPaymentDetailsList.get(0);
        if (sfcStatusValue.getStatus().equals(SfcStatus.SO_UPDATED.getStatus())) {
            sfcStatusValue.setRipDate(sfcFirstPaymentDetail.getPaymtStartDate());
        }
        BigDecimal ripAmount = determineRipAmount(sfcPaymentDetailsList, sfcStatusValue);
        LOGGER.info("Rip Amount determined for PA Line " + rcLinePaDataRecord.get(0).getId() + " is " + ripAmount);
        sfcStatusValue.setRipAmt(ripAmount);
        BigDecimal reversedAmount = BigDecimal.ZERO;
        boolean isCompletelyRipped = false;
        for (RcScheduleRecord rcScheduleRecord : rcScheduleRecordList) {
            BigDecimal negativeInterest = rcScheduleRecord.getAmount().multiply(BigDecimal.valueOf(-1));
            if (reversedAmount.add(rcScheduleRecord.getAmount()).compareTo(ripAmount) > 0) {
                negativeInterest = reversedAmount.subtract(ripAmount);
                reversedAmount = reversedAmount.add(ripAmount.subtract(reversedAmount));
                isCompletelyRipped = true;
            }
            CalendarDetails calendarDetail = new CalendarDetails(rcScheduleRecord.getPeriodId(), null, null, null);
            schdIndicator.setCrAcctgFlag(financeTypeFlagDetailsList.get(0).getIncomeStmtFlag().charAt(0));
            schdIndicator.setDrAcctgFlag(financeTypeFlagDetailsList.get(0).getCrAcctgFlag().charAt(0));
            RcScheduleRecord rcScheduleRecordNegative = rcScheduleService.populateRcScheduleRecord(rcLineDetails, rcLinePaDataRecord, calendarDetail,
                    request, negativeInterest, rcVersion, openPeriodId, drAcctSeg, crAcctSeg, schdIndicator);
            rcScheduleRecordListNegative.add(rcScheduleRecordNegative);
            if (isCompletelyRipped) {
                break;
            }
            reversedAmount = reversedAmount.add(rcScheduleRecord.getAmount());
        }
        rcScheduleRecordBatch.addAll(rcScheduleRecordListNegative);
        /*rcLinePaDataService.updateAmountsToRcLinePaData(handle, rcLinePaDataRecord, rcLineDetails.get(0).getId(),
                vcTypeDetailsList.get(0).getVcTypeId(), rcLinePaDataRecord.get(0).getFncTypeVersion());
         */
        if (!rcLinePaDataRecord.isEmpty() && rcLinePaDataRecord.get(0) != null) {
            BigDecimal updatedRecAmt = rcLinePaDataRecord.get(0).getRecAmt().subtract(ripAmount);
            rcLinePaDataRecord.get(0).setRecAmt(updatedRecAmt);
            rcLinePaDataRecord.get(0).setLineId(rcLineDetails.get(0).getId());
            rcLinePaDataRecord.get(0).setVcTypeId(financeTypeFlagDetailsList.get(0).getVcTypeId());
        }
        return reversedAmount;
    }

    public List<RcScheduleRecord> getRcScheduleTableRecords(SfcDao sfcDao, RcLinePaData rcLinePaData, long openPeriodId) {

        List<RcScheduleRecord> rcScheduleTableRecordsList = sfcDao.cacheRcScheduleTableRecordsByLineId(openPeriodId, rcLinePaData.getId(), openPeriodId);
        return rcScheduleTableRecordsList;
    }

    public BigDecimal determineRipAmount(List<SfcPaymentDetails> sfcPaymentDetailsList, SfcStatusValues sfcStatusValue) {

        Function<SfcPaymentDetails, BigDecimal> paymentAmountMapper = sfcPaymentDetails -> sfcPaymentDetails.getInterestAccrual();
        BigDecimal ripAmount = sfcPaymentDetailsList.stream()
                .filter(sfcPaymentDetail -> sfcPaymentDetail.getPaymtStartDate().compareTo(sfcStatusValue.getRipDate()) >= 0)
                .map(paymentAmountMapper).reduce(BigDecimal.ZERO, BigDecimal::add);
        return ripAmount;
    }
}
