package com.zuora.neo.engine.jobs.sfc.workflow;

import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.workflow.WorkflowInterface;
import io.temporal.workflow.WorkflowMethod;

@WorkflowInterface
public interface SfcWorkflow {

    @WorkflowMethod
    WorkflowResponse processSfc();
}
