package com.zuora.neo.engine.jobs.transferaccounting.common;

public enum ActivityType {
    UPDATE, TRANSFER, VALIDATE
}
