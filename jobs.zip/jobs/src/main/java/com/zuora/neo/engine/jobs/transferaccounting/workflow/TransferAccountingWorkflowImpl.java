package com.zuora.neo.engine.jobs.transferaccounting.workflow;

import com.zuora.neo.engine.annotations.workflow.WorkflowImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.TransferAccountingTestEvaluator;
import com.zuora.neo.engine.jobs.transferaccounting.activities.AccountingActivities;
import com.zuora.neo.engine.jobs.transferaccounting.activities.closeprocess.CloseProcessActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.copy.GlCopyRoundActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.filedownload.DownloadActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.split.SplitActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.stagehandler.StageHandlerActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.support.SupportActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.transfer.TransferActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.update.UpdateActivity;
import com.zuora.neo.engine.jobs.transferaccounting.activities.validation.ValidateActivity;
import com.zuora.neo.engine.jobs.transferaccounting.api.ChunkRecord;
import com.zuora.neo.engine.jobs.transferaccounting.api.ThreadDetails;
import com.zuora.neo.engine.jobs.transferaccounting.common.ThreadExecutor;
import com.zuora.neo.engine.jobs.transferaccounting.common.TransferUtility;
import com.zuora.neo.engine.jobs.transferaccounting.config.ConfigProperties;
import com.zuora.neo.engine.jobs.transferaccounting.constants.StageHandlerType;
import com.zuora.neo.engine.jobs.transferaccounting.constants.TransferStatus;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.workflows.LoggerWorkflowImpl;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.workflow.Workflow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@WorkflowImplementation
public class TransferAccountingWorkflowImpl extends LoggerWorkflowImpl implements TransferAccountingWorkflow {

    private static final String TRANSFER_ERRORS = "Error in Transfer :";
    private static final String NO_DATA = "NO DATA FOUND";
    private static final String BOOK_ERR = "Invalid Book Name";
    private static final String NO_BOOK_DATA = "No Postable Book found";
    private static final String INVALID_PERIOD = "Period is not Opened for the Book";
    private static final String MANY_BOOK_ERR = "Multiple Books found, Please choose a Book to Post";
    private static final String RETRY_TRANSFER_VALIDATE_ERR = "Transfer failed even after max retry, please validate";
    private static final String TRANSFER_ERR = "Transfer failed. Please contact support";
    private static final String UPDATE_ERR = "Update failed. Please contact support";
    private static final String VALIDATION_ERR = "Tansfer Validation Failed!";
    private static final String CRITERIA_NOT_DEFINED = "not defined in the lookup";
    private static final String CRITERIA_ERR = "Batch Criteria Field does not exist in the lookup TRANSFER_BATCH_CRITERIA OR Alias is NULL";
    private static final String INCORRECT_BATCH_SETUP = "Batch criteria setup is incorrect";
    private static final String COPY_ERR = "Copy Activity failed to push data from Temp table to GL stage";
    private final AccountingActivities accountingActivity = Workflow.newActivityStub(AccountingActivities.class);
    private final UpdateActivity updateActivity = Workflow.newActivityStub(UpdateActivity.class);
    private final SplitActivity splitActivity = Workflow.newActivityStub(SplitActivity.class);
    private final TransferActivity transferActivity = Workflow.newActivityStub(TransferActivity.class);
    private final DownloadActivity downloadActivity = Workflow.newActivityStub(DownloadActivity.class);
    private final CloseProcessActivity summaryActivity = Workflow.newActivityStub(CloseProcessActivity.class);
    private final ValidateActivity validateActivity = Workflow.newActivityStub(ValidateActivity.class);
    private final StageHandlerActivity stageHandlerActivity = Workflow.newActivityStub(StageHandlerActivity.class);
    private final GlCopyRoundActivity copyActivity = Workflow.newActivityStub(GlCopyRoundActivity.class);
    private final SupportActivity supportActivity = Workflow.newActivityStub(SupportActivity.class);

    @Autowired
    private ConfigProperties configProperties;

    @Override
    public WorkflowResponse processTransferAccounting() {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        String org = accountingActivity.getOrgId(request);
        ThreadedAccountingResult accountingResult = new ThreadedAccountingResult();
        try {
            ThreadExecutor threadExecutor = new ThreadExecutor(updateActivity, transferActivity, validateActivity);
            accountingResult = accountingActivity.processTransferAccounting(org);
            if (accountingResult.getTransferMessage() != null && accountingResult.getTransferMessage().contains(CRITERIA_NOT_DEFINED)) {
                return new WorkflowResponse(RevenueJobStatus.ERROR, accountingResult.getTransferMessage());
            }
            WorkflowResponse response = supportActivity.checkTransferBatch(accountingResult);
            if (response != null) {
                return response;
            }
            ThreadDetails threadDetails = splitActivity.getThreadDetails(accountingResult, org);
            final Integer totalThreads = threadDetails.getNumThreads();
            List<ChunkRecord> batchIds = threadDetails.getSplitBatchIds();
            if (batchIds.isEmpty()) {
                accountingResult.setTransferStatus(TransferStatus.NO_DATA.getTransferStatus());
                splitActivity.updateTransferStatus(accountingResult);
                return new WorkflowResponse(RevenueJobStatus.WARNING, NO_DATA);
            }
            int maxRetry = configProperties.getMaxRetryCount();
            int count = 0;
            accountingResult.setStageHandlerType(StageHandlerType.BEFORE_UPDATE);
            accountingResult = stageHandlerActivity.executeCustomCodeStageHandler(accountingResult, org);
            response = supportActivity.handleCustomApiErrors(accountingResult);
            if (response != null) {
                splitActivity.updateTransferStatus(accountingResult);
                return response;
            }
            if (totalThreads == 1) {
                accountingResult = TransferUtility.performActivitiesForSingleThread(accountingResult, batchIds, org, stageHandlerActivity, updateActivity,
                        validateActivity, transferActivity, splitActivity);
                response = supportActivity.handleIncorrectBatchSetup(accountingResult); //update related incorrect setup errors
                if (response != null) {
                    return response;
                } //custom api related errors
                response = supportActivity.handleCustomApiErrors(accountingResult);
                if (response != null) {
                    splitActivity.updateTransferStatus(accountingResult);
                    return response;
                }
            } else {
                accountingResult = TransferUtility.performActivitiesForMultipleThread(accountingResult, batchIds, org, count, maxRetry, threadExecutor,
                        totalThreads, transferActivity, splitActivity, stageHandlerActivity, updateActivity);
                //update related incorrect setup errors
                response = supportActivity.handleIncorrectBatchSetup(accountingResult);
                if (response != null) {
                    return response;
                }
                //custom api related errors
                response = supportActivity.handleCustomApiErrors(accountingResult);
                if (response != null) {
                    splitActivity.updateTransferStatus(accountingResult);
                    return response;
                }
            }
            if (!batchIds.isEmpty()) { //since we need 1 single outfile below activities needs to be done by the main thread without parallelism and chunk
                accountingResult = TransferUtility.performAfterPostActivities(accountingResult, org, stageHandlerActivity, splitActivity,
                        copyActivity, downloadActivity, summaryActivity, supportActivity);
                if (accountingResult.getTransferMessage() != null && accountingResult.getTransferMessage().contains(COPY_ERR)) {
                    return new WorkflowResponse(RevenueJobStatus.ERROR, COPY_ERR);
                }
                response = supportActivity.handleCustomApiErrors(accountingResult);
                if (response != null) {
                    splitActivity.updateTransferStatus(accountingResult);
                    return response;
                }
            }
        } catch (Exception e) {
            String errMsg = "Error occurred, Please check the Temporal logs for more details: "
                    + (e.getCause() != null ? e.getCause().getMessage() : e.getCause());
            WorkflowResponse response = handleException(e, accountingResult);
            if (response != null) {
                return response;
            }
            if (e.getCause() != null && e.getCause().getMessage().contains(TRANSFER_ERRORS)) { //Transfer activity related exceptions
                response = handleTransferError(accountingResult,org,e.getCause().getMessage());
                if (response == null) {
                    accountingResult = TransferUtility.performAfterPostActivities(accountingResult, org, stageHandlerActivity, splitActivity,
                            copyActivity, downloadActivity, summaryActivity, supportActivity);
                    response = supportActivity.handleCustomApiErrors(accountingResult);
                    if (response != null) {
                        splitActivity.updateTransferStatus(accountingResult);
                        return response;
                    }
                } else {
                    return response;
                }
            }
            return new WorkflowResponse(RevenueJobStatus.ERROR, errMsg); //for all other errors
        } finally {
            accountingActivity.cleanupActivities(org, request);
        }
        return new WorkflowResponse(RevenueJobStatus.COMPLETED, "");
    }

    WorkflowResponse handleTransferError(ThreadedAccountingResult accountingResult, String org, String errorMsg) {
        accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
        //if we fail at the transfer step retry only failed chunks
        int maxRetry = TransferAccountingTestEvaluator.multiThreadSetup() ? configProperties.getMaxRetryTestCount()
                : configProperties.getMaxRetryCount();
        if (configProperties.isRetryEnable()) {
            try {
                TransferUtility.retryTransfer(accountingResult, org, maxRetry, splitActivity, transferActivity);
            } catch (Exception e) {
                if (e.getMessage() != null && e.getMessage().contains(RETRY_TRANSFER_VALIDATE_ERR)) {
                    splitActivity.updateTransferStatus(accountingResult);
                    return new WorkflowResponse(RevenueJobStatus.ERROR, TRANSFER_ERR);
                }
            }
        } else {
            accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
            String[] errMsg = errorMsg.split("type");
            String[] msg = errMsg[0].split("=");
            accountingResult.setTransferMessage(msg[1] + " '");
            splitActivity.updateTransferStatus(accountingResult);
            splitActivity.insertTransferError(accountingResult, org, msg[1] + " '");
            return new WorkflowResponse(RevenueJobStatus.ERROR, TRANSFER_ERR);
        }
        return null;
    }

    WorkflowResponse handleException(Exception e, ThreadedAccountingResult accountingResult) {
        if (e.getCause() != null && e.getCause().getMessage().contains(BOOK_ERR)) {
            return new WorkflowResponse(RevenueJobStatus.ERROR, BOOK_ERR);
        }
        if (e.getCause() != null && e.getCause().getMessage().contains(NO_BOOK_DATA)) {
            return new WorkflowResponse(RevenueJobStatus.ERROR, NO_BOOK_DATA);
        }
        if (e.getCause() != null && e.getCause().getMessage().contains(MANY_BOOK_ERR)) {
            return new WorkflowResponse(RevenueJobStatus.ERROR, MANY_BOOK_ERR);
        }
        if (e.getCause() != null && e.getCause().getMessage().contains(INVALID_PERIOD)) {
            return new WorkflowResponse(RevenueJobStatus.ERROR, e.getCause().getMessage());
        }
        if (e.getCause() != null && e.getCause().getMessage().contains(UPDATE_ERR)) {
            return new WorkflowResponse(RevenueJobStatus.ERROR, UPDATE_ERR);
        }
        if (e.getCause() != null && e.getCause().getMessage().contains(VALIDATION_ERR)) {
            return new WorkflowResponse(RevenueJobStatus.ERROR, "Error: In Update for Batch ID: "
                    + accountingResult.getPostBatchId() + ". ERROR: " + VALIDATION_ERR);
        }
        if (e.getCause() != null && e.getCause().getMessage().contains(CRITERIA_ERR)) {
            return new WorkflowResponse(RevenueJobStatus.ERROR, "Error: In Update for Batch ID: "
                    + accountingResult.getPostBatchId() + ". ERROR: " + CRITERIA_ERR);
        }
        if (e.getCause() != null && e.getCause().getMessage().contains(INCORRECT_BATCH_SETUP)) {
            return new WorkflowResponse(RevenueJobStatus.ERROR, "Error: In Update for Batch ID: "
                    + accountingResult.getPostBatchId() + ". ERROR: " + INCORRECT_BATCH_SETUP);
        }
        return null;
    }

}
