package com.zuora.neo.engine.jobs.caclnetting.service;

import com.zuora.neo.engine.jobs.caclnetting.config.CaclProperties;
import com.zuora.neo.engine.jobs.caclnetting.db.dao.CaclNettingDao;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class CarryForwardService {

    final CaclProperties caclProperties;
    final NeoWorkflowLogger neoWorkflowLogger;
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CarryForwardService.class);

    public CarryForwardService(CaclProperties caclProperties, NeoWorkflowLogger neoWorkflowLogger) {
        this.caclProperties = caclProperties;
        this.neoWorkflowLogger = neoWorkflowLogger;
    }

    public int carryForwardEntries(CaclNettingDao nettingDao, BigDecimal batchId) {
        long prdId = caclProperties.getPeriodDetails().getCurrentPeriodId();
        long prevPrdId = caclProperties.getPeriodDetails().getPreviousPeriodId();
        Long prevNettingPeriodId = caclProperties.getPrevNettingPeriodId();

        int carryForwardCount = nettingDao.insertCarryForwardEntries(prdId, prevPrdId, prevNettingPeriodId, batchId,
                caclProperties.getUser(), caclProperties.getCaclNetRc(),
                caclProperties.getHeadPeriod(), caclProperties.getBookId(), caclProperties.getClientId(), caclProperties.getOrgId());

        LOGGER.info("Picked {} carry forward entries", carryForwardCount);
        neoWorkflowLogger.log("Picked " + carryForwardCount + " carry forward entries");

        return carryForwardCount;
    }

}
