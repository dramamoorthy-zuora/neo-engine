package com.zuora.neo.engine.jobs.archival.db.model;

import lombok.Data;

@Data
public class ArchivalSettingsEntity {
    private int batchSize = 1000;
    private int fetchSize = 100;
    private int keepMonthsOfData = 24;
    private int successiveBatchUpdateFailureThreshold = 3;
    private double maxFailureAttemptsInPercentage = 0.5;
    private boolean logQuery = false;
}
