package com.zuora.neo.engine.jobs.rtp.constants;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum RtpWiStatus {

    NEW("NEW"),
    IN_PROGRESS("IN PROGRESS"),
    SKIPPED("SKIPPED"),
    ERROR("ERROR"),
    COMPLETED("COMPLETED");

    private final String status;

    RtpWiStatus(String status) {
        this.status = status;
    }

    @JsonValue
    public String getStatus() {
        return status;
    }

    private static final Map<String, RtpWiStatus> LOOKUP =
            Arrays.stream(RtpWiStatus.values()).collect(
                    Collectors.toMap(RtpWiStatus::getStatus, Function.identity()));

    @JsonCreator
    public static RtpWiStatus fromHeaderStatus(String status) {
        return LOOKUP.get(status);
    }
}
