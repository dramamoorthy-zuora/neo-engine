package com.zuora.neo.engine.jobs.internal.workflow;

import com.zuora.neo.engine.temporal.workflows.BaseWorkflow;

import io.temporal.workflow.WorkflowInterface;

@WorkflowInterface
public interface NovaInternalWorkflow extends BaseWorkflow {
}
