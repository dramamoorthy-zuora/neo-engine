package com.zuora.neo.engine.jobs.rtp.service;

import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.rtp.config.RtpProperties;
import com.zuora.neo.engine.jobs.rtp.constants.RtpConstants;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import com.google.common.annotations.VisibleForTesting;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RtpInitializerService {

    @Autowired
    RtpProperties rtpProperties;

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;

    @VisibleForTesting
    void validate() {
        if (!rtpProperties.isRtpEnabled()) {
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.COMPLETED, RtpConstants.RTP_DISABLED);
        }
    }

    public void initialize(CommonDao commonDao) {
        rtpProperties.load(commonDao);
        neoWorkflowLogger.log(rtpProperties.toString());
        validate();
    }
}
