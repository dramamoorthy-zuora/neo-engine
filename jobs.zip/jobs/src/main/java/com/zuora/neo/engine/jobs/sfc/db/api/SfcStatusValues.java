package com.zuora.neo.engine.jobs.sfc.db.api;

import java.math.BigDecimal;
import java.util.Date;

public class SfcStatusValues {

    private String docNum;
    private String docLineId;
    private String status;
    private long rcId;
    private long lineId;
    private BigDecimal netNpvAmt;
    private BigDecimal netInterestAccrual;
    private Date ripDate;
    private String errMsg;
    private BigDecimal ripAmt;
    private String indicators;

    public SfcStatusValues(String docNum, String docLineId, String status, long rcId, long lineId, BigDecimal netNpvAmt, BigDecimal netInterestAccrual,
            Date ripDate, String errMsg, BigDecimal ripAmt, String indicators) {
        this.docNum = docNum;
        this.docLineId = docLineId;
        this.status = status;
        this.rcId = rcId;
        this.lineId = lineId;
        this.netNpvAmt = netNpvAmt;
        this.netInterestAccrual = netInterestAccrual;
        this.ripDate = ripDate == null ? null : new Date(ripDate.getTime());
        this.errMsg = errMsg;
        this.ripAmt = ripAmt;
        this.indicators = indicators;
    }

    public SfcStatusValues() {

    }


    public String getDocNum() {
        return docNum;
    }

    public void setDocNum(String docNum) {
        this.docNum = docNum;
    }

    public String getDocLineId() {
        return docLineId;
    }

    public void setDocLineId(String docLineId) {
        this.docLineId = docLineId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getRcId() {
        return rcId;
    }

    public void setRcId(long rcId) {
        this.rcId = rcId;
    }

    public long getLineId() {
        return lineId;
    }

    public void setLineId(long lineId) {
        this.lineId = lineId;
    }

    public BigDecimal getNetNpvAmt() {
        return netNpvAmt;
    }

    public void setNetNpvAmt(BigDecimal netNpvAmt) {
        this.netNpvAmt = netNpvAmt;
    }

    public BigDecimal getNetInterestAccrual() {
        return netInterestAccrual;
    }

    public void setNetInterestAccrual(BigDecimal netInterestAccrual) {
        this.netInterestAccrual = netInterestAccrual;
    }

    public Date getRipDate() {
        return ripDate == null ? null : new Date(ripDate.getTime());
    }

    public void setRipDate(Date ripDate) {
        this.ripDate = ripDate == null ? null : new Date(ripDate.getTime());
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

    public BigDecimal getRipAmt() {
        return ripAmt;
    }

    public void setRipAmt(BigDecimal ripAmt) {
        this.ripAmt = ripAmt;
    }

    public String getIndicators() {
        return indicators;
    }

    public void setIndicators(String indicators) {
        this.indicators = indicators;
    }

    @Override
    public String toString() {
        return "SfcStatusValues{"
                + "docNum='" + docNum + '\''
                + ", docLineId='" + docLineId + '\''
                + ", status='" + status + '\''
                + ", rcId=" + rcId
                + ", lineId=" + lineId
                + ", netNpvAmt=" + netNpvAmt
                + ", netInterestAccrual=" + netInterestAccrual
                + '}';
    }
}
