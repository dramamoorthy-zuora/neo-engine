package com.zuora.neo.engine.jobs.archival.db.dao;

import com.zuora.neo.engine.jobs.archival.db.mapper.DataArchivalTableMapper;
import com.zuora.neo.engine.jobs.archival.db.model.DataArchivalTable;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlCall;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.statement.UseRowMapper;

import java.util.List;

/**
 * @author tkrishnakumar
 */
public interface DataArchivableTablesDao {

    @SqlQuery("select a.* from rpro_da_archive_g a where archivable='Y'  order by order_by desc")
    @UseRowMapper(DataArchivalTableMapper.class)
    List<DataArchivalTable> getArchivalTableList();


    @SqlQuery("select sys_context( 'userenv', 'current_schema' ) from dual")
    String getSchemaName();

    @SqlCall("{CALL rpro_da_archive_pkg.populate_copy_query}")
    void updateCopyQuery();

    @SqlUpdate("Insert into rpro_da_map_g\n"
            + " SELECT DISTINCT a.rc_id,\n"
            + " a.doc_num      so_num,\n"
            + " a.doc_line_num so_line_num,\n"
            + " b.doc_num      inv_num,\n"
            + " b.doc_line_num  inv_line_num,\n"
            + " a.doc_line_id  so_line_id,\n"
            + " a.sec_atr_val sec_atr_val\n"
            + " from rpro_rc_line_g a ,\n"
            + " rpro_rc_bill_g b\n"
            + " where a.rc_id = b.rc_id(+)\n"
            + " and a.id =b.line_id(+) \n"
            + "and a.rc_id in (<rcIds>)")
    int insertRcMapping(@BindList("rcIds")List rcIds);

    @SqlQuery("select RC_ID from rpro_da_head_g where PROCESSED_FLAG = :processedFlag and id = :batchId fetch first :batchSize rows only")
    List<Long> getExpiredRcs(@Bind("batchSize") Integer batchSize, @Bind("batchId") long batchId, @Bind("processedFlag") String processedFlag);

    @SqlUpdate("update rpro_da_head_g set processed_flag = :processFlag where rc_id in (<rcIds>)")
    int updateCopyAndDeleteStatus(@Bind("processFlag")String processFlag, @BindList("rcIds")List rcIds);

    @SqlUpdate("INSERT INTO rpro_da_head_g \n"
            + "    (SELECT :id, rh.id RC_ID,'N',sysdate,sysdate,:userName,:userName\n"
            + "       FROM rpro_rc_head_g rh , rpro_calendar_g rc\n"
            + "      WHERE 1=1\n"
            + "        AND rc.id = :currentOpenPeriodId\n"
            + "        AND rh.init_pob_exp_dt <  rc.start_date\n"
            + "        AND rh.id > 0\n"
            + "        AND MONTHS_BETWEEN( rc.start_date,rh.init_pob_exp_dt)>:keepMonthOfData\n"
            + "        AND NOT EXISTS (SELECT 1 \n"
            + "                          FROM rpro_rc_line_g rl \n"
            + "                         WHERE rh.id =rl.rc_id \n"
            + "                           AND (Def_amt <> 0 \n"
            + "                                 OR Bld_def_amt <>0\n"
            + "                                 OR (ext_sll_prc= 0 \n"
            + "                                      AND NVL(cum_cv_amt,0) <>0 \n"
            + "                                      AND rel_pct <>100) \n"
            + "                                 OR NOT EXISTS (SELECT 1 \n"
            + "                                                  FROM  rpro_calendar_g rc1 \n"
            + "                                                 WHERE rc1.id = nvl((SELECT max(prd_id)  \n"
            + "                                                                       FROM rpro_rc_schd_g rs \n"
            + "                                                                      WHERE rl.id = rs.root_line_id), :minOfClosedPrdId) \n"
            + "                                                   AND MONTHS_BETWEEN( rc.start_date,rc1.start_date)>:keepMonthOfData  \n"
            + "                                                  )\n"
            + "                                   )\n"
            + "                           )\n"
            + "     )")
    int insertHeadGDetails(@Bind("id")long id,
                           @Bind("userName")String userName,
                           @Bind("keepMonthOfData")int keepMonthOfData,
                           @Bind("currentOpenPeriodId")int currentOpenPeriodId,
                           @Bind("minOfClosedPrdId")int minOfClosedPrdId);

    @SqlUpdate("DELETE FROM rpro_da_head_g where processed_flag = 'N'")
    int clearUnProcessedEntriesFromPreviousBatch();

    @SqlQuery("  SELECT Min(a.id) prd_id \n"
            + "   FROM rpro_period_g a, rpro_book_g b\n"
            + "  WHERE a.book_id = b.id \n"
            + "    AND rpro_book_pkg.get_enabled_flag(b.indicators)='Y'")
    int getCurrentOpenPrdId();

    @SqlQuery("  SELECT Min(id) prd_id \n"
            + "    FROM rpro_period_h_g")
    int getMinOfClosedPrdId();

    @SqlQuery("select NVL (rpro_utility_pkg.get_profile (:profileKey), :defaultValue) from dual ")
    String checkArchivalEnabled(@Bind("profileKey") String profileKey, @Bind("defaultValue") String defaultValue);

    @SqlUpdate("INSERT INTO RPRO_DA_HEAD_G(ID, RC_ID, PROCESSED_FLAG, CREATED_DATE, UPDATED_DATE, CREATED_BY, UPDATED_BY) VALUES "
            + "(:batchId, :rcId, 'T', SYSDATE, SYSDATE, :userName, :userName)")
    int insertHeadGDetailsRecovery(@Bind("batchId")long batchId, @Bind("rcId")Long rcId, @Bind("userName")String userName);

    @SqlQuery("select RC_ID from rpro_da_head_g where PROCESSED_FLAG = :processedFlag and id = :batchId fetch first :batchSize rows only")
    List<Long> fetchRecoverableRcs(@Bind("batchSize") Integer batchSize, @Bind("batchId") long batchId, @Bind("processedFlag") String processedFlag);

    @SqlUpdate("DELETE FROM RPRO_DA_MAP_G WHERE RC_ID IN (<rcIds>)")
    int deleteRcMapping(@BindList("rcIds")List rcIds);

    @SqlUpdate("UPDATE RPRO_DA_HEAD_G SET ID = :requestId WHERE PROCESSED_FLAG='T'")
    void updateIdOfInsertedRCs(@Bind("requestId")long requestId);

    @SqlUpdate("update rpro_da_head_g set processed_flag = :processFlag where rc_id in (<rcIds>) and processed_flag = 'T'")
    int updateRecoveryStatus(@Bind("processFlag")String processFlag, @BindList("rcIds")List rcIds);
}
