package com.zuora.neo.engine.jobs.transferaccounting.db.api;

public class BatchCriteria {

    private Long postBatchId;
    private String fieldName;
    private String operator;
    private String operand;
    private Long criteriaId;
    private String alias;
    private String fieldValue;

    public BatchCriteria(Long postBatchId, String fieldName, String operator, String operand, Long criteriaId, String alias, String fieldValue) {
        this.postBatchId = postBatchId;
        this.fieldName = fieldName;
        this.operator = operator;
        this.operand = operand;
        this.criteriaId = criteriaId;
        this.alias = alias;
        this.fieldValue = fieldValue;
    }

    public Long getPostBatchId() {
        return postBatchId;
    }

    public String getFieldName() {
        return fieldName;
    }

    public String getOperator() {
        return operator;
    }

    public String getOperand() {
        return operand;
    }

    public Long getCriteriaId() {
        return criteriaId;
    }

    public String getAlias() {
        return alias;
    }

    public String getFieldValue() {
        return fieldValue;
    }
}
