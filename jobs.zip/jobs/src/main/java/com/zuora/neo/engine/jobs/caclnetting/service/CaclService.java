package com.zuora.neo.engine.jobs.caclnetting.service;

import com.zuora.neo.engine.common.AccountTypes;
import com.zuora.neo.engine.common.ScheduleTypes;
import com.zuora.neo.engine.common.util.CommonUtils;
import com.zuora.neo.engine.db.api.PeriodDetails;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.caclnetting.config.CaclProperties;
import com.zuora.neo.engine.jobs.caclnetting.constants.CaclConstants;
import com.zuora.neo.engine.jobs.caclnetting.constants.NettingReversalFlags;
import com.zuora.neo.engine.jobs.caclnetting.db.dao.CaclNettingDao;
import com.zuora.neo.engine.jobs.rtp.constants.RtpWiHeaderStatus;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;
import com.zuora.neo.engine.test.NeoTestContext;

import com.google.common.annotations.VisibleForTesting;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;

@Service
public class CaclService {

    final NeoWorkflowLogger neoWorkflowLogger;

    final CaclProperties caclProperties;
    final CleanupService cleanupService;
    final CarryForwardService carryForwardService;

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CaclService.class);

    public CaclService(NeoWorkflowLogger neoWorkflowLogger, CaclProperties caclProperties,
                       CleanupService cleanupService, CarryForwardService carryForwardService) {
        this.neoWorkflowLogger = neoWorkflowLogger;
        this.caclProperties = caclProperties;
        this.cleanupService = cleanupService;
        this.carryForwardService = carryForwardService;
    }

    /**
     * At this point, we have data in RPRO_CACL_NET_RC (RC's to be picked for netting process)
     * The core logic starts below and returns the total number of RC's processed
     */
    public int performNettingService(CaclNettingDao nettingDao, CommonDao commonDao, BigDecimal batchId, Long bookId,
                                     String createLineLevel, String user, long clientId, String orgId) {

        String reportingCurrency = commonDao.getProfileValue("REPORTING_CURRENCY", "USD");

        long prdId = caclProperties.getPeriodDetails().getCurrentPeriodId();
        long prevPrdId = caclProperties.getPeriodDetails().getPreviousPeriodId();
        long nextPeriodId = caclProperties.getPeriodDetails().getNextPeriodId();
        Long prevNettingPeriodId = caclProperties.getPrevNettingPeriodId();

        int intermediateEntriesCount = nettingDao.insertIntoIntermediateTable(prdId, prevPrdId, prevNettingPeriodId,
                AccountTypes.LIABILITY_ID.getAccountType(), AccountTypes.ASSETS_ID.getAccountType(),
                AccountTypes.INTER_COMP.getAccountType(), ScheduleTypes.ALLOCATION.getScheduleType(),
                ScheduleTypes.MJE.getScheduleType(), AccountTypes.ADJUSTMENT_LIABILITY.getAccountType(),
                ScheduleTypes.NETTING.getScheduleType(), ScheduleTypes.VARIABLE_CONSIDERATION.getScheduleType(),
                caclProperties.getSchdTypes(), batchId, reportingCurrency,
                user, caclProperties.getCaclNetRc(), caclProperties.getHeadPeriod(),
                caclProperties.getBookId(), caclProperties.getClientId(), caclProperties.getOrgId());

        LOGGER.info("Inserted {} to intermediate table", intermediateEntriesCount);

        /*
            this adds the current period amounts with the prior period amounts if they already exist (delta calculation)
            also, if we have prior period entry and no entry in current period, we carry forward that entry to the current period
         */
        int updateCount = nettingDao.updateWithPriorPeriodAmounts(prdId, prevPrdId, prevNettingPeriodId,
                batchId, user, caclProperties.getCaclNetRc(),
                bookId, clientId, orgId);

        LOGGER.info("Updated {} prior period entries", updateCount);

        LocalDate endDate = LocalDate.of(2040, 12, 12);

        LocalDate startDate = CommonUtils.toLocalDate(commonDao.getPeriodDetailsById(prdId).get(0).getStartDate());

        int nettingEntriesCount = nettingDao.insertNettingHeader(user, prdId, startDate, endDate, batchId,
                CaclConstants.HEAD_PERIOD_DEFAULT_INDICATOR,
                caclProperties.getCaclNetRc(), caclProperties.getHeadPeriod(), caclProperties.getHeadPeriodSequence(),
                caclProperties.getBookId(), caclProperties.getClientId(), caclProperties.getOrgId());

        LOGGER.info("Created {} netting header entries", nettingEntriesCount);

        nettingDao.updateHeaderCaBalFlag(user, prdId, caclProperties.getCaclNetRc(), caclProperties.getHeadPeriod(),
                caclProperties.getBookId(), caclProperties.getClientId(), caclProperties.getOrgId());

        if (CommonUtils.isProfileEnabled(createLineLevel)) {

            String commonsFlags = "SCHD_TYPE:" + ScheduleTypes.NETTING.getScheduleType()
                    + "#DR_ACCTG:" + AccountTypes.ASSETS_ID.getAccountType()
                    + "#UPDATE_OR_INSERT:N#UNBILLED:N";

            String setNettingReversalFlag = "REVERSAL:" + NettingReversalFlags.REVERSAL.getFlag();

            int nettingSchedulesCount = nettingDao.insertNettingSchedules(batchId, user, prdId, nextPeriodId,
                    AccountTypes.ASSETS_ID.getAccountType(), ScheduleTypes.NETTING.getScheduleType(),
                    AccountTypes.LIABILITY_ID.getAccountType(), AccountTypes.ADJUSTMENT_LIABILITY.getAccountType(),
                    ScheduleTypes.REVENUE.getScheduleType(),
                    CaclConstants.SCHEDULES_DEFAULT_INDICATOR, commonsFlags, setNettingReversalFlag,
                    caclProperties.getCaclNetRc(), caclProperties.getHeadPeriod(), caclProperties.getScheduleTable(),
                    caclProperties.getScheduleSequence(), caclProperties.getBookId(),
                    caclProperties.getClientId(), caclProperties.getOrgId());

            LOGGER.info("Created {} netting schedules", nettingSchedulesCount);
        }

        int rcProcessedCount = nettingDao.updateRcStatusToComplete(batchId, caclProperties.getCaclNetRc(),
                caclProperties.getBookId(), caclProperties.getClientId(), caclProperties.getOrgId());

        cleanupService.deleteNetRc(nettingDao, batchId);

        LOGGER.info("Processed {} RCs", rcProcessedCount);

        return rcProcessedCount;
    }

    /**
     * Inserts the eligible RCs for CA/CL netting, accepts null for irrelevant parameters depending on rtpProcess value
     * Returns the number of RCs inserted
     */
    public int insertNettingRc(CaclNettingDao nettingDao, BigDecimal batchId,
                        Long rcId, String fullRefresh,
                        boolean rtpProcess) {
        int totalRowsInserted = 0;
        if (rtpProcess) {
            totalRowsInserted += nettingDao.populateRealtimeNettingRc(caclProperties.getPeriodDetails().getCurrentPeriodId(),
                    caclProperties.getPrevNettingPeriodId(),
                    batchId, RtpWiHeaderStatus.IN_PROGRESS.getHeaderStatus(),
                    caclProperties.getCaclNetRc(), caclProperties.getHeadPeriod());
        } else {
            totalRowsInserted += pickRcToProcess(nettingDao, rcId, fullRefresh, batchId);
        }
        LOGGER.info("Initial pick - {} RCs", totalRowsInserted);

        if (totalRowsInserted > 0) {
            cleanupService.cleanCurrentPeriodData(nettingDao, batchId);
        }

        if (!rtpProcess || NeoTestContext.isIntegrationTesting()) {
            totalRowsInserted += carryForwardService.carryForwardEntries(nettingDao, batchId);

            LOGGER.info(totalRowsInserted + " RCs picked || batch id - " + batchId);
        }

        return totalRowsInserted;
    }

    @VisibleForTesting
    long pickRcToProcess(CaclNettingDao nettingDao, Long rcId, String fullRefresh, BigDecimal batchId) {
        long clientId = caclProperties.getClientId();
        long bookId = caclProperties.getBookId();
        String orgId = caclProperties.getOrgId();

        PeriodDetails periodDetails = caclProperties.getPeriodDetails();

        LOGGER.info("Shadow mode: {}", caclProperties.isShadowMode());

        int totalRowsInserted = 0;

        long currentPeriodId = periodDetails.getCurrentPeriodId();

        if (rcId != null) {
            /* rcId parameter passed */
            int rcIdExists = nettingDao.getRcId(rcId);
            if (rcIdExists != 1) {
                NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, "ERROR: Invalid RC ID");
            }
            LOGGER.info("Processing RC - {}", rcId);
            totalRowsInserted = nettingDao.insertNettingRcForGivenRc(rcId, currentPeriodId, caclProperties.getPrevNettingPeriodId(), batchId,
                    caclProperties.getCaclNetRc(), caclProperties.getHeadPeriod(),
                    bookId, clientId, orgId);
        } else {
            /*
             * Process for all RC's eligible in the given input
             * */
            totalRowsInserted = nettingDao.insertRcForCurrentPeriod(caclProperties.getSchdTypes(), currentPeriodId,
                    caclProperties.getPrevNettingPeriodId(),
                    batchId, ScheduleTypes.NETTING.getScheduleType(), caclProperties.getCaclNetRc(), caclProperties.getHeadPeriod(),
                    fullRefresh, bookId, clientId, orgId);
        }

        return totalRowsInserted;
    }



}
