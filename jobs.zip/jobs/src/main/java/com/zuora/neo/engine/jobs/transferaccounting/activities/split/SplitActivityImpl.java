package com.zuora.neo.engine.jobs.transferaccounting.activities.split;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.api.BatchCriteriaCondition;
import com.zuora.neo.engine.jobs.transferaccounting.api.ChunkRecord;
import com.zuora.neo.engine.jobs.transferaccounting.api.ThreadDetails;
import com.zuora.neo.engine.jobs.transferaccounting.common.AccountingQuery;
import com.zuora.neo.engine.jobs.transferaccounting.config.Properties;
import com.zuora.neo.engine.jobs.transferaccounting.constants.TransferStatus;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.BatchCriteria;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.ChunkStatus;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.SplitBatchRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.AccountingDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.CriteriaLookupDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.ErrorDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.SplitDao;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.jdbi.v3.core.Jdbi;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

@ActivityImplementation
@Component
public class SplitActivityImpl implements SplitActivity {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SplitActivityImpl.class);
    private static final String CRITERIA_ERR = "Batch Criteria Field does not exist in the lookup TRANSFER_BATCH_CRITERIA OR Alias is NULL";
    private static final String INCORRECT_BATCH_SETUP = "Batch criteria setup is incorrect.";
    private static final String SPLIT_ACTIVITY_ERROR = "Error in Update : ";
    private static final String postBatchIdSeq = "RPRO_ACCT_XFER_ID_S";
    private static final String splitType = "RC_ID";
    private static final String batchType = "TRANSFER";

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;
    @Autowired
    Properties properties;

    @Override
    public ThreadDetails getThreadDetails(ThreadedAccountingResult accountingResult, String orgId) {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Long postBatchId = accountingResult.getPostBatchId();
        Long bookId = accountingResult.getBookId();
        Jdbi jdbi = DbContext.getConnection();
        final Integer[] numThreads = new Integer[1];
        AtomicReference<List<SplitBatchRecord>> batches = new AtomicReference<>(new ArrayList<>());

        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            SplitDao splitDao = handle.attach(SplitDao.class);
            ErrorDao errorDao = handle.attach(ErrorDao.class);
            properties.load(commonDao, request.getTenantId());
            CriteriaLookupDao criteriaLookupDao = handle.attach(CriteriaLookupDao.class);
            Long splitBatchSize = properties.getSplitBatchSize();

            archiveBatch(splitDao, splitType, batchType, request, orgId);

            String criteria = getCriteriaForBatchSelect(accountingResult, criteriaLookupDao, commonDao, errorDao, request, orgId);
            String[] criterias = criteria.split("~");
            String regSchdCondition = criterias[0];
            String mjeCondition = criterias[1];
            LOGGER.info("orgId: " + orgId);
            neoWorkflowLogger.log("regSchdCondition: " + regSchdCondition);
            neoWorkflowLogger.log("mjeCondition: " + mjeCondition);

            String insertStmt = "INSERT INTO rpro_batch_split( batch_id,type,batch_type,book_id,chunk_id"
                    + " ,min_value,max_value,processed,start_date,sec_atr_val,client_id)"
                    + " SELECT :postBatchId, 'RC_ID', 'TRANSFER', book_id, chunk_id, MIN(rc_id) min_grp_by_val"
                    + " ,MAX(rc_id) max_grp_by_val, 'N', NULL, :orgId, :clientId FROM (SELECT book_id, rc_id,"
                    + " CEIL(cumm_sum / :l_split_size) chunk_id FROM (SELECT book_id, rc_id"
                    + " ,SUM(cnt) OVER(ORDER BY rc_id) cumm_sum FROM (SELECT book_id, rc_id, COUNT(rc_id) cnt"
                    + " FROM rpro_rc_schd rrs WHERE ";
            if (!regSchdCondition.equals(" ") && !mjeCondition.equals(" ")) {
                insertStmt = insertStmt + "(( " + regSchdCondition + " ) OR ( " + mjeCondition + " )) AND";
            } else if (regSchdCondition.equals(" ") && !mjeCondition.equals(" ")) {
                insertStmt = insertStmt + "(( " + mjeCondition + " )) AND";
            } else if (!regSchdCondition.equals(" ") && mjeCondition.equals(" ")) {
                insertStmt = insertStmt + "(( " + regSchdCondition + " )) AND";
            }

            insertStmt = insertStmt + " rrs.sec_atr_val = :orgId AND rrs.client_id = :clientId "
                    + "  GROUP BY rrs.book_id, rrs.rc_id ORDER BY rrs.book_id, rrs.rc_id"
                    + " ))) GROUP BY chunk_id, book_id";
            try {
                Integer newBatchCount = handle.createUpdate(insertStmt).bind("postBatchId", postBatchId)
                        .bind("l_split_size", splitBatchSize).bind("orgId", orgId)
                        .bind("clientId", request.getClientId()).execute();
                neoWorkflowLogger.log("batch Size: " + splitBatchSize);
                neoWorkflowLogger.log("Number of batches created: " + newBatchCount);
            } catch (Exception e) {
                accountingResult.setTransferMessage(SPLIT_ACTIVITY_ERROR + INCORRECT_BATCH_SETUP);
                accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
                updateTransferStatus(accountingResult);
                NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, INCORRECT_BATCH_SETUP);
            }
            numThreads[0] = properties.getNoOfThreads();
            neoWorkflowLogger.log("Number of threads: " + numThreads[0]);
            batches.set(splitDao.getSplitBatches(postBatchId, splitType, bookId, batchType));
        });

        List<ChunkRecord> batchIds = new ArrayList<>();
        for (SplitBatchRecord record : batches.get()) {
            ChunkRecord chunkRecord = new ChunkRecord(record.getBatchId(), record.getChunkId());
            batchIds.add(chunkRecord);
        }

        return new ThreadDetails(numThreads[0], batchIds);
    }

    @Override
    public void moveHistToMainBatch(Long postBatchId, String orgId) {
        Jdbi jdbi = DbContext.getConnection();
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        jdbi.useHandle(handle -> {
            SplitDao splitDao = handle.attach(SplitDao.class);
            Integer insertCount = splitDao.insertBatchesFromHistToMain(splitType, batchType, orgId, request.getClientId(), postBatchId);
            LOGGER.info("insertCount in moveHistToMainBatch: " + insertCount);
            Integer deleteCount = splitDao.deleteHistBatchesByType(splitType, batchType, orgId, request.getClientId(), postBatchId);
            LOGGER.info("deleteCount in moveHistToMainBatch: " + deleteCount);
        });
    }

    @Override
    public  long newPostBatchIdForMasterJobError(ThreadedAccountingResult accountingResult) {
        AtomicLong newPostBatchId = new AtomicLong();
        Jdbi jdbi = DbContext.getConnection();
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            newPostBatchId.set(commonDao.getNextSequenceNumber(postBatchIdSeq, request.getClientId()));
            StringBuilder defaultIndicator = new StringBuilder("NNNNNNNNNNNNNNNNNNNN");
            accountingDao.insertHeader(newPostBatchId.get(), TransferStatus.NEW.getTransferStatus(), request.getClientId(),
                    commonDao.getCrtdPeriodId(accountingResult.getBookId(), request.getOrgId()), request.getOrgId(),
                    accountingResult.getBookId(), request.getUser(), defaultIndicator.toString());
        });
        return newPostBatchId.get();
    }

    @Override
    public void updateTransferStatus(ThreadedAccountingResult accountingResult) {
        Jdbi jdbi = DbContext.getConnection();
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        jdbi.useHandle(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            accountingDao.updateTransferStatusMsg(accountingResult.getTransferStatus(), accountingResult.getTransferMessage(),
                    request.getUser(), accountingResult.getPostBatchId());
        });
    }

    @Override
    public void updateTransferChunkStatus(ThreadedAccountingResult accountingResult) {
        Jdbi jdbi = DbContext.getConnection();
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        jdbi.useHandle(handle -> {
            SplitDao splitDao = handle.attach(SplitDao.class);
            splitDao.updateTransferStatusChunk(TransferStatus.ERROR.getTransferStatus(), "", request.getUser(),
                    accountingResult.getPostBatchId(), accountingResult.getChunkId());
        });
    }

    @Override
    public void insertTransferError(ThreadedAccountingResult accountingResult, String orgId, String errMsg) {
        Jdbi jdbi = DbContext.getConnection();
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        jdbi.useHandle(handle -> {
            ErrorDao errorDao = handle.attach(ErrorDao.class);
            errorDao.insertError(accountingResult.getPostBatchId(), errMsg, request.getUser(), request.getClientId(),
                    accountingResult.getBookId(), orgId, accountingResult.getChunkId());
        });
    }

    @Override
    public List<ChunkStatus> getAllChunkStatus(ThreadedAccountingResult accountingResult) {
        Jdbi jdbi = DbContext.getConnection();
        AtomicReference<List<ChunkStatus>> chunkStatuses = new AtomicReference<>(
                new ArrayList<>());
        jdbi.useHandle(handle -> {
            SplitDao splitDao = handle.attach(SplitDao.class);
            chunkStatuses.set(splitDao.getAllChunkStatus(accountingResult.getPostBatchId()));
        });

        return chunkStatuses.get();
    }

    @Override
    public ThreadDetails getBatchDetailFromHist(ThreadedAccountingResult accountingResult, String org) {
        Jdbi jdbi = DbContext.getConnection();
        AtomicReference<List<SplitBatchRecord>> batches = new AtomicReference<>(new ArrayList<>());
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();

        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            SplitDao splitDao = handle.attach(SplitDao.class);
            properties.load(commonDao, request.getTenantId());
            batches.set(splitDao.getSplitBatchesHistory(accountingResult.getPostBatchId(), splitType, batchType));
        });

        Integer numThreads = properties.getNoOfThreads();
        List<ChunkRecord> batchIds = new ArrayList<>();
        for (SplitBatchRecord record : batches.get()) {
            ChunkRecord chunkRecord = new ChunkRecord(record.getBatchId(), record.getChunkId());
            batchIds.add(chunkRecord);
        }

        return new ThreadDetails(numThreads, batchIds);
    }

    private String getCriteriaForBatchSelect(ThreadedAccountingResult result, CriteriaLookupDao lookupDao, CommonDao commonDao, ErrorDao errorDao,
            WorkflowRequest request, String orgId) {
        StringBuilder scheduleWhereClause = new StringBuilder("");
        Integer rrsFilerCount = 0;
        Integer mjtFilerCount = 0;
        Integer rcFilerCount = 0;
        StringBuilder bookWhereClause = new StringBuilder("");
        StringBuilder mjtWhereClause = new StringBuilder("");
        StringBuilder prdWhereClause = new StringBuilder("");
        StringBuilder nonSchWhereClause = new StringBuilder("");
        List<BatchCriteria> batchCriteriaList = lookupDao.getBatchCriteriaDetails(result.getPostBatchId());
        LOGGER.info("batchCriteriaList: " + batchCriteriaList.size());
        BatchCriteriaCondition bcc = null;
        for (BatchCriteria criteria: batchCriteriaList) {
            if (criteria.getAlias() == null) {
                result.setTransferMessage(SPLIT_ACTIVITY_ERROR + CRITERIA_ERR);
                result.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
                updateTransferStatus(result);
                errorDao.insertError(result.getPostBatchId(), SPLIT_ACTIVITY_ERROR + CRITERIA_ERR, request.getUser(), request.getClientId(),
                        result.getBookId(), orgId, result.getChunkId());
                NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, CRITERIA_ERR);
            }
            bcc = BatchCriteriaCondition.createBatchCondition(criteria, scheduleWhereClause, bookWhereClause, mjtWhereClause,
                    rcFilerCount, prdWhereClause, nonSchWhereClause, mjtFilerCount, rrsFilerCount);
        }
        if (result.getBookId() != null) {
            bookWhereClause.append(" AND rrs.book_id = ").append(result.getBookId());
        }
        Long currentPeriodId = commonDao.getCreatedPeriodId(result.getBookId().intValue(), orgId, request.getClientId());
        StringBuilder regSchdQuery = new StringBuilder(" ");
        if (bcc == null) {
            regSchdQuery = AccountingQuery.createRegularSchdQuery(regSchdQuery, request,
                    currentPeriodId, null, null, null, null,
                    null, null, 0);
        } else {
            if (bcc.getMjtFilerCount() == 0) {
                regSchdQuery = AccountingQuery.createRegularSchdQuery(regSchdQuery, request,
                        currentPeriodId, null, null, scheduleWhereClause, bookWhereClause,
                        prdWhereClause, nonSchWhereClause, batchCriteriaList.size());
            }
        }

        String mjeEnabled = properties.getMjeEnabled() ? "Y" : "N";
        StringBuilder mjeQuery = new StringBuilder(" ");
        if (bcc == null) {
            if ("Y".equals(mjeEnabled)) {
                mjeQuery = AccountingQuery.createMjeQuery(mjeQuery, request,
                        currentPeriodId, null, null, null, null,
                        null, null, 0);
            }
        } else {
            if (bcc.getRcFilerCount() == 0 && "Y".equals(mjeEnabled)) {
                mjeQuery = AccountingQuery.createMjeQuery(mjeQuery, request,
                        currentPeriodId, null, null, scheduleWhereClause, bookWhereClause,
                        prdWhereClause, nonSchWhereClause, batchCriteriaList.size());
            }
        }

        return regSchdQuery + "~" + mjeQuery;
    }

    private void archiveBatch(SplitDao splitDao, String splitType, String batchType, WorkflowRequest request, String orgId) {
        Integer histBatchCount = splitDao.insertBatchesInHistory(splitType, batchType, orgId, request.getClientId());
        neoWorkflowLogger.log("Number of batches inserted into history table: " + histBatchCount);

        Integer deleteCount = splitDao.deleteBatchesByType(splitType, batchType, orgId, request.getClientId());
        neoWorkflowLogger.log("Number of batches deleted from split table: " + deleteCount);
    }

}
