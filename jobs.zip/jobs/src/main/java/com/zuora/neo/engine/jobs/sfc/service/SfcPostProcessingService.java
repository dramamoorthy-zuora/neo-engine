package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.db.api.AccountValue;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.sfc.SfcResult;
import com.zuora.neo.engine.jobs.sfc.api.SfcSegmentsFlagsVersions;
import com.zuora.neo.engine.jobs.sfc.constants.SfcConstants;
import com.zuora.neo.engine.jobs.sfc.constants.SfcStatus;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.context.SfcPostProcessDetailsContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.SchdIndicator;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusIndicator;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;

import org.jdbi.v3.core.Handle;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class SfcPostProcessingService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcPostProcessingService.class);

    @Autowired
    ParseProgramParameters parseProgramParameters;
    @Autowired
    NpvCalculationService npvCalculationService;
    @Autowired
    AccrualEntryService accrualEntryService;
    @Autowired
    SfcScheduleCreationService sfcScheduleCreationService;
    @Autowired
    RcLinePaDataService rcLinePaDataService;
    @Autowired
    PrincipleAmountCalculationService principleAmountCalculationService;
    @Autowired
    SoUpdateProcessingService soUpdateProcessingService;
    @Autowired
    SfcTablesBatchInsertUpdateService sfcTablesBatchInsertUpdateService;
    @Autowired
    RippedLineProcessingService rippedLineProcessingService;
    @Autowired
    SfcServiceUtils sfcServiceUtils;
    @Autowired
    RcHeadDataService rcHeadDataService;

    public static List<RcLinePaData> getRcLinePaDataFromDB(SfcDao sfcDao, long lineId) {
        LOGGER.debug("Fetching RC Line PA Data Table for the line Id : " + lineId);
        List<RcLinePaData> rcLinePaDataList = sfcDao.getRcLinePaDataForLineId(lineId);
        return rcLinePaDataList;
    }

    /*
       Service Method to post process SFC records. Calculate the interest amount for each schedule
       and creates the schedules in rpro_rc_schd and rpro_sfc_calc_det tables in the DB.

       Input :
       sfcStatusValuesList -> Lines from Sfc Status Table
       sfcDbCacheContext -> Has common details such as data from rpro_account, rpro_currency, rpro_financ_typ and rpro_calendar
       sfcResult -> contains warning count
       handle -> Jdbi Handle object to perform DB operations
     */
    public void postProcessSfc(List<SfcStatusValues> sfcStatusValuesList, SfcDbCacheContext sfcDbCacheContext,
            SfcResult sfcResult, WorkflowRequest request, Handle handle) {

        SfcDao sfcDao = handle.attach(SfcDao.class);

        List<String> sfcDocLineIds = sfcStatusValuesList.stream().map(SfcStatusValues::getDocLineId).collect(Collectors.toList());

        LOGGER.info("Fetching RC Line Table details for batch in Post Process");
        /*List<Account> accountTableList = sfcDbCacheContext.getAccountTableList();
        List<String> accountSourceValuesFromLineTable = accountTableList.stream()
                .map(Account::getSourceValue).collect(Collectors.toList());
        String columns = String.join(",",accountSourceValuesFromLineTable);*/
        List<RcLineDetails> rcLineDetailsBatch = sfcDao.getRcLineDetailsByDocLineIdListWithAttributes(sfcDocLineIds);

        LOGGER.info("Fetching Payment Table details for batch in Post Process");
        List<SfcPaymentDetails> sfcPaymentDetailsBatch = sfcDao.getSfcPaymentDetailsByDocLineIdList(sfcDocLineIds);

        Map<String, List<RcLineDetails>> rcLineDetailsBatchMap = rcLineDetailsBatch.stream()
                .collect(Collectors.groupingBy(RcLineDetails::getDocLineId));
        Map<String, List<SfcPaymentDetails>> sfcPaymentDetailsBatchMap = sfcPaymentDetailsBatch.stream()
                .collect(Collectors.groupingBy(SfcPaymentDetails::getDocLineId));

        List<AccountValue> accountValuesList = sfcDbCacheContext.getAccountValuesList();
        long openPeriodId = sfcDbCacheContext.getCurrentPeriodId();

        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();
        List<SfcCalcDetails> sfcCalcDetailsBatch = new ArrayList<>();
        List<RcLinePaData> rcLinePaDataRecordBatch = new ArrayList<>();

        SfcPostProcessDetailsContext sfcPostProcessDetailsContext = new SfcPostProcessDetailsContext(rcScheduleRecordBatch, sfcCalcDetailsBatch,
                rcLinePaDataRecordBatch, rcLineDetailsBatchMap, sfcPaymentDetailsBatchMap);

        performSfcCalculations(sfcStatusValuesList, sfcPostProcessDetailsContext,
                sfcDbCacheContext, sfcResult, request, handle);

        sfcTablesBatchInsertUpdateService.batchInsertSfcTables(rcScheduleRecordBatch, sfcCalcDetailsBatch,
                accountValuesList, openPeriodId, handle);
        sfcTablesBatchInsertUpdateService.batchUpdateSfcStatusTable(sfcStatusValuesList, handle);

    }

    public void performSfcCalculations(List<SfcStatusValues> sfcStatusValuesList, SfcPostProcessDetailsContext sfcPostProcessDetailsContext,
            SfcDbCacheContext sfcDbCacheContext, SfcResult sfcResult, WorkflowRequest request, Handle handle) {
        CommonDao commonDao = handle.attach(CommonDao.class);
        SfcDao sfcDao = handle.attach(SfcDao.class);
        long openPeriodId = sfcDbCacheContext.getCurrentPeriodId();
        Map<String, List<RcLineDetails>> rcLineDetailsBatchMap = sfcPostProcessDetailsContext.getRcLineDetailsBatchMap();
        Map<String, List<SfcPaymentDetails>> sfcPaymentDetailsBatchMap = sfcPostProcessDetailsContext.getSfcPaymentDetailsBatchMap();
        List<RcScheduleRecord> rcScheduleRecordBatch = sfcPostProcessDetailsContext.getRcScheduleRecordBatch();
        List<RcLinePaData> rcLinePaDataRecordBatch = sfcPostProcessDetailsContext.getRcLinePaDataRecordBatch();
        List<Long> rcIdList = new ArrayList<>();

        for (SfcStatusValues sfcStatusValue : sfcStatusValuesList) {
            if (sfcStatusValue != null && sfcStatusValue.getDocLineId() != null) {
                sfcStatusValue.setErrMsg(null);
                List<SfcPaymentDetails> sfcPaymentDetails = sfcPaymentDetailsBatchMap.get(sfcStatusValue.getDocLineId());
                List<RcLineDetails> rcLineDetails = rcLineDetailsBatchMap.get(sfcStatusValue.getDocLineId());
                long lineId = rcLineDetails.get(0).getId();
                long bookId = rcLineDetails.get(0).getBookId();
                Date startDate = rcLineDetails.get(0).getStartDate() != null
                        ? rcLineDetails.get(0).getStartDate() : sfcPaymentDetails.get(0).getPaymtStartDate();
                long lineStartDatePeriod = getPeriodId(sfcDbCacheContext,startDate,openPeriodId);
                LOGGER.debug("Fetching Finance Type Values for SFC..");
                List<RcLinePaData> rcLinePaDataRecordBeforeProcessing = SfcBatchProcessingService.getRcLinePaRecordForFinanceId(sfcDao,
                        rcLineDetails.get(0).getId(), sfcDbCacheContext);
                List<FinanceTypeValues> financeTypeValueForRcLine = sfcServiceUtils.getFinanceTypeForRcLine(rcLinePaDataRecordBeforeProcessing,
                        sfcDbCacheContext, rcLineDetails);
                if (financeTypeValueForRcLine.isEmpty()) {
                    LOGGER.error("Finance Type Table is not available for doc line id " + sfcStatusValue.getDocLineId());
                    sfcServiceUtils.updateSfcStatusAndAddWarningCount(sfcResult, sfcStatusValue, SfcConstants.SFC_SETUP_NOT_AVAILABLE);
                    continue;
                }
                Boolean isSfcValid = sfcServiceUtils.validSfcLine(sfcStatusValue, sfcPaymentDetails, rcLineDetails, financeTypeValueForRcLine);
                SchdIndicator schdIndicator = new SchdIndicator();
                if (isSfcValid) {
                    long vcTypeId = Math.toIntExact(financeTypeValueForRcLine.get(0).getId());
                    List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
                    SfcSegmentsFlagsVersions sfcSegmentsFlagsVersions = sfcServiceUtils.getSegmentsFlagsVersions(financeTypeValueForRcLine,
                            financeTypeFlagDetailsList, rcLineDetails, vcTypeId, bookId, lineId, sfcDbCacheContext, commonDao, sfcDao);
                    financeTypeFlagDetailsList = sfcSegmentsFlagsVersions.getFinanceTypeFlagDetailsList();
                    sfcStatusValue.setStatus(SfcStatus.COMPLETED.getStatus());
                    List<RcLinePaData> rcLinePaDataList = getRcLinePaDataFromDB(sfcDao, lineId);
                    List<FinanceTypeFlagDetails> finalFinanceTypeFlagDetailsList = financeTypeFlagDetailsList;
                    List<RcLinePaData> rcLinePaDataRecord = rcLinePaDataList.stream()
                            .filter(rcLinePaDataItem -> rcLinePaDataItem.getIndicators().charAt(0) == 'Y'
                                    && rcLinePaDataItem.getVcTypeId() == finalFinanceTypeFlagDetailsList.get(0).getVcTypeId())
                            .collect(Collectors.toList());
                    if (rcLinePaDataList.isEmpty() || rcLinePaDataRecord.isEmpty()) {
                        LOGGER.error("Error in processing SFC. RC Line Pa Data empty for " + sfcStatusValue.getDocLineId());
                        sfcServiceUtils.updateSfcStatusAndAddWarningCount(sfcResult, sfcStatusValue, SfcConstants.ERROR_PROCESSING_SFC);
                        continue;
                    }
                    String crAcctgFlag = finalFinanceTypeFlagDetailsList.get(0).getDrAcctgFlag();
                    String drAcctgFlag = finalFinanceTypeFlagDetailsList.get(0).getContractLiabilityFlag();
                    String drAcctgSeg = sfcSegmentsFlagsVersions.getContractLiabilitySeg();
                    String crAcctgSeg = sfcSegmentsFlagsVersions.getDrAcctSeg();
                    BigDecimal intAccrual = sfcStatusValue.getNetInterestAccrual();
                    accrualEntryService.createAccrualEntry(rcLineDetails, rcLinePaDataRecord, request,
                            intAccrual, crAcctgFlag, drAcctgFlag,
                            openPeriodId, sfcSegmentsFlagsVersions.getRcVersion(), drAcctgSeg,
                            crAcctgSeg, schdIndicator, rcScheduleRecordBatch, lineStartDatePeriod, 'N');
                    crAcctgFlag = finalFinanceTypeFlagDetailsList.get(0).getCrAcctgFlag();
                    drAcctgFlag = finalFinanceTypeFlagDetailsList.get(0).getContractLiabilityFlag();
                    drAcctgSeg = sfcSegmentsFlagsVersions.getContractLiabilitySeg();
                    crAcctgSeg = sfcSegmentsFlagsVersions.getCrAcctSeg();
                    //making this negative for a positive entry in the schedule
                    intAccrual = sfcStatusValue.getNetInterestAccrual().multiply(BigDecimal.valueOf(-1));
                    accrualEntryService.createAccrualEntry(rcLineDetails, rcLinePaDataRecord, request,
                            intAccrual, crAcctgFlag, drAcctgFlag,
                            openPeriodId, sfcSegmentsFlagsVersions.getRcVersion(), drAcctgSeg,
                            crAcctgSeg, schdIndicator, rcScheduleRecordBatch, lineStartDatePeriod, 'Y');
                    LOGGER.debug("Accrual Entry Service created");
                    sfcScheduleCreationService.createSfcSchedule(sfcStatusValue, rcLinePaDataRecord, financeTypeFlagDetailsList, openPeriodId,
                            schdIndicator, sfcDbCacheContext, sfcPostProcessDetailsContext, sfcSegmentsFlagsVersions);
                    LOGGER.debug("SFC Schedules inserted.");
                    rcLinePaDataService.populateAmountsForPaRecord(rcLinePaDataRecord.get(0), rcLinePaDataRecord.get(0).getDefAmt(),
                            BigDecimal.ZERO, rcLinePaDataRecord.get(0).getDefAmt());
                    rcLinePaDataService.populateIdsVersionsForPaRecord(rcLinePaDataRecord.get(0), lineId, vcTypeId,
                            sfcSegmentsFlagsVersions.getFinanceTypeVersion());
                    LOGGER.debug("RC Line Pa Data populated for " + sfcStatusValue.getDocLineId());
                    rcLinePaDataRecordBatch.addAll(rcLinePaDataRecord);
                    rcIdList.add(rcLinePaDataRecord.get(0).getRcId());
                    sfcStatusValue.setStatus(SfcStatus.COMPLETED.getStatus());
                    //Setting SFC Status Indicator for Real Time Summarization for SFC Completed RCs
                    SfcStatusIndicator sfcStatusIndicators = SfcStatusIndicator.valueOf(sfcStatusValue.getIndicators());
                    sfcStatusIndicators.setRealTimeSummReadyFlag('Y');
                    sfcStatusValue.setIndicators(sfcStatusIndicators.getIndicator());
                }
            }
        }
        rcLinePaDataService.updateAmountsToRcLinePaDataBatch(handle, rcLinePaDataRecordBatch);
        rcHeadDataService.updateAmountsToRcHeadDataBatch(handle, rcIdList, request.getUser());
    }

    public long getPeriodId(SfcDbCacheContext sfcDbCacheContext, Date startDate, long openPeriodId) {
        List<CalendarDetails> calendarDetailsCache = sfcDbCacheContext.getCalendarDetailsCache();
        for (CalendarDetails calendarDetail : calendarDetailsCache) {
            boolean startDateBetweenPeriod = startDate.compareTo(calendarDetail.getStartDate()) >= 0
                    && startDate.compareTo(calendarDetail.getEndDate()) <= 0;

            if (startDateBetweenPeriod) {
                return calendarDetail.getId();
            }
        }
        return openPeriodId;
    }
}
