package com.zuora.neo.engine.jobs.transferaccounting.db.api;

public class RcHeadRecord {
    private Long rcId;
    private Long bookId;
    private Long objectVersion;

    public Long getRcId() {
        return rcId;
    }

    public void setRcId(Long rcId) {
        this.rcId = rcId;
    }

    public Long getBookId() {
        return bookId;
    }

    public void setBookId(Long bookId) {
        this.bookId = bookId;
    }

    public Long getObjectVersion() {
        return objectVersion;
    }

    public void setObjectVersion(Long objectVersion) {
        this.objectVersion = objectVersion;
    }

    public RcHeadRecord(Long rcId, Long bookId, Long objectVersion) {
        this.rcId = rcId;
        this.bookId = bookId;
        this.objectVersion = objectVersion;
    }
}
