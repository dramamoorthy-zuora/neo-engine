package com.zuora.neo.engine.jobs.rtp.service;

import com.zuora.neo.engine.jobs.rtp.WorkItemResult;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public interface RtpService {
    WorkItemResult process(String secAtrVal, BigDecimal batchId);
}
