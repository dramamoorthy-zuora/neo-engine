package com.zuora.neo.engine.jobs.reporting.activities;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface SetReportStatus {
    String setRecords(String h);

    String setErrorInDB(String err);
}
