package com.zuora.neo.engine.common.lookup;

import lombok.Data;

@Data
public class LookupEntity {
    private String key;
    private String value;

    public LookupEntity(String key, String value) {
        this.key = key;
        this.value = value;
    }
}
