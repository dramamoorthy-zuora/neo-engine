package com.zuora.neo.engine.jobs.ltst.service;

import com.zuora.neo.engine.jobs.rtp.WorkItemResult;
import com.zuora.neo.engine.jobs.rtp.service.RtpService;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class LtstRtpService implements RtpService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(LtstRtpService.class);

    @Override
    public WorkItemResult process(String secAtrVal, BigDecimal batchId) {
        LOGGER.info("--------- LT/ST - batchId to process - " + batchId);
        LOGGER.info("########## Returning from LT/ST service ########");
        return new WorkItemResult("", 0);
    }
}
