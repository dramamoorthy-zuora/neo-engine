package com.zuora.neo.engine.jobs.sfc.db.dao;

import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.db.mapper.RcLineDetailsAttributesMapper;
import com.zuora.neo.engine.db.mapper.RcLineDetailsDocNumMapper;
import com.zuora.neo.engine.db.mapper.RcLineDetailsMapper;
import com.zuora.neo.engine.db.mapper.RcLinePaDataMapper;
import com.zuora.neo.engine.db.mapper.RcScheduleRecordMapper;
import com.zuora.neo.engine.jobs.sfc.constants.SfcConstants;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.mapper.FinanceTypeValuesMapper;
import com.zuora.neo.engine.jobs.sfc.db.mapper.SfcCalcDetailsMapper;
import com.zuora.neo.engine.jobs.sfc.db.mapper.SfcPaymentDetailsMapper;
import com.zuora.neo.engine.jobs.sfc.db.mapper.SfcStatusValuesMapper;

import org.jdbi.v3.core.statement.OutParameters;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.customizer.OutParameter;
import org.jdbi.v3.sqlobject.statement.SqlBatch;
import org.jdbi.v3.sqlobject.statement.SqlCall;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.statement.UseRowMapper;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface SfcDao {

    @SqlQuery("SELECT doc_num, doc_line_id,status,rc_id,line_id,net_npv_amt,net_interest_accrual,rip_date,error_msg,rip_amt,indicators "
            + "FROM rpro_sfc_status where doc_line_id = :docLineId ")
    @UseRowMapper(SfcStatusValuesMapper.class)
    List<SfcStatusValues> getSfcStatusValuesByDocLineId(@Bind("docLineId") String docLineId);

    @SqlBatch("update rpro_sfc_paymt_det set net_paymt_value = :netPaymentValue , interest_accrual = :interestAccrual , paymt_start_dt = :paymntStartDate "
            + "where id = :id")
    void updatePaymentBatchById(@Bind("netPaymentValue") List<BigDecimal> netPaymentValueList, @Bind("interestAccrual") List<BigDecimal> interestAccrualList,
            @Bind("paymntStartDate") List<Date> paymntStartDateList, @Bind("id") List<Long> ids);

    @SqlUpdate("update rpro_sfc_status set net_npv_amt = :netNpvAmount , net_interest_accrual = :netInterestAccrual, status = :status, rip_amt = :ripAmt "
            + "where doc_line_id = :docLineId ")
    void updateSfcStatusWithNpvInterestAndStatus(@Bind("netNpvAmount") BigDecimal netNpvAmount, @Bind("netInterestAccrual") BigDecimal netInterestAccrual,
            @Bind("status") String status, @Bind("ripAmt") BigDecimal ripAmt, @Bind("docLineId") String docLineId);

    @SqlQuery("SELECT id,paymt_date,doc_line_id,paymt_amount,net_paymt_value,interest_accrual,paymt_start_dt"
            + ",paymt_end_dt from rpro_sfc_paymt_det where doc_line_id in (<docLineIdList>) order by doc_line_id, paymt_date")
    @UseRowMapper(SfcPaymentDetailsMapper.class)
    List<SfcPaymentDetails> getSfcPaymentDetailsByDocLineIdList(@BindList("docLineIdList") List<String> docLineIdList);

    @SqlQuery("SELECT id,rc_id,doc_line_id,ext_sll_prc,ext_fv_prc,ext_lst_prc,rec_amt,def_amt,rel_pct,"
            + "npv_interest_rate,curr,book_id, client_id, sec_atr_val, rc_pob_id, "
            + "f_ex_rate, g_ex_rate, doc_date, doc_num , start_date, end_date, principle_amt from rpro_rc_line where doc_line_id in (<docLineIdList>)")
    @UseRowMapper(RcLineDetailsMapper.class)
    List<RcLineDetails> getRcLineDetailsByDocLineIdList(@BindList("docLineIdList") List<String> docLineIdList);

    @SqlQuery("SELECT id,rc_id,doc_line_id,ext_sll_prc,ext_fv_prc,ext_lst_prc,rec_amt,def_amt,rel_pct,"
            + "npv_interest_rate,curr,book_id, client_id, sec_atr_val, rc_pob_id, "
            + "f_ex_rate, g_ex_rate, doc_date, doc_num , start_date, end_date, principle_amt, rev_segments, def_segments, "
            + "atr1, atr2, atr3, atr4, atr5, atr6, atr7, atr8, atr9, atr10, atr11, atr12, atr13, atr14, atr15, atr16, atr17, atr18,"
            + "atr19, atr20, atr21, atr22, atr23, atr24, atr25, atr26, atr27, atr28, atr29, atr30, atr31, atr32, atr33, atr34, atr35, atr36,"
            + "atr37, atr38, atr39, atr40, atr41, atr42, atr43, atr44, atr45, atr46, atr47, atr48, atr49, atr50, atr51, atr52, atr53, atr54, atr55, atr56,"
            + "atr57, atr58, atr59, atr60, num1, num2, num3, num4, num5, num6, num7, num8, num9, num10, num11, num12, num13, num14, num15 "
            + "from rpro_rc_line where doc_line_id in (<docLineIdList>)")
    @UseRowMapper(RcLineDetailsAttributesMapper.class)
    List<RcLineDetails> getRcLineDetailsByDocLineIdListWithAttributes(@BindList("docLineIdList") List<String> docLineIdList);

    @SqlQuery("SELECT doc_num, sum(ext_sll_prc) as sum_ext_sll_prc, sum(ext_fv_prc) as sum_ext_fv_prc, sum(ext_lst_prc) as sum_ext_lst_prc from rpro_rc_line "
            + "where doc_num in (<docNumsList>) group by doc_num")
    @UseRowMapper(RcLineDetailsDocNumMapper.class)
    List<RcLineDetails> getRcLineDetailsByDocNum(@BindList("docNumsList") List<String> docNums);

    @SqlQuery("SELECT 1 FROM DUAL WHERE EXISTS "
            + "(SELECT 1 FROM rpro_sfc_paymt_stg WHERE error_msg is not null and (so_num in (<docNumsList>) or so_line_id in (<docLineIdList>)))"
            + " UNION SELECT 1 FROM DUAL WHERE EXISTS (select 1 from rpro_sfc_paymt_upload WHERE NVL(process_flag,'N') = 'N')")
    Optional<Integer> getNumberOfErrorLinesInPaymentStageTable(@BindList("errorMsgList") List<String> errorMsgList,
            @BindList("docLineIdList") List<String> docLineIdList, @BindList("docNumsList") List<String> docNums);

    @SqlQuery("SELECT id, line_id, vc_type_id, def_amt, rec_amt, pa_base_amt, applied_pct, vc_grp_id, indicators, client_id, crtd_prd_id, crtd_by,"
            + "crtd_dt, updt_by, updt_dt, batch_id, sec_atr_val, book_id, rc_id, hier_seq, accrued_amt, cleared_amt, expired_amt, "
            + "comments, pa_base_qty, est_amt, act_amt, est_qty, act_qty, vc_strat_id, cleared_qty, "
            + "accrued_qty, parent_id, expiry_date, start_date, end_date, calculation_method, interest_rate, fnc_type_version "
            + "from rpro_rc_line_pa where line_id = :lineId")
    @UseRowMapper(RcLinePaDataMapper.class)
    List<RcLinePaData> getRcLinePaDataForLineId(@Bind("lineId") long lineId);

    @SqlQuery("SELECT id, line_id, vc_type_id, def_amt, rec_amt, pa_base_amt, applied_pct, vc_grp_id, indicators, client_id, crtd_prd_id, crtd_by,"
            + "crtd_dt, updt_by, updt_dt, batch_id, sec_atr_val, book_id, rc_id, hier_seq, accrued_amt, cleared_amt, expired_amt, "
            + "comments, pa_base_qty, est_amt, act_amt, est_qty, act_qty, vc_strat_id, cleared_qty, "
            + "accrued_qty, parent_id, expiry_date, start_date, end_date, calculation_method, interest_rate, fnc_type_version "
            + "from rpro_rc_line_pa where line_id = :lineId and vc_type_id = :financeTypeId "
            + "and rpro_rc_line_pa_pkg.get_leaf_flag(indicators) = 'Y'")
    @UseRowMapper(RcLinePaDataMapper.class)
    List<RcLinePaData> getRcLinePaDataForLineId(@Bind("lineId") long lineId, @Bind("financeTypeId") long financeTypeId);

    @SqlQuery("SELECT id, line_id, vc_type_id, def_amt, rec_amt, pa_base_amt, applied_pct, vc_grp_id, indicators, client_id, crtd_prd_id, crtd_by,"
            + "crtd_dt, updt_by, updt_dt, batch_id, sec_atr_val, book_id, rc_id, hier_seq, accrued_amt, cleared_amt, expired_amt, "
            + "comments, pa_base_qty, est_amt, act_amt, est_qty, act_qty, vc_strat_id, cleared_qty, "
            + "accrued_qty, parent_id, expiry_date, start_date, end_date, calculation_method, interest_rate, fnc_type_version "
            + "from rpro_rc_line_pa where line_id in (<lineIdList>) and vc_type_id = :financeTypeId "
            + "and rpro_rc_line_pa_pkg.get_leaf_flag(indicators) = 'Y'")
    @UseRowMapper(RcLinePaDataMapper.class)
    List<RcLinePaData> getRcLinePaDataForLineIdBatch(@BindList("lineIdList") List<Long> lineIdList, @Bind("financeTypeId") long financeTypeId);

    @SqlCall("{call rpro_sfc_process_pkg.get_sfc_acctg_acct_wrapper(:p_line_id, :p_income_acct_flag, :p_dr_acct_flag, :p_cr_acct_flag,"
            + " :p_int_imp_flag, :p_cont_imp_flag, :p_book_id, :p_accrual_dr_acctg_segment, :p_accrual_cr_acctg_segment,"
            + " :p_income_stmt_dr_acctg_segment, :p_inc_imp_segment, :p_cont_imp_acctg_segment)}")
    @OutParameter(name = "p_accrual_dr_acctg_segment", sqlType = Types.VARCHAR)
    @OutParameter(name = "p_accrual_cr_acctg_segment", sqlType = Types.VARCHAR)
    @OutParameter(name = "p_income_stmt_dr_acctg_segment", sqlType = Types.VARCHAR)
    @OutParameter(name = "p_inc_imp_segment", sqlType = Types.VARCHAR)
    @OutParameter(name = "p_cont_imp_acctg_segment", sqlType = Types.VARCHAR)
    OutParameters getSfcAcct(@Bind("p_line_id") long lineId, @Bind("p_income_acct_flag") String incomeAcctFlag,
            @Bind("p_dr_acct_flag") String drAcctFlag, @Bind("p_cr_acct_flag") String crAcctFlag, @Bind("p_book_id") long bookId,
            @Bind("p_int_imp_flag") String impairmentAccountFlag, @Bind("p_cont_imp_flag") String contractImpairmentAccountFlag);

    @SqlQuery("SELECT id, name, description, version, rev_rec_type, interest_rate, eligiblity_column, eligiblity_value, "
            + "prncl_weightage_column, start_date, end_date, client_id, "
            + "crtd_prd_id, crtd_by, crtd_dt, updt_by, updt_dt, seq, indicators "
            + "from rpro_financ_type")
    @UseRowMapper(FinanceTypeValuesMapper.class)
    List<FinanceTypeValues> getFinanceTypeDetailsForSfc(); //TODO get Sfc Flag filter

    @SqlUpdate("update rpro_rc_line set principle_amt = :principleAmt where doc_line_id = :docLineId ")
    void updateRcLineDetailsWithPrincipleAmt(@Bind("principleAmt") BigDecimal principleAmt, @Bind("docLineId") String docLineId);

    @SqlCall("{call rpro_sfc_paymt_upload_pkg.process_paymt_record(:p_errbuff, :p_retcode, :p_batch_id)}")
    @OutParameter(name = "p_errbuff", sqlType = Types.VARCHAR)
    @OutParameter(name = "p_retcode", sqlType = Types.INTEGER)
    OutParameters processUnprocessedPaymentLines(@Bind("p_batch_id") long batchId);

    @SqlQuery(SfcConstants.SFC_CALC_TABLE_BY_DOC_LINE)
    @UseRowMapper(SfcCalcDetailsMapper.class)
    List<SfcCalcDetails> getSfcCalcByDocLine(@Bind("lineId") long lineId);

    @SqlQuery(SfcConstants.SFC_RC_SCHD_RECORDS_LINE_ID_BY_PERIOD)
    @UseRowMapper(RcScheduleRecordMapper.class)
    List<RcScheduleRecord> cacheRcScheduleTableRecordsByLineId(@Bind("openPeriodId") long openPeriodId, @Bind("paId") long paId,
            @Bind("reversePeriodId") long reversePeriodId);

    @SqlUpdate("update rpro_rc_line_pa set fnc_type_version = :fncTypeVersion where line_id = :lineId and vc_type_id = :vcTypeId ")
    void updateRcLinePaTableWithFncTypeVersion(@Bind("fncTypeVersion") long fncTypeVersion, @Bind("lineId") long lineId, @Bind("vcTypeId") long vcTypeId);

    @SqlQuery("SELECT :column FROM rpro_rc_line where id = :lineId")
    String getRcLineTableColumnValue(@Bind("column") String column, @Bind("lineId") long lineId);

    @SqlCall("{call rpro_sfc_process_pkg.call_realtime_summ(:p_errbuf, :p_retcode, :p_sec_atr_val, :p_client_id)}")
    @OutParameter(name = "p_errbuf", sqlType = Types.VARCHAR)
    @OutParameter(name = "p_retcode", sqlType = Types.INTEGER)
    OutParameters callRealTimeSummarization(@Bind("p_sec_atr_val") String secAtrVal, @Bind("p_client_id") long clientId);
}
