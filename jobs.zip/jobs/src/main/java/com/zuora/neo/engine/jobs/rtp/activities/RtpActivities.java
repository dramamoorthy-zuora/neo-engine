package com.zuora.neo.engine.jobs.rtp.activities;

import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface RtpActivities {

    WorkflowResponse performRtp();
}
