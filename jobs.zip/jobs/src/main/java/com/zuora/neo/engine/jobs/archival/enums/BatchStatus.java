package com.zuora.neo.engine.jobs.archival.enums;

public enum BatchStatus {

    NEW("N"),
    COPIED("C"),
    MOVED("M"),
    EXCEPTION("X"),
    TO_BE_RECOVERED("T"),
    RECOVERY_EXCEPTION("RE"),
    RECOVERED("R");

    public final String label;

    BatchStatus(String label) {
        this.label = label;
    }

}
