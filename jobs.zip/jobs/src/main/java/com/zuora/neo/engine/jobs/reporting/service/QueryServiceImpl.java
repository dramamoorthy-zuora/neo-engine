package com.zuora.neo.engine.jobs.reporting.service;

import com.zuora.neo.engine.exception.NonRetryableActivityException;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

public class QueryServiceImpl implements QueryService {
    // String CookieString="cookie: Zuora-User-Language=en; Zuora-User-Locale=en_US;
    static String zuoraTokenId = "2988c3d0-4623-4f14-9eb3-5be3b93597a8";
    String queryID = "INIT_QID";
    String tenantID;
    String envCheck = System.getenv("LOCAL_DEV");
    String getQueryServiceUrl = System.getenv("QUERY_SERVICE_ENDPOINT");

    public QueryServiceImpl(String id) {
        tenantID = id;
    }

    public String getZuoraTokenId() {
        String envToken = System.getenv("ZUORA_TOKEN_ID");
        return envToken == null ? zuoraTokenId : envToken;
    }

    public void setGetQueryServiceUrl(String urlFromOracle) {
        getQueryServiceUrl = (urlFromOracle.equals("null")) ? getQueryServiceUrl : urlFromOracle;
    }

    public String getQueryID() {
        return queryID;
    }

    private String getGetUrl() {
        String envValue = envCheck == null ? "0" : envCheck;
        if (envValue.equals("0")) {
            String urlValue = getQueryServiceUrl == null
                    ? "http://query-service-stg01.stg.auw2.zuora/query/internal/revenue/jobs"
                    : getQueryServiceUrl;
            return urlValue + "/" + queryID;
        } else {
            System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
            return "http://localhost:9008/query/internal/revenue/jobs/" + queryID;
        }
    }

    private String getPostUrl() {
        String envValue = envCheck == null ? "0" : envCheck;
        if (envValue.equals("0")) {
            String urlValue = getQueryServiceUrl == null
                    ? "http://query-service-stg01.stg.auw2.zuora/query/internal/revenue/jobs"
                    : getQueryServiceUrl;
            return urlValue;
        } else {

            System.setProperty("sun.net.http.allowRestrictedHeaders", "true");
            return "http://localhost:9008/query/internal/revenue/jobs";
        }
    }

    public String sendGetRequest() {
        try {
            String apiUrl = getGetUrl();
            // String apiUrl = "https://aditya2.free.beeceptor.com/poiu";
            String envValue = envCheck == null ? "0" : envCheck;
            // Set the request method and headers
            String requestMethod = "GET";
            String contentType = "application/json";
            String accept = "application/json";
            URL url = new URL(apiUrl);
            // Create a new HTTP connection
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod(requestMethod);
            connection.setRequestProperty("Content-Type", contentType);
            connection.setRequestProperty("Accept", accept);
            connection.setRequestProperty("Zuora-Token-Id", getZuoraTokenId());
            // required for local
            if (envValue.equals("1")) {
                connection.setRequestProperty("Host", "query-service-stg01.stg.auw2.zuora");
            }
            // todo make this id dynamic as required
            connection.setRequestProperty("x-rev-tenant-id", tenantID);

            // to get request properties used in debugging
            // Map<String, List<String>> df = connection.getRequestProperties();

            // Send the request and get the response
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) { // success
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(connection.getInputStream(), "UTF-8"));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                JSONObject responseToJson = new JSONObject(response.toString());
                JSONObject dataInJson = responseToJson.has("data") ? responseToJson.getJSONObject("data")
                        : new JSONObject();
                dataInJson.put("httpStatusCode", responseCode);
                String fileUrl = dataInJson.has("dataFile")
                        ? dataInJson.getString("dataFile")
                        : "No Data File Url Present";
                String queryStatus = dataInJson.has("queryStatus")
                        ? dataInJson.getString("queryStatus")
                        : "No Q Status Present";
                if (envValue.equals("1")) {
                    System.out.println("############## Query Service Get Status ##############");
                    System.out.println(queryStatus + " " + fileUrl);
                    System.out.println(response.toString() + "#######");
                    System.out.println(dataInJson.toString());
                    System.out.println("############## Query Service Get Status ##############");
                }
                return dataInJson.toString();
            } else {
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(connection.getErrorStream(), "UTF-8"));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                JSONObject responseToJsonObject = new JSONObject();
                responseToJsonObject.put("response",response);
                responseToJsonObject.put("httpStatusCode", responseCode);
                return responseToJsonObject.toString();
            }
        } catch (IOException | JSONException e) {
            e.printStackTrace();
            throw new NonRetryableActivityException("Error: inside get Query Service " + e.getMessage(), e);
        }
    }

    public String sendPostRequest(String query) {
        try {

            String envValue = envCheck == null ? "0" : envCheck;
            String apiUrl = getPostUrl();
            // for local testing used this
            // String apiUrl = "https://aditya.free.beeceptor.com/asd";
            String requestMethod = "POST";
            String contentType = "application/json";
            String accept = "application/json";
            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod(requestMethod);
            connection.setRequestProperty("Content-Type", contentType);
            connection.setRequestProperty("Accept", accept);
            connection.setRequestProperty("Zuora-Token-Id", getZuoraTokenId());
            connection.setRequestProperty("x-rev-tenant-id", tenantID);
            // for local debugging and testing
            if (envValue.equals("1")) {
                connection.setRequestProperty("Host", "query-service-stg01.stg.auw2.zuora");
                //connection.setRequestProperty("Host", "query-service-sbx08.sbx.auw2.zuora");
            }
            JSONObject body = new JSONObject();
            body.put("query", query);
            JSONObject target = new JSONObject();
            target.put("target", "s3");
            body.put("output", target);
            body.put("sourceData", "REVENUEREPORTING");
            body.put("compression", "NONE");
            body.put("outputFormat", "CSV");
            String requestBody = body.toString();
            // send POST request
            if (envValue.equals("1")) {
                // only for local to check the request
                Map<String, List<String>> df = connection.getRequestProperties();
                System.out.println(df.toString());
            }
            connection.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
            wr.writeBytes(requestBody);
            wr.flush();
            wr.close();

            int responseCode = connection.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) { // success
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        connection.getInputStream(), "UTF-8"));
                String inputLine;
                StringBuffer response = new StringBuffer();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                JSONObject responseToJsonObject = new JSONObject(response.toString());
                JSONObject dataJsonObject = responseToJsonObject.has("data")
                        ? responseToJsonObject.getJSONObject("data")
                        : new JSONObject();
                String status = dataJsonObject.has("queryStatus") ? dataJsonObject.getString("queryStatus")
                        : "No Query Status Present";

                if (envValue.equals("1")) {
                    System.out.println("############## Query POST Status ##############");
                    System.out.println(status);
                    System.out.println(dataJsonObject.toString());
                    System.out.println("############## Query POST Status ##############");

                }
                // setting global queryid for Get request
                queryID = dataJsonObject.has("id") ? dataJsonObject.getString("id") : "No Query id Present";

                dataJsonObject.put("httpStatusCode", responseCode);
                dataJsonObject.put("queryID", queryID);
                // failed or accesspted updated here - same as queryStatus
                dataJsonObject.put("status", status);
                return dataJsonObject.toString();
            } else {
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(connection.getErrorStream(), "UTF-8"));
                String inputLine;
                StringBuffer response = new StringBuffer();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                JSONObject responseToJson = new JSONObject();
                responseToJson.put("response",response);
                responseToJson.put("httpStatusCode", responseCode);
                return responseToJson.toString();
            }
        } catch (IOException | JSONException e) {
            e.printStackTrace();
            throw new NonRetryableActivityException("Error: inside post Query Service " + e.getMessage(), e);
        }
    }

}
