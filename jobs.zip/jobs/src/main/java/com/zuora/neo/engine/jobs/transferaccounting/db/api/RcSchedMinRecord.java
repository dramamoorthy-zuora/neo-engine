package com.zuora.neo.engine.jobs.transferaccounting.db.api;

public class RcSchedMinRecord {
    private Long lineId;
    private Long rootLineId;
    private Double amount;
    private String indicators;
    private String crSegments;
    private String drSegments;
    private Double foreignExRate;
    private Double globalExRate;
    private Integer postPeriodId;

    public RcSchedMinRecord(Long lineId, Long rootLineId, Double amount, String indicators, String crSegments, String drSegments, Double foreignExRate,
            Double globalExRate, Integer postPeriodId) {
        this.lineId = lineId;
        this.rootLineId = rootLineId;
        this.amount = amount;
        this.indicators = indicators;
        this.crSegments = crSegments;
        this.drSegments = drSegments;
        this.foreignExRate = foreignExRate;
        this.globalExRate = globalExRate;
        this.postPeriodId = postPeriodId;
    }

    public Long getLineId() {
        return lineId;
    }

    public void setLineId(Long lineId) {
        this.lineId = lineId;
    }

    public Long getRootLineId() {
        return rootLineId;
    }

    public void setRootLineId(Long rootLineId) {
        this.rootLineId = rootLineId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getIndicators() {
        return indicators;
    }

    public void setIndicators(String indicators) {
        this.indicators = indicators;
    }

    public String getCrSegments() {
        return crSegments;
    }

    public void setCrSegments(String crSegments) {
        this.crSegments = crSegments;
    }

    public String getDrSegments() {
        return drSegments;
    }

    public void setDrSegments(String drSegments) {
        this.drSegments = drSegments;
    }

    public Integer getPostPeriodId() {
        return postPeriodId;
    }

    public void setPostPeriodId(Integer postPeriodId) {
        this.postPeriodId = postPeriodId;
    }

    public Double getForeignExRate() {
        return foreignExRate;
    }

    public void setForeignExRate(Double foreignExRate) {
        this.foreignExRate = foreignExRate;
    }

    public Double getGlobalExRate() {
        return globalExRate;
    }

    public void setGlobalExRate(Double globalExRate) {
        this.globalExRate = globalExRate;
    }
}
