package com.zuora.neo.engine.jobs.archival;

import com.zuora.neo.engine.jobs.archival.enums.ArchivalStatus;

public class ArchivalResult {

    private ArchivalStatus status;

    private String message;

    private boolean retryPossible;

    public ArchivalResult() {
        this.status = ArchivalStatus.SUCCESS;
        this.retryPossible = true;
    }

    public ArchivalStatus getStatus() {
        return status;
    }

    public void setStatus(ArchivalStatus status) {
        this.status = status;
    }



    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    public boolean isRetryPossible() {
        return retryPossible;
    }

    public void isRetryPossible(boolean canRetry) {
        this.retryPossible = canRetry;
    }

}
