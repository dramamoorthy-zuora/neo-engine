package com.zuora.neo.engine.jobs.transferaccounting.db.api;

import java.util.Date;

public class FxGainLossRecord {
    private Long sobId;
    private Long ledgerId;
    private String currencyCode;
    private String periodName;
    private Double entDiffAmount;
    private Double accDiffAmount;
    private Date currencyConversionDate;

    public FxGainLossRecord(Long sobId, Long ledgerId, String currencyCode, String periodName, Date currencyConversionDate,
            Double entDiffAmount, Double accDiffAmount) {
        this.sobId = sobId;
        this.ledgerId = ledgerId;
        this.currencyCode = currencyCode;
        this.periodName = periodName;
        this.currencyConversionDate = currencyConversionDate == null ? null : new Date(currencyConversionDate.getTime());
        this.entDiffAmount = entDiffAmount;
        this.accDiffAmount = accDiffAmount;
    }

    public Long getSobId() {
        return sobId;
    }

    public Long getLedgerId() {
        return ledgerId;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public String getPeriodName() {
        return periodName;
    }

    public Double getEntDiffAmount() {
        return entDiffAmount;
    }

    public Double getAccDiffAmount() {
        return accDiffAmount;
    }

    public Date getCurrencyConversionDate() {
        return currencyConversionDate == null ? currencyConversionDate : new Date(currencyConversionDate.getTime());
    }
}
