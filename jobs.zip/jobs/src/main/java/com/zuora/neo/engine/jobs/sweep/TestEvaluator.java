package com.zuora.neo.engine.jobs.sweep;

import com.zuora.neo.engine.test.NeoTestContext;

public class TestEvaluator {

    public static final String INVALID_PERIOD_KEY = "simulatePeriodNotPresent";

    public static final String TRANSACTION_ERROR = "simulateTransactionError";

    public static Long evaluateForInvalidPeriod(Long periodId) {
        if (NeoTestContext.isIntegrationTesting()) {
            Object simulatePeriodNotPresent = NeoTestContext.getTestVariable(INVALID_PERIOD_KEY);
            if (simulatePeriodNotPresent != null && (Boolean) simulatePeriodNotPresent.equals(Boolean.TRUE)) {
                return null;
            }
        }
        return periodId;
    }

    public static boolean evaluateForTransactionError() {
        if (NeoTestContext.isIntegrationTesting()) {
            Object simulateTransactionError = NeoTestContext.getTestVariable(TRANSACTION_ERROR);
            if (simulateTransactionError != null && (Boolean) simulateTransactionError.equals(Boolean.TRUE)) {
                return true;
            }
        }
        return false;
    }
}
