package com.zuora.neo.engine.jobs.sfc.db.mapper;

import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SfcStatusValuesMapper implements RowMapper<SfcStatusValues> {

    @Override
    public SfcStatusValues map(ResultSet rs, StatementContext ctx) throws SQLException {
        return new SfcStatusValues(rs.getString("doc_num"), rs.getString("doc_line_id"), rs.getString("status"), rs.getLong("rc_id"),
                rs.getLong("line_id"), rs.getBigDecimal("net_npv_amt"), rs.getBigDecimal("net_interest_accrual"), rs.getDate("rip_date"),
                rs.getString("error_msg"), rs.getBigDecimal("rip_amt"), rs.getString("indicators"));
    }
}
