package com.zuora.neo.engine.jobs.rtp.constants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class RtpParams {

    public static final String ERRORS_ONLY = "ERRORS_ONLY";

    public static final String ERRORS_ONLY_DEFAULT = "N";
    public static final String RC_IDS = "RC_IDS";
    public static final String RC_IDS_DELIMITER = ",";

    private String errorsOnly;
    private String rcIdsString;


    public RtpParams(Map<String, String> paramsMap) {
        this.errorsOnly = paramsMap.get(ERRORS_ONLY).length() > 0 ? paramsMap.get(ERRORS_ONLY) : ERRORS_ONLY_DEFAULT;
        this.rcIdsString = paramsMap.get(RC_IDS);
    }

    public String getErrorsOnly() {
        return errorsOnly;
    }

    public void setErrorsOnly(String errorsOnly) {
        this.errorsOnly = errorsOnly;
    }

    public String getRcIdsString() {
        return rcIdsString;
    }

    public void setRcIdsString(String rcIdsString) {
        this.rcIdsString = rcIdsString;
    }

    public List<Integer> getRcIds() {
        List<Integer> rcIds = new ArrayList<>();
        if (rcIdsString != null && rcIdsString.length() > 0) {
            rcIds = Arrays.stream(rcIdsString.split(RC_IDS_DELIMITER)).map(Integer::parseInt).collect(Collectors.toList());
        }
        return rcIds;
    }

    public Boolean isErrorsOnly() {
        return (errorsOnly != null && errorsOnly.equals("Y"));
    }

    @Override
    public String toString() {
        return "RtpParams{"
                + "errorsOnly='" + errorsOnly + '\''
                + ", rcIdsString='" + rcIdsString + '\''
                + '}';
    }
}
