package com.zuora.neo.engine.common.indicators;

import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

public class Indicators<T extends Enum<T> & IndicatorEnum> {

    private char[] indicatorByte;
    private final Class<T> enumClass;
    private final int indicatorSize;

    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(Indicators.class);


    public Indicators(Class<T> enumClass) {
        this.enumClass = enumClass;
        this.indicatorSize = enumClass.getEnumConstants()[0].getSize();
        this.fillIndicators();
    }


    public void resetToDefault() {
        this.fillIndicators();
    }


    public static <T extends Enum<T> & IndicatorEnum> Indicators valueOf(Class<T> enumClass, String val) {
        int indicatorSize = enumClass.getEnumConstants()[0].getSize();
        if (val.length() != indicatorSize) {
            logger.warn("Supplied val doesn't match with the indicator structure :" + val + "," + enumClass.getName());
        }

        Indicators<T> ind = new Indicators<>(enumClass);
        //copy only till what we want.If smaller it will be padded with default value.
        System.arraycopy(val.toCharArray(), 0, ind.indicatorByte, 0, val.length());
        return ind;
    }

    @Override
    public String toString() {
        return String.valueOf(this.indicatorByte);
    }

    public void setIndicator(T indicator, char v) {
        this.indicatorByte[indicator.getPosition()] = v;
    }

    public void setIndicators(List<FlagValuePair<T>> indicators) {
        indicators.forEach(indicatorPair -> this.setIndicator(indicatorPair.indicator, indicatorPair.val));
    }

    public char getIndicator(T indicator) {
        return this.indicatorByte[indicator.getPosition()];
    }

    private void fillIndicators() {
        T enumConstant = enumClass.getEnumConstants()[0];
        char[] defaultValue = enumConstant.getDefaultValue();
        indicatorByte = new char[indicatorSize];
        System.arraycopy(defaultValue, 0, indicatorByte, 0, defaultValue.length);

        if (enumConstant.getSize() > defaultValue.length) {
            //pad the unused flags with provided default value
            char unusedDefaultValue = enumConstant.getUnusedDefaultValue();
            Arrays.fill(indicatorByte, defaultValue.length, indicatorByte.length, unusedDefaultValue);
        }
    }

}

