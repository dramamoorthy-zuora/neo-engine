package com.zuora.neo.engine.jobs.caclnetting.db.dao;

import org.jdbi.v3.core.statement.OutParameters;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.Define;
import org.jdbi.v3.sqlobject.customizer.OutParameter;
import org.jdbi.v3.sqlobject.statement.SqlCall;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.math.BigDecimal;
import java.sql.Types;
import java.time.LocalDate;
import java.util.List;

public interface CaclNettingDao {

    @SqlQuery("SELECT MAX(prd_id) FROM <RPRO_RC_HEAD_PERIOD> WHERE prd_id < :currentPeriodId "
             + "AND book_id = :bookId AND client_id = :clientId and sec_atr_val = :secAtrVal")
    long getPreviousNettingPeriodId(@Define("RPRO_RC_HEAD_PERIOD") String rproRcHeadPeriod, @Bind("currentPeriodId") long currentPeriodId,
                                    @Bind("bookId") Long bookId, @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlUpdate("DELETE FROM <RPRO_CACL_NET_RC> WHERE batch_id = :batchId "
            + "AND book_id = :bookId AND client_id = :clientId AND sec_atr_val = :secAtrVal")
    void deleteNetRc(@Bind("batchId") BigDecimal batchId, @Define("RPRO_CACL_NET_RC") String rproCaclNetRc, @Bind("bookId") Long bookId,
                    @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlQuery("SELECT rpro_utility_pkg.generate_id('RPRO_RC_BATCH_ID_S', :clientId) FROM dual")
    BigDecimal getBatchId(@Bind("clientId") Long clientId);

    @SqlQuery("SELECT COUNT(*) FROM rpro_rc_head WHERE id = :rcId")
    int getRcId(@Bind("rcId") Long rcId);

    @SqlCall("{call RPRO_RC_PRD_DEFBAL_PKG.rc_head_open_prd_defbal(:errorBuffer, :retCode, :periodName, :orgId, "
             + ":bookName, :createLineLevel, :rcId, :fullRefresh)}")
    @OutParameter(name = "errorBuffer", sqlType = Types.VARCHAR)
    @OutParameter(name = "retCode", sqlType = Types.INTEGER)
    OutParameters performNettingProcedure(@Bind("periodName") String periodName, @Bind("orgId") String orgId, @Bind("bookName") String bookName,
                                          @Bind("createLineLevel") String createLineLevel, @Bind("rcId") Long rcId, @Bind("fullRefresh") String fullRefresh);

    @SqlUpdate("INSERT INTO <RPRO_CACL_NET_RC> (batch_id, rc_id, book_id, crtd_dt, updt_dt, processed_flag, "
             + "process_start_dt, "
            + "sec_atr_val, client_id, delta_calculation) "
            + "SELECT :batchId, id rc_id, book_id, sysdate crtd_dt, sysdate updt_dt, 'N', sysdate process_start_dt, "
            + "sec_atr_val, client_id, "
            + "CASE WHEN EXISTS (SELECT 1 FROM <RPRO_RC_HEAD_PERIOD> rrhp WHERE rrhp.rc_id = hd.id AND  "
            + "rrhp.prd_id = :prevNettingPrdId) THEN 'Y' ELSE 'N' END delta_calculation "
            + "FROM rpro_rc_head hd "
            + "WHERE (EXISTS(SELECT 1 FROM rpro_rc_schd schd WHERE "
            + "rc_id = hd.id "
            + "AND book_id = hd.book_id "
            + "AND client_id = hd.client_id "
            + "AND sec_atr_val = hd.sec_atr_val "
            + "AND (rpro_rc_schd_pkg.get_schd_type_flag(indicators) IN (<schd_types>) "
            + "OR rpro_rc_schd_pkg.get_schd_type_flag(indicators) = :nettingSchd) "
            + "AND ((:fullRefresh = 'N' AND (post_prd_id <= :prdId "
            + "AND (:prevNettingPrdId IS NULL OR post_prd_id > :prevNettingPrdId))) "
            + "OR (:fullRefresh = 'Y' AND post_prd_id <= :prdId))) "
            + "OR EXISTS(SELECT 1 FROM <RPRO_RC_HEAD_PERIOD> hp WHERE "
            + "hp.rc_id = hd.id "
            + "AND hp.book_id = hd.book_id "
            + "AND hp.client_id = hd.client_id "
            + "AND hp.ca_amt <> 0 "
            + "AND hp.prd_id = (SELECT MAX(prd_id) FROM <RPRO_RC_HEAD_PERIOD> WHERE "
            + "hp.rc_id = hd.id "
            + "AND hp.book_id = hd.book_id "
            + "AND hp.client_id = hd.client_id "
            + "AND (hp.ca_amt <> 0 OR hp.cl_amt <> 0) "
            + "AND hp.prd_id < :prdId))) "
            + "AND hd.book_id = :bookId AND hd.sec_atr_val = :secAtrVal AND hd.client_id = :clientId")
    int insertRcForCurrentPeriod(@Define("schd_types") String schdTypes, @Bind("prdId") long prdId,
                                 @Bind("prevNettingPrdId") Long prevNettingPrdId, @Bind("batchId") BigDecimal batchId,
                                 @Bind("nettingSchd") String nettingSchd,
                                 @Define("RPRO_CACL_NET_RC") String rproCaclNetRc,
                                 @Define("RPRO_RC_HEAD_PERIOD") String rproRcHeadPeriod,
                                 @Bind("fullRefresh") String fullRefresh,
                                 @Bind("bookId") long bookId, @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlUpdate("INSERT INTO <RPRO_CACL_NET_RC> (batch_id, rc_id, book_id, crtd_dt, updt_dt, process_start_dt, "
            + "processed_flag, sec_atr_val, client_id, delta_calculation) "
            + "SELECT :batchId, id RC_ID, book_id, sysdate crtd_dt, sysdate updt_dt, sysdate process_start_dt, 'N', "
            + "sec_atr_val, client_id, "
            + "CASE WHEN EXISTS (SELECT 1 FROM <RPRO_RC_HEAD_PERIOD> rrhp WHERE rrhp.rc_id = hd.id AND  "
            + "rrhp.prd_id = :prevNettingPrdId) THEN 'Y' ELSE 'N' END delta_calculation "
            + "FROM rpro_rc_head hd "
            + "WHERE id = :rcId AND book_id = :bookId AND sec_atr_val = :secAtrVal AND client_id = :clientId")
    int insertNettingRcForGivenRc(@Bind("rcId") long rcId, @Bind("prdId") long prdId,
                                  @Bind("prevNettingPrdId") long prevNettingPrdId, @Bind("batchId") BigDecimal batchId,
                                  @Define("RPRO_CACL_NET_RC") String rproCaclNetRc, @Define("RPRO_RC_HEAD_PERIOD") String rproRcHeadPeriod,
                                  @Bind("bookId") long bookId, @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlQuery("SELECT DISTINCT book_id FROM rpro_rtp_wi_header WHERE batch_id = :batchId AND status = :headerStatus "
                + "AND sec_atr_val = :secAtrVal")
    List<Long> getUniqueBookIdsForRtpBatch(@Bind("batchId") BigDecimal batchId, @Bind("headerStatus") String headerStatus,
                                           @Bind("secAtrVal") String secAtrVal);

    @SqlUpdate("INSERT INTO <RPRO_CACL_NET_RC> "
            + "(batch_id, rc_id, book_id, crtd_dt, updt_dt, process_start_dt, "
            + "processed_flag, sec_atr_val, client_id, delta_calculation) "
            + "SELECT :batchId, header.rc_id, header.book_id, SYSDATE crtd_dt, SYSDATE updt_dt, SYSDATE process_start_dt, "
            + "'N', header.sec_atr_val, header.client_id, "
            + "CASE WHEN EXISTS (SELECT 1 FROM <RPRO_RC_HEAD_PERIOD> WHERE rc_id = header.rc_id AND prd_id = :prevNettingPrdId) "
            + "THEN 'Y' ELSE 'N' END "
            + "FROM rpro_rtp_wi_header header "
            + "WHERE header.batch_id = :batchId AND header.status = :headerStatus")
    int populateRealtimeNettingRc(@Bind("prdId") long prdId, @Bind("prevNettingPrdId") long prevNettingPrdId, @Bind("batchId") BigDecimal batchId,
                                  @Bind("headerStatus") String headerStatus,
                                  @Define("RPRO_CACL_NET_RC") String rproCaclNetRc, @Define("RPRO_RC_HEAD_PERIOD") String rproRcHeadPeriod);

    @SqlUpdate("INSERT INTO <RPRO_CACL_NET_RC> (batch_id, rc_id, book_id, "
            + "crtd_dt, updt_dt, processed_flag, "
            + "process_start_dt, "
            + "sec_atr_val, client_id) "
            + "SELECT :batchId, rrhp.rc_id, rrhp.book_id,  "
            + "       SYSDATE crtd_dt, SYSDATE updt_dt, 'N',"
            + "       SYSDATE process_start_dt, "
            + "       rrhp.sec_atr_val, rrhp.client_id "
            + "FROM <RPRO_RC_HEAD_PERIOD> rrhp "
            + "WHERE NOT EXISTS(SELECT 1 "
            + "                 FROM <RPRO_RC_HEAD_PERIOD> rrhpi "
            + "                 WHERE rrhpi.rc_id = rrhp.rc_id "
            + "                   AND rrhpi.prd_id = :prdId) "
            + "  AND rrhp.rc_id NOT IN (SELECT rcnr.rc_id FROM <RPRO_CACL_NET_RC> rcnr WHERE rcnr.batch_id = :batchId) "
            + "  AND rrhp.prd_id = :prevNettingPrdId AND (rrhp.ca_amt <> 0 OR rrhp.cl_amt <> 0)  "
            + "AND rrhp.book_id = :bookId AND rrhp.client_id = :clientId AND rrhp.sec_atr_val = :secAtrVal")
    int insertCarryForwardEntries(@Bind("prdId") long prdId, @Bind("prevPrdId") long prevPrdId,
                                  @Bind("prevNettingPrdId") Long prevNettingPrdId, @Bind("batchId") BigDecimal batchId,
                                  @Bind("user") String user, @Define("RPRO_CACL_NET_RC") String rproCaclNetRc,
                                  @Define("RPRO_RC_HEAD_PERIOD") String rproRcHeadPeriod, @Bind("bookId") Long bookId,
                                  @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlUpdate("DELETE FROM rpro_rc_line_period "
            + "WHERE rc_id IN (SELECT rc_id FROM <RPRO_CACL_NET_RC> WHERE batch_id = :batchId AND book_id = :bookId "
            + "   AND sec_atr_val = :secAtrVal) "
            + "AND prd_id = :prdId AND book_id = :bookId AND sec_atr_val = :secAtrVal")
    int cleanIntermediateEntries(@Bind("prdId") long prdId, @Bind("batchId") BigDecimal batchId,
                                 @Define("RPRO_CACL_NET_RC") String rproCaclNetRc, @Bind("bookId") Long bookId,
                                 @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlUpdate("INSERT INTO rpro_rc_line_period (id, rc_id, line_id, book_id, client_id, company_code, "
            + "sec_atr_val, prd_id, def_segments, asst_acct_seg, "
            + "net_cr_acct, crtd_dt, crtd_by, updt_dt, updt_by, "
            + "amount, curr, f_curr, f_ex_rate, g_ex_rate, ex_rate_date, rc_ver, curr_prd_schd) "
            + "SELECT rpro_utility_pkg.generate_id('rpro_rc_line_period_id_s', q.client_id), "
            + "       q.rc_id, "
            + "       q.line_id, "
            + "       q.book_id, "
            + "       q.client_id, "
            + "       q.company_code, "
            + "       q.sec_atr_val, "
            + "       :prdId, "
            + "       CASE WHEN q.net_cr_acct = 'L' THEN rpro_utility_pkg.get_acct_sgmts_wrapper(q.line_id, :liabilityAccount) "
            + "       ELSE rpro_utility_pkg.get_acct_sgmts_wrapper(q.line_id, :adjustmentLiabilityAccount) END def_segments, "
            + "       rpro_utility_pkg.get_acct_sgmts_wrapper(q.line_id, :assetAccount)     asst_acct_seg, "
            + "       q.net_cr_acct, "
            + "       SYSDATE                                                               crtd_dt, "
            + "       :user                                                                 crtd_by, "
            + "       SYSDATE                                                               updt_dt, "
            + "       :user                                                                 updt_by, "
            + "       CASE "
            + "           WHEN (q.multi_curr_flag <> 'N') "
            + "               THEN SUM(net_amount * "
            + "                        NVL(CASE WHEN q.net_cr_acct = 'W' THEN q.schd_f_ex_rate ELSE q.line_f_ex_rate END, 1)) "
            + "           ELSE SUM(net_amount) "
            + "           END                                                               amount, "
            + "       CASE "
            + "           WHEN (q.multi_curr_flag <> 'N') "
            + "               THEN q.f_cur "
            + "           ELSE q.curr "
            + "           END                                                               curr, "
            + "       q.f_cur, "
            + "       CASE "
            + "           WHEN (q.multi_curr_flag <> 'N') THEN 1 "
            + "           WHEN q.net_cr_acct = 'W' THEN MAX(q.schd_f_ex_rate) "
            + "           ELSE q.line_f_ex_rate "
            + "           END                                                               f_ex_rate, "
            + "       CASE WHEN q.net_cr_acct = 'W' THEN MAX(q.schd_g_ex_rate) ELSE q.line_g_ex_rate END g_ex_rate, "
            + "       CASE WHEN q.net_cr_acct = 'W' THEN MAX(q.schd_ex_rate_date) ELSE q.line_ex_rate_date END ex_rate_date, "
            + "       q.version, "
            + "       'Y'                                                                   curr_prd_schd "
            + "FROM (SELECT /*+ no_expand leading(rcnr) use_nl( rcnr, hd, l, acctg.rrs) "
            + "             INDEX(hd, RPRO_RC_HEAD_N1) INDEX(l, rpro_rc_line_n1), INDEX(acctg, rpro_rc_schd_i3) */ "
            + "             rrl.rc_id, "
            + "             rrl.id                                line_id, "
            + "             rrl.book_id, "
            + "             rrl.client_id, "
            + "             NVL(rrl.company_code, 'X')            company_code, "
            + "             rrl.sec_atr_val, "
            + "             :prdId, "
            + "             CASE "
            + "                 WHEN acctg.schd_type IN (:interCompany, :allocation) OR "
            + "                      (acctg.schd_type = :mje AND acctg.acctg_type = :adjustmentLiabilityAccount) "
            + "                                     THEN :adjustmentLiabilityAccount "
            + "                 ELSE :liabilityAccount "
            + "                 END                             net_cr_acct, "
            + "             (acctg.cr_amount - acctg.dr_amount) net_amount, "
            + "             rrl.curr, "
            + "             rrl.f_cur, "
            + "             rrl.f_ex_rate                         line_f_ex_rate, "
            + "             acctg.f_ex_rate                     schd_f_ex_rate, "
            + "             rrl.g_ex_rate                         line_g_ex_rate, "
            + "             acctg.g_ex_rate                     schd_g_ex_rate, "
            + "             rrl.doc_date                          line_ex_rate_date, "
            + "             acctg.ex_rate_date                  schd_ex_rate_date, "
            + "             hd.version                             version, "
            + "             rpro_rc_head_pkg.get_multi_currency_flag(hd.indicators) multi_curr_flag "
            + "      FROM rpro_rc_cacl_net_schd_v acctg, "
            + "           rpro_acct_type rat, "
            + "           rpro_rc_line rrl, "
            + "           <RPRO_CACL_NET_RC> rcnr, "
            + "           rpro_rc_head hd "
            + "      WHERE hd.id = rcnr.rc_id  "
            + "        AND rrl.rc_id = rcnr.rc_id "
            + "        AND rcnr.batch_id = :batchId "
            + "        AND rrl.book_id = rcnr.book_id "
            + "        AND acctg.root_line_id = rrl.id "
            + "        AND acctg.acctg_type = rat.id "
            + "        AND acctg.schd_type IN (<schd_types>) "
            + "        AND ((rcnr.delta_calculation = 'N' AND acctg.post_prd_id <= :prdId) "
            + "          OR (rcnr.delta_calculation = 'Y' AND "
            + "             acctg.post_prd_id > NVL(:prevNettingPrdId, :prevPrdId) AND acctg.post_prd_id <= :prdId)) "
            + "        AND ((acctg.schd_type != :variableConsideration "
            + "          AND rpro_acct_type_pkg.get_balance_sheet_account_flag(rat.indicators) = 'Y' "
            + "          AND rpro_acct_type_pkg.get_include_in_netting_flag(rat.indicators) = 'Y') "
            + "          OR (acctg.schd_type = :variableConsideration "
            + "              AND acctg.acctg_type = :liabilityAccount "
            + "              AND EXISTS( "
            + "                      SELECT 1 "
            + "                      FROM rpro_rc_line_pa ra, "
            + "                           rpro_vc_type vt "
            + "                      WHERE ra.line_id = rrl.id "
            + "                        AND vt.id = ra.vc_type_id "
            + "                        AND rpro_vc_type_pkg.get_enable_cacl_flag(vt.indicators) = 'Y'))) "
            + "        AND rcnr.book_id = :bookId "
            + "        AND rcnr.client_id = :clientId "
            + "        AND rcnr.sec_atr_val = :secAtrVal) q "
            + "GROUP BY q.version, q.net_cr_acct, q.rc_id, q.line_id, q.book_id, q.company_code, q.client_id, q.sec_atr_val, "
            + "         q.multi_curr_flag, q.curr, q.line_f_ex_rate, q.line_g_ex_rate, q.line_ex_rate_date, q.f_cur")
    int insertIntoIntermediateTable(@Bind("prdId") long prdId, @Bind("prevPrdId") long prevPrdId,
                                    @Bind("prevNettingPrdId") Long prevNettingPrdId,
                                    @Bind("liabilityAccount") String liabilityAccount, @Bind("assetAccount") String assetAccount,
                                    @Bind("interCompany") String interCompany, @Bind("allocation") String allocation,
                                    @Bind("mje") String mje, @Bind("adjustmentLiabilityAccount") String adjustmentLiabilityAccount,
                                    @Bind("nettingSchd") String nettingSchd, @Bind("variableConsideration") String variableConsiderationSchd,
                                    @Define("schd_types") String schdTypes, @Bind("batchId") BigDecimal batchId,
                                    @Bind("reportingCurr") String reportingCurr,
                                    @Bind("user") String user, @Define("RPRO_CACL_NET_RC") String rproCaclNetRc,
                                    @Define("RPRO_RC_HEAD_PERIOD") String rproRcHeadPeriod, @Bind("bookId") Long bookId,
                                    @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlUpdate("MERGE INTO rpro_rc_line_period t1 "
            + "USING (SELECT rrlp.rc_id, rrlp.line_id, rrlp.book_id, rrlp.client_id, rrlp.company_code, "
            + "              rrlp.sec_atr_val, rrlp.prd_id, rrlp.def_segments, rrlp.asst_acct_seg, "
            + "              rrlp.net_cr_acct, :user crtd_by, :user updt_by, SYSDATE crtd_dt, SYSDATE updt_dt, "
            + "              CASE "
            + "                  WHEN rpro_rc_head_pkg.get_multi_currency_flag(hd.indicators) = 'N' THEN rrlp.amount "
            + "                  ELSE rrlp.amount * NVL(rrlp.f_ex_rate, 1) "
            + "              END amount, "
            + "              CASE "
            + "                  WHEN rpro_rc_head_pkg.get_multi_currency_flag(hd.indicators) = 'N' THEN rrlp.curr "
            + "                  ELSE rrlp.f_curr "
            + "              END curr, "
            + "              rrlp.f_curr, "
            + "              CASE "
            + "                  WHEN rpro_rc_head_pkg.get_multi_currency_flag(hd.indicators) = 'N' THEN rrlp.f_ex_rate "
            + "                  ELSE 1 "
            + "              END f_ex_rate, "
            + "              rrlp.g_ex_rate, rrlp.ex_rate_date, rrlp.rc_ver "
            + "       FROM rpro_rc_line_period rrlp, "
            + "            rpro_rc_head hd, "
            + "            <RPRO_CACL_NET_RC> rcnr "
            + "       WHERE rrlp.rc_id = rcnr.rc_id "
            + "         AND rcnr.batch_id = :batchId "
            + "         AND rrlp.rc_id = hd.id "
            + "         AND rrlp.prd_id = :prevNettingPrdId "
            + "         AND rrlp.book_id = :bookId "
            + "         AND rrlp.client_id = :clientId "
            + "         AND rrlp.sec_atr_val = :secAtrVal) t2 "
            + "ON (t1.line_id = t2.line_id AND t1.net_cr_acct = t2.net_cr_acct AND t1.prd_id = :prdId) "
            + "WHEN MATCHED THEN "
            + "    UPDATE "
            + "    SET t1.amount = t1.amount + t2.amount, "
            + "        t1.updt_by = :user, "
            + "        t1.updt_dt = SYSDATE "
            + "WHEN NOT MATCHED THEN "
            + "    INSERT (id, rc_id, line_id, book_id, client_id, company_code, "
            + "            sec_atr_val, prd_id, def_segments, asst_acct_seg, "
            + "            net_cr_acct, crtd_dt, crtd_by, updt_dt, updt_by, "
            + "            amount, curr, f_curr, f_ex_rate, g_ex_rate, ex_rate_date, rc_ver, curr_prd_schd) "
            + "    VALUES (rpro_utility_pkg.generate_id('rpro_rc_line_period_id_s', t2.client_id), "
            + "            t2.rc_id, t2.line_id, t2.book_id, t2.client_id, t2.company_code, "
            + "            t2.sec_atr_val, :prdId, t2.def_segments, t2.asst_acct_seg, "
            + "            t2.net_cr_acct, SYSDATE, :user, SYSDATE, :user, "
            + "            t2.amount, t2.curr, t2.f_curr, t2.f_ex_rate, t2.g_ex_rate, t2.ex_rate_date, t2.rc_ver, 'N')")
    int updateWithPriorPeriodAmounts(@Bind("prdId") long prdId, @Bind("prevPrdId") long prevPrdId,
                                     @Bind("prevNettingPrdId") Long prevNettingPrdId,
                                     @Bind("batchId") BigDecimal batchId, @Bind("user") String user,
                                     @Define("RPRO_CACL_NET_RC") String rproCaclNetRc, @Bind("bookId") Long bookId,
                                    @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlUpdate("INSERT INTO <RPRO_RC_HEAD_PERIOD> (id, rc_id, book_id, client_id, prd_id, ca_amt, cl_amt, "
            + "indicators, crtd_prd_id, "
            + "curr, f_cur, f_ex_rate, g_ex_rate, ex_rate_date, "
            + "crtd_by, crtd_dt, updt_by, updt_dt, start_date, end_date, "
            + "sec_atr_val, company_code) "
            + "SELECT "
            + "    rpro_utility_pkg.generate_id(:headPeriodSequence, client_id) ID, "
            + "    rc_id, book_id, client_id, prd_id, "
            + "    CASE "
            + "        WHEN (amount < 0 AND positive_rc = 1) THEN ROUND(abs(amount), NVL(c.rounding, 2)) "
            + "        ELSE 0 "
            + "    END ca_amt, "
            + "    CASE "
            + "        WHEN (amount > 0) OR (amount < 0 AND positive_rc = 0) THEN ROUND(abs(amount), NVL(c.rounding, 2)) "
            + "        ELSE 0 "
            + "    END cl_amt, "
            + "    CASE "
            + "        WHEN positive_rc = 0 THEN rpro_rc_head_period_pkg.set_multiple_flag(:defaultIndicator, 'RC_ALL_NEGAMT:Y') "
            + "        WHEN amount < 0 THEN rpro_rc_head_period_pkg.set_multiple_flag(:defaultIndicator, 'CA_BAL:Y') "
            + "        ELSE :defaultIndicator "
            + "   END indicators, "
            + "   crtd_prd_id, curr, f_curr, f_ex_rate, g_ex_rate, ex_rate_date, crtd_by, crtd_dt, updt_by, updt_dt, "
            + "   start_date, end_date, "
            + "   sec_atr_val,  company_code "
            + "FROM "
            + "    ( "
            + "        SELECT "
            + "            rrlp.rc_id, rrlp.book_id, rrlp.client_id, rrlp.prd_id, SUM(amount) amount, "
            + "            rrlp.prd_id crtd_prd_id, MAX(curr) curr, f_curr, MAX(f_ex_rate) f_ex_rate, MAX(g_ex_rate) g_ex_rate, "
            + "            MAX(rrlp.ex_rate_date) ex_rate_date, "
            + "            :user crtd_by, SYSDATE crtd_dt, :user updt_by, SYSDATE updt_dt, "
            + "            :startDate start_date, :endDate end_date, rrlp.sec_atr_val, rrlp.company_code, "
            + "                 (SELECT count(*) "
            + "                FROM dual "
            + "                WHERE EXISTS ( "
            + "                              SELECT 1 "
            + "                              FROM RPRO_RC_LINE "
            + "                              WHERE EXT_SLL_PRC > 0 AND RC_ID = rrlp.RC_ID "
            + "                          ) "
            + "            ) positive_rc "
            + "        FROM "
            + "            rpro_rc_line_period rrlp, <RPRO_CACL_NET_RC> rcnr "
            + "        WHERE "
            + "                rrlp.rc_id = rcnr.rc_id AND rrlp.book_id = rcnr.book_id AND rrlp.prd_id = :prdId "
            + "          AND rcnr.batch_id = :batchId AND rrlp.client_id = rcnr.client_id AND rrlp.sec_atr_val = rcnr.sec_atr_val "
            + "          AND rcnr.book_id = :bookId AND rcnr.client_id = :clientId AND rcnr.sec_atr_val = :secAtrVal"
            + "        GROUP BY "
            + "             rrlp.rc_id, rrlp.book_id, rrlp.prd_id, rrlp.company_code, rrlp.client_id, rrlp.sec_atr_val, "
            + "             rrlp.f_curr"
            + "    ) q, rpro_currency_setup c "
            + "WHERE "
            + "     q.curr = c.currency_code "
            + "     AND (q.amount <> 0 "
            + "            OR EXISTS( "
            + "            SELECT 1 "
            + "            FROM rpro_rc_line_period rrlp "
            + "            WHERE rrlp.rc_id = q.rc_id AND rrlp.prd_id = q.prd_id AND rrlp.book_id = q.book_id "
            + "              AND rrlp.curr_prd_schd = 'Y' "
            + "              AND rrlp.client_id = q.client_id AND rrlp.sec_atr_val = q.sec_atr_val) "
            + ") ")
    int insertNettingHeader(@Bind("user") String user, @Bind("prdId") long prdId,
                            @Bind("startDate") LocalDate startDate, @Bind("endDate") LocalDate endDate,
                            @Bind("batchId") BigDecimal batchId, @Bind("defaultIndicator") String defaultIndicator,
                            @Define("RPRO_CACL_NET_RC") String rproCaclNetRc, @Define("RPRO_RC_HEAD_PERIOD") String rproRcHeadPeriod,
                            @Bind("headPeriodSequence") String headPeriodSequence, @Bind("bookId") Long bookId,
                            @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlUpdate("MERGE INTO <RPRO_RC_HEAD_PERIOD> rrhp "
            + "USING (SELECT rc_id, "
            + "              CASE WHEN amount < 0 THEN 'Y' ELSE 'N' END ca_bal_flag "
            + "       FROM (SELECT rrlp.rc_id, "
            + "                 CASE WHEN rpro_rc_head_pkg.get_multi_currency_flag(hd.indicators) = 'R' "
            + "                 THEN ROUND(SUM(rrlp.amount * NVL(rrlp.f_ex_rate, 1) * NVL(rrlp.g_ex_rate, 1)), NVL(c.rounding, 2)) "
            + "                 WHEN rpro_rc_head_pkg.get_multi_currency_flag(hd.indicators) = 'F' "
            + "                 THEN ROUND(SUM(rrlp.amount * NVL(rrlp.f_ex_rate, 1)), NVL(c.rounding, 2)) "
            + "                 ELSE ROUND(SUM(rrlp.amount), NVL(c.rounding, 2)) END amount"
            + "             FROM rpro_rc_line_period rrlp, "
            + "                  <RPRO_CACL_NET_RC> rcnr, "
            + "                  rpro_currency_setup c, "
            + "                  <RPRO_RC_HEAD_PERIOD> rrhpi, rpro_rc_head hd "
            + "             WHERE rrlp.rc_id = rcnr.rc_id AND rrhpi.rc_id = rcnr.rc_id "
            + "               AND hd.id = rcnr.rc_id AND c.currency_code = rrhpi.curr "
            + "               AND rrhpi.prd_id = rrlp.prd_id AND rrlp.prd_id = :prdId "
            + "               AND rpro_rc_head_period_pkg.get_rc_all_negamt_flag(rrhpi.indicators) = 'N' "
            + "               AND rrlp.book_id = :bookId AND rrlp.client_id = :clientId AND rrlp.sec_atr_val = :secAtrVal"
            + "             GROUP BY rrlp.rc_id, rpro_rc_head_pkg.get_multi_currency_flag(hd.indicators), c.rounding)) src "
            + "ON (rrhp.rc_id = src.rc_id AND rrhp.prd_id = :prdId) "
            + "WHEN MATCHED THEN "
            + "    UPDATE SET indicators = rpro_rc_head_period_pkg.set_ca_bal_flag(indicators, src.ca_bal_flag)")
    void updateHeaderCaBalFlag(@Bind("user") String user, @Bind("prdId") long prdId,
                              @Define("RPRO_CACL_NET_RC") String rproCaclNetRc, @Define("RPRO_RC_HEAD_PERIOD") String rproRcHeadPeriod,
                              @Bind("bookId") Long bookId,
                              @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlUpdate("INSERT INTO <RPRO_RC_SCHD> (id, rc_id, line_id, amount, indicators, "
            + "cr_segments, dr_segments, "
            + "curr, f_ex_rate, g_ex_rate, ex_rate_date, "
            + "prd_id, post_prd_id, crtd_prd_id, "
            + "rc_ver, crtd_by, crtd_dt, updt_by, updt_dt, "
            + "root_line_id, book_id, client_id, sec_atr_val) "
            + "SELECT rpro_utility_pkg.generate_id(:scheduleSequence, rrlp.client_id), "
            + "rrlp.rc_id, line_id, -SUM(ROUND(amount, NVL(c.rounding, 2))) amount, "
            + "rpro_rc_schd_pkg.set_multiple_flag(:schedulesDefaultIndicator, "
            + ":commonFlags || "
            + "'#CR_ACCTG:' || rrlp.net_cr_acct) indicators, "
            + "def_segments, asst_acct_seg, "
            + "rrlp.curr, MAX(rrlp.f_ex_rate), MAX(rrlp.g_ex_rate), MAX(rrlp.ex_rate_date), "
            + "rrlp.prd_id, rrlp.prd_id, rrlp.prd_id, "
            + "rrlp.rc_ver, :user, SYSDATE, :user, SYSDATE, "
            + "line_id, rrlp.book_id, rrlp.client_id, rrlp.sec_atr_val "
            + "FROM rpro_rc_line_period rrlp, <RPRO_CACL_NET_RC> rcnr, <RPRO_RC_HEAD_PERIOD> rrhp, rpro_currency_setup c "
            + "WHERE rcnr.batch_id = :batchId AND rrlp.rc_id = rcnr.rc_id AND rrhp.rc_id = rcnr.rc_id "
            + "AND rpro_rc_head_period_pkg.get_ca_bal_flag(rrhp.indicators) = 'Y' AND rrlp.prd_id = :prdId "
            + "AND rrhp.prd_id = :prdId AND rrhp.company_code = rrlp.company_code AND rrlp.curr = c.currency_code "
            + "AND rrlp.book_id = rcnr.book_id AND rrhp.book_id = rrlp.book_id "
            + "AND rrlp.client_id = rcnr.client_id AND rrhp.client_id = rcnr.client_id "
            + "AND rrlp.sec_atr_val = rcnr.sec_atr_val AND rrhp.sec_atr_val = rcnr.sec_atr_val "
            + "AND rcnr.book_id = :bookId AND rcnr.client_id = :clientId AND rcnr.sec_atr_val = :secAtrVal "
            + "GROUP BY rrlp.rc_id, line_id, def_segments, asst_acct_seg, rrlp.curr, rrlp.prd_id, rrlp.sec_atr_val, "
            + "rrlp.book_id, rrlp.client_id, rrlp.rc_ver, rrlp.net_cr_acct "
            + "HAVING SUM(amount) != 0 "
            + "UNION ALL "
            + "SELECT rpro_utility_pkg.generate_id(:scheduleSequence, rrlp.client_id), "
            + "rrlp.rc_id, line_id, SUM(ROUND(amount, NVL(c.rounding, 2))) amount, "
            + "rpro_rc_schd_pkg.set_multiple_flag(:schedulesDefaultIndicator, "
            + ":commonFlags || "
            + "'#CR_ACCTG:' || rrlp.net_cr_acct || '#' || "
            + ":setNettingReversalFlag) indicators, "
            + "def_segments, asst_acct_seg, "
            + "rrlp.curr, MAX(rrlp.f_ex_rate), MAX(rrlp.g_ex_rate), MAX(rrlp.ex_rate_date), "
            + ":nextPrdId, :nextPrdId, rrlp.prd_id, "
            + "rrlp.rc_ver, :user, SYSDATE, :user, SYSDATE, "
            + "line_id, rrlp.book_id, rrlp.client_id, rrlp.sec_atr_val "
            + "FROM rpro_rc_line_period rrlp, <RPRO_CACL_NET_RC> rcnr, <RPRO_RC_HEAD_PERIOD> rrhp, rpro_currency_setup c "
            + "WHERE rcnr.batch_id = :batchId AND rrlp.rc_id = rcnr.rc_id AND rrhp.rc_id = rcnr.rc_id "
            + "AND rpro_rc_head_period_pkg.get_ca_bal_flag(rrhp.indicators) = 'Y' AND rrlp.prd_id = :prdId "
            + "AND rrhp.prd_id = :prdId AND rrhp.company_code = rrlp.company_code AND rrlp.curr = c.currency_code "
            + "AND rrlp.book_id = rcnr.book_id AND rrhp.book_id = rrlp.book_id "
            + "AND rrlp.client_id = rcnr.client_id AND rrhp.client_id = rcnr.client_id "
            + "AND rrlp.sec_atr_val = rcnr.sec_atr_val AND rrhp.sec_atr_val = rcnr.sec_atr_val "
            + "AND rcnr.book_id = :bookId AND rcnr.client_id = :clientId AND rcnr.sec_atr_val = :secAtrVal "
            + "GROUP BY rrlp.rc_id, line_id, def_segments, asst_acct_seg, rrlp.curr, rrlp.prd_id, rrlp.sec_atr_val, "
            + "rrlp.book_id, rrlp.client_id, rrlp.rc_ver, rrlp.net_cr_acct "
            + "HAVING SUM(amount) != 0")
    int insertNettingSchedules(@Bind("batchId") BigDecimal batchId, @Bind("user") String user, @Bind("prdId") long prdId,
                               @Bind("nextPrdId") long nextPrdId,
                               @Bind("assetAccount") String assetAccount, @Bind("nettingSchd") String nettingSchd,
                               @Bind("liabilityAccount") String liabilityAccount,
                               @Bind("adjustmentLiabilityAccount") String adjustmentLiabilityAccount,
                               @Bind("revenueSchd") String revenueSchd, @Bind("schedulesDefaultIndicator") String schedulesDefaultIndicator,
                               @Bind("commonFlags") String commonFlags, @Bind("setNettingReversalFlag") String setNettingReversalFlag,
                               @Define("RPRO_CACL_NET_RC") String rproCaclNetRc,
                               @Define("RPRO_RC_HEAD_PERIOD") String rproRcHeadPeriod,
                               @Define("RPRO_RC_SCHD") String rproRcSchd, @Bind("scheduleSequence") String scheduleSequence,
                               @Bind("bookId") Long bookId,
                               @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlUpdate("UPDATE <RPRO_CACL_NET_RC> SET process_end_dt = SYSDATE, updt_dt = SYSDATE, processed_flag = 'Y' "
            + "WHERE batch_id = :batchId")
    int updateRcStatusToComplete(@Bind("batchId") BigDecimal batchId, @Define("RPRO_CACL_NET_RC") String rproCaclNetRc,
                                 @Bind("bookId") Long bookId,
                                 @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlUpdate("DELETE FROM <RPRO_RC_HEAD_PERIOD> WHERE rc_id IN ( "
            + "SELECT rc_id "
            + "FROM <RPRO_CACL_NET_RC> rcnr "
            + "WHERE rcnr.batch_id = :batchId AND "
            + "rcnr.book_id = :bookId AND rcnr.client_id = :clientId AND rcnr.sec_atr_val = :secAtrVal) "
            + "AND prd_id = :prdId")
    int removeNettingHeaders(@Bind("batchId") BigDecimal batchId, @Bind("prdId") long prdId,
                             @Define("RPRO_CACL_NET_RC") String rproCaclNetRc, @Define("RPRO_RC_HEAD_PERIOD") String rproRcHeadPeriod,
                             @Bind("bookId") Long bookId,
                             @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlUpdate("DELETE FROM "
            + "    <RPRO_RC_SCHD> "
            + "WHERE "
            + "    id IN ( "
            + "        SELECT /*+ index(rrs, rpro_rc_schd_shadow_i1) index(rrl, rpro_rc_line_n1) */ "
            + "            rrs.id "
            + "        FROM "
            + "            <RPRO_CACL_NET_RC> rcnr, <RPRO_RC_SCHD> rrs, rpro_rc_line rrl "
            + "        WHERE "
            + "            rcnr.batch_id = :batchId "
            + "            AND rrl.rc_id = rcnr.rc_id "
            + "            AND rrs.root_line_id = rrl.id "
            + "            AND rpro_rc_schd_pkg.get_schd_type_flag(rrs.indicators) = :nettingSchd "
            + "            AND rpro_rc_schd_pkg.get_interfaced_flag(rrs.indicators) = 'N' "
            + "            AND ((rpro_rc_schd_pkg.get_reversal_flag(rrs.indicators) = 'N' "
            + "                AND rrs.post_prd_id = :prdId) "
            + "                    OR  "
            + "                (rpro_rc_schd_pkg.get_reversal_flag(rrs.indicators) = :reversalFlag "
            + "                AND rrs.post_prd_id = :nextPrdId) "
            + "            ) "
            + "            AND rrs.book_id = rcnr.book_id "
            + "            AND rrs.sec_atr_val = rcnr.sec_atr_val "
            + "            AND rrs.book_id = :bookId "
            + "            AND rrs.client_id = :clientId "
            + "            AND rrs.sec_atr_val = :secAtrVal)")
    int deleteUnpostedSchedules(@Bind("batchId") BigDecimal batchId, @Bind("prdId") long prdId, @Bind("nextPrdId") long nextPrdId,
                                 @Bind("nettingSchd") String nettingSchd, @Bind("reversalFlag") String reversalFlag,
                                 @Define("RPRO_CACL_NET_RC") String rproCaclNetRc, @Define("RPRO_RC_SCHD") String rproRcSchd,
                                 @Bind("bookId") Long bookId, @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlUpdate("INSERT INTO <RPRO_RC_SCHD> "
            + "(id, rel_id, rc_id, rc_ver, line_id, pob_id, curr, amount, rel_pct, "
            + "indicators, "
            + "post_date, prd_id, post_prd_id, post_batch_id, dr_segments, cr_segments, "
            + "f_ex_rate, g_ex_rate, atr1, atr2, atr3, atr4, atr5, client_id, crtd_prd_id, sec_atr_val, crtd_by, crtd_dt, updt_by, updt_dt, "
            + "dist_id, ref_bill_id, root_line_id, book_id, bld_fx_dt, bld_fx_rate, "
            + "rord_inv_ref, orig_line_id, dr_link_id, cr_link_id, model_id, je_batch_id, je_batch_name, pp_amt, pq_amt, py_amt, updt_prd_id, schd_addl_id) "
            + "SELECT /*+ index(rrs, RPRO_RC_SCHD_SHADOW_I1) index(rrl, rpro_rc_line_n1) */ "
            + "    rpro_utility_pkg.generate_id(:scheduleSequence, rrs.client_id), "
            + "    rrs.rel_id, rrs.rc_id, rrs.rc_ver, rrs.line_id, rrs.pob_id, rrs.curr, - rrs.amount, rrs.rel_pct, "
            + "    CASE WHEN rrs.post_prd_id = :prdId "
            + "    THEN rpro_rc_schd_pkg.set_multiple_flag(rrs.indicators, :postedNettingReversal) "
            + "    ELSE rpro_rc_schd_pkg.set_multiple_flag(rrs.indicators, :postedReversalOfReversal) "
            + "    END indicators, "
            + "    rrs.post_date, rrs.post_prd_id, rrs.post_prd_id, rrs.post_batch_id, rrs.dr_segments, rrs.cr_segments,  "
            + "    rrs.f_ex_rate, rrs.g_ex_rate, rrs.atr1, rrs.atr2, rrs.atr3, rrs.atr4, rrs.atr5, rrs.client_id, "
            + "    rrs.crtd_prd_id, rrs.sec_atr_val, :user crtd_by, SYSDATE crtd_dt, :user updt_by, SYSDATE updt_dt, rrs.dist_id, "
            + "    rrs.ref_bill_id, rrs.root_line_id, rrs.book_id, rrs.bld_fx_dt, rrs.bld_fx_rate, rrs.rord_inv_ref,  "
            + "    rrs.orig_line_id, rrs.dr_link_id, rrs.cr_link_id, rrs.model_id, rrs.je_batch_id, rrs.je_batch_name, "
            + "    rrs.pp_amt, rrs.pq_amt, rrs.py_amt, :prdId, rrs.schd_addl_id "
            + "FROM "
            + "    <RPRO_RC_SCHD> rrs, <RPRO_CACL_NET_RC> rcnr, rpro_rc_line rrl "
            + "WHERE "
            + "    rcnr.batch_id = :batchId  "
            + "    AND rcnr.rc_id = rrl.rc_id "
            + "    AND rrs.root_line_id = rrl.id "
            + "    AND rpro_rc_schd_pkg.get_schd_type_flag(rrs.indicators) = :nettingSchd "
            + "    AND rpro_rc_schd_pkg.get_interfaced_flag(rrs.indicators) = 'Y' "
            + "    AND (rrs.post_prd_id = :prdId "
            + "        AND rpro_rc_schd_pkg.get_reversal_flag(rrs.indicators) = 'N' "
            + "        OR  "
            + "        (rrs.post_prd_id = :nextPrdId "
            + "        AND rpro_rc_schd_pkg.get_reversal_flag(rrs.indicators) = :reversalFlag)) "
            + "    AND rcnr.book_id = rrs.book_id AND rcnr.client_id = rrs.client_id AND rcnr.sec_atr_val = rrs.sec_atr_val "
            + "    AND rrs.book_id = :bookId AND rrs.client_id = :clientId AND rrs.sec_atr_val = :secAtrVal")
    int reversePostedSchedules(@Bind("batchId") BigDecimal batchId, @Bind("prdId") long prdId, @Bind("nextPrdId") long nextPrdId,
                                @Bind("nettingSchd") String nettingSchd, @Bind("reversalFlag") String reversalFlag,
                                @Bind("scheduleSequence") String scheduleSequence, @Bind("postedNettingReversal") String postedNettingReversal,
                                @Bind("postedReversalOfReversal") String postedReversalOfReversal,
                                @Define("RPRO_CACL_NET_RC") String rproCaclNetRc, @Define("RPRO_RC_SCHD") String rproRcSchd,
                                @Bind("user") String user, @Bind("bookId") Long bookId,
                                @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);

    @SqlUpdate("UPDATE /*+ index(rrs, rpro_rc_schd_shadow_i1) */ "
            + "    <RPRO_RC_SCHD> rrs "
            + "SET INDICATORS = CASE "
            + "                     WHEN rrs.post_prd_id = :prdId "
            + "                         THEN RPRO_RC_SCHD_PKG.SET_MULTIPLE_FLAG(INDICATORS, :postedNettingUpdate) "
            + "                     ELSE RPRO_RC_SCHD_PKG.SET_MULTIPLE_FLAG(INDICATORS, :postedReversalUpdate) "
            + "    END "
            + "WHERE (root_line_id, book_id) IN (SELECT rrl.id, rrl.book_id "
            + "             FROM <RPRO_CACL_NET_RC> rcnr, rpro_rc_line rrl "
            + "             WHERE rcnr.batch_id = :batchId AND rrl.rc_id = rcnr.rc_id) "
            + "AND rpro_rc_schd_pkg.get_schd_type_flag(rrs.indicators) = :nettingSchd "
            + "AND rpro_rc_schd_pkg.get_interfaced_flag(rrs.indicators) = 'Y' "
            + "AND ((rrs.post_prd_id = :prdId "
            + "                 AND rpro_rc_schd_pkg.get_reversal_flag(rrs.indicators) = 'N') "
            + "                 OR "
            + "                    (rrs.post_prd_id = :nextPrdId "
            + "                        AND rpro_rc_schd_pkg.get_reversal_flag(rrs.indicators) = :reversalFlag)) ")
    int updatePostedSchedules(@Bind("batchId") BigDecimal batchId, @Bind("prdId") long prdId, @Bind("nextPrdId") long nextPrdId,
                               @Bind("nettingSchd") String nettingSchd, @Bind("reversalFlag") String reversalFlag,
                               @Bind("postedNettingUpdate") String postedNettingUpdate, @Bind("postedReversalUpdate") String postedReversalUpdate,
                               @Define("RPRO_CACL_NET_RC") String rproCaclNetRc, @Define("RPRO_RC_SCHD") String rproRcSchd,
                               @Bind("user") String user, @Bind("bookId") Long bookId,
                               @Bind("clientId") Long clientId, @Bind("secAtrVal") String secAtrVal);
}
