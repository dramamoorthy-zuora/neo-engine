package com.zuora.neo.engine.jobs.transferaccounting.retry;

import com.zuora.neo.engine.jobs.transferaccounting.api.OrgBookStatus;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface RetryActivity {
    Long getBatchDetails();

    OrgBookStatus getTransferStatus();

    String getErrorDetails();
}

