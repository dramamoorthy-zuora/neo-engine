package com.zuora.neo.engine.jobs.sweep.activities.summarization;

import com.zuora.neo.engine.jobs.sweep.SweepResult;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface SweepSummarization {

    void summarize(SweepResult sweepResult);

}
