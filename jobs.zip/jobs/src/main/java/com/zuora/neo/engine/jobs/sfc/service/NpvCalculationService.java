package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.sfc.SfcResult;
import com.zuora.neo.engine.jobs.sfc.constants.SfcConstants;
import com.zuora.neo.engine.jobs.sfc.constants.SfcStatus;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.context.SfcPostProcessDetailsContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;
import com.zuora.neo.engine.jobs.sfc.exception.NoDetailsFoundException;

import org.jdbi.v3.core.Handle;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class NpvCalculationService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(NpvCalculationService.class);

    @Autowired
    private SfcServiceUtils sfcServiceUtils;

    @Autowired
    SfcTablesBatchInsertUpdateService sfcTablesBatchInsertUpdateService;

    @Autowired
    CoreNpvCalculationService coreNpvCalculationService;

    /*
        Service Method to Calculate Npv Interest for the batch
        Queries Rc Line Details and Payment Details for the batch and creates local cache maps.
        This method also sends these cache details to another method for NPV computation.
        After the calculation, the NPV Details for entire batch is persisted to the database at once.

        Input Args :
        sfcStatusValuesList -> Records from rpro_sfc_status for this batch
        sfcDbCacheContext -> Has common details such as data from rpro_account, rpro_currency, rpro_financ_typ and rpro_calendar
        sfcResult -> Has Warning Count Details
        handle -> JDBI Handle for DB operations
     */
    public void calculateNpvInterestForBatch(List<SfcStatusValues> sfcStatusValuesList, SfcDbCacheContext sfcDbCacheContext,
            SfcResult sfcResult, Handle handle) {

        SfcDao sfcDao = handle.attach(SfcDao.class);

        List<String> sfcDocLineIds = sfcStatusValuesList.stream().map(SfcStatusValues::getDocLineId).collect(Collectors.toList());
        LOGGER.info("Fetching RC Line Table details in NPV Calc Service for batch");
        List<RcLineDetails> rcLineDetailsBatch = sfcDao.getRcLineDetailsByDocLineIdList(sfcDocLineIds);

        LOGGER.info("Fetching Payment Table details in NPV Calc Service for batch");
        List<SfcPaymentDetails> sfcPaymentDetailsBatch = sfcDao.getSfcPaymentDetailsByDocLineIdList(sfcDocLineIds);

        Map<String, List<RcLineDetails>> rcLineDetailsBatchMap = rcLineDetailsBatch.stream()
                .collect(Collectors.groupingBy(rcLineDetails -> rcLineDetails.getDocLineId()));
        Map<String, List<SfcPaymentDetails>> sfcPaymentDetailsBatchMap = sfcPaymentDetailsBatch.stream()
                .collect(Collectors.groupingBy(sfcPaymentDetails -> sfcPaymentDetails.getDocLineId()));

        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();
        List<SfcCalcDetails> sfcCalcDetailsBatch = new ArrayList<>();
        List<RcLinePaData> rcLinePaDataRecordBatch = new ArrayList<>();

        SfcPostProcessDetailsContext sfcPostProcessDetailsContext = new SfcPostProcessDetailsContext(rcScheduleRecordBatch, sfcCalcDetailsBatch,
                rcLinePaDataRecordBatch, rcLineDetailsBatchMap, sfcPaymentDetailsBatchMap);
        performNpvCalculationsForBatch(sfcStatusValuesList, sfcPostProcessDetailsContext, sfcDbCacheContext, sfcResult, handle);

        sfcTablesBatchInsertUpdateService.batchUpdateSfcStatusTable(sfcStatusValuesList, handle);
    }

    /*
        Service Method to Perform Npv Calculations for the batch
        This method loops through the Sfc Status Table data for the batch, queries more data for each line, checks if the line is valid
        and then calls the Core NPV Calculation Service to compute net NPV and interest for each line

        Input Args :
        sfcStatusValuesList -> Records from rpro_sfc_status for this batch
        sfcPostProcessDetailsContext -> Has local maps cached that have details from rc line table and payment table/
        sfcDbCacheContext -> Has common details such as data from rpro_account, rpro_currency, rpro_financ_typ and rpro_calendar
        sfcResult -> Has Warning Count Details
        handle -> JDBI Handle for DB operations
     */
    public void performNpvCalculationsForBatch(List<SfcStatusValues> sfcStatusValuesList, SfcPostProcessDetailsContext sfcPostProcessDetailsContext,
            SfcDbCacheContext sfcDbCacheContext, SfcResult sfcResult, Handle handle) {
        CommonDao commonDao = handle.attach(CommonDao.class);
        SfcDao sfcDao = handle.attach(SfcDao.class);
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Map<String, Integer> currencyMap = sfcDbCacheContext.getCurrencyMap();
        Map<String, List<RcLineDetails>> rcLineDetailsBatchMap = sfcPostProcessDetailsContext.getRcLineDetailsBatchMap();
        Map<String, List<SfcPaymentDetails>> sfcPaymentDetailsBatchMap = sfcPostProcessDetailsContext.getSfcPaymentDetailsBatchMap();

        for (SfcStatusValues sfcStatusValue : sfcStatusValuesList) {
            if (sfcStatusValue != null && sfcStatusValue.getDocLineId() != null) {
                sfcStatusValue.setErrMsg(null);
                List<SfcPaymentDetails> sfcPaymentDetails = sfcPaymentDetailsBatchMap.get(sfcStatusValue.getDocLineId());
                List<RcLineDetails> rcLineDetails = rcLineDetailsBatchMap.get(sfcStatusValue.getDocLineId());
                long lineId = rcLineDetails.get(0).getId();
                long rcId = rcLineDetails.get(0).getRcId();
                long bookId = rcLineDetails.get(0).getBookId();
                LOGGER.debug("Fetching Finance Type Values for SFC for doc line id : " + sfcStatusValue.getDocLineId());
                List<RcLinePaData> rcLinePaDataRecordBeforeProcessing = getRcLinePaRecordForFinanceId(sfcDao,
                        rcLineDetails.get(0).getId(), sfcDbCacheContext);
                List<FinanceTypeValues> financeTypeValueForRcLine = sfcServiceUtils.getFinanceTypeForRcLine(rcLinePaDataRecordBeforeProcessing,
                        sfcDbCacheContext, rcLineDetails); //TODO remove pa table query, take finance line by date
                if (financeTypeValueForRcLine.isEmpty()) {
                    LOGGER.error("Finance Type Table is not available for doc line id " + sfcStatusValue.getDocLineId());
                    sfcServiceUtils.updateSfcStatusAndAddWarningCount(sfcResult, sfcStatusValue, SfcConstants.SFC_SETUP_NOT_AVAILABLE);
                    continue;
                }
                Boolean isSfcValid = sfcServiceUtils.validSfcLine(sfcStatusValue, sfcPaymentDetails, rcLineDetails, financeTypeValueForRcLine);
                if (isSfcValid) {
                    long vcTypeId = Math.toIntExact(financeTypeValueForRcLine.get(0).getId());
                    try {
                        coreNpvCalculationService.calculateNetNpv(sfcDao, commonDao, sfcStatusValue, sfcPaymentDetails, rcLineDetails, currencyMap, lineId,
                                vcTypeId, rcId, bookId, financeTypeValueForRcLine, request);
                    } catch (NoDetailsFoundException e) {
                        LOGGER.error("Error in processing SFC. No Details Found Exception occurred for " + sfcStatusValue.getDocLineId());
                        sfcServiceUtils.updateSfcStatusAndAddWarningCount(sfcResult, sfcStatusValue, SfcConstants.ERROR_PROCESSING_SFC);
                        continue;
                    }
                    LOGGER.debug("Calculation of Net Payment Value is done for " + sfcStatusValue.getDocLineId());
                    sfcStatusValue.setStatus(SfcStatus.NPV_INTEREST_CALCULATED.getStatus());
                }
            }
        }
    }

    /*
        Service Method to get RC Line Pa Record for Finance Type Id

        Input Args :
        sfcDao - Dao for SFC Db operations
        rcId - rcId for the particular line
        sfcDbCacheContext -> Has common details such as data from rpro_account, rpro_currency, rpro_financ_typ and rpro_calendar

        Output :
        Returns RC Line Pa Data
     */
    public List<RcLinePaData> getRcLinePaRecordForFinanceId(SfcDao sfcDao, long rcId, SfcDbCacheContext sfcDbCacheContext) {
        long financeTypeId = sfcDbCacheContext.getFinanceTypeValuesList().get(0).getId();
        List<RcLinePaData> rcLinePaDataList = getRcLinePaDataFromDB(sfcDao, rcId, financeTypeId);
        return rcLinePaDataList;
    }

    /*
        Service Method to get RC Line Pa Data from the database for given lineId and financeTypeId

        Input Args :
        sfcDao - Dao for SFC Db operations
        lineId - Line Id for the particular line
        financeTypeId - SFC Finance Type Id

        Output :
        Returns RC Line Pa Data
     */
    public List<RcLinePaData> getRcLinePaDataFromDB(SfcDao sfcDao, long lineId, long financeTypeId) {
        LOGGER.debug("Fetching RC Line PA Data Table for the line Id : " + lineId);
        List<RcLinePaData> rcLinePaDataList = sfcDao.getRcLinePaDataForLineId(lineId, financeTypeId);
        return rcLinePaDataList;
    }

}
