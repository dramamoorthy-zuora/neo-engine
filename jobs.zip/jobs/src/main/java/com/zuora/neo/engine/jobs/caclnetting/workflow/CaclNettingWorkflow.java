package com.zuora.neo.engine.jobs.caclnetting.workflow;

import com.zuora.neo.engine.temporal.workflows.BaseWorkflow;

import io.temporal.workflow.WorkflowInterface;

@WorkflowInterface
public interface CaclNettingWorkflow extends BaseWorkflow {
}
