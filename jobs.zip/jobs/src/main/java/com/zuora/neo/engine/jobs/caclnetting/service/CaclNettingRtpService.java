package com.zuora.neo.engine.jobs.caclnetting.service;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.common.util.CommonUtils;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.caclnetting.api.WorkflowResultBuffer;
import com.zuora.neo.engine.jobs.caclnetting.config.CaclProperties;
import com.zuora.neo.engine.jobs.caclnetting.constants.CaclMessages;
import com.zuora.neo.engine.jobs.caclnetting.db.dao.CaclNettingDao;
import com.zuora.neo.engine.jobs.rtp.WorkItemResult;
import com.zuora.neo.engine.jobs.rtp.constants.RtpWiHeaderStatus;
import com.zuora.neo.engine.jobs.rtp.service.RtpService;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import com.google.common.annotations.VisibleForTesting;

import org.jdbi.v3.core.Jdbi;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class CaclNettingRtpService implements RtpService {

    final CleanupService cleanupService;
    final CaclProperties caclProperties;
    final CaclService caclService;
    final NeoWorkflowLogger neoWorkflowLogger;
    final InitializerService initializerService;
    final CarryForwardService carryForwardService;
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CaclNettingRtpService.class);

    public CaclNettingRtpService(CleanupService cleanupService, CaclProperties caclProperties, CaclService caclService,
                                 NeoWorkflowLogger neoWorkflowLogger, InitializerService initializerService, CarryForwardService carryForwardService) {
        this.cleanupService = cleanupService;
        this.caclProperties = caclProperties;
        this.caclService = caclService;
        this.neoWorkflowLogger = neoWorkflowLogger;
        this.initializerService = initializerService;
        this.carryForwardService = carryForwardService;
    }

    @Override
    public WorkItemResult process(String secAtrVal, BigDecimal batchId) {
        LOGGER.info("--------- CA/CL - batchId to process - " + batchId);

        Jdbi jdbi = DbContext.getConnection();

        WorkflowResultBuffer workflowResultBuffer = new WorkflowResultBuffer();

        jdbi.useTransaction(handle -> {
            CaclNettingDao nettingDao = handle.attach(CaclNettingDao.class);
            CommonDao commonDao = handle.attach(CommonDao.class);

            boolean nettingEnabled = CommonUtils.isProfileEnabled(commonDao.getProfileValueFromTable("ALLOW_NETTING_PROCESS", "N"));
            if (!nettingEnabled) {
                workflowResultBuffer.setMessageBuffer(CaclMessages.NETTING_DISABLED);
                workflowResultBuffer.setReturnCode(1);
                return;
            }

            performNettingRtp(nettingDao, commonDao, batchId, secAtrVal);
            workflowResultBuffer.setReturnCode(0);
        });

        LOGGER.info("########## Returning from CA/CL Netting service ########");

        return new WorkItemResult(workflowResultBuffer.getMessageBuffer(), workflowResultBuffer.getReturnCode());
    }

    /**
     * Start of the process - picks eligible RCs and calls CaclService
     */
    @VisibleForTesting
    void performNettingRtp(CaclNettingDao nettingDao, CommonDao commonDao,
                                   BigDecimal batchId, String orgId) {

        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();

        long clientId = request.getClientId();
        String user = request.getUser();

        List<Long> bookIds = nettingDao.getUniqueBookIdsForRtpBatch(batchId, RtpWiHeaderStatus.IN_PROGRESS.getHeaderStatus(), orgId);

        for (Long bookId : bookIds) {
            initializerService.performInitOperations(commonDao, nettingDao, bookId, clientId, orgId, user);

            String createLineLevel = "Y";

            if (caclProperties.getNettingLevel().equals("Application")) {
                createLineLevel = "N";
            }

            processWorkItemForGivenBook(nettingDao, commonDao, batchId, createLineLevel);
        }
    }

    @VisibleForTesting
    void processWorkItemForGivenBook(CaclNettingDao nettingDao, CommonDao commonDao,
                                             BigDecimal batchId, String createLineLevel) {
        caclService.insertNettingRc(nettingDao, batchId, null, null, true);

        caclService.performNettingService(nettingDao, commonDao, batchId, caclProperties.getBookId(), createLineLevel,
                caclProperties.getUser(), caclProperties.getClientId(), caclProperties.getOrgId());
    }
}
