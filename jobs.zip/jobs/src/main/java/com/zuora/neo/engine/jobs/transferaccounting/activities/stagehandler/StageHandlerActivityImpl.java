package com.zuora.neo.engine.jobs.transferaccounting.activities.stagehandler;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.db.dao.LockDao;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.activities.transfer.TransferActivityImpl;
import com.zuora.neo.engine.jobs.transferaccounting.config.Properties;
import com.zuora.neo.engine.jobs.transferaccounting.constants.StageHandlerType;
import com.zuora.neo.engine.jobs.transferaccounting.constants.TransferStatus;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.StageHandlerTable;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.AccountingDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.ErrorDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.StageHandlerDao;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@ActivityImplementation
@Component
public class StageHandlerActivityImpl implements StageHandlerActivity {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(TransferActivityImpl.class);
    private static final String stageType = "TRANSFER";
    private static final String procedureName = "DO_ACCTG_TRANSFER";
    private static final String CUSTOM_API_ER = "ERROR: During custom stage processor:";

    @Autowired
    Properties properties;
    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;

    @Override
    public ThreadedAccountingResult executeCustomCodeStageHandler(ThreadedAccountingResult accountingResult, String orgId) {
        Long postBatchId = accountingResult.getPostBatchId();
        Long bookId = accountingResult.getBookId();
        Jdbi jdbi = DbContext.getConnection();
        StageHandlerType stageHandlerType = accountingResult.getStageHandlerType();
        return jdbi.inTransaction(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            LockDao lockDao = handle.attach(LockDao.class);
            ErrorDao errorDao = handle.attach(ErrorDao.class);
            return executeStageHandler(accountingDao, commonDao, postBatchId, lockDao, accountingResult, bookId,
                    stageType, stageHandlerType, orgId, errorDao, handle);
        });
    }

    /*
        We have 4 types of stage handling. If the stage handler is enabled it will get called twice for both Update and Transfer
        i.e. before update, after update, before post, after post.
        Stage handler execution happens if enabled to handle use cases like we want to update any of the account segments
        before transfer accounting, and the customer will create procedures to do it.
        Similarly for the other 3 scenarios customers can create procedures to handle it.

     */
    private ThreadedAccountingResult executeStageHandler(AccountingDao accountingDao, CommonDao commonDao, Long postBatchId, LockDao lockDao,
            ThreadedAccountingResult accountingResult, Long bookId, String stageType, StageHandlerType stageHandlerType,
                                                         String orgId, ErrorDao errorDao, Handle handle) {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        properties.load(commonDao, request.getTenantId());
        Boolean customCodeAllowed = properties.getCustomCodeAllowed();

        if (customCodeAllowed) {
            try {
                switch (stageHandlerType) {
                    case BEFORE_UPDATE:
                        //STAGE PROCESSOR : TRANSFER: BEFORE UPDATE
                        invokeStageHandler(accountingResult, handle, postBatchId, StageHandlerType.BEFORE_UPDATE.getStageHandlerType());
                        break;
                    case AFTER_UPDATE:
                        //STAGE PROCESSOR : TRANSFER: AFTER UPDATE
                        invokeStageHandler(accountingResult, handle, postBatchId, StageHandlerType.AFTER_UPDATE.getStageHandlerType());
                        break;
                    case BEFORE_POST:
                        //STAGE PROCESSOR : TRANSFER: BEFORE POST
                        invokeStageHandler(accountingResult, handle, postBatchId, StageHandlerType.BEFORE_POST.getStageHandlerType());
                        break;
                    case AFTER_POST:
                        //STAGE PROCESSOR : TRANSFER: AFTER POST
                        invokeStageHandler(accountingResult, handle, postBatchId, StageHandlerType.AFTER_POST.getStageHandlerType());
                        break;
                    default:
                        break;
                }
            } catch (Exception e) {
                String errText = CUSTOM_API_ER + stageHandlerType.getStageHandlerType() + "~" + stageType;
                commonDao.recordErrors(procedureName, errText);
                LOGGER.error(e.getMessage());
                String errMsg = "The custom stage process failed. Verify the custom process: " + e.getMessage();
                accountingDao.updateTransferStatusMsg(TransferStatus.ERROR.getTransferStatus(), errMsg, request.getUser(), postBatchId);
                errorDao.insertError(postBatchId, errMsg, request.getUser(), request.getClientId(),
                        bookId, orgId, accountingResult.getChunkId());
                lockDao.removeLock(orgId);
                accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
                accountingResult.setTransferMessage(errText);
            }

        }

        return accountingResult;
    }

    /*
        We have 4 types of stage handling. If the stage handler is enabled it will get called twice for both Update and Transfer
        i.e. before update, after update, before post, after post.
        Stage handler execution happens if enabled to handle use cases like we want to update any of the account segments
        before transfer accounting, and the customer will create procedures to do it.
        Similarly for the other 3 scenarios customers can create procedures to handle it.

        NOTE: THIS NEEDS - Grant for custom API’s, we need to prepare dynamic script to give grant to Int user.
     */
    private ThreadedAccountingResult invokeStageHandler(ThreadedAccountingResult accountingResult, Handle handle,
            Long postBatchId, String executeWhen) {
        StageHandlerDao handlerDao = handle.attach(StageHandlerDao.class);
        List<StageHandlerTable> procNames = handlerDao.getStageHandlerProcedureName(executeWhen, stageType);

        if (procNames.isEmpty()) {
            neoWorkflowLogger.log("No custom code found in " + stageType + " for " + executeWhen);
        } else {
            for (StageHandlerTable procedure : procNames) {
                StringBuilder customStageApi = new StringBuilder("CALL ");
                customStageApi = customStageApi.append(procedure.getProcedureName()).append(" (NULL, ").append(postBatchId).append(")");
                handle.createCall(customStageApi.toString()).invoke();
                LOGGER.info("Stage handler API name: " + customStageApi);
            }
        }

        return accountingResult;
    }
}
