package com.zuora.neo.engine.jobs.transferaccounting.db.api;

public class BookOrgRecord {
    private Long bookId;
    private String orgId;

    public BookOrgRecord(Long bookId, String orgId) {
        this.bookId = bookId;
        this.orgId = orgId;
    }

    public Long getBookId() {
        return bookId;
    }

    public String getOrgId() {
        return orgId;
    }
}
