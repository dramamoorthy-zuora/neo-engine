package com.zuora.neo.engine.jobs.sfc.activities;

import com.zuora.neo.engine.jobs.sfc.SfcResult;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface SfcSoUpdateActivities {
    SfcResult soUpdateSfc(SfcResult sfcResult);
}
