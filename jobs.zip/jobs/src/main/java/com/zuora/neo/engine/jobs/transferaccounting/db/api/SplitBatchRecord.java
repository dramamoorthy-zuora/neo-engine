package com.zuora.neo.engine.jobs.transferaccounting.db.api;

import java.util.Date;

public class SplitBatchRecord {
    private Long batchId;
    private String type;
    private String batchType;
    private Long chunkId;
    private String minValue;
    private String maxValue;
    private Date startDate;
    private Date endDate;
    private Long requestId;
    private String orgId;
    private Long clientId;
    private Long bookId;
    private String processed;

    public SplitBatchRecord(Long batchId, String type, String batchType, Long chunkId, String minValue, String maxValue,
            String processed, Date startDate, Date endDate, Long requestId, String orgId, Long clientId, Long bookId) {
        this.batchId = batchId;
        this.type = type;
        this.batchType = batchType;
        this.chunkId = chunkId;
        this.minValue = minValue;
        this.maxValue = maxValue;
        this.processed = processed;
        this.startDate = startDate == null ? null : new Date(startDate.getTime());
        this.endDate = endDate == null ? null : new Date(endDate.getTime());
        this.requestId = requestId;
        this.orgId = orgId;
        this.clientId = clientId;
        this.bookId = bookId;
    }

    public SplitBatchRecord() {
    }

    public Long getBatchId() {
        return batchId;
    }

    public String getType() {
        return type;
    }

    public String getBatchType() {
        return batchType;
    }

    public Long getChunkId() {
        return chunkId;
    }

    public String getMinValue() {
        return minValue;
    }

    public String getMaxValue() {
        return maxValue;
    }

    public Date getStartDate() {
        return startDate == null ? null : new Date(startDate.getTime());
    }

    public Date getEndDate() {
        return endDate == null ? null : new Date(endDate.getTime());
    }

    public Long getRequestId() {
        return requestId;
    }

    public String getOrgId() {
        return orgId;
    }

    public Long getClientId() {
        return clientId;
    }

    public Long getBookId() {
        return bookId;
    }

    public String getProcessed() {
        return processed;
    }
}
