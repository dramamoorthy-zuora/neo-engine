package com.zuora.neo.engine.jobs.reporting.activities;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.reporting.service.QueryServiceImpl;

import com.amazonaws.HttpMethod;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;

import io.temporal.workflow.Workflow;

import org.json.JSONObject;
import org.springframework.stereotype.Component;

import java.net.URL;
import java.util.Date;

/**
 * @author achaudhary
 *         <p>
 *         Implementation of {@link GetReportConfig}
 */
@ActivityImplementation
@Component
public class FetchingDataFileUrlFromQueryServiceImpl implements FetchingDataFileUrlFromQueryService {

    private static final org.slf4j.Logger LOGGER = Workflow.getLogger(FetchingDataFileUrlFromQueryService.class);
    FetchDataFromDb db = new FetchDataFromDb();
    AmazonS3 s3 = db.s3();

    @Override
    public String getUrlFromQueryService2(String config2) {
        WorkflowContext context = WorkflowContextManager.getWorkflowContext();
        WorkflowRequest request = context.getRequest();
        String tenantId = String.valueOf(request.getTenantId());
        String parameterText = request.getParameterText();
        // We need qid from query service
        JSONObject config = new JSONObject(config2);
        LOGGER.info("In get url from query id" + config);
        QueryServiceImpl getDetails = new QueryServiceImpl(tenantId);
        String status = "INIT STATUS";
        getDetails.setGetQueryServiceUrl(config.getString("qsurl"));
        String postResponse = getDetails.sendPostRequest(config.getString("query"));
        JSONObject returnObject = new JSONObject();
        JSONObject postResponseInJson = new JSONObject(postResponse);
        LOGGER.info(postResponseInJson.toString());
        String getResponse = "INIT RESPONSE";
        String getStatus = "INIT get Status";
        JSONObject getResponseInJson = new JSONObject();
        int number = 0;
        if (postResponseInJson.get("httpStatusCode").equals(200)
                && postResponseInJson.getString("status").equals("accepted")) {
            while (true) {
                // Make a GET request
                number++;
                getResponse = getDetails.sendGetRequest();
                getResponseInJson = new JSONObject(getResponse);
                if (getResponseInJson.get("httpStatusCode").equals(200)) {
                    getStatus = getResponseInJson.has("queryStatus") ? getResponseInJson.getString("queryStatus")
                            : "error";
                    if (getStatus.equals("completed")) {
                        status = "success";
                        LOGGER.info("query success ");
                        break;
                    }
                    if (getStatus.equals("failed")) {
                        status = "failed";
                        JSONObject getFailedStatus = new JSONObject();

                        getFailedStatus.put("getErrorMessage", getResponseInJson.getString("errorMessage"));
                        getFailedStatus.put("getErrorCode", getResponseInJson.getString("errorCode"));
                        getFailedStatus.put("status", getStatus);
                        returnObject.put("getError", getFailedStatus);
                        LOGGER.info("Query failed error in query service ");
                        break;
                    }
                    if (getStatus.equals("error")) {
                        status = "error";
                        returnObject.put("getError", getResponseInJson);
                        LOGGER.info("error in get query ");
                        break;
                    }
                    if (number == 1000) {
                        status = "limit reached";
                        getResponseInJson.put("limitCheck","Limit reached 1000");
                        returnObject.put("getError", getResponseInJson);
                        LOGGER.info("get query limit 1000 reached ");
                        break;
                    }

                } else {
                    returnObject.put("getError", getResponseInJson);
                    LOGGER.info(" Error in Get Request ");
                    break;
                }
                // Wait for 10 seconds before making the next request
                try {
                    Thread.sleep(5000);
                } catch (Exception e) {
                    LOGGER.info(e + " error in thread query service");
                    e.printStackTrace();
                    throw new NonRetryableActivityException("Error: " + e.getMessage(),e);
                }
            }
        } else {
            returnObject.put("postError", postResponseInJson);
            LOGGER.info("Error ############################");
            LOGGER.info(postResponseInJson.toString());
        }

        String fileUrl = getResponseInJson.has("dataFile") ? getResponseInJson.getString("dataFile") : "null";
        String queryID = getDetails.getQueryID();
        LOGGER.info("Inside  activity reporting-- exitting get url from query service+" + fileUrl + "parameterText" + parameterText);
        // for local degubbing
        // if (tenantId.equals("dvmk7up")) {
        // System.out.println("inside rteanntsdafsdasf");
        // fileUrl = generatePresignedUrl2();
        // }
        returnObject.put("fileUrl", fileUrl);
        returnObject.put("postRequestStatus", postResponseInJson);
        returnObject.put("getRequestStatus", getResponseInJson);
        returnObject.put("status", status);
        returnObject.put("queryID", queryID);
        returnObject.put("No of get hits", number);
        LOGGER.info(returnObject.toString());
        return returnObject.toString();
    }

    @Override
    public String generatePresignedUrl2() {

        WorkflowContext context = WorkflowContextManager.getWorkflowContext();
        WorkflowRequest request = context.getRequest();
        String parameterText = request.getParameterText();

        Date expiration = new Date();
        long expTimeMillis = expiration.getTime();
        expTimeMillis += 1000 * 60 * 60;
        expiration.setTime(expTimeMillis);

        // Generate the presigned URL.
        String bucketName = "snowflake-poc-devops";
        String key = "report-builder/10581_20221216_012457.csv";

        if (parameterText.equals("10781")) {
            key = "report-builder/10581_20221216_012457.csv";
        } else {
            key = "report-builder/Huge_Report_File_ForTesting.CSV";
        }
        GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(bucketName, key)
                .withMethod(HttpMethod.GET)
                .withExpiration(expiration);
        URL presignedUrl = s3.generatePresignedUrl(generatePresignedUrlRequest);

        // Print the presigned URL to the console.
        System.out.println("Presigned URL: " + presignedUrl.toString());
        String fileUrl = presignedUrl.toString();
        return fileUrl;
    }

}
