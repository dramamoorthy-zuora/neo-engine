package com.zuora.neo.engine.jobs.internal.activities;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface NovaInternalWorkflowActivities {

    void sync();

}
