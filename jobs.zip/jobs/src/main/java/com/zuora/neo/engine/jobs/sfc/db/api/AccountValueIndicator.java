package com.zuora.neo.engine.jobs.sfc.db.api;

import java.util.Arrays;

public class AccountValueIndicator {


    static final int ENABLED_FLAG_POS = 0;
    static final int STATUS_FLAG_POS = 1;
    static final int VALIDATED_FLAG_POS = 2;
    static final int UPD_RCL_FLAG_POS = 3;
    static final int PERFORM_COLLECTION_FLAG_POS = 4;
    /* Flags from Position 5 to 18 are not in use as of now. In future, please add in order and also add the getter and setter methods for the same */
    static final int UPDATE_OR_INSERT_FLAG_POS = 19;

    static final  char[] defaultAccountValueIndicator = {'Y' /* Enabled Flag */,
            'N' /* Status Flag */,
            'N' /* Validated  Flag */,
            'N' /* Update RCL Flag */,
            'N' /* Perform Collection Flag */,
            'N' /* Flag Not Used */,
            'N' /* Flag Not Used */,
            'N' /* Flag Not Used */,
            'N' /* Flag Not Used */,
            'N' /* Flag Not Used */,
            'N' /* Flag Not Used */,
            'N' /* Flag Not Used */,
            'N' /* Flag Not Used */,
            'N' /* Flag Not Used */,
            'N' /* Flag Not Used */,
            'N' /* Flag Not Used */,
            'N' /* Flag Not Used */,
            'N' /* Flag Not Used */,
            'N' /* Flag Not Used */,
            'N' /* Update or Insert Flag */
    };

    char[] accountValueIndicator;

    public static String getDefault() {
        return String.valueOf(defaultAccountValueIndicator);
    }

    public AccountValueIndicator() {
        this.accountValueIndicator = Arrays.copyOf(defaultAccountValueIndicator,defaultAccountValueIndicator.length);
    }

    public  String getIndicator() {
        return String.valueOf(accountValueIndicator);
    }

    public static AccountValueIndicator valueOf(String indicators) {

        int maxLength = defaultAccountValueIndicator.length - 1;
        int stringLength = indicators.length();

        AccountValueIndicator si = new AccountValueIndicator();
        for (int i = 0; i < maxLength; i++) {
            if (i >= stringLength) {
                break;
            }
            si.accountValueIndicator[i] = indicators.charAt(i);
        }
        return si;
    }

    public char getEnabledFlag() {
        return accountValueIndicator[ENABLED_FLAG_POS];
    }

    public void setEnabledFlag(char enabledFlag) {
        this.accountValueIndicator[ENABLED_FLAG_POS] = enabledFlag;
    }

    public char getStatusFlag() {
        return accountValueIndicator[STATUS_FLAG_POS];
    }

    public void setStatusFlag(char statusFlag) {
        this.accountValueIndicator[STATUS_FLAG_POS] = statusFlag;
    }

    public char getValidatedFlag() {
        return accountValueIndicator[VALIDATED_FLAG_POS];
    }

    public void setValidatedFlag(char validatedFlag) {
        this.accountValueIndicator[VALIDATED_FLAG_POS] = validatedFlag;
    }

    public char getUpdRclFlag() {
        return accountValueIndicator[UPD_RCL_FLAG_POS];
    }

    public void setUpdRclFlag(char updRclFlag) {
        this.accountValueIndicator[UPD_RCL_FLAG_POS] = updRclFlag;
    }

    public char getPerfomCollectionFlag() {
        return accountValueIndicator[PERFORM_COLLECTION_FLAG_POS];
    }

    public void setPerfomCollectionFlag(char perfomCollectionFlag) {
        this.accountValueIndicator[PERFORM_COLLECTION_FLAG_POS] = perfomCollectionFlag;
    }

    public char getUpdateOrInsertFlag() {
        return accountValueIndicator[UPDATE_OR_INSERT_FLAG_POS];
    }

    public void setUpdateOrInsertFlag(char updateOrInsertFlag) {
        this.accountValueIndicator[UPDATE_OR_INSERT_FLAG_POS] = updateOrInsertFlag;
    }

}
