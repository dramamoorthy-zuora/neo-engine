package com.zuora.neo.engine.jobs.transferaccounting.db.dao;

import com.zuora.neo.engine.jobs.transferaccounting.db.api.AccountSegment;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.AccountSegmentType;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.BookOrgRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.RcHeadRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.AccountSegmentMapper;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.AccountSegmentTypeMapper;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.BookMapper;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.BookOrgMapper;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.RcHeadRecordMapper;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.ValueMapper;

import org.jdbi.v3.core.statement.OutParameters;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.OutParameter;
import org.jdbi.v3.sqlobject.statement.SqlCall;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.statement.UseRowMapper;

import java.sql.Types;
import java.util.List;

public interface AccountingDao {

    @SqlUpdate("insert into rpro_acct_xfer (ID,NAME,status,client_id,crtd_prd_id,sec_atr_val,book_id,crtd_by,crtd_dt,updt_by,"
            + "updt_dt,indicators,no_of_schedules) values (?,'TRANSFER BATCH' || '_' || TO_CHAR ( SYSDATE, 'YYYYMMDD_HH24MISS'),"
            + "?,?,?,?,?,?,sysdate,NULL,NULL,?,0)")
    void insertHeader(Long id, String status, Long clientId, Long currentPeriodId, String secAttrVal, Long bookId,
            String createdBy, String indicators);

    @SqlQuery("select count(*) from rpro_acct_xfer where id=:postBatchId AND status IN ('TRANSFERRED','READY TO TRANSFER')")
    Integer getTransferStatusCount(@Bind("postBatchId") Long postBatchId);

    @SqlUpdate("UPDATE rpro_rc_schd set post_batch_id = NULL , dr_link_id = NULL, cr_link_id= NULL"
            + " WHERE post_batch_id = :post_batch_id AND rc_id between :minRcId AND :maxRcId"
            + " AND rpro_rc_schd_pkg.get_interfaced_flag (indicators) = 'N'")
    Integer resetAcctValues(@Bind("post_batch_id") Long postBatchId, @Bind("minRcId") Long minRcId, @Bind("maxRcId") Long maxRcId);

    @SqlUpdate("UPDATE rpro_acct_xfer SET no_of_schedules = NVL(:l_rc_upd_count,0) + NVL(:l_je_upd_count,0) + no_of_schedules WHERE ID = :p_post_batch_id ")
    void updateSchedulesNum(@Bind("l_rc_upd_count") Long rcCount, @Bind("l_je_upd_count") Long jeCount,
            @Bind("p_post_batch_id") long postBatchId, @Bind("chunkId") long chunkId);

    @SqlUpdate("UPDATE rpro_acct_xfer set status = :status, message = LTRIM(RTRIM(message || ' '|| :message)), updt_dt = SYSDATE "
            + ", updt_by = :updatedBy where id = :postBatchId and ( INSTR( message, :message) = 0 OR message is null)")
    void updateTransferStatusMsg(@Bind("status") String status, @Bind("message") String message,
            @Bind("updatedBy") String updatedBy, @Bind("postBatchId") Long postBatchId);

    @SqlQuery("select status from rpro_acct_xfer where id=:postBatchId")
    String getTransferStatus(@Bind("postBatchId") Long postBatchId);

    @SqlUpdate("UPDATE rpro_acct_xfer SET Indicators = rpro_acct_xfer_pkg.set_summary_xfer_flag(:defaultIndicator,'Y') "
            + "WHERE id = :post_batch_id")
    void updateHeaderSummaryFlag(@Bind("defaultIndicator") String defaultIndicator, @Bind("post_batch_id") Long postBatchId);

    @SqlQuery("select rpro_book_pkg.get_postable_flag(indicators) FROM rpro_book WHERE rpro_book_pkg.get_enabled_flag(indicators) = 'Y'")
    String getPostableFlag();

    @SqlUpdate("UPDATE rpro_rc_head rh SET indicators = CASE WHEN rpro_rc_head_pkg.get_posted_flag (indicators) = 'N'"
            + " AND (NVL(tot_cv_amt,0) <> 0 OR rpro_rc_head_pkg.get_alloc_trtmt_flag (rh.indicators) = 'P')"
            + " THEN rpro_rc_head_pkg.set_posted_flag ( indicators, 'Y') ELSE indicators END"
            + " ,updt_by = :g_user WHERE 1=1 AND (rh.id, book_id) IN (SELECT sch.rc_id, sch.book_id"
            + " FROM rpro_rc_schd sch WHERE rpro_rc_schd_pkg.get_interfaced_flag (sch.indicators) = 'Y'"
            + " AND rpro_rc_schd_pkg.GET_SCHD_TYPE_FLAG(sch.indicators) in ('A','I') "
            + " AND sch.post_batch_id = :postBatchId AND sch.rc_id BETWEEN :minRcId AND :maxRcId)")
    Integer updateRcHeadPosted(@Bind("g_user") String user, @Bind("postBatchId") Long postBatchId,
            @Bind("minRcId") Long minRcId, @Bind("maxRcId") Long maxRcId);

    @SqlUpdate("insert into rpro_ri_rc_schd_min_data_gt (LINE_ID, ROOT_LINE_ID, AMOUNT, INDICATORS, CR_SEGMENTS,"
            + " DR_SEGMENTS, F_EX_RATE, G_EX_RATE, POST_PRD_ID) "
            + " values (?,?,?,?,?,?,?,?,?)")
    Integer insertRcSchdData(Long lineId, Long rootLineId, Double amount, String indicators, String crSegments,String drSegments,
            Double foreignExRate, Double globalExRate, Integer postPeriodId);

    @SqlCall("{call rpro_ri_pre_summ_pkg.update_post_unpost(:l_err_buf, :l_ret_code, :p_post_batch_id)}")
    @OutParameter(name = "l_err_buf", sqlType = Types.VARCHAR)
    @OutParameter(name = "l_ret_code", sqlType = Types.VARCHAR)
    OutParameters updatePostUnpost(@Bind("p_post_batch_id") Long postBatchId);

    @SqlUpdate("UPDATE rpro_acct_xfer SET FILE_ID = :l_request_id WHERE ID = :post_batch_id")
    void updateFileIdHeader(@Bind("l_request_id") Long requestId, @Bind("post_batch_id") Long postBatchId);

    @SqlCall("{call rpro_neo_engine_pkg.submit_download(:post_batch_id, :out_request_id)}")
    @OutParameter(name = "out_request_id", sqlType = Types.BIGINT)
    OutParameters submitFileDownload(@Bind("post_batch_id") Long postBatchId);

    @SqlCall("{call rpro_neo_engine_pkg.schedule_job(:p_errbuf, :p_retcode, :p_request_id, :p_program_id, :p_parameter_text)}")
    @OutParameter(name = "p_errbuf", sqlType = Types.VARCHAR)
    @OutParameter(name = "p_retcode", sqlType = Types.VARCHAR)
    @OutParameter(name = "p_request_id", sqlType = Types.BIGINT)
    OutParameters scheduleJob(@Bind("p_program_id") Integer programId, @Bind("p_parameter_text") String paramText);

    @SqlQuery("SELECT DISTINCT acctg_seg schd_acctg_segments FROM rpro_rc_schd_v rrs WHERE (rrs.manual_je_flag = 'N' OR rrs.schd_type_flag = 'D')"
            + " AND post_batch_id = :p_post_batch_id and rc_id between :minRcId and :maxRcId")
    @UseRowMapper(AccountSegmentMapper.class)
    List<AccountSegment> getAccountSegments(@Bind("p_post_batch_id") long postBatchId,@Bind("minRcId") long minRcId, @Bind("maxRcId") long maxRcId);

    @SqlCall("{call rpro_acct_validation_pkg.validate_acct_seg(:p_acct_seg, :p_check_with_erp, :p_sob_id, :p_valid_seg)}")
    @OutParameter(name = "p_valid_seg", sqlType = Types.VARCHAR)
    OutParameters validateAcctSegment(@Bind("p_acct_seg") String accountSegment, @Bind("p_check_with_erp") String erpCheck,
            @Bind("p_sob_id") Long sobId);

    @SqlQuery("SELECT segment FROM rpro_segment WHERE rpro_segment_pkg.get_seg_type_flag (indicators) = 'E'"
            + " AND rpro_segment_pkg.get_enabled_flag (indicators) = 'Y' AND ROWNUM = 1")
    String getLegalEntitySegment();

    @SqlQuery("SELECT name FROM rpro_acct_type WHERE id = :l_acct_type AND ROWNUM = 1")
    String getAccountName(@Bind("l_acct_type") String accountType);

    @SqlQuery("SELECT name FROM rpro_acct_xfer WHERE id = :p_post_batch_id")
    String getPostBatchName(@Bind("p_post_batch_id") long postBatchId);

    @SqlQuery("SELECT id FROM rpro_rev_hold WHERE name = :l_hold_name AND rpro_rev_hold_pkg.get_enabled_flag(indicators) = 'Y'")
    Integer getHoldId(@Bind("l_hold_name") String holdName);

    @SqlQuery("SELECT s.segment, a.source_value FROM rpro_segment s, rpro_account a WHERE a.acct_type_id = :acct_type"
            + " AND a.source_type = 'CONSTANT' AND s.id = a.segment_id AND s.segment <> :leg_ent_acc")
    @UseRowMapper(AccountSegmentTypeMapper.class)
    List<AccountSegmentType> getAccountSegmentPerType(@Bind("acct_type") String accountType, @Bind("leg_ent_acc") String legalEntity);

    @SqlQuery("SELECT id rc_id, book_id, obj_version FROM rpro_rc_head WHERE (id, book_id) IN (SELECT c.rc_id , b.book_id"
            + " FROM rpro_int_error a, rpro_rc_schd b, rpro_rc_line c WHERE acct_xfer_id = :p_post_batch_id "
            + " AND b.root_line_id = c.id AND a.rc_id between :minRcId and :maxRcId"
            + " AND b.book_id = c.book_id AND a.rc_id = b.rc_id AND a.book_id = b.book_id"
            + " AND rpro_int_error_pkg.get_current_batch_flag(a.indicators) = 'Y')")
    @UseRowMapper(RcHeadRecordMapper.class)
    List<RcHeadRecord> getRcHeaderRec(@Bind("p_post_batch_id") long postBatchId,
            @Bind("minRcId") long minRcId, @Bind("maxRcId") long maxRcId);

    @SqlCall("{call rpro_process_hold_pkg.apply_holds(:p_user_id, :p_hold_id, :p_hold_comment, :p_rc_id, :p_rc_pob_id,"
            + ":p_rc_line_id, :p_rc_ovn, :p_book_id, :p_ret_code, :p_err_buf, :p_lock_override)}")
    @OutParameter(name = "p_ret_code", sqlType = Types.BIGINT)
    @OutParameter(name = "p_err_buf", sqlType = Types.VARCHAR)
    OutParameters applyHolds(@Bind("p_user_id") String userId, @Bind("p_hold_id") Integer holdId, @Bind("p_hold_comment") String holdComment,
            @Bind("p_rc_id") Long rcId, @Bind("p_rc_pob_id") Long pobId, @Bind("p_rc_line_id") Long rcLineId, @Bind("p_rc_ovn") Long rcOvn,
            @Bind("p_book_id") Long bookId, @Bind("p_lock_override") String lockOverride);

    @SqlQuery("SELECT rro.org_id value \n"
            + "    FROM rpro_role_org rro, rpro_org ro\n"
            + "   WHERE role_id = :roleId\n"
            + "     AND rpro_org_pkg.get_enabled_flag(ro.indicators) = 'Y'\n"
            + "     AND ro.org_id = rro.org_id")
    @UseRowMapper(ValueMapper.class)
    List<String> getAllOrgs(@Bind("roleId") long roleId);

    @SqlQuery("SELECT id value FROM rpro_book WHERE rpro_book_pkg.get_enabled_flag(indicators) = 'Y'")
    @UseRowMapper(BookMapper.class)
    List<Long> getGlobalBookId();

    @SqlUpdate("update rpro_rc_schd set post_batch_id = NULL , dr_link_id = NULL, cr_link_id= NULL where post_batch_id = :postBatchId"
            + " AND rpro_rc_schd_pkg.get_interfaced_flag (indicators) = 'N'")
    Integer cleanupPostBatchIdSchd(@Bind("postBatchId") long postBatchId);

    @SqlQuery("SELECT book_id, sec_atr_val FROM rpro_acct_xfer WHERE ID = :postBatchId")
    @UseRowMapper(BookOrgMapper.class)
    List<BookOrgRecord> getBookIdForBatch(@Bind("postBatchId") long postBatchId);

    @SqlUpdate("DELETE FROM rpro_acct_xfer where id = :postBatchId")
    Integer deleteXferRecord(@Bind("postBatchId") long postBatchId);

    @SqlUpdate("DELETE FROM rpro_acct_xfer_details where post_batch_id = :postBatchId")
    Integer deleteXferDetailsRecord(@Bind("postBatchId") long postBatchId);

    @SqlUpdate("UPDATE rpro_acct_xfer SET no_of_schedules = 0 where ID = :post_batch_id")
    Integer resetNoOfSchedules(@Bind("post_batch_id") Long postBatchId);

    @SqlUpdate("insert into RPRO_ACCT_XFER_SUMMARY (POST_BATCH_ID, SEC_ATR_VAL, STATUS, CRTD_DT, CRTD_BY, MESSAGE)"
            + " values (?,?,?,SYSDATE,?,?)")
    void insertOrgBatch(Long id, String orgId, String status, String user, String message);

    @SqlQuery("SELECT err_msg from rpro_int_error where acct_xfer_id = :post_batch_id and chunk_id = :chunkId")
    String getErrorMessage(@Bind("post_batch_id") Long postBatchId,@Bind("chunkId") long chunkId);

    @SqlQuery("select message from rpro_acct_xfer where id=:postBatchId and status = 'ERRORS' ")
    String getTransferErrorMessage(@Bind("postBatchId") Long postBatchId);

    @SqlQuery("select distinct post_batch_id from rpro_rc_schd where post_batch_id = :postBatchId")
    Long checkPostBatchExists(@Bind("postBatchId") Long postBatchId);

    @SqlUpdate("UPDATE rpro_acct_xfer SET no_of_schedules = 0, updt_dt = SYSDATE, updt_by = :user, message = NULL where ID = :post_batch_id")
    Integer updateHeaderOnRetry(@Bind("post_batch_id") Long postBatchId, @Bind("user") String user);

    @SqlUpdate("UPDATE rpro_acct_xfer SET updt_dt = SYSDATE, updt_by = :user, message = NULL where ID = :post_batch_id")
    Integer resetErrMsgHeaderOnRetry(@Bind("post_batch_id") Long postBatchId, @Bind("user") String user);

    @SqlCall("{call rpro_utility_pkg.record_log_act(:p_type, :p_text, :p_log_level)}")
    void recordOrgStatus(@Bind("p_type") String type, @Bind("p_text") String text, @Bind("p_log_level") Integer logLevel);

}
