package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.db.api.Account;
import com.zuora.neo.engine.db.api.RcLineAttributes;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLineNumAttributes;
import com.zuora.neo.engine.jobs.sfc.api.SfcSegmentsFlagsVersions;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;

import org.apache.commons.lang.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class SfcAcctSegmentsService {


    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcAcctSegmentsService.class);

    public SfcSegmentsFlagsVersions getSfcAcct(long lineId, String incomeStmtFlag, String drAcctFlag, String crAcctFlag, long bookId,
            String impairmentAccountFlag, String contractImpairmentAccountFlag, String contractLiabilityFlag, RcLineDetails rcLineDetails,
            SfcDbCacheContext sfcDbCacheContext, SfcDao sfcDao) {

        String accrualDrAcctgSegment = getAccountSegmentsForFlags(sfcDao, sfcDbCacheContext, rcLineDetails, drAcctFlag);
        String accrualCrAcctgSegment = getAccountSegmentsForFlags(sfcDao, sfcDbCacheContext, rcLineDetails, crAcctFlag);
        String incomeStmtDrAcctgSegment = getAccountSegmentsForFlags(sfcDao, sfcDbCacheContext, rcLineDetails, incomeStmtFlag);
        String incomeImpairmentSegment = getAccountSegmentsForFlags(sfcDao, sfcDbCacheContext, rcLineDetails, impairmentAccountFlag);
        String contractImpairmentSegment = getAccountSegmentsForFlags(sfcDao, sfcDbCacheContext, rcLineDetails, contractImpairmentAccountFlag);
        String contractLiabilitySegment = getAccountSegmentsForFlags(sfcDao, sfcDbCacheContext, rcLineDetails, contractLiabilityFlag);

        SfcSegmentsFlagsVersions sfcSegmentsFlagsVersions = new SfcSegmentsFlagsVersions();
        sfcSegmentsFlagsVersions.setCrAcctSeg(accrualCrAcctgSegment);
        sfcSegmentsFlagsVersions.setDrAcctSeg(accrualDrAcctgSegment);
        sfcSegmentsFlagsVersions.setIncomeAcctSeg(incomeStmtDrAcctgSegment);
        sfcSegmentsFlagsVersions.setIncomeImpairmentSeg(incomeImpairmentSegment);
        sfcSegmentsFlagsVersions.setContractImparimentSeg(contractImpairmentSegment);
        sfcSegmentsFlagsVersions.setContractLiabilitySeg(contractLiabilitySegment);
        return sfcSegmentsFlagsVersions;
    }

    public String getAccountSegmentsForFlags(SfcDao sfcDao, SfcDbCacheContext sfcDbCacheContext, RcLineDetails rcLineDetails, String flag) {

        List<Account> accountTableList = sfcDbCacheContext.getAccountTableList();
        List<Account> accountTableValuesForFlag = accountTableList.stream().filter(
                accountTableValue -> accountTableValue.getAcctTypeId().equals(flag)).collect(Collectors.toList());
        String segment = "";
        String concSegment = "";
        String segmentDelimiter = sfcDbCacheContext.getSegmentDelimiter();
        Map<String, String> rcLineColumnMethods = getRcLineColumnMethodsMap();
        for (Account accountTableValue : accountTableValuesForFlag) {
            if (accountTableValue.getSourceType().equals("CONSTANT")) {
                segment = accountTableValue.getSourceValue();
            } else if (accountTableValue.getSourceType().equals("LINE")) {
                String column = accountTableValue.getSourceValue();
                if (column.startsWith("ATR") || column.startsWith("NUM")) {
                    String methodName = rcLineColumnMethods.get(column);
                    RcLineAttributes rcLineAttributes = rcLineDetails.getRcLineAttributes();
                    RcLineNumAttributes rcLineNumAttributes = rcLineDetails.getRcLineNumAttributes();
                    if (methodName == null) {
                        LOGGER.error("Column " + column + " not found for this Doc Line ID " + rcLineDetails.getDocLineId());
                        continue;
                    }
                    Method method = null;
                    try {
                        if (column.startsWith("ATR")) {
                            method = Class.forName("com.zuora.neo.engine.db.api.RcLineAttributes").getMethod(methodName, null);
                            segment = (String) method.invoke(rcLineAttributes);
                        } else if (column.startsWith("NUM")) {
                            method = Class.forName("com.zuora.neo.engine.db.api.RcLineNumAttributes").getMethod(methodName, null);
                            segment = (String) method.invoke(rcLineNumAttributes);
                        }
                    } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                        LOGGER.error("No class or method found for Rc Line Details for doc line Id " + rcLineDetails.getDocLineId() + " method " + methodName);
                        LOGGER.error("Exception Occurred while invoking method " + methodName + " : " + e);
                        continue;
                    }
                } else if (column.startsWith("REV") || column.startsWith("DEF")) {
                    String positionStr = null;
                    if (accountTableValue.getSourceValue().length() > 8) {
                        positionStr = accountTableValue.getSourceValue().substring(7, 9);
                    } else if (accountTableValue.getSourceValue().length() > 7) {
                        positionStr = accountTableValue.getSourceValue().substring(7, 8);
                    }
                    int segmentNum = 0;
                    if (positionStr != null) {
                        segmentNum = Integer.parseInt(positionStr);
                    }
                    if (column.startsWith("REV")) {
                        segment = getSegment(rcLineDetails.getRevSegments(), segmentNum, segmentDelimiter);
                    } else if (column.startsWith("DEF")) {
                        segment = getSegment(rcLineDetails.getDefSegments(), segmentNum, segmentDelimiter);
                    }
                } else {
                    segment = sfcDao.getRcLineTableColumnValue(column, rcLineDetails.getId());
                }
            }

            if (concSegment.isEmpty() && !segment.isEmpty()) {
                concSegment = segment;
            } else if ((!concSegment.isEmpty() && !segment.isEmpty()) || (!concSegment.isEmpty() && segment.isEmpty())) {
                concSegment = concSegment + segmentDelimiter + segment;
            } else if (concSegment.isEmpty() && segment.isEmpty()) {
                concSegment = "^";
            }

            concSegment = StringUtils.stripStart(concSegment, "^");
        }

        return concSegment;
    }


    public String getSegment(String segments, int segmentNum, String segmentDelimiter) {
        String segment = "";
        if (segmentNum > 0) {
            String delimiter = segmentDelimiter == null ? "~" : segmentDelimiter;
            String str = delimiter + segments + delimiter;
            int before = instrOccurence(str, delimiter, segmentNum);
            int after = instrOccurence(str, delimiter, segmentNum + 1);
            if (before <= after) {
                segment = str.substring(before + 1, after);
            }
        }
        return segment;
    }

    public int instrOccurence(String str, String subStr, int occurence) {
        return StringUtils.ordinalIndexOf(str, subStr, occurence);
    }

    public Map<String, String> getRcLineColumnMethodsMap() {
        Map<String, String> rcLineColumnMethodsMap = new HashMap<>();
        rcLineColumnMethodsMap.put("ATR1", "getAtr1");
        rcLineColumnMethodsMap.put("ATR2", "getAtr2");
        rcLineColumnMethodsMap.put("ATR3", "getAtr3");
        rcLineColumnMethodsMap.put("ATR4", "getAtr4");
        rcLineColumnMethodsMap.put("ATR5", "getAtr5");
        rcLineColumnMethodsMap.put("ATR6", "getAtr6");
        rcLineColumnMethodsMap.put("ATR7", "getAtr7");
        rcLineColumnMethodsMap.put("ATR8", "getAtr8");
        rcLineColumnMethodsMap.put("ATR9", "getAtr9");
        rcLineColumnMethodsMap.put("ATR10", "getAtr10");
        rcLineColumnMethodsMap.put("ATR11", "getAtr11");
        rcLineColumnMethodsMap.put("ATR12", "getAtr12");
        rcLineColumnMethodsMap.put("ATR13", "getAtr13");
        rcLineColumnMethodsMap.put("ATR14", "getAtr14");
        rcLineColumnMethodsMap.put("ATR15", "getAtr15");
        rcLineColumnMethodsMap.put("ATR16", "getAtr16");
        rcLineColumnMethodsMap.put("ATR17", "getAtr17");
        rcLineColumnMethodsMap.put("ATR18", "getAtr18");
        rcLineColumnMethodsMap.put("ATR19", "getAtr19");
        rcLineColumnMethodsMap.put("ATR20", "getAtr20");
        rcLineColumnMethodsMap.put("ATR21", "getAtr21");
        rcLineColumnMethodsMap.put("ATR22", "getAtr22");
        rcLineColumnMethodsMap.put("ATR23", "getAtr23");
        rcLineColumnMethodsMap.put("ATR24", "getAtr24");
        rcLineColumnMethodsMap.put("ATR25", "getAtr25");
        rcLineColumnMethodsMap.put("ATR26", "getAtr26");
        rcLineColumnMethodsMap.put("ATR27", "getAtr27");
        rcLineColumnMethodsMap.put("ATR28", "getAtr28");
        rcLineColumnMethodsMap.put("ATR29", "getAtr29");
        rcLineColumnMethodsMap.put("ATR30", "getAtr30");
        rcLineColumnMethodsMap.put("ATR31", "getAtr31");
        rcLineColumnMethodsMap.put("ATR32", "getAtr32");
        rcLineColumnMethodsMap.put("ATR33", "getAtr33");
        rcLineColumnMethodsMap.put("ATR34", "getAtr34");
        rcLineColumnMethodsMap.put("ATR35", "getAtr35");
        rcLineColumnMethodsMap.put("ATR36", "getAtr36");
        rcLineColumnMethodsMap.put("ATR37", "getAtr37");
        rcLineColumnMethodsMap.put("ATR38", "getAtr38");
        rcLineColumnMethodsMap.put("ATR39", "getAtr39");
        rcLineColumnMethodsMap.put("ATR40", "getAtr40");
        rcLineColumnMethodsMap.put("ATR41", "getAtr41");
        rcLineColumnMethodsMap.put("ATR42", "getAtr42");
        rcLineColumnMethodsMap.put("ATR43", "getAtr43");
        rcLineColumnMethodsMap.put("ATR44", "getAtr44");
        rcLineColumnMethodsMap.put("ATR45", "getAtr45");
        rcLineColumnMethodsMap.put("ATR46", "getAtr46");
        rcLineColumnMethodsMap.put("ATR47", "getAtr47");
        rcLineColumnMethodsMap.put("ATR48", "getAtr48");
        rcLineColumnMethodsMap.put("ATR49", "getAtr49");
        rcLineColumnMethodsMap.put("ATR50", "getAtr50");
        rcLineColumnMethodsMap.put("ATR51", "getAtr51");
        rcLineColumnMethodsMap.put("ATR52", "getAtr52");
        rcLineColumnMethodsMap.put("ATR53", "getAtr53");
        rcLineColumnMethodsMap.put("ATR54", "getAtr54");
        rcLineColumnMethodsMap.put("ATR55", "getAtr55");
        rcLineColumnMethodsMap.put("ATR56", "getAtr56");
        rcLineColumnMethodsMap.put("ATR57", "getAtr57");
        rcLineColumnMethodsMap.put("ATR58", "getAtr58");
        rcLineColumnMethodsMap.put("ATR59", "getAtr59");
        rcLineColumnMethodsMap.put("ATR60", "getAtr60");
        rcLineColumnMethodsMap.put("NUM1", "getNum1");
        rcLineColumnMethodsMap.put("NUM2", "getNum2");
        rcLineColumnMethodsMap.put("NUM3", "getNum3");
        rcLineColumnMethodsMap.put("NUM4", "getNum4");
        rcLineColumnMethodsMap.put("NUM5", "getNum5");
        rcLineColumnMethodsMap.put("NUM6", "getNum6");
        rcLineColumnMethodsMap.put("NUM7", "getNum7");
        rcLineColumnMethodsMap.put("NUM8", "getNum8");
        rcLineColumnMethodsMap.put("NUM9", "getNum9");
        rcLineColumnMethodsMap.put("NUM10", "getNum10");
        rcLineColumnMethodsMap.put("NUM11", "getNum11");
        rcLineColumnMethodsMap.put("NUM12", "getNum12");
        rcLineColumnMethodsMap.put("NUM13", "getNum13");
        rcLineColumnMethodsMap.put("NUM14", "getNum14");
        rcLineColumnMethodsMap.put("NUM15", "getNum15");
        return rcLineColumnMethodsMap;
    }

}
