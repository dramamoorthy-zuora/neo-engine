package com.zuora.neo.engine.jobs.transferaccounting.activities.support;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.constants.AccountingParams;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.AccountingDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.GeneralLedgerDao;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.workflows.WorkflowResponse;

import org.jdbi.v3.core.Jdbi;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@ActivityImplementation
@Component
public class SupportActivityImpl implements SupportActivity {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SupportActivityImpl.class);
    private static final String LOCK_ERR = "Unable to lock application to transfer the batch";
    private static final String BATCH_ALREADY_TRANSFERRED = "Batch Already Transferred";
    private static final String NEW_LOCK_ERR = "Error: Unable to lock application to transfer the batch, message: Another BATCH collection IN progress";
    private static final String CUSTOM_API_ERR = "ERROR: During custom stage processor:";
    private static final String WRONG_BATCH = "Batch should not contain criteria from both arrangement and manual journal level";
    private static final String INCORRECT_BATCH_SETUP = "Batch criteria setup is incorrect";
    private static final String UPDATE_ERR = "Error: In Update for Batch ID. ERROR:Batch criteria setup is incorrect";
    private static final String CRITERIA_ERR = "Batch Criteria Field does not exist in the lookup TRANSFER_BATCH_CRITERIA OR Alias is NULL";
    private static final String BATCH_ID_ERR = "Post batch Id can't be null";
    private static final String ACTION_ERR = "Action is not provided for the batch";
    @Autowired
    ParseProgramParameters parseProgramParameters;

    @Override
    public WorkflowResponse checkTransferBatch(ThreadedAccountingResult accountingResult) {
        if (accountingResult.getTransferMessage() != null && LOCK_ERR.equals(accountingResult.getTransferMessage())) {
            return new WorkflowResponse(RevenueJobStatus.FAILED, NEW_LOCK_ERR);
        }
        if (accountingResult.getTransferMessage() != null && BATCH_ALREADY_TRANSFERRED.equals(accountingResult.getTransferMessage())) {
            return new WorkflowResponse(RevenueJobStatus.WARNING, BATCH_ALREADY_TRANSFERRED);
        }

        return null;
    }

    @Override
    public WorkflowResponse handleCustomApiErrors(ThreadedAccountingResult accountingResult) {
        if (accountingResult.getTransferMessage() != null && accountingResult.getTransferMessage().contains(CUSTOM_API_ERR)) {
            return new WorkflowResponse(RevenueJobStatus.ERROR, accountingResult.getTransferMessage());
        }
        return null;
    }

    @Override
    public WorkflowResponse handleIncorrectBatchSetup(ThreadedAccountingResult accountingResult) {
        if (accountingResult.getTransferMessage() != null
                && (accountingResult.getTransferMessage().contains(WRONG_BATCH)
                || accountingResult.getTransferMessage().contains(INCORRECT_BATCH_SETUP)
                || accountingResult.getTransferMessage().contains(CRITERIA_ERR))) {
            return new WorkflowResponse(RevenueJobStatus.ERROR, UPDATE_ERR);
        }
        return null;
    }

    @Override
    public Boolean checkBatchExists(Long postBatchId) {
        Jdbi jdbi = DbContext.getConnection();
        return jdbi.withHandle(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            Long batchId = accountingDao.checkPostBatchExists(postBatchId);
            Boolean exists = batchId != null ? true : false;
            return exists;
        });
    }

    @Override
    public void updateHeaderForRetry(Long postBatchId, String user) {
        Jdbi jdbi = DbContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            Integer updated = accountingDao.updateHeaderOnRetry(postBatchId, user);
            LOGGER.info("updated for retry: " + updated);
        });
    }

    @Override
    public Boolean glDataExists(Long postBatchId) {
        Jdbi jdbi = DbContext.getConnection();
        return jdbi.withHandle(handle -> {
            GeneralLedgerDao ledgerDao = handle.attach(GeneralLedgerDao.class);
            Integer glIntStageExists = ledgerDao.glIntStageExists(postBatchId);
            Boolean exists = glIntStageExists != null ? true : false;
            return exists;
        });
    }

    @Override
    public void resetErrorMsgOnRetry(Long postBatchId, String user) {
        Jdbi jdbi = DbContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            Integer updated = accountingDao.resetErrMsgHeaderOnRetry(postBatchId, user);
            LOGGER.info("reset ErrMsg in Header On Retry: " + updated);
        });
    }

    @Override
    public String getDeleteAction(WorkflowRequest request) {
        String action = null;
        Map<String, String> paramsMap = parseProgramParameters.parseParamString(request.getTenantId(), request.getProgramId(), request.getParameterText());
        if (paramsMap.containsKey(AccountingParams.TYPE)) {
            action = paramsMap.get(AccountingParams.TYPE);
            if (action == null) { //throw error or continue with both update and transfer??
                NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, ACTION_ERR);
            }
        }
        return action;
    }

    @Override
    public Long getPostBatchId(WorkflowRequest request) {
        Long postBatchId = null;
        Map<String, String> paramsMap = parseProgramParameters.parseParamString(request.getTenantId(), request.getProgramId(), request.getParameterText());
        if (paramsMap.containsKey(AccountingParams.BATCH_ID)) {
            String postBatchIdStr = paramsMap.get(AccountingParams.BATCH_ID);
            postBatchId =  Long.valueOf(postBatchIdStr);
            if (postBatchId == null) {
                NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, BATCH_ID_ERR);
            }
        }
        return postBatchId;
    }
}
