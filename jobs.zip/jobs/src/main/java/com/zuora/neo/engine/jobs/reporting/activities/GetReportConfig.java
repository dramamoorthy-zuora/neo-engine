package com.zuora.neo.engine.jobs.reporting.activities;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface GetReportConfig {

    String getRecords();
}
