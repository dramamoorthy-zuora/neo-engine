package com.zuora.neo.engine.jobs.sfc.db.api;

public enum PrincipleWeightageColumn {
    EXT_SLL_PRC,
    EXT_FV_PRC,
    EXT_LST_PRC,
}
