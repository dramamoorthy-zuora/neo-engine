package com.zuora.neo.engine.jobs.transferaccounting.activities.closeprocess;

import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;

import io.temporal.activity.ActivityInterface;

@ActivityInterface
public interface CloseProcessActivity {
    void doSummaryAnalysis(ThreadedAccountingResult accountingResult, String orgId);
}
