package com.zuora.neo.engine.jobs.sfc.db.api;


public class FinanceTypeFlagDetails {

    private long  vcTypeId;
    private String   drAcctgFlag;
    private String   crAcctgFlag;
    private String   incomeStmtFlag;
    private String   accrualUponBillFlag;
    private String   contractLiabilityFlag;

    public FinanceTypeFlagDetails(long vcTypeId, String drAcctgFlag, String crAcctgFlag, String incomeStmtFlag,
            String accrualUponBillFlag, String contractLiabilityFlag) {
        this.vcTypeId = vcTypeId;
        this.drAcctgFlag = drAcctgFlag;
        this.crAcctgFlag = crAcctgFlag;
        this.incomeStmtFlag = incomeStmtFlag;
        this.accrualUponBillFlag = accrualUponBillFlag;
        this.contractLiabilityFlag = contractLiabilityFlag;
    }

    public long getVcTypeId() {
        return vcTypeId;
    }

    public void setVcTypeid(long vcTypeId) {
        this.vcTypeId = vcTypeId;
    }

    public String getDrAcctgFlag() {
        return drAcctgFlag;
    }

    public void setDrAcctgFlag(String drAcctgFlag) {
        this.drAcctgFlag = drAcctgFlag;
    }

    public String getCrAcctgFlag() {
        return crAcctgFlag;
    }

    public void setCrAcctgFlag(String crAcctgFlag) {
        this.crAcctgFlag = crAcctgFlag;
    }

    public String getIncomeStmtFlag() {
        return incomeStmtFlag;
    }

    public void setIncomeStmtFlag(String incomeStmtFlag) {
        this.incomeStmtFlag = incomeStmtFlag;
    }

    public String getAccrualUponBillFlag() {
        return accrualUponBillFlag;
    }

    public void setAccrualUponBillFlag(String accrualUponBillFlag) {
        this.accrualUponBillFlag = accrualUponBillFlag;
    }

    public String getContractLiabilityFlag() {
        return contractLiabilityFlag;
    }

    public void setContractLiabilityFlag(String contractLiabilityFlag) {
        this.contractLiabilityFlag = contractLiabilityFlag;
    }

    @Override
    public String toString() {
        return "FinanceTypeFlagDetails{"
                + "vcTypeid='" + vcTypeId + '\''
                + ", drAcctgFlag='" + drAcctgFlag + '\''
                + ", crAcctgFlag=" + crAcctgFlag
                + ", incomeStmtFlag=" + incomeStmtFlag
                + ", accrualUponBillFlag=" + accrualUponBillFlag
                + '}';
    }
}
