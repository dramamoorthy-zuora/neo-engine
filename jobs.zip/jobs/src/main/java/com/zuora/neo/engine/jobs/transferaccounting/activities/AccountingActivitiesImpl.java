package com.zuora.neo.engine.jobs.transferaccounting.activities;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.JobsMetadata;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.db.dao.LockDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.TransferAccountingTestEvaluator;
import com.zuora.neo.engine.jobs.transferaccounting.api.ChunkRecord;
import com.zuora.neo.engine.jobs.transferaccounting.api.ThreadDetails;

import com.zuora.neo.engine.jobs.transferaccounting.config.Properties;
import com.zuora.neo.engine.jobs.transferaccounting.constants.AccountingParams;
import com.zuora.neo.engine.jobs.transferaccounting.constants.TransferStatus;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.BookOrgRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.SplitBatchRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.AccountingDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.CriteriaLookupDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.SplitDao;
import com.zuora.neo.engine.scheduler.RevenueJobStatus;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.OutParameters;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

@ActivityImplementation
@Component
public class AccountingActivitiesImpl implements AccountingActivities {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AccountingActivitiesImpl.class);
    private static final String delimiterCharacter = ":";
    private static final String defaultIndicators = "NNNGNNNNNNNNNNNNNNNN";
    private static final String postBatchIdSeq = "RPRO_ACCT_XFER_ID_S";
    private static final String transferBatch = "TRANSFER BATCH";
    private static final String criteriaIdSeq = "RPRO_CRITERIA_ID_S";
    private static final String batchInProgress = "Transfer Batch is in Progress";
    private static final String lockErr = "Unable to lock application to transfer the batch";
    private static final String bookErr = "Invalid Book Name";
    private static final String noBookData = "No Postable Book found";
    private static final String manyBookErr = "Multiple Books found, Please choose a Book to Post";
    private static final String invalidPeriod = "Period is not Opened for the Book";
    private static final String BATCH_ID_ERR = "Post batch Id can't be null";
    private static final String ACTION_ERR = "Action is not provided for the batch";
    private static final String splitType = "RC_ID";
    private static final String batchType = "TRANSFER";

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;
    @Autowired
    ParseProgramParameters parseProgramParameters;
    @Autowired
    Properties properties;

    @Override
    //The transfer accounting process consist of 2 main components – UPDATE and TRANSFER
    public ThreadedAccountingResult processTransferAccounting(String orgId) {
        LOGGER.debug("Process Transfer Accounting Activity initiated");

        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Long clientId =  request.getClientId();
        String[] criteriaParams = new String[0];
        String[] criteriaValParams = new String[0];
        String[] excludeFlags = new String[0];
        Long postBatchId = null;
        String action;
        Map<String, String> paramsMap;

        if (request.getProgramId() == JobsMetadata.TRANSFER_ACCOUNTING_MASTER.getId()) {
            if (request.getParameterText() == null || request.getParameterText().isEmpty()) {
                neoWorkflowLogger.log("No batch criteria selected, will proceed with default criteria !!");
            } else {
                paramsMap = parseProgramParameters.parseParamString(request.getTenantId(), request.getProgramId(), request.getParameterText());
                String criteriaName = paramsMap.get(AccountingParams.CRITERIA_NAME);
                String criteriaValue = paramsMap.get(AccountingParams.CRITERIA_VALUE);
                String excludeFlag = paramsMap.get(AccountingParams.EXCLUDE_FLAG);
                criteriaParams = criteriaName.split(delimiterCharacter);
                criteriaValParams = criteriaValue.split(delimiterCharacter);
                excludeFlags = excludeFlag.split(delimiterCharacter);
            }
        } else if (request.getProgramId() == JobsMetadata.UI_TRANSFER_ACCOUNTING.getId()) {
            paramsMap = parseProgramParameters.parseParamString(request.getTenantId(), request.getProgramId(), request.getParameterText());
            if (paramsMap.containsKey(AccountingParams.BATCH_ID)) {
                String postBatchIdStr = paramsMap.get(AccountingParams.BATCH_ID);
                postBatchId =  Long.valueOf(postBatchIdStr);
                if (postBatchId == null) {
                    NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, BATCH_ID_ERR);
                }
            }
            if (paramsMap.containsKey(AccountingParams.TYPE)) {
                action = paramsMap.get(AccountingParams.TYPE);
                if (action == null) { //throw error or continue with both update and transfer??
                    NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, ACTION_ERR);
                }
            }
        } else if (request.getProgramId() == JobsMetadata.TRANSFER_ACCOUNTING.getId()) {
            if (request.getParameterText() == null || request.getParameterText().isEmpty()) {
                neoWorkflowLogger.log("No batch criteria selected, will proceed with default criteria !!");
            } else {
                paramsMap = parseProgramParameters.parseParamString(request.getTenantId(), request.getProgramId(), request.getParameterText());
                String criteriaName = paramsMap.get(AccountingParams.CRI_NAME);
                String criteriaValue = paramsMap.get(AccountingParams.CRI_VAL);
                String excludeFlag = paramsMap.get(AccountingParams.EXC_FLAG);
                criteriaParams = criteriaName.split(delimiterCharacter);
                criteriaValParams = criteriaValue.split(delimiterCharacter);
                excludeFlags = excludeFlag.split(delimiterCharacter);
            }
        }

        final String[] bookName = {null};
        Jdbi jdbi = DbContext.getConnection();
        ThreadedAccountingResult accountingResult = new ThreadedAccountingResult();

        try {
            String[] finalCriteriaParams = criteriaParams;
            String[] finalExcludeFlags = excludeFlags;
            String[] finalCriteriaValParams = criteriaValParams;
            Long finalPostBatchId = postBatchId;
            jdbi.useHandle(handle -> {
                CommonDao commonDao = handle.attach(CommonDao.class);
                properties.load(commonDao, request.getTenantId());
                if (request.getProgramId() == JobsMetadata.TRANSFER_ACCOUNTING.getId()
                        || request.getProgramId() == JobsMetadata.TRANSFER_ACCOUNTING_MASTER.getId()
                        || request.getProgramId() == JobsMetadata.RETRY_ACCOUNTING.getId()) {
                    doAccountTransferInTransaction(handle, finalCriteriaParams, finalExcludeFlags,
                            finalCriteriaValParams, clientId, bookName, request, accountingResult, orgId);
                } else if (request.getProgramId() == JobsMetadata.UI_TRANSFER_ACCOUNTING.getId()) {
                    doUiAccountingFlowForAction(handle, finalPostBatchId, request, accountingResult);
                }
            });
        } catch (Exception e) {
            //TODO: discuss on exceptions to be handled or raised. will do it in separate PR
            LOGGER.error("Error in transfer accounting flow: " + e.getMessage());
            throw e;
        }

        return accountingResult;
    }

    @Override
    public List<String> getAllOrgs() {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Jdbi jdbi = DbContext.getConnection();
        return jdbi.withHandle(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            List<String> orgList = accountingDao.getAllOrgs(request.getRoleId());
            return orgList;
        });
    }

    @Override
    public void releaseLock(String orgId) {
        Jdbi jdbi = DbContext.getConnection();
        jdbi.useHandle(handle -> {
            LockDao lockDao = handle.attach(LockDao.class);
            Integer lockCount = lockDao.checkLockExists();
            if (lockCount > 0) {
                lockDao.removeLock(orgId);
            }
        });
    }

    @Override
    public  void cleanupActivities(String org, WorkflowRequest request) {
        releaseLock(org);
        properties.resetLoadedFlag(request.getTenantId());
    }

    @Override
    public ThreadDetails getNumThreadAndBatches(ThreadedAccountingResult accountingResult, String org) {
        AtomicReference<List<SplitBatchRecord>> batches = new AtomicReference<>(new ArrayList<>());
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();

        Jdbi jdbi = DbContext.getConnection();
        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            SplitDao splitDao = handle.attach(SplitDao.class);
            properties.load(commonDao, request.getTenantId());
            batches.set(splitDao.getSplitBatches(accountingResult.getPostBatchId(), splitType, accountingResult.getBookId(), batchType));
        });

        List<ChunkRecord> batchIds = new ArrayList<>();
        for (SplitBatchRecord record : batches.get()) {
            ChunkRecord chunkRecord = new ChunkRecord(record.getBatchId(), record.getChunkId());
            batchIds.add(chunkRecord);
        }
        Integer numThreads = properties.getNoOfThreads();

        return new ThreadDetails(numThreads, batchIds);
    }

    @Override
    public Integer getNumberOfThreads() {
        Jdbi jdbi = DbContext.getConnection();
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            properties.load(commonDao, request.getTenantId());

        });
        return properties.getNoOfThreads();
    }

    @Override
    public void processBatchPerOrgInfo(String orgId, Long postBatchId, String status, String message) {
        Jdbi jdbi = DbContext.getConnection();
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        jdbi.useHandle(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            accountingDao.insertOrgBatch(postBatchId, orgId, status, request.getUser(), message);
            String text = "Master job for Org " + orgId + " ran with status: " + status;
            accountingDao.recordOrgStatus("MASTER_JOB_STATUS", text, 10);
        });
    }

    @Override
    public void acquireLock(Long postBatchId, String orgId) {
        Jdbi jdbi = DbContext.getConnection();
        jdbi.useHandle(handle -> {
            LockDao lockDao = handle.attach(LockDao.class);
            Integer lockCount = lockDao.checkLockExists();
            if (lockCount > 0) {
                lockDao.removeLock(orgId);
            }
            OutParameters outParameters = lockDao.acquireLock(postBatchId, transferBatch, batchInProgress, orgId);
            String errorBuffer = outParameters.getString("p_ret_msg");
            String lockResult = outParameters.getString("p_result");
            LOGGER.info("Acquire Results : " + errorBuffer + " " + lockResult);
        });
    }

    private ThreadedAccountingResult doAccountTransferInTransaction(Handle handle, String[] criteriaParams, String[] excludeFlags,
            String[] criteriaValParams, Long clientId, String[] bookName,
            WorkflowRequest request, ThreadedAccountingResult accountingResult, String orgId) {
        CommonDao commonDao = handle.attach(CommonDao.class);
        AccountingDao accountingDao = handle.attach(AccountingDao.class);
        LockDao lockDao = handle.attach(LockDao.class);
        CriteriaLookupDao lookupDao = handle.attach(CriteriaLookupDao.class);
        String langProfileName = properties.getLanguage();

        Long bookId = null;
        if (criteriaParams.length != 0) {
            for (int i = 0; i < criteriaParams.length; ++i) {
                if ("BOOK_NAME".equals(criteriaParams[i])) {
                    bookName[0] = criteriaValParams[i];
                    bookId = commonDao.getBookId(bookName[0], clientId);
                    if (bookId == null) {
                        NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, bookErr);
                    }
                }
            }
        }

        if (bookId == null) {
            List<Long> globalBookId = accountingDao.getGlobalBookId();
            globalBookId = TransferAccountingTestEvaluator.noGlobalBookId(globalBookId);
            if (globalBookId.isEmpty()) {
                lockDao.removeLock(orgId);
                NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, noBookData);
            }
            globalBookId = TransferAccountingTestEvaluator.multipleGlobalBookId(globalBookId);
            if (!globalBookId.isEmpty() && globalBookId.size() > 1) {
                lockDao.removeLock(orgId);
                NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, manyBookErr);
            } else {
                bookId = globalBookId.get(0);
            }
        }

        Long currentPeriodId = commonDao.getCrtdPeriodId(bookId, orgId);

        currentPeriodId = TransferAccountingTestEvaluator.invalidCrtdPeriodId(currentPeriodId);
        if (currentPeriodId == null) {
            lockDao.removeLock(orgId);
            NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, invalidPeriod + " " + bookId);
        }
        Long postBatchId = commonDao.getNextSequenceNumber(postBatchIdSeq, request.getClientId());
        StringBuilder defaultIndicator = new StringBuilder("NNNNNNNNNNNNNNNNNNNN");
        accountingDao.insertHeader(postBatchId, TransferStatus.NEW.getTransferStatus(), request.getClientId(),
                currentPeriodId, orgId, bookId, request.getUser(), defaultIndicator.toString());
        LOGGER.info("Created Transfer batch id {}", postBatchId + " for the requested id:: " + request.getRequestId());
        neoWorkflowLogger.log("Created Transfer batch id::" + postBatchId + " for the requested id:: " + request.getRequestId());

        List<String> criteriaNames = lookupDao.getBatchCriteria(langProfileName);
        ArrayList<String> criteriaNameList = new ArrayList<>();
        if (criteriaParams.length != 0) {
            criteriaNameList.addAll(Arrays.asList(criteriaParams));
            List<String> streamList = criteriaNameList.stream()
                    .filter(
                            two -> criteriaNames.stream()
                                    .noneMatch(one -> one.equals(two))
                    )
                    .collect(Collectors.toList());
            if (!streamList.isEmpty()) {
                String errMsg = "Criteria name " + streamList + " not defined in the lookup";
                accountingResult.setTransferStatus(TransferStatus.ERROR.name());
                accountingResult.setTransferMessage(errMsg);
                return accountingResult;
                //NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, errMsg);
            }

            String operator = null;
            for (int i = 0; i < criteriaParams.length; ++i) {
                if ("Y".equalsIgnoreCase(excludeFlags[i])) {
                    operator = "<>";
                } else {
                    operator = "=";
                }
                Long criteriaId = commonDao.getNextSequenceNumber(criteriaIdSeq, request.getClientId());
                LOGGER.info("Created criteria criteriaId {}", criteriaId + " for the requested id:: " + request.getRequestId());
                neoWorkflowLogger.log("Created criteria criteriaId::" + criteriaId + " for the requested id:: " + request.getRequestId());
                lookupDao.insertCriteria(criteriaId, criteriaParams[i], operator, criteriaValParams[i], postBatchId, defaultIndicators,
                        clientId, currentPeriodId, request.getUser());
            }
        }

        checkLockExists(lockDao, postBatchId, orgId, request, accountingResult, accountingDao);

        accountingResult = doAccountTransfer(accountingDao, postBatchId, bookId, accountingResult, request);

        return accountingResult;
    }

    private ThreadedAccountingResult doUiAccountingFlowForAction(Handle handle, Long postBatchId,
            WorkflowRequest request, ThreadedAccountingResult accountingResult) {
        LockDao lockDao = handle.attach(LockDao.class);
        AccountingDao accountingDao = handle.attach(AccountingDao.class);

        BookOrgRecord rec = accountingDao.getBookIdForBatch(postBatchId).get(0);
        Long bookId = null;
        String orgId = null;
        if (rec != null) {
            bookId = rec.getBookId();
            if (bookId == null) {
                List<Long> globalBookId = accountingDao.getGlobalBookId();
                if (globalBookId.isEmpty()) {
                    lockDao.removeLock(orgId);
                    NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, noBookData);
                }
                if (!globalBookId.isEmpty() && globalBookId.size() > 1) {
                    lockDao.removeLock(orgId);
                    NonRetryableActivityException.throwNonRetryableActivityException(RevenueJobStatus.ERROR, manyBookErr);
                } else {
                    bookId = globalBookId.get(0);
                }
            }
            orgId = rec.getOrgId();
            if (orgId == null) {
                orgId = request.getOrgId();
            }
        }

        checkLockExists(lockDao, postBatchId, orgId, request, accountingResult, accountingDao);

        accountingResult = doAccountTransfer(accountingDao, postBatchId, bookId, accountingResult, request);
        accountingResult.setPostBatchId(postBatchId);

        accountingResult.setOrgId(orgId);

        return accountingResult;
    }

    private ThreadedAccountingResult checkLockExists(LockDao lockDao, Long postBatchId, String orgId,
            WorkflowRequest request, ThreadedAccountingResult accountingResult, AccountingDao accountingDao) {
        OutParameters outParameters = lockDao.acquireLock(postBatchId, transferBatch, batchInProgress, orgId);
        String errorBuffer = outParameters.getString("p_ret_msg");
        String lockResult = outParameters.getString("p_result");
        if ("FALSE".equals(lockResult)) {
            LOGGER.error(lockErr, errorBuffer);
            accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
            accountingResult.setTransferMessage(lockErr);
            accountingDao.updateTransferStatusMsg(TransferStatus.ERROR.getTransferStatus(),lockErr, request.getUser(), postBatchId);
            return accountingResult;
        }
        return accountingResult;
    }



    private ThreadedAccountingResult doAccountTransfer(AccountingDao accountingDao, Long postBatchId,
            Long bookId, ThreadedAccountingResult accountingResult, WorkflowRequest request) {
        int transferStatusCount = accountingDao.getTransferStatusCount(postBatchId);
        transferStatusCount = TransferAccountingTestEvaluator.batchAlreadyTransferred(transferStatusCount);
        if (transferStatusCount > 0) {
            String errMsg = "Batch Already Transferred";
            accountingResult.setTransferMessage(errMsg);
            accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
            accountingDao.updateTransferStatusMsg(TransferStatus.ERROR.getTransferStatus(),errMsg, request.getUser(), postBatchId);
            return accountingResult;
        }

        accountingResult.setPostBatchId(postBatchId);
        accountingResult.setBookId(bookId);
        accountingResult.setTransferStatus(accountingDao.getTransferStatus(postBatchId));

        Integer noOfThreads = properties.getNoOfThreads();
        accountingResult.setNoOfThreads(noOfThreads);

        return accountingResult;
    }

    @Override
    public void resetBatchDetailsForUpdateUI(Long postBatchId) {
        Jdbi jdbi = DbContext.getConnection();

        jdbi.useHandle(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            neoWorkflowLogger.log("before cleanup:");
            Integer rowCountPostBatchId = accountingDao.cleanupPostBatchIdSchd(postBatchId);
            Integer rowCountXfer = accountingDao.resetNoOfSchedules(postBatchId);
            neoWorkflowLogger.log(" rowCount for cleanupPostBatchId in Schedules : " + rowCountPostBatchId);
            neoWorkflowLogger.log(" rowCount for cleanupXfer in Xfer : " + rowCountXfer);
        });

    }

    @Override
    public String getOrgId(WorkflowRequest request) {
        String org;
        if (request.getParameterText() == null || request.getParameterText().isEmpty()) {
            LOGGER.info("No batch criteria selected, will proceed with default criteria !!");
            org = String.valueOf(request.getOrgId()); //TODO: what should be default org if not sent
        } else {
            Map<String, String> paramsMap = parseProgramParameters.parseParamString(request.getTenantId(), request.getProgramId(), request.getParameterText());
            org = paramsMap.get(AccountingParams.ORG_ID);
        }
        return org;
    }

}
