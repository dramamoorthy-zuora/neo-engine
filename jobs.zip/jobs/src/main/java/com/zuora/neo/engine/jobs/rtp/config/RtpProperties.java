package com.zuora.neo.engine.jobs.rtp.config;

import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.rtp.constants.RtpConstants;
import com.zuora.neo.engine.jobs.rtp.constants.RtpProfiles;

import lombok.Data;
import org.springframework.stereotype.Component;

@Data
@Component
public class RtpProperties {

    private boolean rtpEnabled;
    private int batchSize;

    private int maxRetryCount;

    private boolean shadowMode;

    public RtpProperties() {
        rtpEnabled = false;
        batchSize = 1;
        maxRetryCount = 5;
        shadowMode = true;
    }

    public void load(CommonDao commonDao) {

        // TODO: Once Redis is setup, will implement cache on properties
        rtpEnabled = commonDao.getProfileValueFromTable(RtpProfiles.ENABLE_REALTIME_PROCESSING, "N").equals("Y");
        shadowMode = commonDao.getProfileValueFromTable(RtpProfiles.ENABLE_REALTIME_PROCESSING_SHADOW_MODE, "Y").equals("Y");
        batchSize = commonDao.getProfileValueFromTable(RtpProfiles.RTP_BATCH_SIZE, 1);
        maxRetryCount = RtpConstants.RTP_WI_HEADERS_MAX_RETRY_COUNT;

    }

    @Override
    public String toString() {
        return "RtpProperties{"
                + "rtpEnabled=" + rtpEnabled
                + ", batchSize=" + batchSize
                + ", maxRetryCount=" + maxRetryCount
                + ", shadowMode=" + shadowMode
                + '}';
    }
}
