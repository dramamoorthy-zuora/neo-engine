package com.zuora.neo.engine.jobs.sfc.db.api;

import java.math.BigDecimal;
import java.util.Date;

public class SfcPaymentDetails {

    private long id;
    private Date paymtDate;
    private String docLineId;
    private BigDecimal paymtAmt;
    private BigDecimal netPaymtAmt;
    private BigDecimal interestAccrual;
    private Date paymtStartDate;
    private Date paymtEndDate;


    public SfcPaymentDetails(long id, Date paymtDate, String docLineId, BigDecimal paymtAmt, BigDecimal netPaymtAmt,
            BigDecimal interestAccrual, Date paymtStartDate, Date paymtEndDate) {
        this.id = id;
        if (paymtDate == null) {
            this.paymtDate = null;
        } else {
            this.paymtDate = new Date(paymtDate.getTime());
        }
        this.docLineId = docLineId;
        this.paymtAmt = paymtAmt;
        this.netPaymtAmt = netPaymtAmt;
        this.interestAccrual = interestAccrual;
        if (paymtStartDate == null) {
            this.paymtStartDate = null;
        } else {
            this.paymtStartDate = new Date(paymtStartDate.getTime());
        }
        if (paymtEndDate == null) {
            this.paymtEndDate = null;
        } else {
            this.paymtEndDate = new Date(paymtEndDate.getTime());
        }
    }

    public SfcPaymentDetails() {

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getPaymtDate() {
        if (paymtDate == null) {
            return null;
        } else {
            return new Date(paymtDate.getTime());
        }
    }

    public void setPaymtDate(Date paymtDate) {
        if (paymtDate == null) {
            this.paymtDate = null;
        } else {
            this.paymtDate = new Date(paymtDate.getTime());
        }
    }

    public String getDocLineId() {
        return docLineId;
    }

    public void setDocLineId(String docLineId) {
        this.docLineId = docLineId;
    }

    public BigDecimal getPaymtAmt() {
        return paymtAmt;
    }

    public void setPaymtAmt(BigDecimal paymtAmt) {
        this.paymtAmt = paymtAmt;
    }

    public BigDecimal getNetPaymtAmt() {
        return netPaymtAmt;
    }

    public void setNetPaymtAmt(BigDecimal netPaymtAmt) {
        this.netPaymtAmt = netPaymtAmt;
    }

    public BigDecimal getInterestAccrual() {
        return interestAccrual;
    }

    public void setInterestAccrual(BigDecimal interestAccrual) {
        this.interestAccrual = interestAccrual;
    }

    public Date getPaymtStartDate() {
        if (paymtStartDate == null) {
            return null;
        } else {
            return new Date(paymtStartDate.getTime());
        }
    }

    public void setPaymtStartDate(Date paymtStartDate) {
        if (paymtStartDate == null) {
            this.paymtStartDate = null;
        } else {
            this.paymtStartDate = new Date(paymtStartDate.getTime());
        }
    }

    public Date getPaymtEndDate() {
        if (paymtEndDate == null) {
            return null;
        } else {
            return new Date(paymtEndDate.getTime());
        }
    }

    public void setPaymtEndDate(Date paymtEndDate) {
        if (paymtEndDate == null) {
            this.paymtEndDate = null;
        } else {
            this.paymtEndDate = new Date(paymtEndDate.getTime());
        }
    }

    public static class Builder {

        private long id;
        private Date paymtDate;
        private String docLineId;
        private BigDecimal paymtAmt;
        private BigDecimal netPaymtAmt;
        private BigDecimal interestAccrual;
        private Date paymtStartDate;
        private Date paymtEndDate;


        public Builder() {
        }

        public Builder withId(long id) {
            this.id = id;
            return this;
        }

        public Builder withPaymtDate(Date paymtDate) {
            if (paymtDate == null) {
                this.paymtDate = null;
            } else {
                this.paymtDate = new Date(paymtDate.getTime());
            }
            return this;
        }

        public Builder withDocLineId(String docLineId) {
            this.docLineId = docLineId;
            return this;
        }

        public Builder withPaymtAmt(BigDecimal paymtAmt) {
            this.paymtAmt = paymtAmt;
            return this;
        }

        public Builder withNetPaymtAmt(BigDecimal netPaymtAmt) {
            this.netPaymtAmt = netPaymtAmt;
            return this;
        }

        public Builder withNetInterestAccrual(BigDecimal interestAccrual) {
            this.interestAccrual = interestAccrual;
            return this;
        }

        public Builder withPaymtStartDate(Date paymtStartDate) {
            if (paymtStartDate == null) {
                this.paymtStartDate = null;
            } else {
                this.paymtStartDate = new Date(paymtStartDate.getTime());
            }
            return this;
        }

        public Builder withPaymtEndDate(Date paymtEndDate) {
            if (paymtEndDate == null) {
                this.paymtEndDate = null;
            } else {
                this.paymtEndDate = new Date(paymtEndDate.getTime());
            }
            return this;
        }

        public SfcPaymentDetails build() {
            return new SfcPaymentDetails(id, paymtDate, docLineId,
                    paymtAmt, netPaymtAmt, interestAccrual, paymtStartDate, paymtEndDate);
        }
    }
}
