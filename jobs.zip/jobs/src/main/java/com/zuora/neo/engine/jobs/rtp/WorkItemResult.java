package com.zuora.neo.engine.jobs.rtp;

public class WorkItemResult {

    String errorMessage;
    Integer returnCode;

    public WorkItemResult(String errorMessage, Integer returnCode) {
        this.errorMessage = errorMessage;
        this.returnCode = returnCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public Integer getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(Integer returnCode) {
        this.returnCode = returnCode;
    }

    public Boolean isSuccess() {
        return returnCode != null && returnCode.equals(0);
    }

    public Boolean isSkipped() {
        return returnCode != null && returnCode.equals(1);
    }

    @Override
    public String toString() {
        return "WorkItemResult{"
                +   "errorMessage='" + errorMessage + '\''
                +   ", returnCode=" + returnCode
                +   '}';
    }
}
