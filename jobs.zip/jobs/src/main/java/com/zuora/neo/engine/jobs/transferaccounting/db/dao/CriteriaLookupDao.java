package com.zuora.neo.engine.jobs.transferaccounting.db.dao;

import com.zuora.neo.engine.jobs.transferaccounting.db.api.BatchCriteria;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.BatchCriteriaMapper;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.ValueMapper;

import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.statement.UseRowMapper;

import java.util.List;

public interface CriteriaLookupDao {
    @SqlQuery("SELECT lkpv.lookup_code AS VALUE\n"
            + "FROM rpro_lkp lkp,rpro_lkp_val lkpv,rpro_lkp_val_ml lkpvml\n"
            + "WHERE lkp.ID = lkpv.lookup_id\n"
            + "AND lkpv.id = lkpvml.id\n"
            + "AND lkp.NAME = 'TRANSFER_BATCH_CRITERIA'\n"
            + "AND lkpv.active_flag = 'Y'\n"
            + "AND lkpvml.language = :language")
    //AND lkpvml.display_value = l_cri_name(i);
    @UseRowMapper(ValueMapper.class)
    List<String> getBatchCriteria(@Bind("language") String language);

    @SqlUpdate("insert into rpro_criteria (ID,seq,NAME,OPERATOR,operand,OBJ_ID,obj_type,indicators,client_id,"
            + "crtd_prd_id,crtd_by,crtd_dt,updt_by,updt_dt,obj_version) "
            + "values (?,NULL,?,?,?,?,'ACCT_XFER',rpro_criteria_pkg.set_enabled_flag (?, 'Y'),?,?,?,SYSDATE,NULL,NULL,NULL)")
    void insertCriteria(Long id, String name, String operator, String operand, Long objId, String indicators,
            Long clientId, Long currentPeriodId, String createdBy);

    @SqlQuery("SELECT rc.obj_id post_batch_id,rlv.lookup_code field_name,rc.OPERATOR,rc.operand,rc.ID criteria_id,UPPER (rlv.sub_group1) ALIAS"
            + " ,UPPER (rlv.sub_group2) field_val FROM rpro_criteria rc,rpro_lkp rl,rpro_lkp_val rlv"
            + " WHERE rc.obj_id = :postBatchId AND rc.obj_type = 'ACCT_XFER' AND rpro_criteria_pkg.get_enabled_flag (rc.indicators) = 'Y'"
            + " AND UPPER (rc.NAME) = UPPER (rlv.lookup_code) AND rl.ID = rlv.lookup_id AND rl.NAME = 'TRANSFER_BATCH_CRITERIA'"
            + " ORDER BY criteria_id ASC")
    @UseRowMapper(BatchCriteriaMapper.class)
    List<BatchCriteria> getBatchCriteriaDetails(@Bind("postBatchId") long postBatchId);

    @SqlUpdate("DELETE FROM rpro_criteria rc WHERE rc.obj_id = :postBatchId AND rc.obj_type = 'ACCT_XFER'")
    Integer deleteCriteriaRecords(@Bind("postBatchId") long postBatchId);
}
