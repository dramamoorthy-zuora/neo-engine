package com.zuora.neo.engine.jobs.transferaccounting.db.mapper;

import com.zuora.neo.engine.jobs.transferaccounting.db.api.ChunkStatus;

import org.jdbi.v3.core.mapper.RowMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ChunkMapper implements RowMapper<ChunkStatus> {

    @Override
    public ChunkStatus map(ResultSet rs, StatementContext ctx) throws SQLException {
        return new ChunkStatus(rs.getLong(1), rs.getString(2));
    }
}
