package com.zuora.neo.engine.jobs.transferaccounting.activities.update;

import com.zuora.neo.engine.annotations.activities.ActivityImplementation;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.common.DbContext;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.transferaccounting.ThreadedAccountingResult;
import com.zuora.neo.engine.jobs.transferaccounting.TransferAccountingTestEvaluator;
import com.zuora.neo.engine.jobs.transferaccounting.api.BatchCriteriaCondition;
import com.zuora.neo.engine.jobs.transferaccounting.common.AccountingQuery;
import com.zuora.neo.engine.jobs.transferaccounting.common.ActivityType;
import com.zuora.neo.engine.jobs.transferaccounting.config.Properties;
import com.zuora.neo.engine.jobs.transferaccounting.constants.TransferStatus;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.BatchCriteria;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.SplitBatchRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.AccountingDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.CriteriaLookupDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.ErrorDao;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.SplitDao;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@ActivityImplementation
@Component
public class UpdateActivityImpl implements UpdateActivity {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(UpdateActivityImpl.class);
    private static final String SPLIT_TYPE = "RC_ID";
    private static final String BATCH_TYPE = "TRANSFER";
    private static final String WRONG_BATCH = "Batch should not contain criteria from both arrangement and manual journal level.";
    private static final String CRITERIA_ERR = "Batch Criteria Field does not exist in the lookup TRANSFER_BATCH_CRITERIA OR Alias is NULL";
    private static final String INCORRECT_BATCH_SETUP = "Batch criteria setup is incorrect.";
    private static final String INCORRECT_BATCH_SETUP_MJE = "Batch criteria setup is incorrect for Manual JE.";
    private static final String UPDATE_ERROR = "Error in Update : ";

    @Autowired
    NeoWorkflowLogger neoWorkflowLogger;
    @Autowired
    Properties properties;

    @Override
    public void resetNoOfSchedules(Long postBatchId) {
        Jdbi jdbi = DbContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            accountingDao.resetNoOfSchedules(postBatchId);
        });
    }

    @Override
    public void updateStatusToInProgress(Long postBatchId) {
        String transferStatus = ActivityType.UPDATE + " - " + TransferStatus.IN_PROGRESS.getTransferStatus();
        Jdbi jdbi = DbContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
            //update main batch to in-progress
            accountingDao.updateTransferStatusMsg(transferStatus, "", request.getUser(), postBatchId);
        });
    }


    /*
        Identifies the schedules to be posted based on the criteria.
        stamps the post batch id and custom stage handler if enabled.
     */
    @Override
    public ThreadedAccountingResult doUpdateProcess(ThreadedAccountingResult accountingResult, String orgId) {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        Long bookId = accountingResult.getBookId();
        Long postBatchId = accountingResult.getPostBatchId();
        Jdbi jdbi = DbContext.getConnection();

        jdbi.useTransaction(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            AccountingDao accountingDao = handle.attach(AccountingDao.class);
            properties.load(commonDao, request.getTenantId());
            doUpdateInTransaction(accountingDao, commonDao, postBatchId, request, bookId, accountingResult, handle, orgId, properties);
        });

        return accountingResult;
    }

    private ThreadedAccountingResult doUpdateInTransaction(AccountingDao accountingDao, CommonDao commonDao, Long postBatchId,
            WorkflowRequest request, Long bookId, ThreadedAccountingResult accountingResult, Handle handle,
            String orgId, Properties properties) {

        CriteriaLookupDao criteriaLookupDao = handle.attach(CriteriaLookupDao.class);
        ErrorDao errorDao = handle.attach(ErrorDao.class);
        SplitDao splitDao = handle.attach(SplitDao.class);
        //for retry we will have the chunk id in DB already else null
        Long existingChunkId = splitDao.getChunkId(postBatchId, accountingResult.getChunkId());
        if (existingChunkId == null) {
            splitDao.insertDetailHeader(TransferStatus.NEW.getTransferStatus(), "", accountingResult.getChunkId(),
                    postBatchId, request.getClientId(), request.getUser(), orgId);
        }

        Long currentPeriodId = commonDao.getCrtdPeriodId(bookId, request.getOrgId());

        SplitBatchRecord batch = splitDao.getSplitBatchById(postBatchId, SPLIT_TYPE, bookId, BATCH_TYPE, accountingResult.getChunkId());
        accountingResult.setMinRcId(Long.valueOf(batch.getMinValue()));
        accountingResult.setMaxRcId(Long.valueOf(batch.getMaxValue()));
        LOGGER.info("** MIN RC ID" + accountingResult.getMinRcId().toString());
        LOGGER.info("** MAX RC ID" + accountingResult.getMaxRcId().toString());
        updateAccTransfer(accountingDao, postBatchId, bookId, request, currentPeriodId, handle,
                accountingResult, criteriaLookupDao, errorDao, orgId, properties);

        return accountingResult;
    }

    /*
        This method builds the query for both regular schedules and Manual JE to
        update the post batch id into the RPRO_RC_SCHD table
     */
    private ThreadedAccountingResult updateAccTransfer(AccountingDao accountingDao, Long postBatchId, Long bookId,
            WorkflowRequest request, Long currentPeriodId, Handle handle, ThreadedAccountingResult accountingResult,
            CriteriaLookupDao criteriaLookupDao, ErrorDao errorDao, String orgId, Properties properties) {
        SplitDao splitDao = handle.attach(SplitDao.class);
        String transferStatus = ActivityType.UPDATE + " - " + TransferStatus.IN_PROGRESS.getTransferStatus();
        //update chunks to in-progress
        splitDao.updateTransferStatusChunk(transferStatus, "", request.getUser(), postBatchId, accountingResult.getChunkId());
        errorDao.updateIntErr(postBatchId, accountingResult.getChunkId());
        String transferMessage = null;
        if (transferStatus != null && transferStatus.equals(TransferStatus.ERROR.getTransferStatus())) {
            errorDao.insertError(postBatchId, transferMessage, request.getUser(), request.getClientId(),
                    bookId, orgId, accountingResult.getChunkId());
        }

        StringBuilder scheduleWhereClause = new StringBuilder("");
        Integer rrsFilerCount = 0;
        Integer mjtFilerCount = 0;
        Integer rcFilerCount = 0;
        StringBuilder bookWhereClause = new StringBuilder("");
        StringBuilder mjtWhereClause = new StringBuilder("");
        StringBuilder prdWhereClause = new StringBuilder("");
        StringBuilder nonSchWhereClause = new StringBuilder("");

        accountingDao.resetAcctValues(postBatchId, accountingResult.getMinRcId(), accountingResult.getMaxRcId()); // Reset the schedule
        List<BatchCriteria> batchCriteriaList = criteriaLookupDao.getBatchCriteriaDetails(postBatchId);
        LOGGER.info("batchCriteriaList: " + batchCriteriaList.size());
        BatchCriteriaCondition bcc = null;

        for (BatchCriteria criteria: batchCriteriaList) {
            if (criteria.getAlias() == null) {
                accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
                accountingResult.setTransferMessage(UPDATE_ERROR + CRITERIA_ERR);
                return accountingResult;
            }
            bcc = BatchCriteriaCondition.createBatchCondition(criteria, scheduleWhereClause, bookWhereClause, mjtWhereClause,
                    rcFilerCount, prdWhereClause, nonSchWhereClause, mjtFilerCount, rrsFilerCount);
        }
        if (bookId != null) {
            bookWhereClause.append(" AND rrs.book_id = ").append(bookId);
        }
        if (bcc != null && TransferAccountingTestEvaluator.criteriaFromArrangementAndManualJournal()) {
            bcc.setMjtFilerCount(1);
            bcc.setRcFilerCount(1);
        }
        if (bcc != null && bcc.getMjtFilerCount() > 0 && bcc.getRcFilerCount() > 0) {
            accountingResult.setTransferMessage(UPDATE_ERROR + WRONG_BATCH);
            accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
            return accountingResult;
        }

        StringBuilder sqlQuery = new StringBuilder("UPDATE /*+ INDEX(rrs,RPRO_RC_SCHD_F1) */ rpro_rc_schd rrs SET rrs.post_batch_id = :postBatchId"
                + ",rrs.updt_by='").append(request.getUser()).append("',rrs.updt_dt = SYSDATE WHERE");
        Integer rowCountMjt;
        Integer rowCountMje;
        Integer rowCount = 0;
        CombinedResult result;
        sqlQuery = getRegSchdQuery(sqlQuery, bcc, currentPeriodId, request, batchCriteriaList.size(),
                scheduleWhereClause, bookWhereClause, prdWhereClause, nonSchWhereClause, accountingResult);
        LOGGER.info("regular schedules update query: " + sqlQuery + " for the requested id:: " + request.getRequestId());
        result = executeAccountingQuery(sqlQuery.toString(), handle, accountingResult,ScheduleType.Regular.name(), postBatchId, rowCount, orgId, bcc);
        if (result.getAccountingResult().getTransferMessage() != null
                && result.getAccountingResult().getTransferMessage().contains(UPDATE_ERROR + INCORRECT_BATCH_SETUP)) {
            return accountingResult;
        } else {
            rowCountMjt = result.getRowCount();
            result.setRowCount(0);
            String mjeEnabled = properties.getMjeEnabled() ? "Y" : "N";
            StringBuilder sqlMjeQuery = new StringBuilder("UPDATE /*+ INDEX(rrs,RPRO_RC_SCHD_F1) */ rpro_rc_schd rrs SET rrs.post_batch_id = :postBatchId"
                    + ",rrs.updt_by='").append(request.getUser()).append("',rrs.updt_dt = SYSDATE WHERE");
            sqlMjeQuery = getMjeQuery(sqlMjeQuery, bcc, currentPeriodId, request, batchCriteriaList.size(),
                    scheduleWhereClause, bookWhereClause, prdWhereClause, nonSchWhereClause, mjeEnabled, accountingResult);
            LOGGER.info("MJE update query: " + sqlMjeQuery + " for the requested id:: " + request.getRequestId());
            result = executeAccountingQuery(sqlMjeQuery.toString(), handle, result.getAccountingResult(),ScheduleType.MJE.name(),postBatchId,rowCount,
                    orgId, bcc);
            if (result.getAccountingResult().getTransferMessage() != null
                    && result.getAccountingResult().getTransferMessage().contains(UPDATE_ERROR + INCORRECT_BATCH_SETUP_MJE)) {
                return accountingResult;
            } else {
                rowCountMje = result.getRowCount();
                accountingResult = updateAccountingRecords(accountingDao, rowCountMjt, rowCountMje, postBatchId, accountingResult, splitDao);
                return accountingResult;
            }
        }
    }

    private enum ScheduleType {
        Regular, MJE
    }

    private StringBuilder getRegSchdQuery(StringBuilder sqlQuery, BatchCriteriaCondition bcc, Long currentPeriodId,
            WorkflowRequest request, int size, StringBuilder scheduleWhereClause, StringBuilder bookWhereClause,
            StringBuilder prdWhereClause, StringBuilder nonSchWhereClause, ThreadedAccountingResult accountingResult) {
        if (bcc == null) {
            sqlQuery = AccountingQuery.createRegularSchdQuery(sqlQuery, request,
                    currentPeriodId, accountingResult.getMinRcId(), accountingResult.getMaxRcId(), null, null,
                    null, null, 0);
        } else {
            if (bcc.getMjtFilerCount() == 0) {
                sqlQuery = AccountingQuery.createRegularSchdQuery(sqlQuery, request,
                        currentPeriodId, accountingResult.getMinRcId(), accountingResult.getMaxRcId(), scheduleWhereClause, bookWhereClause,
                        prdWhereClause, nonSchWhereClause, size);
            }
        }
        return sqlQuery;
    }

    private StringBuilder getMjeQuery(StringBuilder sqlMjeQuery, BatchCriteriaCondition bcc, Long currentPeriodId,
            WorkflowRequest request, int size, StringBuilder scheduleWhereClause, StringBuilder bookWhereClause,
            StringBuilder prdWhereClause, StringBuilder nonSchWhereClause, String mjeEnabled, ThreadedAccountingResult accountingResult) {
        if (bcc == null) {
            if ("Y".equals(mjeEnabled)) {
                sqlMjeQuery = AccountingQuery.createMjeQuery(sqlMjeQuery, request,
                        currentPeriodId, accountingResult.getMinRcId(), accountingResult.getMaxRcId(), null, null,
                        null, null, 0);
            }
        } else {
            if (bcc.getRcFilerCount() == 0 && "Y".equals(mjeEnabled)) {
                sqlMjeQuery = AccountingQuery.createMjeQuery(sqlMjeQuery, request,
                        currentPeriodId, accountingResult.getMinRcId(), accountingResult.getMaxRcId(), scheduleWhereClause, bookWhereClause,
                        prdWhereClause, nonSchWhereClause, size);
            }
        }
        return sqlMjeQuery;
    }

    static class CombinedResult {
        private ThreadedAccountingResult accountingResult;
        private Integer rowCount;

        CombinedResult(ThreadedAccountingResult accountingResult, Integer rowCount) {
            this.accountingResult = accountingResult;
            this.rowCount = rowCount;
        }

        public ThreadedAccountingResult getAccountingResult() {
            return accountingResult;
        }

        public Integer getRowCount() {
            return rowCount;
        }

        public void setRowCount(Integer rowCount) {
            this.rowCount = rowCount;
        }
    }

    private CombinedResult executeAccountingQuery(String query, Handle handle, ThreadedAccountingResult accountingResult,
                                                  String queryType, Long postBatchId, Integer rowCount, String orgId, BatchCriteriaCondition bcc) {
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        String mjeEnabled = properties.getMjeEnabled() ? "Y" : "N";
        try {
            if ((ScheduleType.MJE.name().equals(queryType) && "Y".equals(mjeEnabled) && (bcc == null || (bcc != null && bcc.getRcFilerCount() == 0)))
                    || ScheduleType.Regular.name().equals(queryType)) {
                rowCount = handle.createUpdate(query)
                        .bind("postBatchId", accountingResult.getPostBatchId())
                        .bind("orgId", orgId)
                        .bind("minRcId", accountingResult.getMinRcId())
                        .bind("maxRcId", accountingResult.getMaxRcId()).execute();
            }
            LOGGER.info("Post batch ID Number of Rows updated: " + rowCount);
        } catch (Exception e) {
            SplitDao splitDao = handle.attach(SplitDao.class);
            neoWorkflowLogger.log("Error: stamping post batch ID failed, Update Stmt: " + query);
            LOGGER.error("Error: stamping post batch ID failed, Update Stmt: " + query);
            String errMsg = ScheduleType.MJE.name().equals(queryType) ? INCORRECT_BATCH_SETUP_MJE : INCORRECT_BATCH_SETUP;
            accountingResult.setTransferMessage(errMsg);
            accountingResult.setTransferStatus(TransferStatus.ERROR.getTransferStatus());
            splitDao.updateTransferStatusChunk(TransferStatus.ERROR.getTransferStatus(), errMsg, request.getUser(),
                    postBatchId, accountingResult.getChunkId());

            return new CombinedResult(accountingResult, 0);
        }
        return new CombinedResult(accountingResult, rowCount);
    }

    private ThreadedAccountingResult updateAccountingRecords(AccountingDao accountingDao, Integer rowCountMjt, Integer rowCountMje,
            Long postBatchId, ThreadedAccountingResult accountingResult, SplitDao splitDao) {
        accountingDao.updateSchedulesNum(Long.valueOf(rowCountMjt), Long.valueOf(rowCountMje), postBatchId, accountingResult.getChunkId());
        WorkflowRequest request = WorkflowContextManager.getWorkflowContext().getRequest();
        String status;
        if (rowCountMjt > 0 || rowCountMje > 0) {
            status = TransferStatus.UPDATED.getTransferStatus();
            //testing retry logic for update activity by overriding status as ERROR
            status = TransferAccountingTestEvaluator.evaluateForUpdateRetryLogic(status);
            accountingResult.setTransferStatus(status);
        } else {
            status = TransferStatus.NO_DATA.getTransferStatus();
            status = TransferAccountingTestEvaluator.evaluateForUpdateRetryLogic(status);
            accountingResult.setTransferStatus(status);
        }
        splitDao.updateTransferStatusChunk(status, "", request.getUser(), postBatchId, accountingResult.getChunkId());
        return accountingResult;
    }

}
