package com.zuora.neo.engine.jobs.caclnetting;

import lombok.Data;

@Data
public class CurrencyDetails {
    String curr, functionalCurrency;
    Double fExRate, gExRate;

    public CurrencyDetails(String curr, String functionalCurrency, Double fExRate, Double gExRate) {
        this.curr = curr;
        this.functionalCurrency = functionalCurrency;
        this.fExRate = fExRate;
        this.gExRate = gExRate;
    }

}
