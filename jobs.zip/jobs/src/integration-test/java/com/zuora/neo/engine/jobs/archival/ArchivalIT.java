package com.zuora.neo.engine.jobs.archival;

import com.zuora.neo.engine.api.WorkflowExecutionEntity;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.JobsMetadata;
import com.zuora.neo.engine.jobs.archival.enums.BatchStatus;
import com.zuora.neo.engine.test.BaseIntegrationTest;
import com.zuora.neo.engine.test.config.TestDbParams;
import com.zuora.neo.engine.test.db.common.DbTestContext;
import io.temporal.api.enums.v1.WorkflowExecutionStatus;
import io.temporal.api.workflow.v1.WorkflowExecutionInfo;
import org.jdbi.v3.core.Jdbi;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import static org.awaitility.Awaitility.with;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ArchivalIT extends BaseIntegrationTest {

    private static final Logger logger = LoggerFactory.getLogger(ArchivalIT.class);


    List<String> insertRecordsList = Arrays.asList(DATestConstants.RPRO_RC_HEAD_A_G_1,DATestConstants.RPRO_RC_HEAD_A_G_2,
            DATestConstants.RPRO_RC_SCHD_G_1,DATestConstants.RPRO_RC_SCHD_G_2,DATestConstants.RPRO_RC_HEAD_G_1,
            DATestConstants.RPRO_RC_LINE_G_1,DATestConstants.RPRO_RC_LINE_G_2,DATestConstants.RPRO_RC_POB_ACT_G_1,DATestConstants.RPRO_RC_POB_ACT_G_2,
            DATestConstants.RPRO_RC_POB_ACT_G_3,DATestConstants.RPRO_RCPOB_PRNT_G_1,DATestConstants.PRO_RCPOB_PRNT_G_2,DATestConstants.RPRO_RCPOB_PRNT_G_3,
            DATestConstants.RPRO_LINE_STG_H_G_1,DATestConstants.RPRO_LINE_STG_H_G_2,DATestConstants.RPRO_LN_COST_A_G_1,DATestConstants.RPRO_LN_COST_A_G_2,
            DATestConstants.RPRO_RC_POB_G_1,DATestConstants.RPRO_RC_POB_G_2,DATestConstants.RPRO_RC_POB_G_3,DATestConstants.RPRO_RC_POB_G_4,
            DATestConstants.RPRO_LN_HOLD_G_1,DATestConstants.RPRO_RC_LINE_A_G_1,DATestConstants.RPRO_RC_LINE_A_G_1,DATestConstants.RPRO_RC_LINE_A_G_2);

    List<String> deleteRecordsInMirrorSchema = Arrays.asList(DATestConstants.DELETE_RPRO_RC_HEAD_A_G_MIR,DATestConstants.DELETE_RPRO_RC_GRP_DTL_G_MIR,DATestConstants.DELETE_RPRO_RC_SCHD_G_MIR,
            DATestConstants.DELETE_RPRO_RC_HEAD_G_MIR,DATestConstants.DELETE_RPRO_RC_LINE_G_MIR,DATestConstants.DELETE_RPRO_RC_POB_ACT_G_MIR,DATestConstants.DELETE_RPRO_RCPOB_PRNT_G_MIR,
            DATestConstants.DELETE_RPRO_LINE_STG_H_G_MIR,DATestConstants.DELETE_RPRO_LN_COST_A_G_MIR,DATestConstants.DELETE_RPRO_RC_POB_G_MIR,
            DATestConstants.DELETE_RPRO_LN_HOLD_G_MIR,DATestConstants.DELETE_RPRO_RC_LINE_A_G_MIR);

    List<String> deleteRecordsInOriginalSchema = Arrays.asList(DATestConstants.DELETE_RPRO_RC_HEAD_A_G,DATestConstants.DELETE_RPRO_RC_GRP_DTL_G,DATestConstants.DELETE_RPRO_RC_SCHD_G,
            DATestConstants.DELETE_RPRO_RC_HEAD_G,DATestConstants.DELETE_RPRO_RC_LINE_G,DATestConstants.DELETE_RPRO_RC_POB_ACT_G,DATestConstants.DELETE_RPRO_RCPOB_PRNT_G,
            DATestConstants.DELETE_RPRO_LINE_STG_H_G,DATestConstants.DELETE_RPRO_LN_COST_A_G,DATestConstants.DELETE_RPRO_RC_POB_G,
            DATestConstants.DELETE_RPRO_LN_HOLD_G,DATestConstants.DELETE_RPRO_RC_LINE_A_G);

    @Test
    public void testArchive() {
        Jdbi jdbi = DbTestContext.getConnection();
        insertRevenueContracts(jdbi);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        try {
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.ARCHIVAL.getId(), 1234, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    dbParams.getRoleId(), "0~GAAP~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
            logger.info("workflow status::" + info.getStatus());
            assertTrue("Workflow status is  complete " + info.getStatus(),
                    info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
            String status = getProcessStatus(jdbi);
            assertEquals(BatchStatus.MOVED.label,status);
        } catch (Exception ex) {
            logger.info("error while running archive test case");
        } finally {
            deleteRevenueContracts(jdbi,deleteRecordsInMirrorSchema);
            updateDeleteQuery(DATestConstants.DELETE_PROCESSED_RC_IN_HEAD_G);
        }
    }

    @Test
    public void testRoleBack() {
        Jdbi jdbi = DbTestContext.getConnection();
        insertRevenueContracts(jdbi);
        updateDeleteQuery(DATestConstants.DELETE_QUERY_WITH_ERROR);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        try{
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.ARCHIVAL.getId(), 1234, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    dbParams.getRoleId(), "0~GAAP~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
            logger.info("workflow status::" + info.getStatus());
            assertTrue("Workflow status is  failed " + info.getStatus(),
                    info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_FAILED);
            String status = getProcessStatus(jdbi);
            logger.info("Process Status::" + status);
            assertEquals(BatchStatus.EXCEPTION.label,status);
            updateDeleteQuery(DATestConstants.DELETE_PROCESSED_RC_IN_HEAD_G);
            logger.info("testRoleBack completed successfully");
        } catch (Exception exception){
            logger.error("error while processing request");
        } finally {
            updateDeleteQuery(DATestConstants.DELETE_QUERY_WITHOUT_ERROR);
            logger.info("delete query reverted back to original");
            deleteRevenueContracts(jdbi,deleteRecordsInOriginalSchema);
        }
    }

    @Test
    public void testMaxFailureThresholdExceeded() {
        Jdbi jdbi = DbTestContext.getConnection();
        insertRevenueContracts(jdbi);
        updateDeleteQuery(DATestConstants.COPY_QUERY_WITH_ERROR);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        try{
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.ARCHIVAL.getId(), 1234, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    dbParams.getRoleId(), "0~GAAP~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
            logger.info("workflow status::" + info.getStatus());
            assertTrue("Workflow status is  failed " + info.getStatus(),
                    info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_FAILED);
            String status = getProcessStatus(jdbi);
            logger.info("Process Status::" + status);
            assertEquals(BatchStatus.EXCEPTION.label,status);
            //updateDeleteQuery(DATestConstants.DELETE_PROCESSED_RC_IN_HEAD_G);
            logger.info("testMaxFailureThresholdExceeded completed successfully");
        } catch (Exception exception){
            logger.error("error while processing request");
        } finally {
            updateDeleteQuery(DATestConstants.COPY_QUERY_WITHOUT_ERROR);
            logger.info("copy query reverted back to original");
            deleteRevenueContracts(jdbi,deleteRecordsInOriginalSchema);
        }
    }

    private void waitForWorkflowComplete(WorkflowExecutionEntity wfe) {
        with().pollInterval(Duration.ofMillis(500)).and().with().pollDelay(100, TimeUnit.MILLISECONDS).await("Workflow complete")
                .atMost(100_000, TimeUnit.MILLISECONDS)
                .until(workflowComplete(wfe));
    }

    private Callable<Boolean> workflowComplete(WorkflowExecutionEntity wfe) {
        return () -> {
            WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
            WorkflowExecutionStatus currentStatus = info.getStatus();
            if (currentStatus == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_RUNNING) {
                return false;
            }
            return true;
        };
    }

    private void insertRevenueContracts(Jdbi jdbi) {
        jdbi.useHandle(handle -> {
           for(String query : insertRecordsList){
               handle.execute(query);
           }
        logger.info("test data inserted successfully");
        });
    }

    private void deleteRevenueContracts(Jdbi jdbi, List<String> deleteRecordsList) {
        jdbi.useHandle(handle -> {
                for(String query : deleteRecordsList){
                    handle.execute(query);
                }
            logger.info("Moved Data deleted successfully");
        });
    }

    private String getProcessStatus(Jdbi jdbi) {
        return jdbi.withHandle(handle -> {
            String processFlag = handle.createQuery(DATestConstants.PROCESS_FLAG)
                    .mapTo(String.class)
                    .findFirst().orElse(null);
            return processFlag;
        });
    }

    private void updateDeleteQuery(String query) {
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            handle.execute(query);
        });
    }

}
