package com.zuora.neo.engine.jobs.rtp;

import com.zuora.neo.engine.api.WorkflowExecutionEntity;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.JobsMetadata;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.rtp.api.RtpWorkflowDefinition;
import com.zuora.neo.engine.jobs.rtp.constants.RtpConstants;
import com.zuora.neo.engine.jobs.rtp.constants.RtpProfiles;
import com.zuora.neo.engine.jobs.rtp.constants.RtpWiHeaderStatus;
import com.zuora.neo.engine.jobs.rtp.constants.RtpWiStatus;
import com.zuora.neo.engine.test.BaseIntegrationTest;
import com.zuora.neo.engine.test.config.TestDbParams;
import com.zuora.neo.engine.test.db.common.DbTestContext;
import io.temporal.api.enums.v1.WorkflowExecutionStatus;
import io.temporal.api.workflow.v1.WorkflowExecutionInfo;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.Duration;
import java.util.Arrays;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import static org.awaitility.Awaitility.with;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class RtpIT extends BaseIntegrationTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(RtpIT.class);

    private static final int wfId = RtpWorkflowDefinition.DEFAULT_WF_ID;
    private static final String user = "INTEGRATION_TEST_USER";

    private static class RtpTestVariables {
        long rcId1 = 11115L, rcId2 = 11116L, requestId = 15000L, prdId = 202302;
        int bookId = 1, headerId1 = 1234, headerId2 = 9876;
    }

    static RtpTestVariables rtpTestVariables;

    @Before
    public void setUp() {
        rtpTestVariables = new RtpTestVariables();
        tearDown();
    }

    @After
    public void tearDown() {
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            deleteRtpHeaders(handle);
            deleteRtpHeadersHistory(handle);
            deleteRtpWiEntries(handle);
            deleteRtpWiEntriesHistory(handle);
        });
    }

    @Test
    public void rtpHappyFlow() throws IOException {
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        executeAndTestWorkflow(dbParams, "N~");

    }

    @Test
    public void rtpWithExistingLock() throws IOException{
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();

        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            insertLockRecord(handle, rtpTestVariables.requestId, dbParams.getOrgId());

            boolean shadowMode = commonDao.getProfileValue(RtpProfiles.ENABLE_REALTIME_PROCESSING_SHADOW_MODE, "Y").equals("Y");

            LOGGER.info("########## shadow mode profile value - " + shadowMode);
            if (shadowMode) {
                LOGGER.info("########## inside shadow mode profile value - " + shadowMode);
                updateProfile(RtpProfiles.ENABLE_REALTIME_PROCESSING_SHADOW_MODE, "N");
                removeProfileCache(handle);
            }

            boolean shadowMode1 = commonDao.getProfileValue(RtpProfiles.ENABLE_REALTIME_PROCESSING_SHADOW_MODE, "Y").equals("Y");
            LOGGER.info("########## after update shadow mode profile value - " + shadowMode1);

            insertHeaderRecord(handle, rtpTestVariables.headerId1, rtpTestVariables.rcId1, rtpTestVariables.bookId, rtpTestVariables.prdId,
                    dbParams.getOrgId(), dbParams.getClientId(), RtpWiHeaderStatus.NEW);

            WorkflowExecutionInfo info = submitAndGetWorkflowExecutionInfo(dbParams, "N~");

            deleteHeaderRecord(handle, rtpTestVariables.headerId1);

            if (shadowMode) {
                updateProfile(RtpProfiles.ENABLE_REALTIME_PROCESSING_SHADOW_MODE, "Y");
                removeProfileCache(handle);
            }

            removeLockRecord(handle, rtpTestVariables.requestId, dbParams.getOrgId());

            assertTrue("Workflow status is not failed " + info.getStatus(),
                    info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_FAILED);
        });
    }

    @Test
    public void rtpWithData() throws IOException {
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();

        jdbi.useHandle(handle -> {

            insertHeaderRecord(handle, rtpTestVariables.headerId1, rtpTestVariables.rcId1, rtpTestVariables.bookId, rtpTestVariables.prdId,
                    dbParams.getOrgId(), dbParams.getClientId(), RtpWiHeaderStatus.NEW);

            executeAndTestWorkflow(dbParams, "N~");

            verifyRtpHeaderHistory(handle, rtpTestVariables.headerId1, rtpTestVariables.rcId1, rtpTestVariables.bookId, rtpTestVariables.prdId,
                    RtpWiHeaderStatus.COMPLETED.getHeaderStatus(), 1);

            verifyRtpWiHistory(handle, rtpTestVariables.headerId1, 1, RtpWiStatus.COMPLETED.getStatus(), 1);
            verifyRtpWiHistory(handle, rtpTestVariables.headerId1, 2, RtpWiStatus.COMPLETED.getStatus(), 1);
            verifyRtpWiHistory(handle, rtpTestVariables.headerId1, 3, RtpWiStatus.COMPLETED.getStatus(), 1);

        });
    }

    @Test
    public void rtpWithErrorData() throws IOException {
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();

        jdbi.useHandle(handle -> {

            // RTP headers with error status and retryCount 5 will be automatically executed everytime when the workflow run.

            insertHeaderRecord(handle, rtpTestVariables.headerId1, rtpTestVariables.rcId1, rtpTestVariables.bookId, rtpTestVariables.prdId,
                    dbParams.getOrgId(), dbParams.getClientId(), RtpWiHeaderStatus.ERROR);

            executeAndTestWorkflow(dbParams, "N~");

            verifyRtpHeaderHistory(handle, rtpTestVariables.headerId1, rtpTestVariables.rcId1, rtpTestVariables.bookId, rtpTestVariables.prdId,
                    RtpWiHeaderStatus.COMPLETED.getHeaderStatus(), 1);

            verifyRtpWiHistory(handle, rtpTestVariables.headerId1, 1, RtpWiStatus.COMPLETED.getStatus(), 1);
            verifyRtpWiHistory(handle, rtpTestVariables.headerId1, 2, RtpWiStatus.COMPLETED.getStatus(), 1);
            verifyRtpWiHistory(handle, rtpTestVariables.headerId1, 3, RtpWiStatus.COMPLETED.getStatus(), 1);

            // If the retry count reached 5, it will be picked up in the usual run.

            insertHeaderRecord(handle, rtpTestVariables.headerId2, rtpTestVariables.rcId2, rtpTestVariables.bookId, rtpTestVariables.prdId,
                    dbParams.getOrgId(), dbParams.getClientId(), RtpWiHeaderStatus.ERROR);

            updateRetryCount(handle, rtpTestVariables.headerId2, 5);

            executeAndTestWorkflow(dbParams, "N~");

            verifyRtpHeader(handle, rtpTestVariables.headerId2, rtpTestVariables.rcId2, rtpTestVariables.bookId, rtpTestVariables.prdId,
                    RtpWiHeaderStatus.ERROR.getHeaderStatus(), 1);

            // when the workflow runs with ERRORS_ONLY parameter as 'Y', only records with 'ERROR' will get picked and run
            // and the records with 'NEW' will not get picked.

            insertHeaderRecord(handle, rtpTestVariables.headerId1, rtpTestVariables.rcId1, rtpTestVariables.bookId, rtpTestVariables.prdId,
                    dbParams.getOrgId(), dbParams.getClientId(), RtpWiHeaderStatus.NEW);

            executeAndTestWorkflow(dbParams, "Y~");

            verifyRtpHeaderHistory(handle, rtpTestVariables.headerId2, rtpTestVariables.rcId2, rtpTestVariables.bookId, rtpTestVariables.prdId,
                    RtpWiHeaderStatus.COMPLETED.getHeaderStatus(), 1);

            verifyRtpWiHistory(handle, rtpTestVariables.headerId2, 1, RtpWiStatus.COMPLETED.getStatus(), 1);
            verifyRtpWiHistory(handle, rtpTestVariables.headerId2, 2, RtpWiStatus.COMPLETED.getStatus(), 1);
            verifyRtpWiHistory(handle, rtpTestVariables.headerId2, 3, RtpWiStatus.COMPLETED.getStatus(), 1);

            verifyRtpHeader(handle, rtpTestVariables.headerId1, rtpTestVariables.rcId1, rtpTestVariables.bookId, rtpTestVariables.prdId,
                    RtpWiHeaderStatus.NEW.getHeaderStatus(), 1);

        });
    }

    @Test
    public void rtpWithSpecificRcs() throws IOException {
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();

        jdbi.useHandle(handle -> {
            insertHeaderRecord(handle, rtpTestVariables.headerId1, rtpTestVariables.rcId1, rtpTestVariables.bookId, rtpTestVariables.prdId,
                    dbParams.getOrgId(), dbParams.getClientId(), RtpWiHeaderStatus.NEW);
            insertHeaderRecord(handle, rtpTestVariables.headerId2, rtpTestVariables.rcId2, rtpTestVariables.bookId, rtpTestVariables.prdId,
                    dbParams.getOrgId(), dbParams.getClientId(), RtpWiHeaderStatus.ERROR);

            executeAndTestWorkflow(dbParams, "N~" + rtpTestVariables.rcId1);

            verifyRtpHeaderHistory(handle, rtpTestVariables.headerId1, rtpTestVariables.rcId1, rtpTestVariables.bookId, rtpTestVariables.prdId,
                    RtpWiHeaderStatus.COMPLETED.getHeaderStatus(), 1);

            verifyRtpWiHistory(handle, rtpTestVariables.headerId1, 1, RtpWiStatus.COMPLETED.getStatus(), 1);
            verifyRtpWiHistory(handle, rtpTestVariables.headerId1, 2, RtpWiStatus.COMPLETED.getStatus(), 1);
            verifyRtpWiHistory(handle, rtpTestVariables.headerId1, 3, RtpWiStatus.COMPLETED.getStatus(), 1);

            verifyRtpHeader(handle, rtpTestVariables.headerId2, rtpTestVariables.rcId2, rtpTestVariables.bookId, rtpTestVariables.prdId,
                    RtpWiHeaderStatus.NEW.getHeaderStatus(), 1);

            verifyRtpWi(handle, rtpTestVariables.headerId1, 1, RtpWiStatus.COMPLETED.getStatus(), 0);
            verifyRtpWi(handle, rtpTestVariables.headerId1, 2, RtpWiStatus.COMPLETED.getStatus(), 0);
            verifyRtpWi(handle, rtpTestVariables.headerId1, 3, RtpWiStatus.COMPLETED.getStatus(), 0);
        });
    }

    private void updateProfile(String profile, String value) {
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            String query = "UPDATE rpro_profile_value_g SET value = :value WHERE prof_id = (SELECT id FROM rpro_profile_g WHERE name = :profile)";
            handle.createUpdate(query)
                    .bind("profile", profile)
                    .bind("value", value)
                    .execute();
        });
    }

    private void removeProfileCache(Handle handle) {
        String query = "{call rpro_utility_pkg.g_profile_data_tab.delete; commit }";
        handle.createCall(query).invoke();
    }

    private void deleteRtpHeadersHistory(Handle handle) {
        String deleteRtpHeadersQuery = "DELETE FROM rpro_rtp_wi_header_h where id in (<headerIds>)";
        handle.createUpdate(deleteRtpHeadersQuery)
                .bindList("headerIds", Arrays.asList(rtpTestVariables.headerId1, rtpTestVariables.headerId2))
                .execute();
    }

    private void deleteRtpHeaders(Handle handle) {
        String deleteRtpHeadersQuery = "DELETE FROM rpro_rtp_wi_header where id in (<headerIds>)";
        handle.createUpdate(deleteRtpHeadersQuery)
                .bindList("headerIds", Arrays.asList(rtpTestVariables.headerId1, rtpTestVariables.headerId2))
                .execute();
    }

    private void deleteRtpWiEntriesHistory(Handle handle) {
        String deleteRtpWiEntriesQuery = "DELETE FROM rpro_rtp_wi_h where header_id in (<headerIds>)";
        handle.createUpdate(deleteRtpWiEntriesQuery)
                .bindList("headerIds", Arrays.asList(rtpTestVariables.headerId1, rtpTestVariables.headerId2))
                .execute();
    }

    private void deleteRtpWiEntries(Handle handle) {
        String deleteRtpWiEntriesQuery = "DELETE FROM rpro_rtp_wi where header_id in (<headerIds>)";
        handle.createUpdate(deleteRtpWiEntriesQuery)
                .bindList("headerIds", Arrays.asList(rtpTestVariables.headerId1, rtpTestVariables.headerId2))
                .execute();
    }

    private void verifyRtpHeader(Handle handle, int headerId, long rcId, int bookId, long prdId, String status, int expectedCount) {
        String headerQuery = "SELECT COUNT(*) FROM rpro_rtp_wi_header WHERE id = :headerId AND rc_id = :rcId AND book_id = :bookId"
                +   " AND prd_id = :prdId AND status = :status";

        long actualCount = handle.createQuery(headerQuery)
                .bind("headerId", headerId)
                .bind("rcId", rcId)
                .bind("bookId", bookId)
                .bind("prdId", prdId)
                .bind("status", status)
                .mapTo(Long.class).first();
        assertEquals("Rtp header count mismatch", expectedCount, actualCount);
    }

    private void verifyRtpHeaderHistory(Handle handle, int headerId, long rcId, int bookId, long prdId, String status, int expectedCount) {
        String headerQuery = "SELECT COUNT(*) FROM rpro_rtp_wi_header_h WHERE id = :headerId AND rc_id = :rcId AND book_id = :bookId"
                +   " AND prd_id = :prdId AND status = :status";

        long actualCount = handle.createQuery(headerQuery)
                .bind("headerId", headerId)
                .bind("rcId", rcId)
                .bind("bookId", bookId)
                .bind("prdId", prdId)
                .bind("status", status)
                .mapTo(Long.class).first();
        assertEquals("Rtp header count mismatch", expectedCount, actualCount);
    }

    private void verifyRtpWiHistory(Handle handle, int headerId, int stepId, String status, int expectedCount) {
        String wiQuery = "SELECT count(*) FROM rpro_rtp_wi_h WHERE header_id = :headerId AND step_id = :stepId AND status = :status";

        long actualCount = handle.createQuery(wiQuery)
                .bind("headerId", headerId)
                .bind("stepId", stepId)
                .bind("status", status)
                .mapTo(Long.class).first();
        assertEquals("Rtp workitem count mismatch", expectedCount, actualCount);
    }

    private void verifyRtpWi(Handle handle, int headerId, int stepId, String status, int expectedCount) {
        String wiQuery = "SELECT count(*) FROM rpro_rtp_wi WHERE header_id = :headerId AND step_id = :stepId AND status = :status";

        long actualCount = handle.createQuery(wiQuery)
                .bind("headerId", headerId)
                .bind("stepId", stepId)
                .bind("status", status)
                .mapTo(Long.class).first();
        assertEquals("Rtp workitem count mismatch", expectedCount, actualCount);
    }

    private void executeAndTestWorkflow(TestDbParams dbParams, String parameterText) throws IOException {

        WorkflowExecutionInfo workflowExecutionInfo = submitAndGetWorkflowExecutionInfo(dbParams, parameterText);

        assertEquals("Workflow status is not complete " + workflowExecutionInfo.getStatus(), WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED,
                workflowExecutionInfo.getStatus());
    }

    private WorkflowExecutionInfo submitAndGetWorkflowExecutionInfo(TestDbParams dbParams, String parameterText) throws IOException {
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.RTP.getId(),
                rtpTestVariables.requestId,
                dbParams.getTenantId(),
                dbParams.getOrgId(),
                dbParams.getClientId(),
                user,
                dbParams.getRoleId(), parameterText);
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        return getWorkflowExecutionInfo(wfe);
    }

    private void insertHeaderRecord(Handle handle, int headerId, long rcId, int bookId, long prdId, String orgId, long clientId, RtpWiHeaderStatus status) {
        handle.createUpdate(RtpTestConstants.INSERT_HEADER_RECORD)
                .bind("headerId", headerId)
                .bind("rcId", rcId)
                .bind("prdId", prdId)
                .bind("bookId", bookId)
                .bind("orgId", orgId)
                .bind("clientId", clientId)
                .bind("wfId", wfId)
                .bind("status", status.getHeaderStatus())
                .bind("user", user)
                .execute();
    }

    private void updateRetryCount(Handle handle, int headerId, int retryCount) {
        handle.createUpdate("update rpro_rtp_wi_header set retry_count = :retryCount where id = :headerId")
                .bind("headerId", headerId)
                .bind("retryCount", retryCount)
                .execute();
    }

    private void deleteHeaderRecord(Handle handle, int headerId) {
        handle.createUpdate("DELETE FROM rpro_rtp_wi_header WHERE id = :header_id")
                .bind("header_id", headerId)
                .execute();
    }

    private void insertLockRecord(Handle handle, long requestId, String orgId) {
        handle.createUpdate(RtpTestConstants.INSERT_LOCK_RECORD)
                .bind("objectId", requestId)
                .bind("objectType", RtpConstants.REALTIME_PROCESS)
                .bind("description", RtpConstants.REALTIME_PROCESS_IN_PROGRESS)
                .bind("orgId", orgId).execute();
    }

    private void removeLockRecord(Handle handle, long requestId, String orgId) {
        handle.createUpdate(RtpTestConstants.REMOVE_LOCK_RECORD)
                .bind("objectId", requestId)
                .bind("objectType", RtpConstants.REALTIME_PROCESS)
                .bind("orgId", orgId).execute();
    }

    private void waitForWorkflowComplete(WorkflowExecutionEntity wfe) {
        with().pollInterval(Duration.ofMillis(500)).and().with().pollDelay(100, TimeUnit.MILLISECONDS).await("Workflow complete")
                .atMost(100_000, TimeUnit.MILLISECONDS)
                .until(workflowComplete(wfe));
    }

    private Callable<Boolean> workflowComplete(WorkflowExecutionEntity wfe) {
        return new Callable<Boolean>() {
            public Boolean call() throws Exception {
                WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
                WorkflowExecutionStatus currentStatus = info.getStatus();
                if (currentStatus == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_RUNNING) {
                    return false;
                }
                return true;
            }
        };
    }

}
