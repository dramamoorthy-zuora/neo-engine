package com.zuora.neo.engine.jobs.transferaccounting;
import com.zuora.neo.engine.api.WorkflowExecutionEntity;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.JobsMetadata;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.transferaccounting.activities.AccountingActivitiesImpl;
import com.zuora.neo.engine.jobs.transferaccounting.api.BatchCriteriaCondition;
import com.zuora.neo.engine.jobs.transferaccounting.common.AccountingQuery;
import com.zuora.neo.engine.jobs.transferaccounting.config.Properties;
import com.zuora.neo.engine.jobs.transferaccounting.constants.*;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.BatchCriteria;
import com.zuora.neo.engine.jobs.transferaccounting.api.GlInsertBuilder;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.FxGainLossRecord;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.GlIntegrationMap;
import com.zuora.neo.engine.jobs.transferaccounting.db.dao.*;
import com.zuora.neo.engine.jobs.transferaccounting.db.mapper.FxGainMapper;
import com.zuora.neo.engine.test.db.common.DbTestContext;
import com.zuora.neo.engine.test.BaseIntegrationTest;
import com.zuora.neo.engine.test.config.TestDbParams;
import io.temporal.api.enums.v1.WorkflowExecutionStatus;
import io.temporal.api.failure.v1.ApplicationFailureInfo;
import io.temporal.api.history.v1.History;
import io.temporal.api.history.v1.HistoryEvent;
import io.temporal.api.history.v1.WorkflowExecutionFailedEventAttributes;
import io.temporal.api.workflow.v1.WorkflowExecutionInfo;
import com.zuora.neo.engine.db.dao.CommonDao;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.mapper.RowMapper;
import org.junit.Test;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import static org.awaitility.Awaitility.with;
import static org.junit.Assert.*;
import java.util.*;


public class TransferAccountingIT extends BaseIntegrationTest {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AccountingActivitiesImpl.class);
    private static final String delimiterCharacter = ":";
    @Autowired
    Properties properties;

    @Autowired
    ParseProgramParameters parseProgramParameters;



    private void waitForWorkflowComplete(WorkflowExecutionEntity wfe) {
        with().pollInterval(Duration.ofMillis(500)).and().with().pollDelay(100, TimeUnit.MILLISECONDS).await("Workflow complete")
                .atMost(600000_000, TimeUnit.MILLISECONDS)
                .until(workflowComplete(wfe));
    }

    private Callable<Boolean> workflowComplete(WorkflowExecutionEntity wfe) {
        return new Callable<Boolean>() {
            public Boolean call() throws Exception {
                WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
                WorkflowExecutionStatus currentStatus = info.getStatus();
                if (currentStatus == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_RUNNING) {
                    return false;
                }
                return true;
            }
        };
    }

    private long getPostBatchId(Handle handle)
    {
        AtomicLong postBatchId = new AtomicLong();

        postBatchId.set(handle.createQuery("Select max(id) from rpro_acct_xfer ")
                .mapTo(long.class).first());
        return postBatchId.longValue();
    }

    @Test
    public void transferAccountingAutomationInsert() throws IOException {
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
    }
//
//    @Test
//    public void transferAccountingAutomationDelete() throws IOException {
//        AccountingTestHelper.deleteRegularSchdData();
//        AccountingTestHelper.deleteMjeSchdData();
//    }

    @Test
    public void transferAccountingHappyPathCRDR() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
        setEnableGlLinkToN(handle);
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING_MASTER.getId(), 16683, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        setEnableGlLinkToY(handle);
            long postBatchId = getPostBatchId(handle);
            WorkflowRequest crDrRequest = new WorkflowRequest(JobsMetadata.CR_DR_LINK.getId(), 20033, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    10040, postBatchId+"~5");
            WorkflowExecutionEntity crDrwfe = submitWorkflowRequest(crDrRequest);
            waitForWorkflowComplete(crDrwfe);
            WorkflowExecutionInfo info = getWorkflowExecutionInfo(crDrwfe);
            assertTrue("CrDr Workflow status is not complete " + info.getStatus(),
                    info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
        });
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
    }
    @Test
    public void transferAccountingHappyPathMaster() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        long startTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        LOGGER.info("startTime : "+ startTime);
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING_MASTER.getId(), 16683, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~"); //BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~  BOOK_NAME:PERIOD_NAME:CURR~GAAP:FEB-22:USD~N:N:N~
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        long endTime =  Timestamp.valueOf(LocalDateTime.now()).getTime();
        LOGGER.info("endTime : "+ endTime);
        LOGGER.info("Time Taken : " + (startTime - endTime));
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
    }

    @Test
    public void transferAccountingTestMasterPerOrgInfo() throws IOException {

        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        jdbi.useHandle(handle -> {

            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING_MASTER.getId(), 16683, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            long postBatchId = getPostBatchId(handle);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            Long afterExecute = handle.createQuery("Select count(*) from RPRO_ACCT_XFER_SUMMARY_G where status ='SUCCESS' AND SEC_ATR_VAL = '5' AND CRTD_BY = 'SingleOrg' AND POST_BATCH_ID = " + postBatchId).mapTo(Long.class).first();
            LOGGER.info("afterExecute : " + afterExecute);
            assertTrue("",afterExecute.equals(Long.valueOf(1)));
        });
    }

    @Test
    public void transferAccountingMasterPerOrgInfoInsideCatch() throws IOException {

        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        //setTestVariable(TransferAccountingTestEvaluator.PER_ORG_INFO_INSIDE_CATCH_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        jdbi.useHandle(handle -> {
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING_MASTER.getId(), 16683, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~x1y1:FEB-22~N:N~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            long postBatchId = getPostBatchId(handle);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            Long afterExecute = handle.createQuery("Select count(*) from RPRO_ACCT_XFER_SUMMARY where status ='ERROR' AND SEC_ATR_VAL = '5' AND CRTD_BY = 'SingleOrg' AND POST_BATCH_ID = 0").mapTo(Long.class).first();
            Integer deleteRowCount = handle.createUpdate("delete from RPRO_ACCT_XFER_SUMMARY where POST_BATCH_ID = 0").execute();
            LOGGER.info("deleteRowCount : " + deleteRowCount);
            LOGGER.info("afterExecute : " + afterExecute);
            assertTrue("", afterExecute.equals(Long.valueOf(1)));
        });
    }

    @Test
    public void transferAccountingHappyPathUIUpdate() throws IOException {

        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        jdbi.useHandle(handle -> {
            handle.createUpdate("delete from rpro_acct_xfer_details where post_batch_id = 14420").execute();
            handle.createUpdate("delete from rpro_acct_xfer where id = 14420").execute();
            handle.createUpdate("delete from rpro_criteria where OBJ_ID =14420").execute();
            CriteriaLookupDao criteriaLookupDao = handle.attach(CriteriaLookupDao.class);
            criteriaLookupDao.insertCriteria(Long.valueOf(100000),"PERIOD_NAME","=","FEB-22",Long.valueOf(14420),"NNNGNNNNNNNNNNNNNNNN",dbParams.getClientId(),Long.valueOf(202202),dbParams.getUser());
            criteriaLookupDao.insertCriteria(Long.valueOf(100001),"BOOK_NAME","=","GAAP",Long.valueOf(14420),"NNNGNNNNNNNNNNNNNNNN",dbParams.getClientId(),Long.valueOf(202202),dbParams.getUser());
            handle.createUpdate("insert into rpro_acct_xfer(id,name,status,client_id,crtd_prd_id,sec_atr_val,Book_id,indicators,no_of_schedules)\n" +
                    "values(14420,'TRANSFER BATCH','NEW',1,202202,'5',1,'NNNNNNNNNNNNNNNNNNNN',0)").execute();

        });
        //TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.UI_TRANSFER_ACCOUNTING.getId(), 30991, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "14420~UPDATE~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
        jdbi.useHandle(handle -> {
            long rowCount = handle.createQuery("select count(*) from rpro_rc_schd where rc_id in(95000,95001,95002,95003,100000,100001,100002,100003) and post_batch_id = 14420" ).mapTo(long.class).first();
            long validateRowCount = handle.createQuery("select count(*) from rpro_int_error where acct_xfer_id = 14420" ).mapTo(long.class).first();
            handle.createUpdate("Delete from rpro_batch_split where batch_id = 14420").execute();
            LOGGER.info("rowCount : " + rowCount);
            LOGGER.info("validateRowCount : " + validateRowCount);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            assertTrue("Incorrect Update",rowCount == 44);
            assertTrue("Incorrect Validation ",validateRowCount == 0);
        });

    }

    @Test
    public void transferAccountingHappyPathUITransfer() throws IOException {

        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        jdbi.useHandle(handle -> {
            CriteriaLookupDao criteriaLookupDao = handle.attach(CriteriaLookupDao.class);
            handle.createUpdate("UPDATE  rpro_rc_schd SET post_batch_id =14420,updt_by ='SingleOrg', updt_dt = SYSDATE where rc_id in (95000,95001,95002,95003,100000,100001,100002,100003)").execute();
            handle.createUpdate("delete from rpro_acct_xfer_details where post_batch_id = 14420").execute();
            handle.createUpdate("delete from rpro_acct_xfer where id = 14420").execute();
            handle.createUpdate("delete from rpro_criteria where OBJ_ID =14420").execute();
            criteriaLookupDao.insertCriteria(Long.valueOf(100000),"PERIOD_NAME","=","FEB-22",Long.valueOf(14420),"NNNGNNNNNNNNNNNNNNNN",dbParams.getClientId(),Long.valueOf(202202),dbParams.getUser());
            criteriaLookupDao.insertCriteria(Long.valueOf(100001),"BOOK_NAME","=","GAAP",Long.valueOf(14420),"NNNGNNNNNNNNNNNNNNNN",dbParams.getClientId(),Long.valueOf(202202),dbParams.getUser());
            handle.createUpdate("insert into rpro_acct_xfer(id,name,status,client_id,crtd_prd_id,sec_atr_val,Book_id,indicators,no_of_schedules)\n" +
                    "values(14420,'TRANSFER BATCH','UPDATED',1,202202,'5',1,'NNNNNNNNNNNNNNNNNNNN',44)").execute();

            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',2)").execute();
            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',3)").execute();
            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',4)").execute();
            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',5)").execute();
            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',6)").execute();
            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',7)").execute();
            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',8)").execute();
            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',9)").execute();

            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',3,'95001','95001','N','5',1,1)").execute();
            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',4,'95002','95002','N','5',1,1)").execute();
            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',6,'100000','100000','N','5',1,1)").execute();
            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',8,'100002','100002','N','5',1,1)").execute();
            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',2,'95000','95000','N','5',1,1)").execute();
            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',5,'95003','95003','N','5',1,1)").execute();
            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',7,'100001','100001','N','5',1,1)").execute();
            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',9,'100003','100003','N','5',1,1)").execute();

        });

        WorkflowRequest request = new WorkflowRequest(JobsMetadata.UI_TRANSFER_ACCOUNTING.getId(), 30991, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "14420~TRANSFER~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        jdbi.useHandle(handle -> {
            String status = handle.createQuery("Select status from rpro_acct_xfer where id =14420").mapTo(String.class).first();
            long count = handle.createQuery("Select count(*) from rpro_acct_xfer_details where status = 'READY TO TRANSFER' and post_batch_id = 14420").mapTo(long.class).first();
            handle.createUpdate("Delete from rpro_batch_split where batch_id = 14420").execute();
            assertTrue("",count == 8);
            assertTrue("",status.equals("READY TO TRANSFER"));
        });
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
    }

    @Test
    public void transferAccountingHappyPathUIDelete() throws IOException {

        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        jdbi.useHandle(handle -> {
            CriteriaLookupDao criteriaLookupDao = handle.attach(CriteriaLookupDao.class);
            handle.createUpdate("UPDATE  rpro_rc_schd SET post_batch_id =14420,updt_by ='SYSADMIN', updt_dt = SYSDATE where rc_id in (95000,95001,95002,95003,100000,100001,100002,100003)").execute();
            handle.createUpdate("delete from rpro_acct_xfer_details where post_batch_id = 14420").execute();
            handle.createUpdate("delete from rpro_acct_xfer where id = 14420").execute();
            handle.createUpdate("delete from rpro_criteria where OBJ_ID =14420").execute();
            criteriaLookupDao.insertCriteria(Long.valueOf(100000),"PERIOD_NAME","=","FEB-22",Long.valueOf(14420),"NNNGNNNNNNNNNNNNNNNN",dbParams.getClientId(),Long.valueOf(202202),dbParams.getUser());
            criteriaLookupDao.insertCriteria(Long.valueOf(100001),"BOOK_NAME","=","GAAP",Long.valueOf(14420),"NNNGNNNNNNNNNNNNNNNN",dbParams.getClientId(),Long.valueOf(202202),dbParams.getUser());
            handle.createUpdate("insert into rpro_acct_xfer(id,name,status,client_id,crtd_prd_id,sec_atr_val,Book_id,indicators,no_of_schedules)\n" +
                    "values(14420,'TRANSFER BATCH','UPDATED',1,202202,'5',1,'NNNNNNNNNNNNNNNNNNNN',44)").execute();

            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',2)").execute();
            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',3)").execute();
            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',4)").execute();
            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',5)").execute();
            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',6)").execute();
            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',7)").execute();
            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',8)").execute();
            handle.createUpdate("insert into rpro_acct_xfer_details(POST_BATCH_ID,STATUS,MESSAGE,SEC_ATR_VAL,CLIENT_ID,BOOK_ID,CREATED_BY,CREATED_DT,UPDT_BY,UPDT_DT,CHUNK_ID)\n" +
                    "values(14420,'UPDATED',NULL,'5',1,NULL,'SingleOrg','18-01-23','SingleOrg','18-01-23',9)").execute();

            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',3,'95001','95001','N','5',1,1)").execute();
            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',4,'95002','95002','N','5',1,1)").execute();
            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',6,'100000','100000','N','5',1,1)").execute();
            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',8,'100002','100002','N','5',1,1)").execute();
            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',2,'95000','95000','N','5',1,1)").execute();
            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',5,'95003','95003','N','5',1,1)").execute();
            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',7,'100001','100001','N','5',1,1)").execute();
            handle.createUpdate("insert into rpro_batch_split(BATCH_ID,TYPE,BATCH_TYPE,CHUNK_ID,MIN_VALUE,MAX_VALUE,PROCESSED,SEC_ATR_VAL,CLIENT_ID,BOOK_ID)" +
                    "values(14420,'RC_ID','TRANSFER',9,'100003','100003','N','5',1,1)").execute();
        });

        WorkflowRequest request = new WorkflowRequest(JobsMetadata.UI_TRANSFER_ACCOUNTING.getId(), 30991, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "14420~DELETE~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        jdbi.useHandle(handle -> {
            long rowCount1 = handle.createQuery("select count(*) from rpro_rc_schd where post_batch_id = 14420").mapTo(long.class).first();
            long rowCount2 = handle.createQuery("select count(*) from rpro_acct_xfer where id = 14420").mapTo(long.class).first();
            long rowCount3 = handle.createQuery("select count(*) from rpro_acct_xfer_details where post_batch_id = 14420 ").mapTo(long.class).first();
            long rowCount4 = handle.createQuery("select count(*) from rpro_criteria rc WHERE rc.obj_id = 14420 AND rc.obj_type = 'ACCT_XFER'").mapTo(long.class).first();
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
            assertTrue("Workflow status is not complete " + info.getStatus(),
                    info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
            assertTrue("rowCount1 :" , rowCount1==0);
            assertTrue("rowCount2 :" , rowCount2==0);
            assertTrue("rowCount3 :" , rowCount3==0);
            assertTrue("rowCount4 :" , rowCount4==0);
        });


    }

    @Test
    public void transferAccountingHappyPathOrg() throws IOException {

        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
    }

    @Test
    public void transferAccountingExcludeFlag() throws IOException {

        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "BOOK_NAME:PERIOD_NAME:RC_ID~GAAP:FEB-22:95000~N:N:Y~5~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            long rowCount = handle.createQuery("select count(*) from rpro_rc_schd where rc_id = 95000 and post_prd_id = 202202 and rpro_rc_schd_pkg.get_interfaced_flag (indicators) = 'N'"
                    + " AND rpro_rc_schd_pkg.get_initial_entry_flag (indicators) = 'N' and post_batch_id is NULL").mapTo(long.class).first();
            LOGGER.info("rowCount : " + rowCount);
            assertTrue("RC_ID 95000 is not excluded", rowCount == 6);
        });
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
    }

    @Test
    public void transferAccountingNoCRtdPeriodId() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_INVALID_CRTD_PERIOD_ID_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();

//            WorkflowExecutionFailedEventAttributes failedEventAttributes = findFailedEventAttributes(wfe);
//            assertNotNull(" Should have found a WorkflowExecution Failed event", failedEventAttributes);
//            String errorMessage = failedEventAttributes.getFailure().getMessage();
//            assertEquals("Error message expected is wrong", "Error: during accounting transfer operation : message='Period is not Opened for the Book 1', type='com.zuora.neo.engine.exception.NonRetryableActivityException', nonRetryable=true", errorMessage);
//            ApplicationFailureInfo apfInfo = failedEventAttributes.getFailure().getApplicationFailureInfo();
//            String errorType = apfInfo.getType();
//            assertEquals("Didnt get NonRetryableActivityException", NonRetryableActivityException.class.getName(), errorType);

        });

    }

    @Test
    public void transferAccountingBatchAlreadyTransferred() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_BATCH_ALREADY_TRANSFER_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            long postBatchid =getPostBatchId(handle);
            long rowcount = handle.createQuery("SELECT count(*) from rpro_acct_xfer where status = 'ERRORS' and message =' Batch Already Transferred' and id = " + postBatchid).mapTo(long.class).first();
            LOGGER.info("       ROWCOUNT : " + rowcount);
            assertTrue("Batch Already Transferred testcase failed",rowcount == 1);
        });

    }

    //Testing happy path for the no criteria
    @Test
    public void transferAccountingHappyPathNoCriteria() throws IOException {

        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
    }

    //Testing happy path for the NULL criteria
    @Test
    public void transferAccountingHappyPathCriteriaNULL() throws IOException {

        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, null);
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
    }

    // With Global BOOK id
    @Test
    public void transferAccountingTestGlobalBookId () throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {

            Long bookCount = handle.createQuery("SELECT count(*) from rpro_book WHERE rpro_book_pkg.get_enabled_flag(indicators) = 'Y'").mapTo(Long.class).first();
            if(bookCount.longValue() == 0 )
            {
                handle.createUpdate("INSERT into rpro_book(ID, NAME, DESCRIPTION, TYPE, RC_PREFIX, OPEN_PRD_ID, START_DATE, END_DATE, INDICATORS, CLIENT_ID, CRTD_PRD_ID, CRTD_DT, CRTD_BY, UPDT_DT,UPDT_BY, ASST_SEGMENTS, LBLTY_SEGMENTS)" +
                        "values(1, 'GAAP','GAAP',NULL,'RC',NULL,NULL,NULL,'YYYYYNNNNNNNNNNNNNNN',1,201501,'01-01-15','SYSADMIN','01-01-15','SYSADMIN',NULL,NULL)").execute();
            }
            LOGGER.info("BOOK ID COUNT : ",bookCount.longValue());
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    10040, "PERIOD_NAME~FEB-22~N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
            assertTrue("Global Book Id is Incorrect " + info.getStatus(),
                    info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            if(bookCount.longValue() == 0 )
            {
                handle.createUpdate("Delete from rpro_book where ID = 1").execute();
            }
        });

    }
    //todo : need to be tested
    //No Global Book Id the workflow should fail
    @Test
    public void transferAccountingTestNoGlobalBookId () throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_NO_GLOBAL_BOOK_ID_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {

            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    10040, "PERIOD_NAME~FEB-22~N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            WorkflowExecutionFailedEventAttributes failedEventAttributes = findFailedEventAttributes(wfe);
            assertNotNull(" Should have found a WorkflowExecution Failed event", failedEventAttributes);
            String errorMessage = failedEventAttributes.getFailure().getMessage();
            assertEquals("Error message expected is wrong", "Error: during accounting transfer operation : message='No Postable Book found', type='com.zuora.neo.engine.exception.NonRetryableActivityException', nonRetryable=true", errorMessage);
            ApplicationFailureInfo apfInfo = failedEventAttributes.getFailure().getApplicationFailureInfo();
            String errorType = apfInfo.getType();
            assertEquals("Didnt get NonRetryableActivityException", NonRetryableActivityException.class.getName(), errorType);
        });

    }
    //todo : need to be tested
    //Multiple Global Book Id the workflow should fail
    @Test
    public void transferAccountingTestMultipleGlobalBookId () throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTIPLE_GLOBAL_BOOK_ID_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    10040, "PERIOD_NAME~FEB-22~N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            WorkflowExecutionFailedEventAttributes failedEventAttributes = findFailedEventAttributes(wfe);
            assertNotNull(" Should have found a WorkflowExecution Failed event", failedEventAttributes);
            String errorMessage = failedEventAttributes.getFailure().getMessage();
            assertEquals("Error message expected is wrong", "Error: during accounting transfer operation : message='Multiple Books found, Please choose a Book to Post', type='com.zuora.neo.engine.exception.NonRetryableActivityException', nonRetryable=true", errorMessage);
            ApplicationFailureInfo apfInfo = failedEventAttributes.getFailure().getApplicationFailureInfo();
            String errorType = apfInfo.getType();
            assertEquals("Didnt get NonRetryableActivityException", NonRetryableActivityException.class.getName(), errorType);

        });

    }

    // Testing the Update retry logic
    @Test
    public void transferAccountingRetryUpdateLogic() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        setTestVariable(TransferAccountingTestEvaluator.UPDATE_RETRY_LOGIC_KEY, true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
        Jdbi jdbi =DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            long postBatchId = getPostBatchId(handle);
            long statusCount = handle.createQuery("SELECT count(*) from rpro_acct_xfer_details where post_batch_id = " + postBatchId + " and status = 'ERRORS'").mapTo(long.class).first();
            assertTrue("Error in Retry Logic ",statusCount==0);
        });
    }

    //todo: need to be tested
    @Test
    public void transferAccountingMaxRetryUpdateLogic() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        setTestVariable(TransferAccountingTestEvaluator.UPDATE_MAX_RETRY_LOGIC_KEY, true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        WorkflowExecutionFailedEventAttributes failedEventAttributes = findFailedEventAttributes(wfe);
        assertNotNull(" Should have found a WorkflowExecution Failed event", failedEventAttributes);
        String errorMessage = failedEventAttributes.getFailure().getMessage();
        assertEquals("Error message expected is wrong", "Error: during accounting transfer operation : message='Update failed even after max retry, please validate', type='com.zuora.neo.engine.exception.NonRetryableActivityException', nonRetryable=true", errorMessage);
        ApplicationFailureInfo apfInfo = failedEventAttributes.getFailure().getApplicationFailureInfo();
        String errorType = apfInfo.getType();
        assertEquals("Didnt get NonRetryableActivityException", NonRetryableActivityException.class.getName(), errorType);

    }

    // Testing the transfer retry logic
    @Test
    public void transferAccountingRetryTransferLogic() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_RETRY_LOGIC_KEY, true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
        Jdbi jdbi =DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            long postBatchId = getPostBatchId(handle);
            long statusCount = handle.createQuery("SELECT count(*) from rpro_acct_xfer_details where post_batch_id = " + postBatchId + " and status = 'ERRORS'").mapTo(long.class).first();
            assertTrue("Error in Retry Logic ",statusCount==0);
        });
    }

    //todo: need to be tested
    @Test
    public void transferAccountingMaxRetryTransferLogic() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MAX_RETRY_LOGIC_KEY, true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
        WorkflowExecutionFailedEventAttributes failedEventAttributes = findFailedEventAttributes(wfe);
        LOGGER.info("Before assert : " + failedEventAttributes);
        //assertNotNull(" Should have found a WorkflowExecution Failed event", failedEventAttributes);
        String errorMessage = failedEventAttributes.getFailure().getCause().getMessage();
        LOGGER.info("Before error msg : ");
        //assertEquals("Error message expected is wrong", "Transfer failed even after max retry, please validate", errorMessage);
        ApplicationFailureInfo apfInfo = failedEventAttributes.getFailure().getCause().getApplicationFailureInfo();
        String errorType = apfInfo.getType();
        LOGGER.info("errorType" + errorType);
        //assertEquals("Didnt get NonRetryableActivityException", NonRetryableActivityException.class.getName(), errorType);
    }


    // Testing Split Batch Insertion for Regular Schdules
    @Test
    public void transferAccountingRproSplitBatchInsertRegularSchd() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AtomicLong afterExecute= new AtomicLong();
        AtomicLong newBatchCount= new AtomicLong(Long.valueOf(0));
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        AccountingTestHelper.regularSchdData();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            setMjeEnabledToN(handle);
            CommonDao commonDao=handle.attach(CommonDao.class);
            properties.load(commonDao, "7fcyoce");
            Long splitBatchSize = properties.getSplitBatchSize();
            List<BatchCriteria> batchCriteriaList = new ArrayList<>() ;
            batchCriteriaList.add(new BatchCriteria(null,"BOOK_NAME","=","GAAP",null,"RB","null"));
            batchCriteriaList.add(new BatchCriteria(null,"PERIOD_NAME","=","FEB-22",null,"RC","null"));
            Integer rrsFilerCount = 0;
            Integer mjtFilerCount = 0;
            Integer rcFilerCount = 0;
            StringBuilder bookWhereClause = new StringBuilder("");
            StringBuilder mjtWhereClause = new StringBuilder("");
            StringBuilder prdWhereClause = new StringBuilder("");
            StringBuilder nonSchWhereClause = new StringBuilder("");
            StringBuilder scheduleWhereClause = new StringBuilder("");
            BatchCriteriaCondition bcc = null;
            Long bookId=Long.valueOf(1);
            for (BatchCriteria criteria: batchCriteriaList) {
                if (criteria.getAlias() == null) {
                    return;
                }
                bcc = BatchCriteriaCondition.createBatchCondition(criteria, scheduleWhereClause, bookWhereClause, mjtWhereClause,
                        rcFilerCount, prdWhereClause, nonSchWhereClause, mjtFilerCount, rrsFilerCount);
            }
            if (bookId != null) {
                bookWhereClause.append(" AND rrs.book_id = ").append(bookId);
            }

            Long currentPeriodId = commonDao.getCreatedPeriodId(1, dbParams.getOrgId(), dbParams.getClientId());
            StringBuilder regSchdCondition = new StringBuilder("");
            if (bcc.getMjtFilerCount() == 0) {
//                regSchdCondition = AccountingQuery.createRegularSchdQuery(regSchdCondition, request, currentPeriodId,null,null, scheduleWhereClause, bookWhereClause,
//                        prdWhereClause, nonSchWhereClause, String.valueOf(5),2);
            }

            String insertStmt = "Select count(*) from"
                    + " ( SELECT  'RC_ID', 'TRANSFER', book_id, chunk_id, MIN(rc_id) min_grp_by_val"
                    + " ,MAX(rc_id) max_grp_by_val, 'N', NULL, 5, 1 FROM (SELECT book_id, rc_id,"
                    + " CEIL(cumm_sum / :l_split_size) chunk_id FROM (SELECT book_id, rc_id"
                    + " ,SUM(cnt) OVER(ORDER BY rc_id) cumm_sum FROM (SELECT book_id, rc_id, COUNT(rc_id) cnt"
                    + " FROM rpro_rc_schd rrs WHERE (( /* REGULAR */"  + regSchdCondition + ") "
                    + " ) AND rrs.sec_atr_val = :orgId AND rrs.client_id = :clientId "
                    + "  GROUP BY rrs.book_id, rrs.rc_id ORDER BY rrs.book_id, rrs.rc_id"
                    + " ))) GROUP BY chunk_id, book_id)";

            newBatchCount.set(handle.createQuery(insertStmt)
                    .bind("l_split_size", splitBatchSize).bind("orgId", 5)
                    .bind("clientId", request.getClientId()).mapTo(long.class).first());
            LOGGER.info("insertStmt : " + insertStmt);
        });

        LOGGER.info("newBatchCount : " + newBatchCount.longValue());
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        jdbi.useHandle(handle -> {
            Long postBatchId =getPostBatchId(handle);
            afterExecute.set(handle.createQuery("select count(*) from rpro_batch_split where BATCH_ID =" + postBatchId).mapTo(long.class).first());
            setMjeEnabledToY(handle);
        });
        LOGGER.info("newBatchCount : " + newBatchCount.longValue());
        LOGGER.info("afterExecute : " + afterExecute.longValue());
        AccountingTestHelper.deleteRegularSchdData();
        assertTrue("Incorrect Batch Split for Regular Schd ",afterExecute.longValue()== newBatchCount.longValue());
    }

    // Testing Split Batch Insertion for MJE Schdules
    @Test
    public void transferAccountingRproSplitBatchInsertMjeSchd() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AtomicLong afterExecute= new AtomicLong();
        AtomicLong newBatchCount= new AtomicLong(Long.valueOf(0));
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            setMjeEnabledToY(handle);
            CommonDao commonDao=handle.attach(CommonDao.class);
            properties.load(commonDao, "7fcyoce");
            Long splitBatchSize = properties.getSplitBatchSize();
            List<BatchCriteria> batchCriteriaList = new ArrayList<>() ;
            batchCriteriaList.add(new BatchCriteria(null,"BOOK_NAME","=","GAAP",null,"RB","null"));
            batchCriteriaList.add(new BatchCriteria(null,"PERIOD_NAME","=","FEB-22",null,"RC","null"));
            Integer rrsFilerCount = 0;
            Integer mjtFilerCount = 0;
            Integer rcFilerCount = 0;
            StringBuilder bookWhereClause = new StringBuilder("");
            StringBuilder mjtWhereClause = new StringBuilder("");
            StringBuilder prdWhereClause = new StringBuilder("");
            StringBuilder nonSchWhereClause = new StringBuilder("");
            StringBuilder scheduleWhereClause = new StringBuilder("");
            BatchCriteriaCondition bcc = null;
            Long bookId=Long.valueOf(1);
            for (BatchCriteria criteria: batchCriteriaList) {
                if (criteria.getAlias() == null) {
                    return;
                }
                bcc = BatchCriteriaCondition.createBatchCondition(criteria, scheduleWhereClause, bookWhereClause, mjtWhereClause,
                        rcFilerCount, prdWhereClause, nonSchWhereClause, mjtFilerCount, rrsFilerCount);
            }
            if (bookId != null) {
                bookWhereClause.append(" AND rrs.book_id = ").append(bookId);
            }

            Long currentPeriodId = commonDao.getCreatedPeriodId(1, dbParams.getOrgId(), dbParams.getClientId());
            StringBuilder regSchdCondition = new StringBuilder("");
            if (bcc.getMjtFilerCount() == 0) {
//                regSchdCondition = AccountingQuery.createRegularSchdQuery(regSchdCondition, request, currentPeriodId,null,null, scheduleWhereClause, bookWhereClause,
//                        prdWhereClause, nonSchWhereClause, String.valueOf(5),2);
            }
            String mjeEnabled = commonDao.getProfileValue(AccountingProfiles.MJE_ENABLED, "N");
            StringBuilder mjeCondition = new StringBuilder("");
            if (bcc.getRcFilerCount() == 0 && "Y".equals(mjeEnabled)) {
//                mjeCondition = AccountingQuery.createMjeQuery(mjeCondition, request, currentPeriodId,null,null, scheduleWhereClause, bookWhereClause,
//                        prdWhereClause, nonSchWhereClause, String.valueOf(5),2);
            }
            String insertStmt = "Select count(*) from"
                    + " ( SELECT  'RC_ID', 'TRANSFER', book_id, chunk_id, MIN(rc_id) min_grp_by_val"
                    + " ,MAX(rc_id) max_grp_by_val, 'N', NULL, 5, 1 FROM (SELECT book_id, rc_id,"
                    + " CEIL(cumm_sum / :l_split_size) chunk_id FROM (SELECT book_id, rc_id"
                    + " ,SUM(cnt) OVER(ORDER BY rc_id) cumm_sum FROM (SELECT book_id, rc_id, COUNT(rc_id) cnt"
                    + " FROM rpro_rc_schd rrs WHERE (( "  + regSchdCondition + ") OR ( " + mjeCondition
                    + " )) AND rrs.sec_atr_val = :orgId AND rrs.client_id = :clientId "
                    + "  GROUP BY rrs.book_id, rrs.rc_id ORDER BY rrs.book_id, rrs.rc_id"
                    + " ))) GROUP BY chunk_id, book_id)";

            newBatchCount.set(handle.createQuery(insertStmt)
                    .bind("l_split_size", splitBatchSize).bind("orgId", 5)
                    .bind("clientId", request.getClientId()).mapTo(long.class).first());

        });


        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        AccountingTestHelper.deleteMjeSchdData();
        jdbi.useHandle(handle -> {
            Long postBatchId =getPostBatchId(handle);
            afterExecute.set(handle.createQuery("select count(*) from rpro_batch_split where BATCH_ID =" + postBatchId).mapTo(long.class).first());
        });
        LOGGER.info("newBatchCount : " + newBatchCount.longValue());
        LOGGER.info("afterExecute : " + afterExecute.longValue());
        assertTrue("Incorrect Batch Split for Mje Schd ",afterExecute.longValue()== newBatchCount.longValue());
    }


    @Test
    public void transferAccountingRproSplitBatchInsertRegularSchdCriteriaNULL() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AtomicLong afterExecute= new AtomicLong();
        AtomicLong newBatchCount= new AtomicLong(Long.valueOf(0));
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        AccountingTestHelper.regularSchdData();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, null);
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            setMjeEnabledToN(handle);
            CommonDao commonDao=handle.attach(CommonDao.class);
            properties.load(commonDao, "7fcyoce");
            Long splitBatchSize = properties.getSplitBatchSize();

            Long currentPeriodId = commonDao.getCreatedPeriodId(1, dbParams.getOrgId(), dbParams.getClientId());
            StringBuilder regSchdCondition = new StringBuilder("");

//            regSchdCondition = AccountingQuery.createRegularSchdQuery(regSchdCondition, request, currentPeriodId,null,null, null,null,
//                    null,null, String.valueOf(5),0);

            String insertStmt = "Select count(*) from"
                    + " ( SELECT  'RC_ID', 'TRANSFER', book_id, chunk_id, MIN(rc_id) min_grp_by_val"
                    + " ,MAX(rc_id) max_grp_by_val, 'N', NULL, 5, 1 FROM (SELECT book_id, rc_id,"
                    + " CEIL(cumm_sum / :l_split_size) chunk_id FROM (SELECT book_id, rc_id"
                    + " ,SUM(cnt) OVER(ORDER BY rc_id) cumm_sum FROM (SELECT book_id, rc_id, COUNT(rc_id) cnt"
                    + " FROM rpro_rc_schd rrs WHERE (( /* REGULAR */"  + regSchdCondition + ") "
                    + " ) AND rrs.sec_atr_val = :orgId AND rrs.client_id = :clientId "
                    + "  GROUP BY rrs.book_id, rrs.rc_id ORDER BY rrs.book_id, rrs.rc_id"
                    + " ))) GROUP BY chunk_id, book_id)";

            newBatchCount.set(handle.createQuery(insertStmt)
                    .bind("l_split_size", splitBatchSize).bind("orgId", 5)
                    .bind("clientId", request.getClientId()).mapTo(long.class).first());
            LOGGER.info("insertStmt : " + insertStmt);
        });

        LOGGER.info("newBatchCount : " + newBatchCount.longValue());
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        jdbi.useHandle(handle -> {
            Long postBatchId =getPostBatchId(handle);
            afterExecute.set(handle.createQuery("select count(*) from rpro_batch_split where BATCH_ID =" + postBatchId).mapTo(long.class).first());
            setMjeEnabledToY(handle);
        });
        LOGGER.info("newBatchCount : " + newBatchCount.longValue());
        LOGGER.info("afterExecute : " + afterExecute.longValue());
        AccountingTestHelper.deleteRegularSchdData();
        assertTrue("Incorrect Batch Split for Regular Schd ",afterExecute.longValue()== newBatchCount.longValue());
    }

    // Testing Split Batch Insertion for MJE Schdules
    @Test
    public void transferAccountingRproSplitBatchInsertMjeSchdCriteriaNULL() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AtomicLong afterExecute= new AtomicLong();
        AtomicLong newBatchCount= new AtomicLong(Long.valueOf(0));
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, null);
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            setMjeEnabledToY(handle);
            CommonDao commonDao=handle.attach(CommonDao.class);
            properties.load(commonDao, "7fcyoce");
            Long splitBatchSize = properties.getSplitBatchSize();

            Long currentPeriodId = commonDao.getCreatedPeriodId(1, dbParams.getOrgId(), dbParams.getClientId());
            StringBuilder regSchdCondition = new StringBuilder("");
//            regSchdCondition = AccountingQuery.createRegularSchdQuery(regSchdCondition, request, currentPeriodId,null,null, null,null,
//                    null,null, String.valueOf(5),0);
            StringBuilder mjeCondition = new StringBuilder("");
//            mjeCondition = AccountingQuery.createMjeQuery(mjeCondition, request, currentPeriodId,null,null, null,null,
//                    null,null, String.valueOf(5),0);
            String insertStmt = "Select count(*) from"
                    + " ( SELECT  'RC_ID', 'TRANSFER', book_id, chunk_id, MIN(rc_id) min_grp_by_val"
                    + " ,MAX(rc_id) max_grp_by_val, 'N', NULL, 5, 1 FROM (SELECT book_id, rc_id,"
                    + " CEIL(cumm_sum / :l_split_size) chunk_id FROM (SELECT book_id, rc_id"
                    + " ,SUM(cnt) OVER(ORDER BY rc_id) cumm_sum FROM (SELECT book_id, rc_id, COUNT(rc_id) cnt"
                    + " FROM rpro_rc_schd rrs WHERE (( "  + regSchdCondition + ") OR ( " + mjeCondition
                    + " )) AND rrs.sec_atr_val = :orgId AND rrs.client_id = :clientId "
                    + "  GROUP BY rrs.book_id, rrs.rc_id ORDER BY rrs.book_id, rrs.rc_id"
                    + " ))) GROUP BY chunk_id, book_id)";

            newBatchCount.set(handle.createQuery(insertStmt)
                    .bind("l_split_size", splitBatchSize).bind("orgId", 5)
                    .bind("clientId", request.getClientId()).mapTo(long.class).first());

        });


        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        AccountingTestHelper.deleteMjeSchdData();
        jdbi.useHandle(handle -> {
            Long postBatchId =getPostBatchId(handle);
            afterExecute.set(handle.createQuery("select count(*) from rpro_batch_split where BATCH_ID =" + postBatchId).mapTo(long.class).first());
        });
        LOGGER.info("newBatchCount : " + newBatchCount.longValue());
        LOGGER.info("afterExecute : " + afterExecute.longValue());
        assertTrue("Incorrect Batch Split for Mje Schd ",afterExecute.longValue()== newBatchCount.longValue());
    }


    private Optional<List<Long>> fetchPostBatchIDs(Handle handle, String selectStmt
    ) {
        RowMapper<Long> fetchPostBatchIDMapper =
                (rs, ctx) -> new Long(rs.getLong(1));
        return Optional.ofNullable(handle.createQuery(selectStmt)
                .map(fetchPostBatchIDMapper).list());
    }

    // Testing ArchiveBatch moving previous batch data to the History table and deleting from split batch table
    @Test
    public void transferAccountingArchiveBatch() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AtomicLong beforeRowCountHistoryTable = new AtomicLong(Long.valueOf(0));
        AtomicLong afterRowCountHistoryTable = new AtomicLong(Long.valueOf(0));
        AtomicLong beforeRowCountSplitBatch = new AtomicLong(Long.valueOf(0));
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            List<Long> postBatchIds = new ArrayList<>();
            beforeRowCountSplitBatch.set( handle.createQuery("select count(*) FROM rpro_batch_split WHERE type = " + " 'RC_ID' "
                    + " AND batch_type ="+" 'TRANSFER' "+" AND sec_atr_val = " + 5 + " AND client_id = "+ 1 ).mapTo(Long.class).first() );
            String query = "select distinct batch_id FROM rpro_batch_split WHERE type =  'RC_ID'  AND batch_type = 'TRANSFER'  AND sec_atr_val = 5  AND client_id = 1 ";
            postBatchIds = fetchPostBatchIDs(handle,query).get();
            beforeRowCountHistoryTable.set( handle.createQuery("select count(*) from rpro_batch_split_h").mapTo(Long.class).first() );
            TestDbParams dbParams = getTestConfig().getTestDbParams();
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            afterRowCountHistoryTable.set( handle.createQuery("select count(*) from rpro_batch_split_h").mapTo(Long.class).first() );
            assertTrue(" History Table Insert Failed ",afterRowCountHistoryTable.longValue() - beforeRowCountHistoryTable.longValue() == beforeRowCountSplitBatch.longValue());
            LOGGER.info("beforeRowCountSplitBatch : " + beforeRowCountSplitBatch.longValue());
            LOGGER.info("beforeRowCountHistoryTable : " + beforeRowCountHistoryTable.longValue());
            LOGGER.info("afterRowCountHistoryTable : " + afterRowCountHistoryTable.longValue());
            LOGGER.info("postBatchIds : " + postBatchIds.toString());
            for( Long postBatchId : postBatchIds)
            {
                long count =handle.createQuery("select count(*) FROM rpro_batch_split WHERE type = " + " 'RC_ID' "
                        + " AND batch_type ="+" 'TRANSFER' "+" AND sec_atr_val = " + 5 + " AND client_id = "+ 1 +" AND batch_id = "+ postBatchId).mapTo(Long.class).first();

                assertTrue("Incorrect Deletion in Split Batch Table",count == 0);
                LOGGER.info("POST BATCH ID " + postBatchId.toString() + " DELETED ");
            }
        });
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
    }

    //Testing Incorrect criteria
    @Test
    public void transferAccountingTestIncorrectCriteria() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "BOOK_NAME:XYZ~GAAP:FEB-22~N:N~5~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            long postBatchId = getPostBatchId(handle);
            long criteriaCount = handle.createQuery("Select count(*) from rpro_criteria where OBJ_ID = " + postBatchId).mapTo(long.class).first();
            long rowCount = handle.createQuery("Select count(*) from rpro_acct_xfer where status ='NEW' and no_of_schedules = 0 and id = " + postBatchId).mapTo(long.class).first();
            assertTrue("Incorrect Criteria was not found", rowCount == 1 && criteriaCount == 0);
        });;
//        WorkflowExecutionFailedEventAttributes failedEventAttributes = findFailedEventAttributes(wfe);
//        assertNotNull(" Should have found a WorkflowExecution Failed event", failedEventAttributes);
//        String errorMessage = failedEventAttributes.getFailure().getMessage();
//        assertEquals("Error message expected is wrong", "Error: during accounting transfer operation : message='Criteria name [XYZ] not defined in the lookup', type='com.zuora.neo.engine.exception.NonRetryableActivityException', nonRetryable=true", errorMessage);
//        ApplicationFailureInfo apfInfo = failedEventAttributes.getFailure().getApplicationFailureInfo();
//        String errorType = apfInfo.getType();
//        assertEquals("Didnt get NonRetryableActivityException", NonRetryableActivityException.class.getName(), errorType);
    }

    private long getNumberOfRowsInRpro_acct_xfer(Handle handle)
    {
        return handle.createQuery("Select count(1) from rpro_acct_xfer")
                .mapTo(long.class).first();
    }

    //Testing Batch Details Inserted to the rpro_acct_xfer table
    @Test
    public void transferAccountingTestBatchDetailsInserted() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AtomicLong beforeExecute = new AtomicLong();
        AtomicLong afterExecute = new AtomicLong();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            beforeExecute.set(getNumberOfRowsInRpro_acct_xfer(handle));
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            afterExecute.set(getNumberOfRowsInRpro_acct_xfer(handle));
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();

        });
        LOGGER.info("beforeExecute " + beforeExecute.longValue());
        LOGGER.info("afterExecute " + afterExecute.longValue());
        assertTrue("TRANSFER BATCH data not inserted in rpro_acct_xfer",afterExecute.longValue()==beforeExecute.longValue()+1);
    }


    private long getNumberOfRowsInRpro_criteria(Handle handle)
    {
        return handle.createQuery("Select max(id) from rpro_criteria ")
                .mapTo(long.class).first();
    }
    //Testing Criteria Details Inserted to the rpro_criteria table
    @Test
    public void transferAccountingTestCriteriaDetailsInserted() throws IOException{
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        AtomicLong beforeExecute = new AtomicLong();
        AtomicLong afterExecute = new AtomicLong();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            beforeExecute.set(getNumberOfRowsInRpro_criteria(handle));
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            afterExecute.set(getNumberOfRowsInRpro_criteria(handle));
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();

        });
        LOGGER.info("beforeExecute " + beforeExecute.longValue());
        LOGGER.info("afterExecute " + afterExecute.longValue());
        assertTrue("BATCH Criteria data not inserted in rpro_criteria",afterExecute.longValue()-beforeExecute.longValue()==2 );

    }
    //todo : need to be tested
    //Testing Criteria Book Id Is NULL
    @Test
    public void transferAccountingTestBookIdIsNULL() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        AtomicLong postBatchId1 = new AtomicLong();
        jdbi.useHandle(handle -> {
            postBatchId1.set(handle.createQuery("Select max(id) from rpro_acct_xfer").mapTo(Long.class).first());
        });
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "BOOK_NAME:PERIOD_NAME~x1y1:FEB-22~N:N~5~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
        AtomicLong postBatchId2 = new AtomicLong();
        jdbi.useHandle(handle -> {
            postBatchId2.set(handle.createQuery("Select max(id) from rpro_acct_xfer").mapTo(Long.class).first());
        });
        assertTrue("BookId NULL not found",postBatchId1.longValue() == postBatchId2.longValue());
//        WorkflowExecutionFailedEventAttributes failedEventAttributes = findFailedEventAttributes(wfe);
//        assertNotNull(" Should have found a WorkflowExecution Failed event", failedEventAttributes);
//        String errorMessage = failedEventAttributes.getFailure().getMessage();
//        assertEquals("Error message expected is wrong", "Error: during accounting transfer operation : message='Invalid Book Name', type='com.zuora.neo.engine.exception.NonRetryableActivityException', nonRetryable=true", errorMessage);
//        ApplicationFailureInfo apfInfo = failedEventAttributes.getFailure().getApplicationFailureInfo();
//        String errorType = apfInfo.getType();
//        assertEquals("Didnt get NonRetryableActivityException", NonRetryableActivityException.class.getName(), errorType);

    }

    public Boolean checkUpdateHeaderSummaryFlag(Handle handle)
    {
        Long postbatchId=getPostBatchId(handle);
        String indicators=handle.createQuery("select Indicators from rpro_acct_xfer where id ="+ postbatchId.toString()).mapTo(String.class).first();
        String trueValue=handle.createQuery(" select rpro_acct_xfer_pkg.set_summary_xfer_flag('NNNNNNNNNNNNNNNNNNNN','Y') from dual").mapTo(String.class).first();
        LOGGER.info("Indicators --> " + indicators + " TrueValue  --> " + trueValue);
        return indicators.equals(trueValue);
    }

    //Testing Update Header Summary Flag for Regular Schedules
    @Test
    public void transferAccountingTestUpdateHeaderSummaryFlagRegularSchd() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            setSummaryTransferToY(handle);
            setMjeSummaryTransferToN(handle);
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            assertTrue("summary xfer flag should be set to Y for Regular Schedules ",checkUpdateHeaderSummaryFlag(handle));
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            setMjeSummaryTransferToY(handle);
        });

    }

    //Testing Update Header Summary Flag for MJE Schedules
    @Test
    public void transferAccountingTestUpdateHeaderSummaryFlagMjeSchd() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            setSummaryTransferToN(handle);
            setMjeSummaryTransferToY(handle);
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                    dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            assertTrue("summary xfer flag should be set to Y Mje Schedules ",checkUpdateHeaderSummaryFlag(handle));
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            setSummaryTransferToY(handle);
        });

    }


    //Testing Update Query for Regular Schedules
    @Test
    public void transferAccountingTestMjtQuery() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        AtomicLong postBatchId=new AtomicLong();
        jdbi.withHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            setMjeEnabledToN(handle);
            CommonDao commonDao = handle.attach(CommonDao.class);

            List<BatchCriteria> batchCriteriaList = new ArrayList<>() ;
            batchCriteriaList.add(new BatchCriteria(null,"BOOK_NAME","=","GAAP",null,"RB","null"));
            batchCriteriaList.add(new BatchCriteria(null,"PERIOD_NAME","=","FEB-22",null,"RC","null"));
            Integer bookId = 1;

            BatchCriteriaCondition bcc = null;
            StringBuilder scheduleWhereClause = new StringBuilder("");
            Integer rrsFilerCount = 0;
            Integer mjtFilerCount = 0;
            Integer rcFilerCount = 0;
            StringBuilder bookWhereClause = new StringBuilder("");
            StringBuilder mjtWhereClause = new StringBuilder("");
            StringBuilder prdWhereClause = new StringBuilder("");
            StringBuilder nonSchWhereClause = new StringBuilder("");
            for (BatchCriteria criteria: batchCriteriaList) {
                if (criteria.getAlias() == null) {
                    return null;
                }
                bcc = BatchCriteriaCondition.createBatchCondition(criteria, scheduleWhereClause, bookWhereClause, mjtWhereClause,
                        rcFilerCount, prdWhereClause, nonSchWhereClause, mjtFilerCount, rrsFilerCount);
            }
            if (bookId != null) {
                bookWhereClause.append(" AND rrs.book_id = ").append(bookId);
            }
            if (bcc.getMjtFilerCount() > 0 && bcc.getRcFilerCount() > 0) {

                return null;
            }
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            Long currentPeriodId = commonDao.getCreatedPeriodId(1, dbParams.getOrgId(), dbParams.getClientId());
            long mjtCount=0;
            StringBuilder regSchdCondition= new StringBuilder("Select count(*) from rpro_rc_schd rrs where ");
            if (bcc.getMjtFilerCount() == 0) {
                regSchdCondition = AccountingQuery.createRegularSchdQuery(regSchdCondition, request, currentPeriodId,null,null, scheduleWhereClause, bookWhereClause,
                        prdWhereClause, nonSchWhereClause,2);
                mjtCount = handle.createQuery(regSchdCondition.toString()).bind("orgId", "5").mapTo(long.class).first();
            }
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            postBatchId.set(getPostBatchId(handle));
            long updatedValue=handle.createQuery("select no_of_schedules from rpro_acct_xfer where id = "+postBatchId.toString()).mapTo(long.class).first();
            AccountingTestHelper.deleteRegularSchdData();
            setMjeEnabledToY(handle);
            LOGGER.info("mjtCount : "+String.valueOf(mjtCount));
            LOGGER.info("UpdatedValue : "+updatedValue);
            assertTrue("Incorrect Updation MJT QUERY! ",mjtCount==updatedValue);
            return null;
        });
    }

    //Testing Update Query for MJE Schedules
    @Test
    public void transferAccountingTestMjeQuery() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        AtomicLong postBatchId=new AtomicLong();
        jdbi.withHandle(handle -> {
            AccountingTestHelper.mjeSchdData();
            setMjeEnabledToY(handle);
            CommonDao commonDao = handle.attach(CommonDao.class);
//            String criteriaValue = "GAAP:FEB-22";
//            String criteriaName = "BOOK_NAME:PERIOD_NAME";
//            String[] criteriaParams = criteriaName.split(delimiterCharacter);
//            String[] criteriaValParams = criteriaValue.split(delimiterCharacter);
            List<BatchCriteria> batchCriteriaList = new ArrayList<>() ;
            batchCriteriaList.add(new BatchCriteria(null,"BOOK_NAME","=","GAAP",null,"RB","null"));
            batchCriteriaList.add(new BatchCriteria(null,"PERIOD_NAME","=","FEB-22",null,"RC","null"));
            Integer bookId = 1;
//            final String[] bookName = {null};
//            for (int i = 0; i < criteriaParams.length; ++i) {
//                if ("BOOK_NAME".equals(criteriaParams[i])) {
//                    bookName[0] = criteriaValParams[i];
//                    bookId = Math.toIntExact(commonDao.getBookId(bookName[0], dbParams.getClientId()));
//                }
//            }

            BatchCriteriaCondition bcc = null;
            StringBuilder scheduleWhereClause = new StringBuilder("");
            Integer rrsFilerCount = 0;
            Integer mjtFilerCount = 0;
            Integer rcFilerCount = 0;
            StringBuilder bookWhereClause = new StringBuilder("");
            StringBuilder mjtWhereClause = new StringBuilder("");
            StringBuilder prdWhereClause = new StringBuilder("");
            StringBuilder nonSchWhereClause = new StringBuilder("");
            for (BatchCriteria criteria: batchCriteriaList) {
                if (criteria.getAlias() == null) {
                    return null;
                }
                bcc = BatchCriteriaCondition.createBatchCondition(criteria, scheduleWhereClause, bookWhereClause, mjtWhereClause,
                        rcFilerCount, prdWhereClause, nonSchWhereClause, mjtFilerCount, rrsFilerCount);
            }
            if (bookId != null) {
                bookWhereClause.append(" AND rrs.book_id = ").append(bookId);
            }

            if (bcc.getMjtFilerCount() > 0 && bcc.getRcFilerCount() > 0) {

                return null;
            }
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            Long currentPeriodId = commonDao.getCreatedPeriodId(1, dbParams.getOrgId(), dbParams.getClientId());
            long mjeCount=0;
            StringBuilder mjeSchdCondition= new StringBuilder("Select count(*) from rpro_rc_schd rrs where ");
            String mjeEnabled = commonDao.getProfileValue("MJE_ENABLED", "N");
            if (bcc.getRcFilerCount() == 0 && "Y".equals(mjeEnabled)) {
//                mjeSchdCondition = AccountingQuery.createMjeQuery(mjeSchdCondition, request, currentPeriodId,null,null, scheduleWhereClause, bookWhereClause,
//                        prdWhereClause, nonSchWhereClause, String.valueOf(5),2);
                mjeCount = handle.createQuery(mjeSchdCondition.toString()).mapTo(long.class).first();
            }

            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            AccountingTestHelper.deleteMjeSchdData();
            postBatchId.set(getPostBatchId(handle));
            long updatedValue=handle.createQuery("select no_of_schedules from rpro_acct_xfer where id = "+postBatchId.toString()).mapTo(long.class).first();
            LOGGER.info("MJE Count:"+String.valueOf(mjeCount));
            LOGGER.info("UpdatedValue : "+updatedValue);
            assertTrue("Incorrect Updation MJE QUERY! "+updatedValue,mjeCount==updatedValue);
            return null;
        });
    }




    @Test
    public void transferAccountingTestMjtQueryCriteriaNULL() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        AtomicLong postBatchId=new AtomicLong();
        jdbi.withHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            setMjeEnabledToN(handle);
            CommonDao commonDao = handle.attach(CommonDao.class);
//            String criteriaValue = "GAAP:FEB-22";
//            String criteriaName = "BOOK_NAME:PERIOD_NAME";
//            String[] criteriaParams = criteriaName.split(delimiterCharacter);
//            String[] criteriaValParams = criteriaValue.split(delimiterCharacter);
//            List<BatchCriteria> batchCriteriaList = new ArrayList<>() ;
//            batchCriteriaList.add(new BatchCriteria(null,"BOOK_NAME","=","GAAP",null,"RB","null"));
//            batchCriteriaList.add(new BatchCriteria(null,"PERIOD_NAME","=","FEB-22",null,"RC","null"));
//            Integer bookId = 1;
//            final String[] bookName = {null};
//            for (int i = 0; i < criteriaParams.length; ++i) {
//                if ("BOOK_NAME".equals(criteriaParams[i])) {
//                    bookName[0] = criteriaValParams[i];
//                    bookId = Math.toIntExact(commonDao.getBookId(bookName[0], dbParams.getClientId()));
//                }
//            }
//            BatchCriteriaCondition bcc = null;
//            StringBuilder scheduleWhereClause = new StringBuilder("");
//            Integer rrsFilerCount = 0;
//            Integer mjtFilerCount = 0;
//            Integer rcFilerCount = 0;
//            StringBuilder bookWhereClause = new StringBuilder("");
//            StringBuilder mjtWhereClause = new StringBuilder("");
//            StringBuilder prdWhereClause = new StringBuilder("");
//            StringBuilder nonSchWhereClause = new StringBuilder("");
//            for (BatchCriteria criteria: batchCriteriaList) {
//                if (criteria.getAlias() == null) {
//                    return null;
//                }
//                bcc = BatchCriteriaCondition.createBatchCondition(criteria, scheduleWhereClause, bookWhereClause, mjtWhereClause,
//                        rcFilerCount, prdWhereClause, nonSchWhereClause, mjtFilerCount, rrsFilerCount);
//            }
//            if (bookId != null) {
//                bookWhereClause.append(" AND rrs.book_id = ").append(bookId);
//            }
//            if (bcc.getMjtFilerCount() > 0 && bcc.getRcFilerCount() > 0) {
//
//                return null;
//            }
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, null);
            Long currentPeriodId = commonDao.getCreatedPeriodId(1, dbParams.getOrgId(), dbParams.getClientId());
            long mjtCount = 0;
            StringBuilder regSchdCondition= new StringBuilder("Select count(*) from rpro_rc_schd rrs where ");
//            if (bcc.getMjtFilerCount() == 0) {
//            regSchdCondition = AccountingQuery.createRegularSchdQuery(regSchdCondition, request, currentPeriodId,null,null, null,null,
//                    null,null, String.valueOf(5),0);
            mjtCount = handle.createQuery(regSchdCondition.toString()).mapTo(long.class).first();
//            }
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            postBatchId.set(getPostBatchId(handle));
            long updatedValue=handle.createQuery("select no_of_schedules from rpro_acct_xfer where id = "+postBatchId.toString()).mapTo(long.class).first();
            AccountingTestHelper.deleteRegularSchdData();
            setMjeEnabledToY(handle);
            LOGGER.info("mjtCount : "+String.valueOf(mjtCount));
            LOGGER.info("UpdatedValue : "+updatedValue);
            assertTrue("Incorrect Updation MJT QUERY! ",mjtCount==updatedValue);
            return null;
        });
    }

    //Testing Update Query for MJE Schedules
    @Test
    public void transferAccountingTestMjeQueryCriteriaNULL() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        AtomicLong postBatchId=new AtomicLong();
        jdbi.withHandle(handle -> {
            AccountingTestHelper.mjeSchdData();
            setMjeEnabledToY(handle);
            CommonDao commonDao = handle.attach(CommonDao.class);
//            String criteriaValue = "GAAP:FEB-22";
//            String criteriaName = "BOOK_NAME:PERIOD_NAME";
//            String[] criteriaParams = criteriaName.split(delimiterCharacter);
//            String[] criteriaValParams = criteriaValue.split(delimiterCharacter);
//            List<BatchCriteria> batchCriteriaList = new ArrayList<>() ;
//            batchCriteriaList.add(new BatchCriteria(null,"BOOK_NAME","=","GAAP",null,"RB","null"));
//            batchCriteriaList.add(new BatchCriteria(null,"PERIOD_NAME","=","FEB-22",null,"RC","null"));
//            Integer bookId = 1;
//            final String[] bookName = {null};
//            for (int i = 0; i < criteriaParams.length; ++i) {
//                if ("BOOK_NAME".equals(criteriaParams[i])) {
//                    bookName[0] = criteriaValParams[i];
//                    bookId = Math.toIntExact(commonDao.getBookId(bookName[0], dbParams.getClientId()));
//                }
//            }
//
//            BatchCriteriaCondition bcc = null;
//            StringBuilder scheduleWhereClause = new StringBuilder("");
//            Integer rrsFilerCount = 0;
//            Integer mjtFilerCount = 0;
//            Integer rcFilerCount = 0;
//            StringBuilder bookWhereClause = new StringBuilder("");
//            StringBuilder mjtWhereClause = new StringBuilder("");
//            StringBuilder prdWhereClause = new StringBuilder("");
//            StringBuilder nonSchWhereClause = new StringBuilder("");
//            for (BatchCriteria criteria: batchCriteriaList) {
//                if (criteria.getAlias() == null) {
//                    return null;
//                }
//                bcc = BatchCriteriaCondition.createBatchCondition(criteria, scheduleWhereClause, bookWhereClause, mjtWhereClause,
//                        rcFilerCount, prdWhereClause, nonSchWhereClause, mjtFilerCount, rrsFilerCount);
//            }
//            if (bookId != null) {
//                bookWhereClause.append(" AND rrs.book_id = ").append(bookId);
//            }
//
//            if (bcc.getMjtFilerCount() > 0 && bcc.getRcFilerCount() > 0) {
//
//                return null;
//            }
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, null);
            Long currentPeriodId = commonDao.getCreatedPeriodId(1, dbParams.getOrgId(), dbParams.getClientId());
            long mjeCount = 0;
            StringBuilder mjeSchdCondition= new StringBuilder("Select count(*) from rpro_rc_schd rrs where ");
            String mjeEnabled = commonDao.getProfileValue("MJE_ENABLED", "N");
            if ("Y".equals(mjeEnabled)) {
//                mjeSchdCondition = AccountingQuery.createMjeQuery(mjeSchdCondition, request, currentPeriodId,null,null, null,null,
//                        null,null, String.valueOf(5),0);
                mjeCount = handle.createQuery(mjeSchdCondition.toString()).mapTo(long.class).first();
            }

            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            AccountingTestHelper.deleteMjeSchdData();
            postBatchId.set(getPostBatchId(handle));
            long updatedValue=handle.createQuery("select no_of_schedules from rpro_acct_xfer where id = "+postBatchId.toString()).mapTo(long.class).first();
            LOGGER.info("MJE Count:"+String.valueOf(mjeCount));
            LOGGER.info("UpdatedValue : "+updatedValue);
            assertTrue("Incorrect Updation MJE QUERY! "+updatedValue,mjeCount==updatedValue);
            return null;
        });
    }

    //todo:need to be tested
    @Test
    public void transferAccountingTestcriteriaFromArrangementAndManualJournal() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        setTestVariable(TransferAccountingTestEvaluator.CRITERIA_FROM_ARRANGEMENT_AND_MANUAL_JOURNAL_KEY,true);
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            long postBatchId =getPostBatchId(handle);
            long rowCount = handle.createQuery("select count(*) from rpro_acct_xfer where status = 'UPDATE - IN PROGRESS' and id = " + postBatchId).mapTo(long.class).first();
            long chunkCount = handle.createQuery("select count(*) from rpro_acct_xfer_details where status = 'UPDATE - IN PROGRESS' and post_batch_id = " + postBatchId).mapTo(long.class).first();
            LOGGER.info("rowCount : " + rowCount);
            LOGGER.info("chunkCount : " + chunkCount);
            assertTrue("", rowCount == 1 && chunkCount ==8);
        });
        //Todo : Need to check with Moni
    }
    private boolean checkUpdateGlLink(Handle handle,long postBatchId)
    {
        Long rowCount1=handle.createQuery(" select count(*) from ( ((select cr_link_id , sum(ENTERED_CR) from rpro_gl_int_Stage where batch_id = "+postBatchId+" and cr_link_id is not null group by cr_link_id )" +
                "minus (select cr_link_id, sum(abs(amount))  from rpro_rc_Schd where post_batch_id ="+postBatchId+" group by cr_link_id)) " +
                "union all" +
                "((select cr_link_id, sum(abs(amount))  from rpro_rc_Schd where post_batch_id = "+postBatchId+" and cr_link_id is not null group by cr_link_id)" +
                "minus (select cr_link_id , sum(ENTERED_CR) from rpro_gl_int_Stage  where batch_id = "+postBatchId+" and cr_link_id is not null group by cr_link_id" +
                ")) )").mapTo(Long.class).first();

        Long rowCount2=handle.createQuery(" select count(*) from ( ((select dr_link_id , sum(ENTERED_DR) from rpro_gl_int_Stage where batch_id = "+postBatchId+" and dr_link_id is not null group by dr_link_id )" +
                "minus (select dr_link_id, sum(abs(amount))  from rpro_rc_Schd where post_batch_id = "+postBatchId+" and dr_link_id is not null group by dr_link_id)) " +
                "union all " +
                "((select dr_link_id, sum(abs(amount))  from rpro_rc_Schd where post_batch_id = "+postBatchId+" and dr_link_id is not null group by dr_link_id) " +
                "minus (select dr_link_id , sum(ENTERED_DR) from rpro_gl_int_Stage where batch_id = "+postBatchId+" and dr_link_id is not null group by dr_link_id" +
                ")) )").mapTo(Long.class).first();
        LOGGER.info("RowCount1 " + rowCount1);
        LOGGER.info("RowCount2 " + rowCount2);
        return rowCount2.equals(Long.valueOf(0)) && rowCount1.equals(Long.valueOf(0));
    }
    void setEnableGlLinkToN(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='N' where prof_id=562").execute();
    }

    void setEnableGlLinkToY(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='Y' where prof_id=562").execute();
    }

    //Testing Update GlLinking for Regular Schedules
    @Test
    public void transferAccountingTestUpdateGlLinkRegularSchd() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            setSummaryTransferToY(handle);
            setMjeSummaryTransferToN(handle);
            setPostableFlagToY(handle);
            setPostSchedulesToY(handle);
            setPostManualJeSchedulesToN(handle);
            setEnableGlLinkToY(handle);
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            assertTrue("Update GlLink for Regular Schd failed",checkUpdateGlLink(handle,getPostBatchId(handle)));
            AccountingTestHelper.deleteRegularSchdData();
            setMjeSummaryTransferToY(handle);
            setPostManualJeSchedulesToY(handle);
        });
    }
    //todo:need to be tested
    //Testing Update GlLinking for MJE Schedules
    //TODO :  need to check the validation query
    @Test
    public void transferAccountingTestUpdateGlLinkMjeSchd() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.mjeSchdData();
            setSummaryTransferToN(handle);
            setMjeSummaryTransferToY(handle);
            setPostableFlagToY(handle);
            setPostSchedulesToN(handle);
            setPostManualJeSchedulesToY(handle);
            setEnableGlLinkToY(handle);
            CommonDao commonDao=handle.attach(CommonDao.class);
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            assertTrue("Update GlLink for Mje Schd failed",checkUpdateGlLink(handle,getPostBatchId(handle)));
            AccountingTestHelper.deleteMjeSchdData();
            setSummaryTransferToY(handle);
            setPostSchedulesToY(handle);

        });
    }

    void setEnableAllocationToN(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='N' where prof_id=88").execute();
    }

    void setEnableAllocationToY(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='Y' where prof_id=88").execute();
    }

    private Long checkValidateCV(Handle handle,Long postBatchId)
    {
        return handle.createQuery("select count(*) from rpro_int_error where err_type='CV' AND ACCT_XFER_ID ="+postBatchId).mapTo(Long.class).first();
    }

    void setDoTransferValidationToY(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='Y' where prof_id=28").execute();
    }

    //Test CV amount Validation
    @Test
    public void transferAccountingTestValidateCV() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            reSetApplyHoldOnBatch(handle);
            setEnableAllocationToY(handle);
            setDoTransferValidationToY(handle);
            handle.createUpdate("update rpro_rc_schd set amount=amount-10 where RC_ID =95000 and substr(indicators,1,3)='NNW' and rownum=1").execute();
            Long postBatchId=getPostBatchId(handle)+1;
            Long beforeExecute=checkValidateCV(handle,postBatchId);
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            //int rowCount=handle.createUpdate("delete from rpro_ln_hold where rc_id=95000").execute();
            //LOGGER.info("ROWS deleted from rpro_ln_hold : " + rowCount);
            postBatchId=getPostBatchId(handle);
            Long afterExecute=checkValidateCV(handle,postBatchId);
//            AccountingTestHelper.deleteRegularSchdData();
//            AccountingTestHelper.deleteMjeSchdData();
            LOGGER.info("CV validate before : "+beforeExecute);
            LOGGER.info("CV validate after : "+afterExecute);
            assertTrue(beforeExecute + 1 == afterExecute);
        });
    }


    private Long checkValidateSegment(Handle handle,Long postBatchId)
    {
        return handle.createQuery("select count(*) from rpro_int_error where err_type='ACCTG SEGMENT' AND ACCT_XFER_ID ="+postBatchId.longValue()).mapTo(Long.class).first();
    }
    //Testing Segment Validation
    @Test
    //14708 with condition
    public void transferAccountingTestValidateSegment() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            reSetApplyHoldOnBatch(handle);
            setDoTransferValidationToY(handle);
            handle.createUpdate("update rpro_rc_schd set CR_SEGMENTS='104:105' where RC_ID = 95000 and INDICATORS like 'N%'and rownum=1").execute();
            Long postBatchId=getPostBatchId(handle)+1;
            Long beforeExecute=checkValidateSegment(handle,postBatchId);
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), "5", dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            int rowCount=handle.createUpdate("delete from rpro_ln_hold_g where rc_id=95000").execute();
            LOGGER.info("ROWS deleted from rpro_ln_hold : " + rowCount);
            postBatchId=getPostBatchId(handle);
            Long afterExecute=checkValidateSegment(handle,postBatchId);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            LOGGER.info("SEG validate before : "+beforeExecute);
            LOGGER.info("SEG validate after : "+afterExecute);
            assertTrue(beforeExecute+1==afterExecute);

        });
    }

    //Testing for 3 segment with 2 segment data with missing segment
    @Test
    public void transferAccountingTestValidateSegmentMissing() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            reSetApplyHoldOnBatch(handle);
            setDoTransferValidationToY(handle);
            handle.createUpdate("update rpro_rc_schd set CR_SEGMENTS = '104:105:' where RC_ID = 95000 and INDICATORS like 'N%'and rownum=1").execute();
            Long postBatchId=getPostBatchId(handle)+1;
            Long beforeExecute=checkValidateSegment(handle,postBatchId);
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            int rowCount=handle.createUpdate("delete from rpro_ln_hold where rc_id=95000").execute();
            LOGGER.info("ROWS deleted from rpro_ln_hold : " + rowCount);
            postBatchId=getPostBatchId(handle);
            Long afterExecute=checkValidateSegment(handle,postBatchId);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            LOGGER.info("SEG validate before : "+beforeExecute);
            LOGGER.info("SEG validate after : "+afterExecute);
            assertTrue(beforeExecute+1==afterExecute);

        });
    }


    //Testing for 3 segment with 2 segment data with empty segment
    @Test
    public void transferAccountingTestValidateSegmentEmpty() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            reSetApplyHoldOnBatch(handle);
            setDoTransferValidationToY(handle);
            handle.createUpdate("update rpro_rc_schd set CR_SEGMENTS = '104:105: ' where RC_ID = 95000 and INDICATORS like 'N%'and rownum=1").execute();
            Long postBatchId=getPostBatchId(handle)+1;
            Long beforeExecute=checkValidateSegment(handle,postBatchId);
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            int rowCount=handle.createUpdate("delete from rpro_ln_hold where rc_id=95000").execute();
            LOGGER.info("ROWS deleted from rpro_ln_hold : " + rowCount);
            postBatchId=getPostBatchId(handle);
            Long afterExecute=checkValidateSegment(handle,postBatchId);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            LOGGER.info("SEG validate before : "+beforeExecute);
            LOGGER.info("SEG validate after : "+afterExecute);
            assertTrue(beforeExecute == afterExecute);

        });
    }
    //todo: need to be tested
//Testing Applying Hold On RC ID
    @Test
    public void transferAccountingTestApplyHoldOnRC() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            reSetApplyHoldOnBatch(handle);
            setDoTransferValidationToY(handle);
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            CommonDao commonDao =handle.attach(CommonDao.class);
            properties.load(commonDao, "7fcyoce");
            handle.createUpdate("update rpro_rc_schd set amount=amount-10 where RC_ID =95000 and substr(indicators,1,3)='NNW' and rownum=1").execute();

            AccountingDao accountingDao=handle.attach(AccountingDao.class);

            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");

            Long beforeHoldCount=handle.createQuery("select count(*) from rpro_ln_hold where rc_id=95000").mapTo(Long.class).first();
            Long beforeRowCount=handle.createQuery("select count(*) from rpro_rc_schd where rc_id=95000").mapTo(Long.class).first();
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            Long postBatchId=getPostBatchId(handle);
            Long rowCount1= Long.valueOf(accountingDao.getRcHeaderRec(postBatchId, 95000, 95000).size()); // handle.createQuery(query).mapTo(Long.class).first();

            Long afterReset=handle.createQuery("select count(*) from rpro_rc_schd where post_batch_id is NULL AND post_date is NULL AND updt_by='SingleOrg' AND TRUNC(updt_dt)= TRUNC(sysdate) AND rc_id = 95000 ").mapTo(Long.class).first();
            Long afterHoldCount=handle.createQuery("select count(*) from rpro_ln_hold where rc_id=95000").mapTo(Long.class).first();
            Long statusCount= Long.valueOf(0);
            if(properties.getWebserviceEnabled())
            {
                statusCount=handle.createQuery("Select count(*) from rpro_acct_xfer where status = "+"'READY TO TRANSFER'"+"AND TRUNC(updt_dt) = TRUNC(SYSDATE) AND id="+postBatchId).mapTo(Long.class).first();
            }
            else{
                statusCount=handle.createQuery("Select count(*) from rpro_acct_xfer where status = "+"'TRANSFERRED'"+"AND TRUNC(updt_dt) = TRUNC(SYSDATE) AND id="+postBatchId).mapTo(Long.class).first();
            }
            Long batchIdCount=handle.createQuery("Select count(*) from rpro_acct_xfer where id="+postBatchId).mapTo(Long.class).first();
            long deleteCount = handle.createUpdate("delete from rpro_ln_hold where rc_id=95000").execute();
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            LOGGER.info("beforeHoldCount : " + beforeHoldCount);
            LOGGER.info("beforeRowCount : " + beforeRowCount);
            LOGGER.info("rowCount1 : " + rowCount1);
            LOGGER.info("afterReset : " + afterReset);
            LOGGER.info("afterHoldCount : " + afterHoldCount);
            LOGGER.info("statusCount : " + statusCount);
            LOGGER.info("batchIdCount :" + batchIdCount);
            LOGGER.info("DeleteCount :" + deleteCount);
            assertTrue("Reset individual RC schedule failed",beforeRowCount.equals(afterReset));
            assertTrue("RC Hold not applied",beforeHoldCount.equals(afterHoldCount-1));
            assertTrue("RC schedule hold failed",statusCount.equals(batchIdCount));
        });
    }



    void setApplyHoldOnBatch(Handle handle)
    {
        handle.createUpdate("update Rpro_profile_value  set value='Y'where prof_id=332").execute();
    }

    void reSetApplyHoldOnBatch(Handle handle)
    {
        handle.createUpdate("update Rpro_profile_value  set value='N'where prof_id=332").execute();
    }

    private WorkflowExecutionFailedEventAttributes findFailedEventAttributes(WorkflowExecutionEntity wfe) {
        History history = getWorkflowExecutionHistory(wfe);
        List<HistoryEvent> eventList = history.getEventsList();
        //lets iterate in reverse for quick finding
        ListIterator<HistoryEvent> listIterator = eventList.listIterator(eventList.size());
        WorkflowExecutionFailedEventAttributes failedEventAttributes = null;
        while (listIterator.hasPrevious()) {
            HistoryEvent event = listIterator.previous();
            if (event.hasWorkflowExecutionFailedEventAttributes()) {
                failedEventAttributes = event.getWorkflowExecutionFailedEventAttributes();
                break;
            }
        }
        return failedEventAttributes;
    }
    //todo : chunk status check
    //Testing Applying Hold On Batch
    @Test
    public void transferAccountingTestApplyHoldOnBatch() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            setApplyHoldOnBatch(handle);
            setDoTransferValidationToY(handle);
            long postBatchId=getPostBatchId(handle)+1;
            handle.createUpdate("update rpro_rc_schd set amount=amount-10 where RC_ID =95000 and substr(indicators,1,3)='NNW' and rownum=1").execute();
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            long rowCount=handle.createQuery("Select count(*) from rpro_int_error where acct_xfer_id ="+postBatchId+" and err_msg='Transfer Validation Failed!'").mapTo(long.class).first();
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            Long errorCount = handle.createQuery("select count(*) from rpro_acct_xfer_details where status = 'ERRORS' AND message = 'Transfer Validation Failed!' AND POST_BATCH_ID = " + postBatchId +
                    " AND CHUNK_ID = (select CHUNK_ID from rpro_batch_split where MIN_VALUE = 95000 AND MAX_VALUE = 95000 AND BATCH_ID ="+postBatchId+")").mapTo(Long.class).first();
            assertTrue("CHUNK update Failed ",errorCount.longValue() ==1);
//            WorkflowExecutionFailedEventAttributes failedEventAttributes = findFailedEventAttributes(wfe);
            assertTrue("Insert to Error table failed",rowCount == 1);
//            assertNotNull(" Should have found a WorkflowExecution Failed event", failedEventAttributes);
//            String errorMessage = failedEventAttributes.getFailure().getMessage();
//            assertEquals("Error message expected is wrong", "Error: during accounting transfer operation : message='Transfer Validation Failed!', type='com.zuora.neo.engine.exception.NonRetryableActivityException', nonRetryable=true", errorMessage);
//            ApplicationFailureInfo apfInfo = failedEventAttributes.getFailure().getApplicationFailureInfo();
//            String errorType = apfInfo.getType();
//            assertEquals("Didnt get NonRetryableActivityException", NonRetryableActivityException.class.getName(), errorType);
            reSetApplyHoldOnBatch(handle);
        });
    }

    private Long checkUpdateFileIdHeader(Handle handle,Long postBatchId)
    {
        return handle.createQuery("select count(*) from rpro_acct_xfer where FILE_ID is NULL AND ID = "+postBatchId).mapTo(Long.class).first();
    }

    void setGenerateFileTransferBatchToY(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='Y' where prof_id=88").execute();
    }

    void setWebServiceEnabled(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='Y' where prof_id=45").execute();
    }

    //Testing the File Download
    @Test
    public void transferAccountingTestFileDownload() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            setWebServiceEnabled(handle);
            setGenerateFileTransferBatchToY(handle);
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            Long postBatchId=getPostBatchId(handle);
            Long count =checkUpdateFileIdHeader(handle,postBatchId);
            LOGGER.info("ROW COUNT : " + count.longValue());
            assertFalse("Update File Id Header FAILED", count.equals(1));
        });
    }

    void setPostableFlagToN(Handle handle)
    {
        handle.createUpdate("update rpro_book set indicators = rpro_book_pkg.set_postable_flag(indicators,'N') WHERE rpro_book_pkg.get_enabled_flag(indicators) = 'Y'").execute();
    }

    void setPostableFlagToY(Handle handle)
    {
        handle.createUpdate("update rpro_book set indicators = rpro_book_pkg.set_postable_flag(indicators,'Y') WHERE rpro_book_pkg.get_enabled_flag(indicators) = 'Y'").execute();
    }


    //13973
    @Test
    public void transferAccountingTestUpdatePostStatus() throws IOException{
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();

        jdbi.useHandle(handle -> {
            setPostableFlagToN(handle);
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            long postBatchId=getPostBatchId(handle);
            long rowCount=handle.createQuery("select count(*) from rpro_rc_schd where post_batch_id ="+postBatchId+" AND rpro_rc_schd_pkg.get_initial_entry_flag (indicators) = 'N'").mapTo(long.class).first();
            long updatedRowCount=handle.createQuery("Select count(*) from  rpro_rc_schd where rpro_rc_schd_pkg.get_interfaced_flag (indicators) = 'Y' AND rpro_rc_schd_pkg.get_initial_entry_flag (indicators) = 'N' and post_batch_id ="+postBatchId).mapTo(long.class).first();
            assertTrue("updateRcPostDetailsGl failed ",rowCount==updatedRowCount);
            long rcHeadUpdatedCount=handle.createQuery("select count(*) from rpro_rc_head rh where\n" +
                    "updt_by = 'SingleOrg' AND (rh.id, book_id) IN (SELECT sch.rc_id, sch.book_id\n" +
                    "FROM rpro_rc_schd sch WHERE rpro_rc_schd_pkg.get_interfaced_flag (sch.indicators) = 'Y'\n" +
                    "AND rpro_rc_schd_pkg.GET_SCHD_TYPE_FLAG(sch.indicators) in ('A','I') AND sch.post_batch_id = "+postBatchId+")").mapTo(long.class).first();
            long rcHeadRowCount=handle.createQuery("select count(*) from rpro_rc_head rh where\n" +
                    "(rh.id, book_id) IN (SELECT sch.rc_id, sch.book_id\n" +
                    "FROM rpro_rc_schd sch WHERE rpro_rc_schd_pkg.get_interfaced_flag (sch.indicators) = 'Y'\n" +
                    "AND rpro_rc_schd_pkg.GET_SCHD_TYPE_FLAG(sch.indicators) in ('A','I') AND sch.post_batch_id = "+postBatchId+")").mapTo(long.class).first();
            LOGGER.info("RowCount : " + rowCount);
            LOGGER.info("updatedRowCount : " + updatedRowCount);
            LOGGER.info("rcHeadUpdatedCount : " + rcHeadUpdatedCount);
            LOGGER.info("rcHeadRowCount : " + rcHeadRowCount);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            assertTrue("updateRcHeadPosted failed",rcHeadRowCount==rcHeadUpdatedCount);
            setPostableFlagToY(handle);
        });

    }

    void setPostSchedulesToN(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='N' where prof_id=30").execute();
    }

    void setPostSchedulesToY(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='Y' where prof_id=30").execute();
    }

    void setMjeEnabledToN(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='N' where prof_id=603").execute();
    }

    void setMjeEnabledToY(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='Y' where prof_id=603").execute();
    }

    void setSummaryTransferToN(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='N' where prof_id=36").execute();
    }

    void setSummaryTransferToY(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='Y' where prof_id=36").execute();
    }

    @Test
    public void transferAccountingTestUpdatePostStatusRegularSchd() throws IOException{
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            setPostableFlagToY(handle);
            setPostSchedulesToY(handle);
            setMjeEnabledToN(handle);
            setSummaryTransferToY(handle);
            CommonDao commonDao=handle.attach(CommonDao.class);
            properties.load(commonDao, "7fcyoce");
            //CommonDao commonDao=handle.attach(CommonDao.class);
            //ScheduleDao scheduleDao=handle.attach(ScheduleDao.class);
            //GeneralLedgerDao ledgerDao=handle.attach(GeneralLedgerDao.class);
            String schdFlag = "";
            Integer glIntStageExist = 0;
            if ("APPLICATION".equals(properties.getNettingLevel())) {
                schdFlag = "D";
            } else {
                schdFlag = "X";
            }

            String summaryTransfer = properties.getSummaryTransferEnabled() ? "Y" : "N"; //commonDao.getProfileValue(AccountingProfiles.SUMMARY_TRANSFER, "N");
            String objectType = AccountingObjectType.GENERAL_LEDGER.getObjectTypeType();
            String postSchedules =properties.getPostScheduleEnabled() ? "Y" : "N"; //commonDao.getProfileValue(AccountingProfiles.POST_SCHEDULES, "N");
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            long postBatchId=getPostBatchId(handle);

            glIntStageExist = handle.createQuery("SELECT 1 FROM rpro_gl_int_stage WHERE batch_id = "+ postBatchId +" AND object_type = 'GL'AND ROWNUM = 1").mapTo(Integer.class).first();
            long rowCount=handle.createQuery("select count(*) from rpro_rc_schd schd where post_batch_id ="+postBatchId+
                    " AND rpro_rc_schd_pkg.get_initial_entry_flag (indicators) = 'N' AND rpro_rc_schd_pkg.get_schd_type_flag (indicators) NOT IN ('M','T', '"+
                    schdFlag+"') AND ('"+ postSchedules + "'= 'N' OR "+glIntStageExist+" = 1 OR EXISTS ( SELECT 1 FROM rpro_gl_int_stage stg WHERE '"+
                    summaryTransfer+"' = 'N' AND stg.schedule_id = schd.id AND stg.object_type = '"+objectType+"' ))").mapTo(long.class).first();

            long updatedRowCount=handle.createQuery("Select count(*) from  rpro_rc_schd schd where rpro_rc_schd_pkg.get_interfaced_flag (indicators) = 'Y'AND post_batch_id ="+postBatchId+
                    " AND rpro_rc_schd_pkg.get_initial_entry_flag (indicators) = 'N' AND rpro_rc_schd_pkg.get_schd_type_flag (indicators) NOT IN ('M','T', '"+
                    schdFlag+"') AND ('"+ postSchedules + "'= 'N' OR "+glIntStageExist+" = 1 OR EXISTS ( SELECT 1 FROM rpro_gl_int_stage stg WHERE '"+
                    summaryTransfer+"' = 'N' AND stg.schedule_id = schd.id AND stg.object_type = '"+objectType+"' ))").mapTo(long.class).first();
            assertTrue("Regular schedule TransferActivity updateRcPostDetailsGl failed ",rowCount==updatedRowCount);
            long rcHeadUpdatedCount=handle.createQuery("select count(*) from rpro_rc_head rh where\n" +
                    "updt_by = 'SingleOrg' AND (rh.id, book_id) IN (SELECT sch.rc_id, sch.book_id\n" +
                    "FROM rpro_rc_schd sch WHERE rpro_rc_schd_pkg.get_interfaced_flag (sch.indicators) = 'Y'\n" +
                    "AND rpro_rc_schd_pkg.GET_SCHD_TYPE_FLAG(sch.indicators) in ('A','I') AND sch.post_batch_id = "+postBatchId+")").mapTo(long.class).first();

            long rcHeadRowCount=handle.createQuery("select count(*) from rpro_rc_head rh where\n" +
                    "(rh.id, book_id) IN (SELECT sch.rc_id, sch.book_id\n" +
                    "FROM rpro_rc_schd sch WHERE rpro_rc_schd_pkg.get_interfaced_flag (sch.indicators) = 'Y'\n" +
                    "AND rpro_rc_schd_pkg.GET_SCHD_TYPE_FLAG(sch.indicators) in ('A','I') AND sch.post_batch_id = "+postBatchId+")").mapTo(long.class).first();
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            LOGGER.info("RowCount : " + rowCount);
            LOGGER.info("UpdatedRowCount : " + updatedRowCount);
            LOGGER.info("RcHeadUpdatedCount : " + rcHeadUpdatedCount);
            LOGGER.info("RcHeadRowCount : " + rcHeadRowCount);
            assertTrue("Regular schedule TransferActivity updateRcHeadPosted failed",rcHeadUpdatedCount==rcHeadRowCount);
            setMjeEnabledToY(handle);
        });
    }



    void setMjeSummaryTransferToN(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='N' where prof_id=252").execute();
    }

    void setMjeSummaryTransferToY(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='Y' where prof_id=252").execute();
    }

    @Test
    public void transferAccountingTestUpdatePostStatusMJE() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            setPostableFlagToY(handle);
            setPostSchedulesToN(handle);
            setMjeEnabledToY(handle);
            setMjeSummaryTransferToY(handle);
            CommonDao commonDao=handle.attach(CommonDao.class);
            properties.load(commonDao, "7fcyoce");
//            CommonDao commonDao = handle.attach(CommonDao.class);
//            ScheduleDao scheduleDao = handle.attach(ScheduleDao.class);
//            GeneralLedgerDao ledgerDao = handle.attach(GeneralLedgerDao.class);
            String schdFlag = "";
            Integer glIntStageExist = 0;
            if ("APPLICATION".equals( properties.getNettingLevel() )) {
                schdFlag = "D";
            } else {
                schdFlag = "X";
            }
            String mjeSummaryTransfer = properties.getMjeSummaryTransferEnabled() ? "Y" : "N";
            String objectType = AccountingObjectType.MANUAL_JE.getObjectTypeType();
            String postMjeSchedules = properties.getPostManualJeScheduleEnabled() ? "Y" : "N";
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            long postBatchId = getPostBatchId(handle);

            glIntStageExist = handle.createQuery("SELECT 1 FROM rpro_gl_int_stage WHERE batch_id = "+ postBatchId +" AND object_type = 'MANUAL-JE' AND ROWNUM = 1").mapTo(Integer.class).first();
            long rowCount = handle.createQuery("select count(*) from rpro_rc_schd schd where post_batch_id =" + postBatchId +
                    " AND rpro_rc_schd_pkg.get_schd_type_flag (indicators) IN ('M','T', 'D') " +
                    "AND ('" + postMjeSchedules + "' = 'N' OR " + glIntStageExist + "= 1 OR EXISTS ( SELECT 1\n" +
                    "FROM rpro_gl_int_stage stg WHERE '" + mjeSummaryTransfer + "' = 'N' AND stg.schedule_id = schd.id\n" +
                    "AND stg.object_type = '" + objectType + "' ))").mapTo(long.class).first();

            long updatedRowCount = handle.createQuery("Select count(*) from  rpro_rc_schd schd where rpro_rc_schd_pkg.get_interfaced_flag (indicators) = 'Y'AND post_batch_id =" + postBatchId +
                    " AND rpro_rc_schd_pkg.get_schd_type_flag (indicators) IN ('M','T', 'D') " +
                    "AND ('" + postMjeSchedules + "' = 'N' OR " + glIntStageExist + "= 1 OR EXISTS ( SELECT 1\n" +
                    "FROM rpro_gl_int_stage stg WHERE '" + mjeSummaryTransfer + "' = 'N' AND stg.schedule_id = schd.id\n" +
                    "AND stg.object_type = '" + objectType + "' ))").mapTo(long.class).first();

            long rcHeadUpdatedCount=handle.createQuery("select count(*) from rpro_rc_head rh where\n" +
                    "updt_by = 'SingleOrg' AND (rh.id, book_id) IN (SELECT sch.rc_id, sch.book_id\n" +
                    "FROM rpro_rc_schd sch WHERE rpro_rc_schd_pkg.get_interfaced_flag (sch.indicators) = 'Y'\n" +
                    "AND rpro_rc_schd_pkg.GET_SCHD_TYPE_FLAG(sch.indicators) in ('A','I') AND sch.post_batch_id = "+postBatchId+")").mapTo(long.class).first();

            long rcHeadRowCount=handle.createQuery("select count(*) from rpro_rc_head rh where\n" +
                    "(rh.id, book_id) IN (SELECT sch.rc_id, sch.book_id\n" +
                    "FROM rpro_rc_schd sch WHERE rpro_rc_schd_pkg.get_interfaced_flag (sch.indicators) = 'Y'\n" +
                    "AND rpro_rc_schd_pkg.GET_SCHD_TYPE_FLAG(sch.indicators) in ('A','I') AND sch.post_batch_id = "+postBatchId+")").mapTo(long.class).first();

            LOGGER.info("rowCount : " + rowCount);
            LOGGER.info("updatedRowCount : " + updatedRowCount);
            LOGGER.info("RcHeadUpdatedCount : " + rcHeadUpdatedCount);
            LOGGER.info("RcHeadRowCount : " + rcHeadRowCount);
            assertTrue("MJE schedule TransferActivity updateRcPostDetailsGl failed ",rowCount == updatedRowCount);
            assertTrue("MJE schedule TransferActivity updateRcHeadPosted failed",rcHeadUpdatedCount==rcHeadRowCount);
            AccountingTestHelper.deleteMjeSchdData();
            AccountingTestHelper.deleteRegularSchdData();
            setPostSchedulesToY(handle);
        });
    }

    @Test
    public void transferAccountingTestGlStageRegularSchdSummTransferY() throws IOException{
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            setPostableFlagToY(handle);
            setPostSchedulesToY(handle);
            setSummaryTransferToY(handle);
            setMjeEnabledToN(handle);
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            long postBatchId=getPostBatchId(handle)+1;
            long beforeExecute=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE").mapTo(long.class).first();
            long beforeExecuteSummaryY=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE where OBJECT_TYPE='GL'and TRANS_ID is NULL and SCHEDULE_ID is NULL and BATCH_ID ="+postBatchId).mapTo(long.class).first();
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            postBatchId=getPostBatchId(handle);
            long afterExecute=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE").mapTo(long.class).first();
            long afterExecuteSummaryY=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE where OBJECT_TYPE='GL'and TRANS_ID is NULL and SCHEDULE_ID is NULL and BATCH_ID ="+postBatchId).mapTo(long.class).first();
            setMjeEnabledToY(handle);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            LOGGER.info("beforeExecute : " + beforeExecute);
            LOGGER.info("beforeExecuteSummaryY : " + beforeExecuteSummaryY);
            LOGGER.info("afterExecute : " + afterExecute);
            LOGGER.info("afterExecuteSummaryY : " + afterExecuteSummaryY);
            assertTrue("Gl Stage GENERAL_LEDGER Summary Y failed",afterExecute-beforeExecute==afterExecuteSummaryY-beforeExecuteSummaryY);
        });
    }

    @Test
    public void transferAccountingTestTransferGlStageRegularSchdSummTransferN() throws IOException{
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            setPostableFlagToY(handle);
            setPostSchedulesToY(handle);
            setSummaryTransferToN(handle);
            setMjeEnabledToN(handle);
            long postBatchId=getPostBatchId(handle)+1;
            long beforeExecute=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE").mapTo(long.class).first();
            long beforeExecuteSummaryN=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE where OBJECT_TYPE='GL'and TRANS_ID is not NULL and SCHEDULE_ID is not NULL and BATCH_ID ="+postBatchId).mapTo(long.class).first();
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            postBatchId=getPostBatchId(handle);
            long afterExecute=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE").mapTo(long.class).first();
            long afterExecuteSummaryN=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE where OBJECT_TYPE='GL'and TRANS_ID is not NULL and SCHEDULE_ID is not NULL and BATCH_ID ="+postBatchId).mapTo(long.class).first();
            setMjeEnabledToY(handle);
            setSummaryTransferToY(handle);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            LOGGER.info("beforeExecute : " + beforeExecute);
            LOGGER.info("beforeExecuteSummaryN : " + beforeExecuteSummaryN);
            LOGGER.info("afterExecute : " + afterExecute);
            LOGGER.info("afterExecuteSummaryN : " + afterExecuteSummaryN);
            assertTrue("Gl Stage GENERAL_LEDGER Summary N failed",afterExecute-beforeExecute==afterExecuteSummaryN-beforeExecuteSummaryN);
        });
    }

    void setPostManualJeSchedulesToN(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='N' where prof_id=29").execute();
    }
    void setPostManualJeSchedulesToY(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='Y' where prof_id=29").execute();
    }

    @Test
    public void transferAccountingTestTransferGlStageMJESchdMjeSummTransferNPostManlschdN() throws IOException{
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            setPostableFlagToY(handle);
            setMjeEnabledToY(handle);
            setMjeSummaryTransferToN(handle);
            setPostSchedulesToN(handle);
            setPostManualJeSchedulesToN(handle);
            long postBatchId=getPostBatchId(handle)+1;
            long beforeExecute=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE").mapTo(long.class).first();
            long beforeExecuteSummaryN=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE where OBJECT_TYPE='MANUAL-JE'and TRANS_ID is not NULL and SCHEDULE_ID is not NULL and BATCH_ID ="+postBatchId).mapTo(long.class).first();
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            postBatchId=getPostBatchId(handle);
            long afterExecute=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE").mapTo(long.class).first();
            long afterExecuteSummaryN=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE where OBJECT_TYPE='MANUAL-JE'and TRANS_ID is not NULL and SCHEDULE_ID is not NULL and BATCH_ID ="+postBatchId).mapTo(long.class).first();
            setPostSchedulesToY(handle);
            setMjeSummaryTransferToY(handle);
            setPostManualJeSchedulesToY(handle);
            LOGGER.info("beforeExecute : " + beforeExecute);
            LOGGER.info("beforeExecuteSummaryN : " + beforeExecuteSummaryN);
            LOGGER.info("afterExecute : " + afterExecute);
            LOGGER.info("afterExecuteSummaryN : " + afterExecuteSummaryN);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            assertTrue("Gl Stage MJE Summary N failed",afterExecute-beforeExecute==afterExecuteSummaryN-beforeExecuteSummaryN);
            setMjeSummaryTransferToY(handle);
            setPostSchedulesToY(handle);
            setPostManualJeSchedulesToY(handle);

        });
    }


    @Test
    public void transferAccountingTestTransferGlStageMJESchdMjeSummTransferNPostManlschdY() throws IOException{
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            setPostableFlagToY(handle);
            setMjeEnabledToY(handle);
            setMjeSummaryTransferToN(handle);
            setPostSchedulesToN(handle);
            setPostManualJeSchedulesToY(handle);
            long postBatchId=getPostBatchId(handle)+1;
            long beforeExecute=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE").mapTo(long.class).first();
            long beforeExecuteSummaryN=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE where OBJECT_TYPE='MANUAL-JE'and TRANS_ID is not NULL and SCHEDULE_ID is not NULL and BATCH_ID ="+postBatchId).mapTo(long.class).first();
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            postBatchId=getPostBatchId(handle);
            long afterExecute=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE").mapTo(long.class).first();
            long afterExecuteSummaryN=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE where OBJECT_TYPE='MANUAL-JE'and TRANS_ID is not NULL and SCHEDULE_ID is not NULL and BATCH_ID ="+postBatchId).mapTo(long.class).first();
            setPostSchedulesToY(handle);
            setMjeSummaryTransferToY(handle);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            LOGGER.info("beforeExecute : " + beforeExecute);
            LOGGER.info("beforeExecuteSummaryN : " + beforeExecuteSummaryN);
            LOGGER.info("afterExecute : " + afterExecute);
            LOGGER.info("afterExecuteSummaryN : " + afterExecuteSummaryN);
            assertTrue("Gl Stage MJE Summary N failed",afterExecute-beforeExecute==afterExecuteSummaryN-beforeExecuteSummaryN);
            setMjeSummaryTransferToY(handle);
            setPostSchedulesToY(handle);
        });
    }


    @Test
    public void transferAccountingTestTransferGlStageMJESchdMjeSummTransferYPostManlschdN() throws IOException{
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            setPostableFlagToY(handle);
            setMjeEnabledToY(handle);
            setMjeSummaryTransferToY(handle);
            setPostSchedulesToN(handle);
            setPostManualJeSchedulesToN(handle);
            long postBatchId=getPostBatchId(handle)+1;
            long beforeExecute=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE").mapTo(long.class).first();
            long beforeExecuteSummaryY=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE where OBJECT_TYPE='MANUAL-JE'and TRANS_ID is NULL and SCHEDULE_ID is NULL and BATCH_ID ="+postBatchId).mapTo(long.class).first();
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            postBatchId=getPostBatchId(handle);
            long afterExecute=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE").mapTo(long.class).first();
            long afterExecuteSummaryY=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE where OBJECT_TYPE='MANUAL-JE'and TRANS_ID is NULL and SCHEDULE_ID is NULL and BATCH_ID ="+postBatchId).mapTo(long.class).first();
            setPostSchedulesToY(handle);
            setPostManualJeSchedulesToY(handle);
            LOGGER.info("beforeExecute : " + beforeExecute);
            LOGGER.info("beforeExecuteSummaryY : " + beforeExecuteSummaryY);
            LOGGER.info("afterExecute : " + afterExecute);
            LOGGER.info("afterExecuteSummaryN : " + afterExecuteSummaryY);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            assertTrue("Gl Stage MJE Summary Y failed",afterExecute-beforeExecute==afterExecuteSummaryY-beforeExecuteSummaryY);
        });
    }

    @Test
    public void transferAccountingTestTransferGlStageMJESchdMjeSummTransferYPostManlschdY() throws IOException{
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            setPostableFlagToY(handle);
            setMjeEnabledToY(handle);
            setMjeSummaryTransferToY(handle);
            setPostSchedulesToN(handle);
            setPostManualJeSchedulesToY(handle);
            long postBatchId=getPostBatchId(handle)+1;
            long beforeExecute=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE").mapTo(long.class).first();
            long beforeExecuteSummaryY=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE where OBJECT_TYPE='MANUAL-JE'and TRANS_ID is NULL and SCHEDULE_ID is NULL and BATCH_ID ="+postBatchId).mapTo(long.class).first();
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            postBatchId=getPostBatchId(handle);
            long afterExecute=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE").mapTo(long.class).first();
            long afterExecuteSummaryY=handle.createQuery("select count(*) from RPRO_GL_INT_STAGE where OBJECT_TYPE='MANUAL-JE'and TRANS_ID is NULL and SCHEDULE_ID is NULL and BATCH_ID ="+postBatchId).mapTo(long.class).first();
            setPostSchedulesToY(handle);
            LOGGER.info("beforeExecute : " + beforeExecute);
            LOGGER.info("beforeExecuteSummaryY : " + beforeExecuteSummaryY);
            LOGGER.info("afterExecute : " + afterExecute);
            LOGGER.info("afterExecuteSummaryN : " + afterExecuteSummaryY);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            assertTrue("Gl Stage MJE Summary Y failed",afterExecute-beforeExecute==afterExecuteSummaryY-beforeExecuteSummaryY);
        });
    }


    @Test
    public void transferAccountingTestGLmappingDynamic() throws ReflectiveOperationException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            GlIntegrationMap glmap=new GlIntegrationMap(0L,"ATTRIBUTE14","GL","DYNAMIC","select TRUNC(SYSDATE +7) from dual","indicators",0,0L,0,"displayLabel");
            GlInsertBuilder mappedValues=GlInsertBuilder.formGlInsertFromMap(glmap,"GL",handle,new StringBuilder(),"Y","Y",new StringBuilder(),new StringBuilder(),0,1,false);
            String trueValue=handle.createQuery("select TRUNC(SYSDATE +7) from dual").mapTo(String.class).first();
            trueValue=",'"+trueValue+"'";
            assertTrue(trueValue.equals(mappedValues.getInsertSelect().toString()));
            assertTrue(",ATTRIBUTE14".equals(mappedValues.getInsertStmt().toString()));
            assertTrue("".equals(mappedValues.getGroupByStr().toString()));
        });
    }

    @Test
    public void transferAccountingTestMJEmappingDynamic() throws ReflectiveOperationException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            GlIntegrationMap glmap=new GlIntegrationMap(0L,"ATTRIBUTE14","MANUAL-JE","DYNAMIC","select TRUNC(SYSDATE +1) from dual","indicators",0,0L,0,"displayLabel");
            GlInsertBuilder mappedValues=GlInsertBuilder.formGlInsertFromMap(glmap,"MANUAL-JE",handle,new StringBuilder(),"Y","Y",new StringBuilder(),new StringBuilder(),0,1,false);
            String trueValue=handle.createQuery("select TRUNC(SYSDATE +1) from dual").mapTo(String.class).first();
            trueValue=",'"+trueValue+"'";
            assertTrue(trueValue.equals(mappedValues.getInsertSelect().toString()));
            assertTrue(",ATTRIBUTE14".equals(mappedValues.getInsertStmt().toString()));
            assertTrue("".equals(mappedValues.getGroupByStr().toString()));
        });
    }


    private Optional<List<FxGainLossRecord>> fetchFxGainRecords(Handle handle, String selectStmt,
                                                                String objectType, Long postBatchId) {
        FxGainMapper mapper = new FxGainMapper();
        LOGGER.info("fx gain loss query: " + selectStmt);
        return Optional.ofNullable(handle.createQuery(selectStmt)
                .bind("p_obj_type", objectType)
                .bind("p_post_batch_id", postBatchId)
                .map(mapper).list());
    }

    //TODO :  need to setup SOB_ID and LEDGER_ID
    @Test
    public void transferAccountingTestFxGainLossRegularSchd() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();

        jdbi.useHandle(handle -> {
            setMjeEnabledToN(handle);
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            AccountingDao accountingDao=handle.attach(AccountingDao.class);
            GeneralLedgerDao ledgerDao=handle.attach(GeneralLedgerDao.class);
            long updateCount = handle.createUpdate("update rpro_gl_int_map SET SOURCE_FROM = 'EXPRESSION', SOURCE_VALUE = 'round(SCHD_CR_AMOUNT,1)' where FIELD_NAME = 'ENTERED_CR' AND OBJECT_TYPE = 'GL'").execute();
            LOGGER.info("rpro_gl_int_map Table UpdateCount : " + updateCount);
            long postBatchId=getPostBatchId(handle);
            String companyAttr = null;
            String legalEntityAccount = accountingDao.getLegalEntitySegment();
            StringBuilder sqlProjection = new StringBuilder("SET_OF_BOOKS_ID, LEDGER_ID, CURRENCY_CODE, PERIOD_NAME, CURRENCY_CONVERSION_DATE");
            if (legalEntityAccount != null) {
                companyAttr = ledgerDao.getCompanyAttribute("GL");
            }
            if (companyAttr != null) {
                sqlProjection.append(',').append(companyAttr);
            }

            long beforeExecution=handle.createQuery("Select count(*) from rpro_gl_int_stage where object_type = 'GL' and ID is not NULL and batch_id !="+postBatchId+1).mapTo(long.class).first();
            LOGGER.info(" beforeExecution "+beforeExecution);
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    1, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            postBatchId=getPostBatchId(handle);

            StringBuilder query = new StringBuilder("SELECT ");
            query.append(sqlProjection).append(" , NVL(SUM(entered_dr) - SUM(entered_cr), 0) ent_dif, "
                    + "NVL(SUM(accounted_dr) - SUM(accounted_cr), 0) acc_dif FROM rpro_gl_int_stage WHERE object_type = :p_obj_type AND ID is NULL"
                    + " AND batch_id = :p_post_batch_id GROUP BY ").append(sqlProjection).append(" HAVING (NVL(SUM(entered_dr) - SUM(entered_cr), 0) != 0 "
                    + "OR NVL(SUM(accounted_dr) - SUM(accounted_cr), 0) != 0)");
            List<FxGainLossRecord> recs = fetchFxGainRecords(handle,query.toString(),"GL",postBatchId).get();

            long afterExecution=handle.createQuery("Select count(*) from rpro_gl_int_stage where object_type = 'GL' and ID is not NULL").mapTo(long.class).first();
            long resetUpdateCount = handle.createUpdate("update rpro_gl_int_map SET SOURCE_FROM = 'TRANSACTION', SOURCE_VALUE = 'SCHD_CR_AMOUNT' where FIELD_NAME = 'ENTERED_CR' AND OBJECT_TYPE = 'GL'").execute();
            LOGGER.info("rpro_gl_int_map Table resetUpdateCount : " + resetUpdateCount);
            LOGGER.info(" afterExecution " + afterExecution);
            LOGGER.info(" Count " + recs.size());
            setMjeEnabledToY(handle);
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            assertTrue("FxGainLoss failed for GL",afterExecution-beforeExecution==recs.size());

        });
    }


    //TODO :  need to setup SOB_ID and LEDGER_ID
    @Test
    public void transferAccountingTestFxGainLossMJE() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            AccountingTestHelper.regularSchdData();
            AccountingTestHelper.mjeSchdData();
            AccountingDao accountingDao=handle.attach(AccountingDao.class);
            GeneralLedgerDao ledgerDao=handle.attach(GeneralLedgerDao.class);
            long updateCount = handle.createUpdate("update rpro_gl_int_map SET SOURCE_FROM = 'EXPRESSION', SOURCE_VALUE = 'round(SCHD_CR_AMOUNT,1)' where FIELD_NAME = 'ENTERED_CR' AND OBJECT_TYPE = 'MANUAL-JE'").execute();
            LOGGER.info("rpro_gl_int_map Table UpdateCount : " + updateCount);
            long postBatchId=getPostBatchId(handle);
            String companyAttr = null;
            String legalEntityAccount = accountingDao.getLegalEntitySegment();
            StringBuilder sqlProjection = new StringBuilder("SET_OF_BOOKS_ID, LEDGER_ID, CURRENCY_CODE, PERIOD_NAME, CURRENCY_CONVERSION_DATE");
            if (legalEntityAccount != null) {
                companyAttr = ledgerDao.getCompanyAttribute("MANUAL-JE");
            }
            if (companyAttr != null) {
                sqlProjection.append(',').append(companyAttr);
            }

            long beforeExecution=handle.createQuery("Select count(*) from rpro_gl_int_stage where object_type = 'MANUAL-JE' and ID is not NULL and batch_id !="+postBatchId+1).mapTo(long.class).first();
            LOGGER.info(" beforeExecution "+beforeExecution);
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    1, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            postBatchId=getPostBatchId(handle);

            StringBuilder query = new StringBuilder("SELECT ");
            query.append(sqlProjection).append(" , NVL(SUM(entered_dr) - SUM(entered_cr), 0) ent_dif, "
                    + "NVL(SUM(accounted_dr) - SUM(accounted_cr), 0) acc_dif FROM rpro_gl_int_stage WHERE object_type = :p_obj_type AND ID is NULL"
                    + " AND batch_id = :p_post_batch_id GROUP BY ").append(sqlProjection).append(" HAVING (NVL(SUM(entered_dr) - SUM(entered_cr), 0) != 0 "
                    + "OR NVL(SUM(accounted_dr) - SUM(accounted_cr), 0) != 0)");
            List<FxGainLossRecord> recs = fetchFxGainRecords(handle,query.toString(),"MANUAL-JE",postBatchId).get();

            long afterExecution=handle.createQuery("Select count(*) from rpro_gl_int_stage where object_type = 'MANUAL-JE' and ID is not NULL").mapTo(long.class).first();
            long resetUpdateCount = handle.createUpdate("update rpro_gl_int_map SET SOURCE_FROM = 'TRANSACTION', SOURCE_VALUE = 'SCHD_CR_AMOUNT' where FIELD_NAME = 'ENTERED_CR' AND OBJECT_TYPE = 'MANUAL-JE'").execute();
            LOGGER.info("rpro_gl_int_map Table resetUpdateCount : " + resetUpdateCount);
            LOGGER.info(" afterExecution " + afterExecution);
            LOGGER.info(" Count " + recs.size());
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            assertTrue("FxGainLoss failed for MANUAL-JE",afterExecution-beforeExecution==recs.size());
        });
    }



    @Test
    public void transferAccountingTestSummaryActivity() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            long postBatchId = getPostBatchId(handle);
            Long rowCount1 = handle.createQuery(" select count(*) from rpro_schd_prog where prog_id = 503  and parameter_text like '%"+postBatchId+"%'").mapTo(Long.class).first();
            Long rowCount2 = handle.createQuery("select count(*) from rpro_schd_prog where prog_id = 519 and parameter_text like '%"+postBatchId+"%'").mapTo(Long.class).first();
            LOGGER.info("ROWCOUNT : " + rowCount1);
            LOGGER.info("ROWCOUNT : " + rowCount2);
            assertTrue("Error in Summary Activity Close Process Job",rowCount1.equals(Long.valueOf(1)) );
            assertTrue("Error in Summary Activity create Rco Job ",rowCount2.equals(Long.valueOf(1)) );
        });
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
    }
    void setCustomCodeAllowedToY(Handle handle)
    {
        handle.createUpdate("update rpro_profile_value set value='Y' where prof_id=7").execute();
    }
    @Test
    public void transferAccountingTestStageHandlerBeforeUpdate() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            setCustomCodeAllowedToY(handle);
            long prevPostBatchId = getPostBatchId(handle);
            long rowCount =handle.createQuery(" select count(*) from rpro_gl_int_stage where batch_id = " + prevPostBatchId).mapTo(long.class).first();
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            long postBatchId = getPostBatchId(handle);
            long count = handle.createQuery(" select count(*) from rpro_log_act where text like '%TESTING BEFORE_UPDATE "+postBatchId+"%'").mapTo(long.class).first();
            long messageCount = handle.createQuery(" select count(*) from rpro_gl_int_stage where batch_id = "+ prevPostBatchId +" and reference27 = 'BEFORE_UPDATE "+postBatchId+"'").mapTo(long.class).first();
            LOGGER.info("COUNT: " + count);
            LOGGER.info("message: " + messageCount);
            LOGGER.info("ROWCOUNT: " + rowCount);
            assertTrue("Error in BEFORE_UPDATE Stage Handler", count == 1 );
            assertTrue("Error in BEFORE_UPDATE Stage Handler", messageCount == rowCount );
        });
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
    }


    @Test
    public void transferAccountingTestStageHandlerAfterUpdate() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            setCustomCodeAllowedToY(handle);
            long prevPostBatchId = getPostBatchId(handle);
            long rowCount =handle.createQuery(" select count(*) from rpro_gl_int_stage where batch_id = " + prevPostBatchId).mapTo(long.class).first();
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            long postBatchId = getPostBatchId(handle);
            long count = handle.createQuery(" select count(*) from rpro_log_act where text like '%TESTING AFTER_UPDATE "+postBatchId+"%'").mapTo(long.class).first();
            long messageCount = handle.createQuery(" select count(*) from rpro_gl_int_stage where batch_id = "+ prevPostBatchId +" and reference28 = 'AFTER_UPDATE "+postBatchId+"'").mapTo(long.class).first();
            LOGGER.info("COUNT: " + count);
            LOGGER.info("message: " + messageCount);
            LOGGER.info("ROWCOUNT: " + rowCount);
            assertTrue("Error in BEFORE_UPDATE Stage Handler", count == 1 );
            assertTrue("Error in BEFORE_UPDATE Stage Handler", messageCount == rowCount );
        });
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
    }

    @Test
    public void transferAccountingTestStageHandlerBeforePost() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            setCustomCodeAllowedToY(handle);
            long prevPostBatchId = getPostBatchId(handle);
            long rowCount =handle.createQuery(" select count(*) from rpro_gl_int_stage where batch_id = " + prevPostBatchId).mapTo(long.class).first();
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            long postBatchId = getPostBatchId(handle);
            long count = handle.createQuery(" select count(*) from rpro_log_act where text like '%TESTING BEFORE_POST "+postBatchId+"%'").mapTo(long.class).first();
            long messageCount = handle.createQuery(" select count(*) from rpro_gl_int_stage where batch_id = "+ prevPostBatchId +" and reference29 = 'BEFORE_POST "+postBatchId+"'").mapTo(long.class).first();
            LOGGER.info("COUNT: " + count);
            LOGGER.info("message: " + messageCount);
            LOGGER.info("ROWCOUNT: " + rowCount);
            assertTrue("Error in BEFORE_UPDATE Stage Handler", count == 1 );
            assertTrue("Error in BEFORE_UPDATE Stage Handler", messageCount == rowCount );
        });
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
    }

    @Test
    public void transferAccountingTestStageHandlerAfterPost() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            setCustomCodeAllowedToY(handle);
            long prevPostBatchId = getPostBatchId(handle);
            long rowCount =handle.createQuery(" select count(*) from rpro_gl_int_stage where batch_id = " + prevPostBatchId).mapTo(long.class).first();
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            long postBatchId = getPostBatchId(handle);
            long count = handle.createQuery(" select count(*) from rpro_log_act where text like '%TESTING AFTER_POST "+postBatchId+"%'").mapTo(long.class).first();
            long messageCount = handle.createQuery(" select count(*) from rpro_gl_int_stage where batch_id = "+ prevPostBatchId +" and reference30 = 'AFTER_POST "+postBatchId+"'").mapTo(long.class).first();
            LOGGER.info("COUNT: " + count);
            LOGGER.info("message: " + messageCount);
            LOGGER.info("ROWCOUNT: " + rowCount);
            assertTrue("Error in BEFORE_UPDATE Stage Handler", count == 1 );
            assertTrue("Error in BEFORE_UPDATE Stage Handler", messageCount == rowCount );
        });
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
    }

    //Testing Incorrect GL interface Mapping
    @Test
    public void transferAccountingTestWrongDynamicGlMapping() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            handle.createUpdate("Insert into rpro_gl_int_map(ID,FIELD_NAME,OBJECT_TYPE,SOURCE_FROM,SOURCE_VALUE,INDICATORS,CLIENT_ID,CRTD_PRD_ID,CRTD_BY ,CRTD_DT,UPDT_BY,UPDT_DT,DISP_SEQ,DISP_LABEL) " +
                    "VALUES(100000,'Attribute20','GL','DYNAMIC','select SYSDATE*7 from dual','YNNNNNNNNNNNNNNNNNNN',1,202202,'SingleOrg',SYSDATE,'SingleOrg',SYSDATE,100,'DUMMY')" ).execute();
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            handle.createUpdate("Delete from rpro_gl_int_map where id = 100000").execute();
            AccountingTestHelper.deleteRegularSchdData();
            AccountingTestHelper.deleteMjeSchdData();
            long postBatchId = getPostBatchId(handle);
            long rowCount = handle.createQuery("Select count(*) from rpro_acct_xfer where message like '%Dynamic SQL IN GL MAPPING failed. Verify the: GL Interface Mapping. Error: ORA-00932: inconsistent datatypes: expected NUMBER got DATE%' and id = "+ postBatchId).mapTo(long.class).first();;
            assertTrue("Didn't get Wrong Dynamic Gl Mapping",rowCount == 1);
            Long chunkRowCount = handle.createQuery("Select count(*) from rpro_int_error where err_msg like '%Dynamic SQL IN GL MAPPING failed. Verify the: GL Interface Mapping. Error: ORA-00932: inconsistent datatypes: expected NUMBER got DATE%' and acct_xfer_id = "+ postBatchId ).mapTo(Long.class).first();
            assertTrue("Err message was inserted to the rpro_int_error ",chunkRowCount == 2);
        });

    }

    @Test
    public void transferAccountingTestGlInterfaceFailed() throws IOException {
        setTestVariable(TransferAccountingTestEvaluator.TRANSFER_MULTI_THREAD_SETUP_KEY,true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        AccountingTestHelper.regularSchdData();
        AccountingTestHelper.mjeSchdData();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            WorkflowRequest request = new WorkflowRequest(JobsMetadata.TRANSFER_ACCOUNTING.getId(), 30992, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(), dbParams.getUser(),
                    10040, "BOOK_NAME:PERIOD_NAME~GAAP:FEB-22~N:N~5~");
            WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
            waitForWorkflowComplete(wfe);
            long postBatchId = getPostBatchId(handle);
            String errorMessage = handle.createQuery("Select message from rpro_acct_xfer where id = "+ postBatchId).mapTo(String.class).first();
            assertTrue("Didn't Wrong Dynamic Gl Mapping",errorMessage.equals(  "e.getMessage()"));
            Long rowCount = handle.createQuery("Select count(*) from rpro_int_error where err_msg = 'GL Interface failed. Verify the GL Interface Mapping. It creates syntactical errors.' and acct_xfer_id = "+ postBatchId ).mapTo(Long.class).first();
            assertTrue("Err message was inserted to the rpro_int_error ",rowCount == 1);
        });
        AccountingTestHelper.deleteRegularSchdData();
        AccountingTestHelper.deleteMjeSchdData();
    }


}


