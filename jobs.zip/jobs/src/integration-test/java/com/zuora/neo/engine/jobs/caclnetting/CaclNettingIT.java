package com.zuora.neo.engine.jobs.caclnetting;

import com.zuora.neo.engine.api.WorkflowExecutionEntity;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.JobsMetadata;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.common.DbCommonUtils;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.caclnetting.db.dao.CaclNettingDao;
import com.zuora.neo.engine.test.BaseIntegrationTest;
import com.zuora.neo.engine.test.config.TestDbParams;
import com.zuora.neo.engine.test.db.common.DbTestContext;
import io.temporal.api.enums.v1.WorkflowExecutionStatus;
import io.temporal.api.workflow.v1.WorkflowExecutionInfo;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import static org.awaitility.Awaitility.with;
import static org.junit.Assert.assertEquals;

public class CaclNettingIT extends BaseIntegrationTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(CaclNettingIT.class);

    private static class NettingTestVariables {
        Long rcId1 = 1000L, rcId2 = 1001L, bookId = 1L, prdId, nextPrdId;
        String invoiceIndicator = "NNLNNYNNNNRNNNNNNNNNNNNNNNNNNNFNNNNNNNNN";
        String revenueIndicators = "NLRNNYNNNNRNNNNNNNNNNNNNNNNNNNFNNNNNNNNN";
        String unbilledIndicators = "NURNNYNNNNRNNNNNNNNNNNNNNNNNNNFNNNNNNNNN";
        String adjustmentCreditIndicator = "NNWNNYNNNNANNNNNNNNNNNNNNNNNNNFNNNNNNNNN";
        String adjustmentDebitIndicator = "NWXNNYNNNNANNNNNNNNNNNNNNNNNNNFNNNNNNNNN";
        String caIndicator = "YNNNNNNNNNNNNNNNNNNN";
        String clIndicator = "NNNNNNNNNNNNNNNNNNNN";
        String clNegRcIndicator = "NYNNNNNNNNNNNNNNNNNN";
        String testFlow = "RTP";
    }

    static NettingTestVariables nettingTestVariables;

    @Test
    public void invalidRC() throws IOException {
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        WorkflowExecutionInfo workflowExecutionInfo = executeAndWaitForWorkflow(dbParams, "FEB-22~0~GAAP~Y~1~~");

        assertEquals("Workflow has not failed", WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_FAILED,
                workflowExecutionInfo.getStatus());
    }


    @Test
    public void testSequentialNetting() throws IOException, InterruptedException {
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();

        CurrencyDetails inrUSD = new CurrencyDetails("INR", "USD", 0.0125, 1.0);

        AtomicLong lineID = new AtomicLong(2000);

        /*
          1. Inserts only a single LR entry of 100
          CA - 100, CL - 0
         */
        jdbi.useHandle(handle -> {
            insertRC(handle, dbParams, nettingTestVariables.rcId1);
            insertRCline(handle, dbParams, lineID.get(), 4000, inrUSD, "CMP1", nettingTestVariables.rcId1);
            insertSchedule(handle, dbParams, lineID.get(), 100.0, inrUSD, nettingTestVariables.revenueIndicators, nettingTestVariables.rcId1);

            executeAndTestWorkflow(dbParams, nettingTestVariables.rcId1);

            verifyNettingHead(handle, 100.0, 0.0, inrUSD, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 1);
            verifyNettingSchedules(handle, 100.0, lineID.get(), 2);
        });

        LOGGER.info("CACL: Case {} done", 1);

        /*
            2. Inserting a new NL entry of 100
            CA - 0, CL - 0
         */
        jdbi.useHandle(handle -> {
            insertSchedule(handle, dbParams, lineID.get(), 100.0, inrUSD, nettingTestVariables.invoiceIndicator, nettingTestVariables.rcId1);

            executeAndTestWorkflow(dbParams, nettingTestVariables.rcId1);

            verifyNettingHead(handle, 0.0, 0.0, inrUSD, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.clIndicator, 2);
            verifyNettingSchedules(handle, 0.0, lineID.get(), 0);
        });

        LOGGER.info("CACL: Case {} done", 2);

        /*
            3. Inserts a new NL entry of 200
            CA - 0, CL - 200
         */

        jdbi.useHandle(handle -> {
            insertSchedule(handle, dbParams, lineID.get(), 200.0, inrUSD, nettingTestVariables.invoiceIndicator, nettingTestVariables.rcId1);

            executeAndTestWorkflow(dbParams, nettingTestVariables.rcId1);

            verifyNettingHead(handle, 0.0, 200.0, inrUSD, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.clIndicator, 3);

            verifyNettingSchedules(handle, 0.0, lineID.get(), 0);
        });

        LOGGER.info("CACL: Case {} done", 3);

        /*
            4. Inserts a new line with LR entry of 300
            CA - 100, CL - 0
         */
        lineID.set(lineID.get() + 1);
        jdbi.useHandle(handle -> {
            insertRCline(handle, dbParams, lineID.get(), 4000, inrUSD, "CMP1", nettingTestVariables.rcId1);
            insertSchedule(handle, dbParams, lineID.get(), 300.0, inrUSD, nettingTestVariables.revenueIndicators, nettingTestVariables.rcId1);
            executeAndTestWorkflow(dbParams, nettingTestVariables.rcId1);

            verifyNettingHead(handle, 100.0, 0.0, inrUSD, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 4);

            verifyNettingSchedules(handle, -200.0, lineID.get() - 1, 2);
            verifyNettingSchedules(handle, 300.0, lineID.get(), 2);
        });

        LOGGER.info("CACL: Case {} done", 4);

        /*
            5. Insert allocation schedules
            CA - 80.0, CL - 0
         */

        jdbi.useHandle(handle -> {
            insertSchedule(handle, dbParams, lineID.get() - 1, 21.0, inrUSD, nettingTestVariables.adjustmentCreditIndicator, nettingTestVariables.rcId1);
            insertSchedule(handle, dbParams, lineID.get() - 1, 1.0, inrUSD, nettingTestVariables.adjustmentDebitIndicator, nettingTestVariables.rcId1);

            executeAndTestWorkflow(dbParams, nettingTestVariables.rcId1);

            verifyNettingHead(handle, 80.0, 0.0, inrUSD, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 5);

            verifyNettingSchedules(handle, -200.0, lineID.get() - 1, 2);
            verifyNettingSchedules(handle, -20.0, lineID.get() - 1, 2);
            verifyNettingSchedules(handle, 300.0, lineID.get(), 2);
        });

        LOGGER.info("CACL: Case {} done", 5);

        /*
            6. Insert a new line with a "CMP2" code with  NL entry of 250
            2 head period entries must be created,
            1st entry should match above case => CA - 80.0, CL - 0
            2nd entry, CA - 0, CL - 250
            No schedules must be created as whole RC is in CL
         */
        lineID.set(lineID.get() + 1);
        jdbi.useHandle(handle -> {
            insertRCline(handle, dbParams, lineID.get(), 4000, inrUSD, "CMP2", nettingTestVariables.rcId1);
            insertSchedule(handle, dbParams, lineID.get(), 250.0, inrUSD, nettingTestVariables.invoiceIndicator, nettingTestVariables.rcId1);

            executeAndTestWorkflow(dbParams, nettingTestVariables.rcId1);

            verifyNettingHead(handle, 80.0, 0.0, inrUSD, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.clIndicator, 6);
            verifyNettingHead(handle, 0.0, 250.0, inrUSD, "CMP2", nettingTestVariables.rcId1, nettingTestVariables.clIndicator, 6);
            verifyNettingSchedules(handle, 0.0, lineID.get() - 1, 0);
            verifyNettingSchedules(handle, 0.0, lineID.get() - 2, 0);
            verifyNettingSchedules(handle, 0.0, lineID.get(), 0);
        });

        LOGGER.info("CACL: Case {} done", 6);

        /*
            7. Insert a new RC2 with ID 1001, with only negative lines
            Insert LR schedule of 100
            Since negative RC, should be CL - 100, no schedules
         */
        lineID.set(lineID.get() + 1);
        jdbi.useHandle(handle -> {
            insertRC(handle, dbParams, nettingTestVariables.rcId2);
            insertRCline(handle, dbParams, lineID.get(), -300, inrUSD, "CMP1", nettingTestVariables.rcId2);
            insertSchedule(handle, dbParams, lineID.get(), 100.0, inrUSD, nettingTestVariables.revenueIndicators, nettingTestVariables.rcId2);

            executeAndTestWorkflow(dbParams, null);

            verifyNettingHead(handle, 80.0, 0.0, inrUSD, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.clIndicator, 7);
            verifyNettingHead(handle, 0.0, 250.0, inrUSD, "CMP2", nettingTestVariables.rcId1, nettingTestVariables.clIndicator, 7);
            verifyNettingSchedules(handle, 0.0, lineID.get() - 2, 0);
            verifyNettingSchedules(handle, 0.0, lineID.get() - 3, 0);
            verifyNettingSchedules(handle, 0.0, lineID.get() - 1, 0);

            verifyNettingHead(handle, 0.0, 100.0, inrUSD, "CMP1", nettingTestVariables.rcId2, nettingTestVariables.clNegRcIndicator, 7);
            verifyNettingSchedules(handle, 0.0, lineID.get(), 0);
        });

        LOGGER.info("CACL: Case {} done", 7);

        /*
            8. Insert new line with RIGHT_TO_BILL flag enabled
            Should not make any changes, whole RC in CL
         */
        lineID.set(lineID.get() + 1);
        jdbi.useHandle(handle -> {
            insertRCline(handle, dbParams, lineID.get(), 100, inrUSD, "CMP1", nettingTestVariables.rcId1);
            insertSchedule(handle, dbParams, lineID.get(), 10000.0, inrUSD, nettingTestVariables.unbilledIndicators, nettingTestVariables.rcId1);

            executeAndTestWorkflow(dbParams, null);

            verifyNettingHead(handle, 80.0, 0.0, inrUSD, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.clIndicator, 8);
        });

        LOGGER.info("CACL: Case {} done", 8);

    }

    /*
        Case 1
        Tests delta calculations (i.e)
        tests calculations across periods
     */
    @Test
    public void testDeltaCalculation() throws IOException {

        long originalPrdId = nettingTestVariables.prdId;

        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();

        CurrencyDetails inrToUsd = new CurrencyDetails("INR", "USD", 0.0125, 1.0);

        AtomicLong lineID = new AtomicLong(2000);

        try {
            /*
                1. Insert 1 LR entry of 100 INR - CMP1 in current period
             */
            jdbi.useHandle(handle -> {

                nettingTestVariables.prdId = 202202L;
                nettingTestVariables.nextPrdId = 202203L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                insertRC(handle, dbParams, nettingTestVariables.rcId1);
                insertRCline(handle, dbParams, lineID.get(), 4000, inrToUsd, "CMP1", nettingTestVariables.rcId1);
                insertSchedule(handle, dbParams, lineID.get(), 100.0, inrToUsd, nettingTestVariables.revenueIndicators, nettingTestVariables.rcId1);

                executeAndTestWorkflow(dbParams, 1000L);

                verifyNettingHead(handle, 100.0, 0.0, inrToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 1);
                verifyNettingSchedules(handle, 100.0, lineID.get(), 2);
            });

            /*
                Insert 1 new line with NL schedule of 50
             */
            jdbi.useHandle(handle -> {

                nettingTestVariables.prdId = 202203L;
                nettingTestVariables.nextPrdId = 202204L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                lineID.set(lineID.get()+1);
                insertRCline(handle, dbParams, lineID.get(), 4000, inrToUsd, "CMP1", nettingTestVariables.rcId1);
                insertSchedule(handle, dbParams, lineID.get(), 50.0, inrToUsd, nettingTestVariables.invoiceIndicator, nettingTestVariables.rcId1);

                executeAndTestWorkflow(dbParams, 1000L);

                verifyNettingHead(handle, 50.0, 0.0, inrToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 2);
                verifyNettingSchedules(handle, 100.0, lineID.get()-1, 2);
                verifyNettingSchedules(handle, -50.0, lineID.get(), 2);
            });

            /*
                RC not touched, so it should have created the same results
             */
            jdbi.useHandle(handle -> {

                nettingTestVariables.prdId = 202204L;
                nettingTestVariables.nextPrdId = 202205L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                executeAndTestWorkflow(dbParams, null);

                verifyNettingHead(handle, 50.0, 0.0, inrToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 3);
                verifyNettingSchedules(handle, 100.0, lineID.get()-1, 2);
                verifyNettingSchedules(handle, -50.0, lineID.get(), 2);
            });

        } finally {
            /*
                Reset the open period
             */
            jdbi.useHandle(handle -> {
                setOpenPeriod(handle, dbParams, originalPrdId);
            });
        }


    }

    /**
     * Case 2
     * RC nets to 0 in a period, should not create entries for further periods
     */
    @Test
    public void testEntryCreationStopping() throws IOException {
        long originalPrdId = nettingTestVariables.prdId;

        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();

        CurrencyDetails inrToUsd = new CurrencyDetails("INR", "USD", 0.0125, 1.0);

        AtomicLong lineID = new AtomicLong(2000);

        try {
            /*
                1. Insert 1 LR entry of 100 INR - CMP1 in current period
             */
            jdbi.useHandle(handle -> {

                nettingTestVariables.prdId = 202202L;
                nettingTestVariables.nextPrdId = 202203L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                insertRC(handle, dbParams, nettingTestVariables.rcId1);
                insertRCline(handle, dbParams, lineID.get(), 4000, inrToUsd, "CMP1", nettingTestVariables.rcId1);
                insertSchedule(handle, dbParams, lineID.get(), 100.0, inrToUsd, nettingTestVariables.revenueIndicators, nettingTestVariables.rcId1);

                executeAndTestWorkflow(dbParams, null);

                verifyNettingHead(handle, 100.0, 0.0, inrToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 1);
                verifyNettingSchedules(handle, 100.0, lineID.get(), 2);
            });

            /*
                1. Insert 1 new line with NL schedule of 100
                CA - 0, CL - 0
             */
            jdbi.useHandle(handle -> {

                nettingTestVariables.prdId = 202203L;
                nettingTestVariables.nextPrdId = 202204L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                insertSchedule(handle, dbParams, lineID.get(), 100.0, inrToUsd, nettingTestVariables.invoiceIndicator, nettingTestVariables.rcId1);

                executeAndTestWorkflow(dbParams, null);

                verifyNettingHead(handle, 0.0, 0.0, inrToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.clIndicator, 2);
                verifyNettingSchedules(handle, 0.0, lineID.get(), 0);
            });

            /*
                No header must be created
             */
            jdbi.useHandle(handle -> {

                nettingTestVariables.prdId = 202204L;
                nettingTestVariables.nextPrdId = 202205L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                executeAndTestWorkflow(dbParams, null);

                verifyNettingHeaderNotExists(handle, nettingTestVariables.rcId1, "CMP1");
                verifyNettingSchedules(handle, 0.0, lineID.get(), 0);
            });

        } finally {
            /*
                Reset the open period
             */
            jdbi.useHandle(handle -> {
                setOpenPeriod(handle, dbParams, originalPrdId);
            });
        }
    }

    /*
        Inserts one line with net 0
        Inserts another line with net positive
     */
    @Test
    public void testTwoLines() throws IOException {
        long originalPrdId = nettingTestVariables.prdId;

        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();

        CurrencyDetails inrToUsd = new CurrencyDetails("INR", "USD", 0.0125, 1.0);

        AtomicLong lineID = new AtomicLong(2000);

        try {
            /*
                Insert 1 LR entry of 100 INR - CMP1 in current period
             */
            jdbi.useHandle(handle -> {

                nettingTestVariables.prdId = 202202L;
                nettingTestVariables.nextPrdId = 202203L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                insertRC(handle, dbParams, nettingTestVariables.rcId1);
                insertRCline(handle, dbParams, lineID.get(), 4000, inrToUsd, "CMP1", nettingTestVariables.rcId1);
                insertSchedule(handle, dbParams, lineID.get(), 100.0, inrToUsd, nettingTestVariables.revenueIndicators, nettingTestVariables.rcId1);

                executeAndTestWorkflow(dbParams, null);

                verifyNettingHead(handle, 100.0, 0.0, inrToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 1);
                verifyNettingSchedules(handle, 100.0, lineID.get(), 2);
            });

            /*
                Insert a new line with NL schedule of 50
                CA - 0, CL - 50
             */
            jdbi.useHandle(handle -> {

                nettingTestVariables.prdId = 202203L;
                nettingTestVariables.nextPrdId = 202204L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                lineID.set(lineID.get()+1);
                insertRCline(handle, dbParams, lineID.get(), 400, inrToUsd, "CMP1", nettingTestVariables.rcId1);
                insertSchedule(handle, dbParams, lineID.get(), 50.0, inrToUsd, nettingTestVariables.invoiceIndicator, nettingTestVariables.rcId1);

                executeAndTestWorkflow(dbParams, null);

                verifyNettingHead(handle, 50.0, 0.0, inrToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 2);
                verifyNettingSchedules(handle, 100.0, lineID.get()-1, 2);
                verifyNettingSchedules(handle, -50.0, lineID.get(), 2);
            });

            /*
                Header must be same as above
             */
            jdbi.useHandle(handle -> {

                nettingTestVariables.prdId = 202204L;
                nettingTestVariables.nextPrdId = 202205L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                executeAndTestWorkflow(dbParams, null);

                verifyNettingHead(handle, 50.0, 0.0, inrToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 3);
                verifyNettingSchedules(handle, 100.0, lineID.get()-1, 2);
                verifyNettingSchedules(handle, -50.0, lineID.get(), 2);
            });

        } finally {
            /*
                Reset the open period
             */
            jdbi.useHandle(handle -> {
                setOpenPeriod(handle, dbParams, originalPrdId);
            });
        }
    }

    /**
     * Case 3
     * In prior period, we perform netting in T curr
     * In current period, we have a new line in F curr implying the new entries should be in F curr
     */
    @Test
    public void testMultiCurrencyInNewPeriod() throws IOException {

        long originalPrdId = nettingTestVariables.prdId;

        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();

        CurrencyDetails inrToUsd = new CurrencyDetails("INR", "USD", 0.0125, 1.0);
        CurrencyDetails usdToUsd = new CurrencyDetails("USD", "USD", 1.0, 1.0);

        AtomicLong lineID = new AtomicLong(2000);

        try {
            /*
                1. Insert 1 LR entry of 100 INR - CMP1 in current period
             */
            jdbi.useHandle(handle -> {

                nettingTestVariables.prdId = 202202L;
                nettingTestVariables.nextPrdId = 202203L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                insertRC(handle, dbParams, nettingTestVariables.rcId1);
                insertRCline(handle, dbParams, lineID.get(), 4000, inrToUsd, "CMP1", nettingTestVariables.rcId1);
                insertSchedule(handle, dbParams, lineID.get(), 100.0, inrToUsd, nettingTestVariables.revenueIndicators, nettingTestVariables.rcId1);

                executeAndTestWorkflow(dbParams, null);

                verifyNettingHead(handle, 100.0, 0.0, inrToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 1);
                verifyNettingSchedules(handle, 100.0, lineID.get(), 2);
            });

            /*
                2. Insert 1 new line with NL schedule of 1 USD - CMP1
             */
            jdbi.useHandle(handle -> {

                nettingTestVariables.prdId = 202203L;
                nettingTestVariables.nextPrdId = 202204L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                updateMultiCurrency(handle, dbParams, "F");

                lineID.set(lineID.get()+1);
                insertRCline(handle, dbParams, lineID.get(), 4000, usdToUsd, "CMP1", nettingTestVariables.rcId1);
                insertSchedule(handle, dbParams, lineID.get(), 1.0, usdToUsd, nettingTestVariables.invoiceIndicator, nettingTestVariables.rcId1);

                executeAndTestWorkflow(dbParams, null);

                verifyNettingHead(handle, 0.25, 0.0, usdToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 2);
                verifyNettingSchedules(handle, 1.25, lineID.get()-1, 2);
                verifyNettingSchedules(handle, -1.0, lineID.get(), 2);
            });

            jdbi.useHandle(handle -> {
                nettingTestVariables.prdId = 202204L;
                nettingTestVariables.nextPrdId = 202205L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                executeAndTestWorkflow(dbParams, null);

                verifyNettingHead(handle, 0.25, 0.0, usdToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 3);
                verifyNettingSchedules(handle, 1.25, lineID.get()-1, 2);
                verifyNettingSchedules(handle, -1.0, lineID.get(), 2);
            });

        } finally {
            /*
                Reset the open period
             */
            jdbi.useHandle(handle -> {
                setOpenPeriod(handle, dbParams, originalPrdId);
            });
        }


    }

    /**
     * Case 4
     * In prior period, we have two entries for R and A in intermediate
     * In current period, we have only schedule for A, not R
     * Result => R entry should be carried forward
     */
    @Test
    public void testSchdTypeCarryOver() throws IOException {

        long originalPrdId = nettingTestVariables.prdId;

        TestDbParams dbParams = getTestConfig().getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();

        CurrencyDetails inrToUsd = new CurrencyDetails("INR", "USD", 0.0125, 1.0);

        AtomicLong lineID = new AtomicLong(2000);

        try {
            /*
                Insert 1 LR entry of 100 INR and 1 WX entry of 10 INR - CMP1 in current period
             */
            jdbi.useHandle(handle -> {

                nettingTestVariables.prdId = 202202L;
                nettingTestVariables.nextPrdId = 202203L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                insertRC(handle, dbParams, nettingTestVariables.rcId1);
                insertRCline(handle, dbParams, lineID.get(), 4000, inrToUsd, "CMP1", nettingTestVariables.rcId1);
                insertSchedule(handle, dbParams, lineID.get(), 100.0, inrToUsd, nettingTestVariables.revenueIndicators, nettingTestVariables.rcId1);
                insertSchedule(handle, dbParams, lineID.get(), 10.0, inrToUsd, nettingTestVariables.adjustmentDebitIndicator, nettingTestVariables.rcId1);

                executeAndTestWorkflow(dbParams, null);

                verifyNettingHead(handle, 110.0, 0.0, inrToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 1);
                verifyNettingSchedules(handle, 100.0, lineID.get(), 2);
                verifyNettingSchedules(handle, 10.0, lineID.get(), 2);
            });

            /*
                Insert another WX schedule of 10 INR - CMP1
             */
            jdbi.useHandle(handle -> {

                nettingTestVariables.prdId = 202203L;
                nettingTestVariables.nextPrdId = 202204L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                insertSchedule(handle, dbParams, lineID.get(), 10.0, inrToUsd, nettingTestVariables.adjustmentDebitIndicator, nettingTestVariables.rcId1);

                executeAndTestWorkflow(dbParams, null);

                verifyNettingHead(handle, 120.0, 0.0, inrToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 2);
                verifyNettingSchedules(handle, 100.0, lineID.get(), 2);
                verifyNettingSchedules(handle, 20.0, lineID.get(), 2);
            });

            jdbi.useHandle(handle -> {
                nettingTestVariables.prdId = 202204L;
                nettingTestVariables.nextPrdId = 202205L;
                setOpenPeriod(handle, dbParams, nettingTestVariables.prdId);

                executeAndTestWorkflow(dbParams, null);

                verifyNettingHead(handle, 120.0, 0.0, inrToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 2);
                verifyNettingSchedules(handle, 100.0, lineID.get(), 2);
                verifyNettingSchedules(handle, 20.0, lineID.get(), 2);
            });

        } finally {
            /*
                Reset the open period
             */
            jdbi.useHandle(handle -> {
                setOpenPeriod(handle, dbParams, originalPrdId);
            });
        }


    }


    /**
     * Case 5
     * We have one RC in 202202 (CA), another RC coming in at 202203 (CL)
     * Check if calculations across RCs across periods are consistent
     */
    @Test
    public void testTwoRC() throws IOException {
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();

        CurrencyDetails inrToUsd = new CurrencyDetails("INR", "USD", 0.0125, 1.0);

        AtomicLong lineID = new AtomicLong(2000);

        /*
            1. Insert 1 LR entry of 100 INR - CMP1
         */
        jdbi.useHandle(handle -> {
            insertRC(handle, dbParams, nettingTestVariables.rcId1);
            insertRCline(handle, dbParams, lineID.get(), 4000, inrToUsd, "CMP1", nettingTestVariables.rcId1);
            insertSchedule(handle, dbParams, lineID.get(), 100.0, inrToUsd, nettingTestVariables.revenueIndicators, nettingTestVariables.rcId1);

            executeAndTestWorkflow(dbParams, null);

            verifyNettingHead(handle, 100.0, 0.0, inrToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 1);
            verifyNettingSchedules(handle, 100.0, lineID.get(), 2);
        });

        /*
            2. Insert new RC with NL of 50
         */
        lineID.set(lineID.get() + 1);
        jdbi.useHandle(handle -> {
            insertRC(handle, dbParams, nettingTestVariables.rcId2);
            insertRCline(handle, dbParams, lineID.get(), 4000, inrToUsd, "CMP1", nettingTestVariables.rcId2);
            insertSchedule(handle, dbParams, lineID.get(), 50.0, inrToUsd, nettingTestVariables.invoiceIndicator, nettingTestVariables.rcId2);

            executeAndTestWorkflow(dbParams, null);

            verifyNettingHead(handle, 100.0, 0.0, inrToUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 1);
            verifyNettingSchedules(handle, 100.0, lineID.get() - 1, 2);

            verifyNettingHead(handle, 0.0, 50.0, inrToUsd, "CMP1", nettingTestVariables.rcId2, nettingTestVariables.clIndicator, 1);
            verifyNettingSchedules(handle, 0.0, lineID.get(), 0);
        });
    }

    /**
     * Case 6
     * We perform netting for a RC resulting in CA position
     * The schedules created are posted
     * Perform netting again to verify the schedules are getting reversed properly
     */
    @Test
    public void testReversalOfPostedSchedules() throws IOException {
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();

        CurrencyDetails inrUSD = new CurrencyDetails("INR", "USD", 0.0125, 1.0);

        AtomicLong lineID = new AtomicLong(2000);

        /*
            Inserts only a single LR entry of 100 and posts the schedule for the current period
            Post the netting schedule in the current period
         */
        jdbi.useHandle(handle -> {
            insertRC(handle, dbParams, nettingTestVariables.rcId1);
            insertRCline(handle, dbParams, lineID.get(), 4000, inrUSD, "CMP1", nettingTestVariables.rcId1);
            insertSchedule(handle, dbParams, lineID.get(), 100.0, inrUSD, nettingTestVariables.revenueIndicators, nettingTestVariables.rcId1);

            executeAndTestWorkflow(dbParams, null);

            verifyNettingHead(handle, 100.0, 0.0, inrUSD, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 1);
            verifyNettingSchedules(handle, 100.0, lineID.get(), 2);
        });

        /*
            Posts the created schedule in the current period
            Results should such that it should reverse out the posted schedules
         */
        jdbi.useHandle(handle -> {
            postActualScheduleForRc(handle, dbParams, lineID.get());

            insertSchedule(handle, dbParams, lineID.get(), 20.0, inrUSD, nettingTestVariables.revenueIndicators, nettingTestVariables.rcId1);
            lineID.set(lineID.get()+1);
            insertRCline(handle, dbParams, lineID.get(), 1000, inrUSD, "CMP1", nettingTestVariables.rcId1);
            insertSchedule(handle, dbParams, lineID.get(), 50.0, inrUSD, nettingTestVariables.invoiceIndicator, nettingTestVariables.rcId1);

            executeAndTestWorkflow(dbParams, null);

            verifyNettingHead(handle, 70.0, 0.0, inrUSD, "CMP1",
                    nettingTestVariables.rcId1, nettingTestVariables.caIndicator, 2);
            verifyPostedNettingSchedules(handle, 100.0, lineID.get()-1, 2);
            verifyNettingSchedules(handle, 120.0, lineID.get()-1, 2);
            verifyNettingSchedules(handle, -50.0, lineID.get(), 2);
        });
    }

    /**
     * Case 7
     * Insert unbilled (right_to_bill flag = 'Y') schedules (UR)
     * The process should not pick those records
     */
    @Test
    public void testUnbilledSchedules() throws IOException {
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();

        CurrencyDetails inrUSD = new CurrencyDetails("INR", "USD", 0.0125, 1.0);

        AtomicLong lineID = new AtomicLong(2000);

        /*
            Inserts only a UR entry of 100 and a LR of 50
            Should ignore UR entries and pick LR of 50
         */
        jdbi.useHandle(handle -> {
            insertRC(handle, dbParams, nettingTestVariables.rcId1);
            insertRCline(handle, dbParams, lineID.get(), 4000, inrUSD, "CMP1", nettingTestVariables.rcId1);
            insertSchedule(handle, dbParams, lineID.get(), 100.0, inrUSD, nettingTestVariables.unbilledIndicators,
                    nettingTestVariables.rcId1);

            lineID.set(lineID.get()+1);
            insertRCline(handle, dbParams, lineID.get(), 100, inrUSD,"CMP1", nettingTestVariables.rcId1);
            insertSchedule(handle, dbParams, lineID.get(), 50.0, inrUSD, nettingTestVariables.revenueIndicators,
                    nettingTestVariables.rcId1);

            executeAndTestWorkflow(dbParams, 1000L);

            verifyNettingHead(handle, 50.0, 0.0, inrUSD, "CMP1", nettingTestVariables.rcId1,
                    nettingTestVariables.caIndicator, 1);
            verifyNettingSchedules(handle, 0.0, lineID.get()-1, 0);
            verifyNettingSchedules(handle, 50.0, lineID.get(), 2);
        });
    }

    /**
     * Case 8
     * Use a negative RC
     * Always should be in CL
     */
    @Test
    public void testNegativeRC() throws IOException {
        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();

        CurrencyDetails inrUSD = new CurrencyDetails("INR", "USD", 0.0125, 1.0);

        AtomicLong lineID = new AtomicLong(2000);

        /*
            Inserts only a negative line
         */
        jdbi.useHandle(handle -> {
            insertRC(handle, dbParams, nettingTestVariables.rcId1);
            insertRCline(handle, dbParams, lineID.get(), -100, inrUSD, "CMP1", nettingTestVariables.rcId1);
            insertSchedule(handle, dbParams, lineID.get(), 50.0, inrUSD, nettingTestVariables.revenueIndicators,
                    nettingTestVariables.rcId1);

            executeAndTestWorkflow(dbParams, 1000L);

            verifyNettingHead(handle, 0.0, 50.0, inrUSD, "CMP1", nettingTestVariables.rcId1,
                    nettingTestVariables.clNegRcIndicator, 1);
            verifyNettingSchedules(handle, 0.0, lineID.get(), 0);
        });
    }

    @Test
    public void testMultiCurrAllocations() throws IOException {

        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();

        CurrencyDetails inrUSD = new CurrencyDetails("INR", "USD", 0.0125, 1.0);
        CurrencyDetails eurUsd = new CurrencyDetails("EUR", "USD", 1.06, 1.0);
        CurrencyDetails usdUsd = new CurrencyDetails("USD", "USD", 1.0, 1.0);

        AtomicLong lineID = new AtomicLong(2000);

        jdbi.useHandle(handle -> {

            insertRC(handle, dbParams, nettingTestVariables.rcId1);
            updateMultiCurrency(handle, dbParams, "F");
            insertRCline(handle, dbParams, lineID.get(), 4000, inrUSD, "CMP1", nettingTestVariables.rcId1);
            insertSchedule(handle, dbParams, lineID.get(), 80.0, inrUSD, nettingTestVariables.revenueIndicators,
                    nettingTestVariables.rcId1); // -LR = -1 INR
            insertSchedule(handle, dbParams, lineID.get(), 20.0, usdUsd, nettingTestVariables.adjustmentCreditIndicator,
                    nettingTestVariables.rcId1); // +NW = +20 USD

            lineID.set(lineID.get()+1);
            insertRCline(handle, dbParams, lineID.get(), 4000, eurUsd, "CMP2", nettingTestVariables.rcId1);
            insertSchedule(handle, dbParams, lineID.get(), 160.0, eurUsd, nettingTestVariables.invoiceIndicator,
                    nettingTestVariables.rcId1); // +NL = +169.6 USD
            insertSchedule(handle, dbParams, lineID.get(), 1.0, usdUsd, nettingTestVariables.adjustmentDebitIndicator,
                    nettingTestVariables.rcId1); // -WX = -1 USD

            executeAndTestWorkflow(dbParams, nettingTestVariables.rcId1);

            verifyNettingHead(handle, 0.0, 19.0, usdUsd, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.clIndicator, 1);
            verifyNettingHead(handle, 0.0, 168.6, usdUsd, "CMP2", nettingTestVariables.rcId1, nettingTestVariables.clIndicator, 1);

            verifyNettingSchedules(handle, 0.0, lineID.get() - 1, 0);
            verifyNettingSchedules(handle, 0.0, lineID.get(), 0);
        });

    }

    @Test
    public void testRoundingOffWhileDetermination() throws IOException {

        TestDbParams dbParams = getTestConfig().getTestDbParams();

        Jdbi jdbi = DbTestContext.getConnection();

        CurrencyDetails inrUSD = new CurrencyDetails("INR", "USD", 0.0125, 1.0);

        AtomicLong lineID = new AtomicLong(2000);

        jdbi.useHandle(handle -> {

            insertRC(handle, dbParams, nettingTestVariables.rcId1);
            insertRCline(handle, dbParams, lineID.get(), 4000, inrUSD, "CMP1", nettingTestVariables.rcId1);
            insertSchedule(handle, dbParams, lineID.get(), 0.000000000003, inrUSD, nettingTestVariables.revenueIndicators,
                    nettingTestVariables.rcId1); // -LR = -1 INR

            executeAndTestWorkflow(dbParams, nettingTestVariables.rcId1);

            verifyNettingHead(handle, 0.0, 0.0, inrUSD, "CMP1", nettingTestVariables.rcId1, nettingTestVariables.clIndicator, 1);
            verifyNettingSchedules(handle, 0.0, lineID.get(), 0);
        });

    }

    private void executeAndTestWorkflow(TestDbParams dbParams, Long rcID) throws IOException {

        LOGGER.info("Open period - {}", nettingTestVariables.prdId);

        String rcIDstring;
        if (rcID == null) {
            rcIDstring = "";
        } else {
            rcIDstring = String.valueOf(rcID);
        }

        if (nettingTestVariables.testFlow.equals("RTP") && !rcIDstring.isEmpty()) {
            Jdbi jdbi = DbTestContext.getConnection();

            jdbi.useHandle(handle -> {
                insertWorkItemHeader(handle, dbParams);
            });

            executeRTPWorkflow(dbParams, "N~");

            return;
        }

        WorkflowExecutionInfo workflowExecutionInfo = executeAndWaitForWorkflow(dbParams, "FEB-22~0~GAAP~Y~" + rcIDstring + "~~");

        assertEquals("Workflow status is not complete " + workflowExecutionInfo.getStatus(), WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED,
                workflowExecutionInfo.getStatus());
    }

    private void verifyNettingHead(Handle handle, Double caAmount, Double clAmount, CurrencyDetails currencyDetails, String companyCode, long rcID,
                                   String indicators, int testCase) {
        String headNettingQuery = "SELECT COUNT(*) FROM rpro_rc_head_period_shadow WHERE rc_id = :rcId AND prd_id = :prdId AND ca_amt = :caAmount AND cl_amt = :clAmount " +
                "AND indicators = :indicators AND curr = :curr AND f_cur = :functionalCurrency AND f_ex_rate = :fExRate AND g_ex_rate = :gExRate";

        long count = handle.createQuery(headNettingQuery)
                .bind("rcId", rcID)
                .bind("prdId", nettingTestVariables.prdId)
                .bind("companyCode", companyCode)
                .bind("caAmount", caAmount)
                .bind("clAmount", clAmount)
                .bind("indicators", indicators)
                .bind("curr", currencyDetails.getCurr())
                .bind("functionalCurrency", currencyDetails.getFunctionalCurrency())
                .bind("fExRate", currencyDetails.getFExRate())
                .bind("gExRate", currencyDetails.getGExRate())
                .mapTo(Long.class).first();

        assertEquals("Netting head does not match for RC - " + nettingTestVariables.rcId1 + " Company code - " + companyCode + " Case - " + testCase,
                1, count);

    }

    private void verifyNettingHeaderNotExists(Handle handle, long rcID, String companyCode) {
        String headNettingQuery = "SELECT COUNT(*) FROM rpro_rc_head_period_shadow WHERE rc_id = :rcId AND prd_id = :prdId";

        long count = handle.createQuery(headNettingQuery)
                .bind("rcId", rcID)
                .bind("prdId", nettingTestVariables.prdId)
                .bind("companyCode", companyCode)
                .mapTo(Long.class).first();

        assertEquals("Netting head exists for RC - " + nettingTestVariables.rcId1 + " Company code - " + companyCode,
                0, count);
    }

    private void verifyNettingSchedules(Handle handle, Double amount, long lineID, int expectedCount) {
        String scheduleNettingQuery;

        if (expectedCount == 0) {
            scheduleNettingQuery = "SELECT COUNT(*) FROM rpro_rc_schd_shadow WHERE line_id = :lineID AND " +
                    "((post_prd_id = :prdId AND rpro_rc_schd_pkg.get_reversal_flag(indicators) = 'N') OR " +
                    "(post_prd_id = :nextPrdId AND rpro_rc_schd_pkg.get_reversal_flag(indicators) = 'L')) AND " +
                    "rpro_rc_schd_pkg.get_schd_type_flag(indicators) = 'D'";
        } else {
            scheduleNettingQuery = "SELECT COUNT(*) FROM rpro_rc_schd_shadow WHERE line_id = :lineID AND " +
                    "((post_prd_id = :prdId AND amount = :amount AND rpro_rc_schd_pkg.get_reversal_flag(indicators) = 'N') OR " +
                    "(post_prd_id = :nextPrdId AND amount = -:amount AND rpro_rc_schd_pkg.get_reversal_flag(indicators) = 'L')) AND " +
                    "rpro_rc_schd_pkg.get_schd_type_flag(indicators) = 'D'";
        }

        long count = handle.createQuery(scheduleNettingQuery)
                .bind("lineID", lineID)
                .bind("prdId", nettingTestVariables.prdId)
                .bind("nextPrdId", nettingTestVariables.nextPrdId)
                .bind("amount", amount)
                .mapTo(Long.class).first();

        assertEquals("Netting schedule creation failed", expectedCount, count);
    }

    private void verifyPostedNettingSchedules(Handle handle, Double amount, long lineID, int expectedCount) {
        String scheduleNettingQuery = "SELECT COUNT(*) FROM rpro_rc_schd_shadow WHERE line_id = :lineID AND prd_id = :prdId " +
                    "AND ((amount = :amount AND rpro_rc_schd_pkg.GET_INTERFACED_FLAG(indicators) = 'Y' AND rpro_rc_schd_pkg.GET_REVERSAL_FLAG(indicators) = 'O') " +
                    "OR (amount = -:amount AND rpro_rc_schd_pkg.GET_INTERFACED_FLAG(indicators) = 'N' AND rpro_rc_schd_pkg.GET_REVERSAL_FLAG(indicators) = 'Y')) " +
                    "AND rpro_rc_schd_pkg.get_schd_type_flag(indicators) = 'D'";


        long count = handle.createQuery(scheduleNettingQuery)
                .bind("lineID", lineID)
                .bind("prdId", nettingTestVariables.prdId)
                .bind("nextPrdId", nettingTestVariables.nextPrdId)
                .bind("amount", amount)
                .mapTo(Long.class).first();

        assertEquals("Netting schedule creation failed", expectedCount, count);
    }

    private void insertRC(Handle handle, TestDbParams dbParams, long rcID) {
        String insertRCquery = "INSERT INTO rpro_rc_head (id, sell_amt, indicators, client_id, sec_atr_val, book_id) " +
                "VALUES (:rcId, 4000, 'NNENNYNNNANNNNRNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN', :clientId, :orgId, :bookId)";
        handle.createUpdate(insertRCquery)
                .bind("rcId", rcID)
                .bind("clientId", dbParams.getClientId())
                .bind("orgId", dbParams.getOrgId())
                .bind("bookId", nettingTestVariables.bookId)
                .execute();
    }

    private void setOpenPeriod(Handle handle, TestDbParams dbParams, long prdId) {
        String query = "UPDATE rpro_period SET id = :prdId WHERE book_id = :bookId AND client_id = :clientId AND sec_atr_val = :secAtrVal";
        handle.createUpdate(query)
                .bind("prdId", prdId)
                .bind("bookId", nettingTestVariables.bookId)
                .bind("clientId", dbParams.getClientId())
                .bind("secAtrVal", dbParams.getOrgId())
                .execute();
    }

    private void updateMultiCurrency(Handle handle, TestDbParams dbParams, String currFlag) {
        String updateQuery = "UPDATE rpro_rc_head SET " +
                "indicators = rpro_rc_head_pkg.set_multi_currency_flag(indicators, :currFlag) WHERE id = :rcId ";

        handle.createUpdate(updateQuery)
                .bind("currFlag", currFlag)
                .bind("rcId", nettingTestVariables.rcId1)
                .execute();
    }

    private void insertRCline(Handle handle, TestDbParams dbParams, long lineID, long extSllPrc, CurrencyDetails currencyDetails, String companyCode, long rcID) {
        String insertLineQuery = "INSERT INTO rpro_rc_line (id, rc_id, ext_sll_prc, curr, f_cur, f_ex_rate, g_ex_rate, book_id, company_code, client_id, sec_atr_val) " +
                "VALUES (:lineID, :rcId, :extSllPrc, :curr, :functionalCurr, :fExRate, :gExRate, :bookId, :companyCode, :clientId, :orgId)";

        handle.createUpdate(insertLineQuery)
                .bind("lineID", lineID)
                .bind("rcId", rcID)
                .bind("extSllPrc", extSllPrc)
                .bind("curr", currencyDetails.getCurr())
                .bind("functionalCurr", currencyDetails.getFunctionalCurrency())
                .bind("fExRate", currencyDetails.getFExRate())
                .bind("gExRate", currencyDetails.getGExRate())
                .bind("bookId", nettingTestVariables.bookId)
                .bind("companyCode", companyCode)
                .bind("clientId", dbParams.getClientId())
                .bind("orgId", dbParams.getOrgId())
                .execute();
    }

    private void insertSchedule(Handle handle, TestDbParams dbParams, long lineID, Double amount, CurrencyDetails currencyDetails, String indicator,
                                long rcID) {
        String insertScheduleQuery = "INSERT INTO rpro_rc_schd (id, line_id, root_line_id, rc_id, amount, prd_id, post_prd_id, crtd_prd_id, indicators, " +
                "dr_segments, cr_segments, curr, f_ex_rate, g_ex_rate, crtd_dt, updt_dt, " +
                "book_id, client_id, sec_atr_val) " +
                "VALUES (rpro_utility_pkg.generate_id('RPRO_RC_SCHD_ID_S', :clientId), :lineID, :lineID, :rcId, :amount, :prdId, :prdId, :prdId, :indicator, " +
                "22, 22, :curr, :fExRate, :gExRate, SYSDATE, SYSDATE, " +
                ":bookId, :clientId, :orgId)";

        handle.createUpdate(insertScheduleQuery)
                .bind("lineID", lineID)
                .bind("rcId", rcID)
                .bind("amount", amount)
                .bind("prdId", nettingTestVariables.prdId)
                .bind("indicator", indicator)
                .bind("curr", currencyDetails.getCurr())
                .bind("fExRate", currencyDetails.getFExRate())
                .bind("gExRate", currencyDetails.getGExRate())
                .bind("bookId", nettingTestVariables.bookId)
                .bind("clientId", dbParams.getClientId())
                .bind("orgId", dbParams.getOrgId())
                .execute();
    }

    private void postActualScheduleForRc(Handle handle, TestDbParams dbParams, long lineId) {
        String postQuery = "UPDATE rpro_rc_schd_shadow SET indicators = rpro_rc_schd_pkg.SET_INTERFACED_FLAG(indicators, 'Y') "
                + "WHERE line_id = :lineId AND prd_id = :prdId";

        handle.createUpdate(postQuery)
                .bind("lineId", lineId)
                .bind("prdId", nettingTestVariables.prdId)
                .execute();
    }

    @Before
    public void setup() {
        nettingTestVariables = new NettingTestVariables();
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            initializePeriodDetails(handle);
            deleteRC(handle);
            deleteLine(handle);
            deleteSchedules(handle);
            deleteCreatedNettingEntries(handle);
            removeWorkItem(handle);
        });
    }

    @After
    public void teardown() {
    }

    private void deleteRC(Handle handle) {
        handle.createUpdate(
                        "DELETE FROM rpro_rc_head WHERE id IN (:rcId1, :rcId2)")
                .bind("rcId1", nettingTestVariables.rcId1)
                .bind("rcId2", nettingTestVariables.rcId2)
                .execute();
    }

    private void deleteLine(Handle handle) {
        handle.createUpdate(
                        "DELETE FROM rpro_rc_line WHERE rc_id IN (:rcId1, :rcId2)")
                .bind("rcId1", nettingTestVariables.rcId1)
                .bind("rcId2", nettingTestVariables.rcId2)
                .execute();
    }

    private void deleteSchedules(Handle handle) {
        int deleted = handle.createUpdate(
                        "DELETE FROM rpro_rc_schd WHERE rc_id IN (:rcId1, :rcId2)")
                .bind("rcId1", nettingTestVariables.rcId1)
                .bind("rcId2", nettingTestVariables.rcId2)
                .execute();
    }

    private void deleteCreatedNettingEntries(Handle handle) {
        handle.createUpdate(
                        "DELETE FROM rpro_rc_line_period WHERE rc_id IN (:rcId1, :rcId2)")
                .bind("rcId1", nettingTestVariables.rcId1)
                .bind("rcId2", nettingTestVariables.rcId2)
                .execute();

        handle.createUpdate(
                        "DELETE FROM rpro_rc_head_period_shadow WHERE rc_id IN (:rcId1, :rcId2)")
                .bind("rcId1", nettingTestVariables.rcId1)
                .bind("rcId2", nettingTestVariables.rcId2)
                .execute();

        handle.createUpdate(
                        "DELETE FROM rpro_rc_schd_shadow WHERE rc_id IN (:rcId1, :rcId2)")
                .bind("rcId1", nettingTestVariables.rcId1)
                .bind("rcId2", nettingTestVariables.rcId2)
                .execute();
    }

    private void initializePeriodDetails(Handle handle) {
        if (nettingTestVariables.prdId == null) {
            CaclNettingDao nettingDao = handle.attach(CaclNettingDao.class);
            CommonDao commonDao = handle.attach(CommonDao.class);

            nettingTestVariables.prdId = commonDao.getPeriodId(1L, "0");
            CalendarDetails calendarDetails = commonDao.getPeriodDetailsById(nettingTestVariables.prdId).get(0);
            nettingTestVariables.nextPrdId = DbCommonUtils.getNextPeriodId(calendarDetails, commonDao);
        }
    }

    private WorkflowExecutionInfo executeAndWaitForWorkflow(TestDbParams dbParams, String parameterText) throws IOException {
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.CACLNETTING.getId(), 10026, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), parameterText);
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);

        return getWorkflowExecutionInfo(wfe);
    }

    private void executeRTPWorkflow(TestDbParams dbParams, String parameterText) throws IOException {
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.RTP.getId(), 10026, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), parameterText);
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
    }

    private void insertWorkItemHeader(Handle handle, TestDbParams dbParams) {
        String insertQuery = "INSERT INTO rpro_rtp_wi_header (id, rc_id, prd_id, book_id, sec_atr_val, client_id, wf_id, status, crtd_by, crtd_dt, updt_by, updt_dt) "
                + "SELECT rpro_utility_pkg.generate_id('RPRO_RTP_WI_HEADER_ID_S', :clientId), :rcId, :prdId, 1, :orgId, :clientId, 1, 'NEW', 'INTEGRATION_TEST', " +
                "SYSDATE, 'INTEGRATION_TEST', SYSDATE FROM dual";

        handle.createUpdate(insertQuery)
                .bind("rcId", nettingTestVariables.rcId1)
                .bind("prdId", nettingTestVariables.prdId)
                .bind("clientId", dbParams.getClientId())
                .bind("orgId", dbParams.getOrgId())
                .execute();
    }

    private void removeWorkItem(Handle handle) {
        String deleteQuery = "DELETE FROM rpro_rtp_wi_header WHERE rc_id = :rcId";
        handle.createUpdate(deleteQuery)
                .bind("rcId", nettingTestVariables.rcId1)
                .execute();

        deleteQuery = "DELETE FROM rpro_rtp_wi_header WHERE rc_id = :rcId";
        handle.createUpdate(deleteQuery)
                .bind("rcId", nettingTestVariables.rcId1)
                .execute();
    }

    private void waitForWorkflowComplete(WorkflowExecutionEntity wfe) {
        with().pollInterval(Duration.ofMillis(500)).and().with().pollDelay(100, TimeUnit.MILLISECONDS).await("Workflow complete")
                .atMost(100000_000, TimeUnit.MINUTES)
                .until(workflowComplete(wfe));
    }

    private Callable<Boolean> workflowComplete(WorkflowExecutionEntity wfe) {
        return new Callable<Boolean>() {
            public Boolean call() throws Exception {
                WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
                WorkflowExecutionStatus currentStatus = info.getStatus();
                if (currentStatus == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_RUNNING) {
                    return false;
                }
                return true;
            }
        };
    }

}
