package com.zuora.neo.engine.jobs.rtp;

public class RtpTestConstants {

    public static final String INSERT_LOCK_RECORD = "INSERT INTO RPRO_LOCK_ACT "
            +   "(object_id,object_type,description,crtd_dt,client_id,sec_atr_val,crtd_prd_id,request_id,request_env)"
            +   " VALUES (:objectId, :objectType, :description, SYSDATE, 1, :orgId, 201701, 10439, 'REVPRO')";

    public static final String REMOVE_LOCK_RECORD = "DELETE FROM RPRO_LOCK_ACT "
            +   "WHERE object_id = :objectId AND object_type = :objectType AND CLIENT_ID = 1 AND sec_atr_val = :orgId";

    public static final String INSERT_HEADER_RECORD = "INSERT INTO RPRO_RTP_WI_HEADER "
            +   "(ID,RC_ID,PRD_ID,BOOK_ID,SEC_ATR_VAL,CLIENT_ID,WF_ID,STATUS,CRTD_BY,UPDT_BY,CRTD_DT,UPDT_DT) "
            +   "VALUES (:headerId,:rcId,:prdId,:bookId,:orgId,:clientId,:wfId,:status,:user,:user,SYSDATE,SYSDATE)";

}
