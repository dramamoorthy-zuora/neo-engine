package com.zuora.neo.engine.jobs.sfc;

import static org.awaitility.Awaitility.with;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.jobs.sfc.constants.SfcStatus;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;
import com.zuora.neo.engine.test.BaseIntegrationTest;
import com.zuora.neo.engine.test.config.IntegrationTestConfig;
import com.zuora.neo.engine.test.config.TestDbParams;
import com.zuora.neo.engine.test.db.common.DbTestContext;
import com.zuora.neo.engine.api.WorkflowExecutionEntity;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.JobsMetadata;

import io.temporal.api.enums.v1.WorkflowExecutionStatus;
import io.temporal.api.workflow.v1.WorkflowExecutionInfo;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.PreparedBatch;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class SfcIT extends BaseIntegrationTest {

    private static final Logger logger = LoggerFactory.getLogger(SfcIT.class);

    private SfcTestVariables sfcTestVariables = null;

    private static class SfcTestVariables {

        boolean rcHeadDetailsInserted;
        String docLineId;
        String docNum;
        long rcId;
        long pobId;
        long lineId;
        long vcTypeId;
        long financeTypeId;
        boolean rcLineDetailsInserted;
        boolean sfcStatusValuesInserted;
        boolean sfcPaymentDetailsInserted;
        boolean rcPobValuesInserted;
        boolean pobTmplValuesInserted;
        boolean rcPobActValuesInserted;
        boolean financeTypeValuesInserted;
        boolean vcTypeValuesInserted;
        boolean pobVcLineValuesInserted;
        boolean rcLinePaDataInserted;
        boolean sfcRcSchdDetailsInserted;
        boolean sfcCalcDetailsInserted;
    }

    @Test
    public void sfcHappyFlow() throws IOException {
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SFC.getId(), 1234, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(), dbParams.getRoleId(), "GAAP~0");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
    }

    @Test
    public void sfcWithData() throws IOException, ParseException {

        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        logger.info("JDBI Connection {}", jdbi);
        jdbi.useHandle(handle -> {
            String docLineId = "AB";
            String docNum = "NEO_SFC_TEST_DOC_1";
            docLineId = docLineId.concat("_NEO_SFC_TEST_1");
            this.sfcTestVariables.docLineId = docLineId;
            this.sfcTestVariables.docNum = docNum;
            long financeTypeId = getFinanceTypeIdFromFinanceTable(jdbi);
            this.sfcTestVariables.financeTypeId = financeTypeId;
            insertSfcStatusValues(handle, docLineId, docNum);
            insertSfcPaymentDetailsValues(handle, docLineId);
            insertRcLineDetailsValues(handle, docLineId, docNum);
            insertRcHeadDetails(handle);
            insertRcPobValues(handle);
            insertPobTmplValues(handle);
            insertRcPobActValues(handle);
            insertPobVcLineValues(handle, financeTypeId);
            this.sfcTestVariables.rcLinePaDataInserted = true;
            this.sfcTestVariables.sfcRcSchdDetailsInserted = true;
            this.sfcTestVariables.sfcCalcDetailsInserted = true;
        });


        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SFC.getId(), 12345, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), "GAAP~0");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
        assertNotNull("NPV Amount is null in SFC Status Table", getNpvAmountFromSfcStatusTable(jdbi, dbParams, sfcTestVariables.docLineId));
        assertEquals("Principle Amount Value is not Equal", BigDecimal.valueOf(394247.62), getPrincipleAmountForRcLine(jdbi));
    }

    @Test
    public void sfcWithMultipleIds() throws IOException, ParseException {

        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        logger.info("JDBI Connection {}", jdbi);
        jdbi.useHandle(handle -> {
            long financeTypeId = getFinanceTypeIdFromFinanceTable(jdbi);
            this.sfcTestVariables.financeTypeId = financeTypeId;
            insertDataMultipleSfcDocLineIds(handle, financeTypeId);
        });


        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SFC.getId(), 12345, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(), dbParams.getRoleId(), "GAAP~0");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);

    }

    @Test
    public void sfcWithPrincipleAmtBySellPrice() throws IOException, ParseException {

        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        logger.info("JDBI Connection {}", jdbi);
        jdbi.useHandle(handle -> {
            String docLineId = "AB";
            String docNum = "NEO_SFC_TEST_DOC_1";
            docLineId = docLineId.concat("_NEO_SFC_TEST_1");
            this.sfcTestVariables.docLineId = docLineId;
            this.sfcTestVariables.docNum = docNum;
            long financeTypeId = getFinanceTypeIdFromFinanceTable(jdbi);
            this.sfcTestVariables.financeTypeId = financeTypeId;
            insertSfcStatusValues(handle, docLineId, docNum);
            insertSfcPaymentDetailsValues(handle, docLineId);
            insertRcLineDetailsValues(handle, docLineId, docNum);
            insertRcHeadDetails(handle);
            insertRcPobValues(handle);
            insertPobTmplValues(handle);
            insertRcPobActValues(handle);
            insertPobVcLineValues(handle, financeTypeId);
            this.sfcTestVariables.rcLinePaDataInserted = true;
            this.sfcTestVariables.sfcRcSchdDetailsInserted = true;
            this.sfcTestVariables.sfcCalcDetailsInserted = true;
        });


        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SFC.getId(), 12345, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), "GAAP~0");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
        assertNotNull("NPV Amount is null in SFC Status Table", getNpvAmountFromSfcStatusTable(jdbi, dbParams, sfcTestVariables.docLineId));
        assertEquals("Principle Amount Value is not Equal", BigDecimal.valueOf(394247.62), getPrincipleAmountForRcLine(jdbi));
    }

    @Test
    public void sfcWithPrincipleAmtByWeightage() throws IOException, ParseException {

        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        logger.info("JDBI Connection {}", jdbi);
        jdbi.useHandle(handle -> {
            long financeTypeId = getFinanceTypeIdFromFinanceTable(jdbi);
            this.sfcTestVariables.financeTypeId = financeTypeId;
            insertMultipleLinesForPrincipleAmtWeightage(handle, financeTypeId);
        });


        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SFC.getId(), 12345, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), "GAAP~0");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertEquals("Workflow status is not complete " + info.getStatus(), info.getStatus(), WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
        assertEquals("Principle Amount Calculated is wrong", BigDecimal.valueOf(666245.5), getPrincipleAmountForRcLine(jdbi));
    }

    @Test
    public void sfcContractModificationSoUpdate() throws IOException, ParseException {

        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        logger.info("JDBI Connection {}", jdbi);
        jdbi.useHandle(handle -> {
            String docLineId = "AB";
            String docNum = "NEO_SFC_TEST_DOC_1";
            docLineId = docLineId.concat("_NEO_SFC_TEST_1");
            this.sfcTestVariables.docLineId = docLineId;
            this.sfcTestVariables.docNum = docNum;
            long financeTypeId = getFinanceTypeIdFromFinanceTable(jdbi);
            this.sfcTestVariables.financeTypeId = financeTypeId;
            this.sfcTestVariables.rcId = 11;
            this.sfcTestVariables.lineId = 12;
            long financeTypeIdFromFinTable = getFinanceTypeIdFromFinanceTable(jdbi);
            insertSfcStatusValuesSoUpdate(handle, docLineId, docNum);
            insertSfcPaymentDetailsValuesSoUpdate(handle, docLineId);
            insertRcLineDetailsValuesSoUpdate(handle, docLineId, docNum);
            insertRcHeadDetails(handle);
            insertRcPobValues(handle);
            insertPobTmplValues(handle);
            insertRcPobActValues(handle);
            insertPobVcLineValues(handle, financeTypeId);
            try {
                insertRcLinePaTableValuesSoUpdate(handle, financeTypeIdFromFinTable);
                insertRcSchedulesSoUpdate(handle);
                insertSfcCalcDetailsSoUpdate(handle);
            } catch (FileNotFoundException fileNotFoundException) {
                logger.error("File Not Found for SFC RC Schedule/Calc Table Insert");
            }
        });


        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SFC.getId(), 12345, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), "GAAP~0");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
        assertEquals("Sfc Status must be Completed", SfcStatus.COMPLETED.getStatus(), getSfcStatusForDocLineId(jdbi, sfcTestVariables.docLineId));
    }

    @Test
    public void sfcContractModificationRipLine() throws IOException, ParseException {

        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        logger.info("JDBI Connection {}", jdbi);
        jdbi.useHandle(handle -> {
            String docLineId = "AB";
            String docNum = "NEO_SFC_TEST_DOC_1";
            docLineId = docLineId.concat("_NEO_SFC_TEST_1");
            this.sfcTestVariables.docLineId = docLineId;
            this.sfcTestVariables.docNum = docNum;
            long financeTypeId = getFinanceTypeIdFromFinanceTable(jdbi);
            this.sfcTestVariables.financeTypeId = financeTypeId;
            this.sfcTestVariables.rcId = 11;
            this.sfcTestVariables.lineId = 12;
            long financeTypeIdFromFinTable = getFinanceTypeIdFromFinanceTable(jdbi);
            insertSfcStatusValuesRipLine(handle, docLineId, docNum);
            insertSfcPaymentDetailsValuesRipLine(handle, docLineId);
            insertRcLineDetailsValuesRipLine(handle, docLineId, docNum);
            insertRcHeadDetails(handle);
            insertRcPobValues(handle);
            insertPobTmplValues(handle);
            insertRcPobActValues(handle);
            insertPobVcLineValues(handle, financeTypeId);
            try {
                insertRcLinePaTableValuesRipLine(handle, financeTypeIdFromFinTable);
                insertRcSchedulesRipLine(handle);
                insertSfcCalcDetailsRipLine(handle);
            } catch (FileNotFoundException fileNotFoundException) {
                logger.error("File Not Found for SFC RC Schedule/Calc Table Insert");
            }
        });


        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SFC.getId(), 12345, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), "GAAP~0");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
        assertEquals("Sfc Status must be Completed", SfcStatus.COMPLETED.getStatus(), getSfcStatusForDocLineId(jdbi, sfcTestVariables.docLineId));
    }

    @Test
    public void sfcContractModificationPaymentUpdate() throws IOException, ParseException {

        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        Jdbi jdbi = DbTestContext.getConnection();
        logger.info("JDBI Connection {}", jdbi);
        jdbi.useHandle(handle -> {
            String docLineId = "AB";
            String docNum = "NEO_SFC_TEST_DOC_1";
            docLineId = docLineId.concat("_NEO_SFC_TEST_1");
            this.sfcTestVariables.docLineId = docLineId;
            this.sfcTestVariables.docNum = docNum;
            long financeTypeId = getFinanceTypeIdFromFinanceTable(jdbi);
            this.sfcTestVariables.financeTypeId = financeTypeId;
            this.sfcTestVariables.rcId = 11;
            this.sfcTestVariables.lineId = 12;
            long financeTypeIdFromFinTable = getFinanceTypeIdFromFinanceTable(jdbi);
            insertSfcStatusValuesPaymentUpdate(handle, docLineId, docNum);
            insertSfcPaymentDetailsValuesPaymentUpdate(handle, docLineId);
            insertRcLineDetailsValuesPaymentUpdate(handle, docLineId, docNum);
            insertRcHeadDetails(handle);
            insertRcPobValues(handle);
            insertPobTmplValues(handle);
            insertRcPobActValues(handle);
            insertPobVcLineValues(handle, financeTypeId);
            try {
                insertRcLinePaTableValuesPaymentUpdate(handle, financeTypeIdFromFinTable);
                insertRcSchedulesPaymentUpdate(handle);
                insertSfcCalcDetailsPaymentUpdate(handle);
            } catch (FileNotFoundException fileNotFoundException) {
                logger.error("File Not Found for SFC RC Schedule/Calc Table Insert");
            }
        });


        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SFC.getId(), 12345, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), "GAAP~0");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
        assertEquals("Sfc Status must be Completed", SfcStatus.COMPLETED.getStatus(), getSfcStatusForDocLineId(jdbi, sfcTestVariables.docLineId));
    }

    private void insertDataMultipleSfcDocLineIds(Handle handle, long financeTypeId) throws ParseException {

        long sfcId = 11;
        String status = "Ready for SFC";
        long rcId = 11;
        long lineId = 12;
        long rcPobId = 17;
        long pobId = 15;
        long pobVcId = 21;
        long crtdPrdId = 202202;
        String rcPobName = "NEO_TEST_RC_POB_";
        String pobTmplName = "POB_INT_TEST_SFC_";
        String pobVersion = "1";
        BigDecimal relPct = new BigDecimal(100);
        BigDecimal extSllPrc = new BigDecimal(394247.62);
        BigDecimal defAmt = new BigDecimal(394247.62);
        BigDecimal recAmt = new BigDecimal(0);
        BigDecimal npvInterestRate = new BigDecimal(7.48);
        String curr = "USD";
        String sfcIndicators = "NNNNNNNNNNNNNNNNNNNN";
        String rcPobIndicators = "SNNNNNNNNRNNNNNNNNNN";
        String docNum = "NEO_SFC_TEST_DOC_1";

        this.sfcTestVariables.rcId = rcId;
        this.sfcTestVariables.pobId = pobId;
        this.sfcTestVariables.docNum = docNum;

        PreparedBatch sfcStatusValuesBatch = handle.prepareBatch(SfcTestConstants.INSERT_SFC_STATUS_VALUES_MULTIPLE);
        PreparedBatch rcLineDetailsBatch = handle.prepareBatch(SfcTestConstants.INSERT_RC_LINE_MULTIPLE);
        PreparedBatch rcHeadDetailsBatch = handle.prepareBatch(SfcTestConstants.INSERT_RC_HEAD_DETAILS_MULTIPLE);
        PreparedBatch rcPobValuesBatch = handle.prepareBatch(SfcTestConstants.INSERT_RC_POB_VALUES_MULTIPLE);
        PreparedBatch pobTmplValuesBatch = handle.prepareBatch(SfcTestConstants.INSERT_POB_TMPL_VALUES_MULTIPLE);
        PreparedBatch rcPobActValuesBatch = handle.prepareBatch(SfcTestConstants.INSERT_RC_POB_ACT_VALUES_MULTIPLE);

        for(int i=0;i<5;i++) {
            String docLineId = "NEO_SFC_TEST_" + sfcId + i;
            bindSfcStatusValues(sfcStatusValuesBatch, sfcId+i, status, docLineId, rcId, lineId, crtdPrdId, sfcIndicators, docNum);
            bindRcLineDetailsValues(rcLineDetailsBatch, lineId+i, rcId+i, docLineId, extSllPrc, extSllPrc, recAmt, defAmt,
                    relPct, npvInterestRate, curr, rcPobId+i, docNum);
            bindRcHeadDetails(rcHeadDetailsBatch, rcId+i);
            bindRcPobValues(rcPobValuesBatch, rcPobId+i, rcPobName+i, pobId+i,
            pobVersion, rcId+i, pobId+i, rcPobId+i, rcPobIndicators);
            bindPobTmplValues(pobTmplValuesBatch, pobId+i, pobVersion, pobTmplName+i);
            bindRcPobActValues(rcPobActValuesBatch, pobId+i, rcId+i, rcPobId+i, 1);
            insertPobVcLineValuesMultiple(handle, financeTypeId, pobId+i, pobVcId+i);
            insertSfcPaymentDetailsValues(handle, docLineId);
        }
        sfcStatusValuesBatch.execute();
        rcLineDetailsBatch.execute();
        rcHeadDetailsBatch.execute();
        rcPobValuesBatch.execute();
        pobTmplValuesBatch.execute();
        rcPobActValuesBatch.execute();

        this.sfcTestVariables.sfcStatusValuesInserted = true;
        this.sfcTestVariables.rcLineDetailsInserted = true;
        this.sfcTestVariables.rcHeadDetailsInserted = true;
        this.sfcTestVariables.rcPobValuesInserted = true;
        this.sfcTestVariables.pobTmplValuesInserted = true;
        this.sfcTestVariables.rcPobActValuesInserted = true;
        this.sfcTestVariables.pobVcLineValuesInserted = true;
        this.sfcTestVariables.rcLinePaDataInserted = true;
    }

    private void insertMultipleLinesForPrincipleAmtWeightage(Handle handle, long financeTypeId) throws ParseException {

        long sfcId = 11;
        String status = "Ready for SFC";
        long rcId = 11;
        long lineId = 12;
        long rcPobId = 17;
        long pobId = 15;
        long crtdPrdId = 202202;
        String rcPobName = "NEO_TEST_RC_POB_";
        String pobTmplName = "POB_INT_TEST_SFC_";
        String pobVersion = "1";
        BigDecimal relPct = new BigDecimal(100);
        BigDecimal defAmt = new BigDecimal(394247.62);
        BigDecimal recAmt = new BigDecimal(979381);
        BigDecimal npvInterestRate = new BigDecimal(4.19);
        String curr = "USD";
        String sfcIndicators = "NNNNNNNNNNNNNNNNNNNN";
        String rcPobIndicators = "SNNNNNNNNRNNNNNNNNNN";
        String docNum = "NEO_SFC_TEST_DOC_1";
        String docLineId = "NEO_SFC_TEST_1";

        this.sfcTestVariables.rcId = rcId;
        this.sfcTestVariables.pobId = pobId;
        this.sfcTestVariables.docNum = docNum;
        this.sfcTestVariables.docLineId = docLineId+0;

        PreparedBatch sfcStatusValuesBatch = handle.prepareBatch(SfcTestConstants.INSERT_SFC_STATUS_VALUES_MULTIPLE);
        bindSfcStatusValues(sfcStatusValuesBatch, sfcId, status, docLineId+0, rcId, lineId, crtdPrdId, sfcIndicators, docNum);

        PreparedBatch rcLineDetailsBatch = handle.prepareBatch(SfcTestConstants.INSERT_RC_LINE_MULTIPLE);
        bindRcLineDetailsValues(rcLineDetailsBatch, lineId+1, rcId, docLineId+1, BigDecimal.valueOf(979381), null, BigDecimal.valueOf(979381), defAmt,
                relPct, null, curr, rcPobId+1, docNum);
        bindRcLineDetailsValues(rcLineDetailsBatch, lineId, rcId, docLineId+0, BigDecimal.valueOf(0.0), BigDecimal.valueOf(888555), recAmt, defAmt,
                relPct, npvInterestRate, curr, rcPobId, docNum);
        bindRcLineDetailsValues(rcLineDetailsBatch, lineId+2, rcId, docLineId+2, BigDecimal.valueOf(0.0), BigDecimal.valueOf(142169), recAmt, defAmt,
                relPct, null, curr, rcPobId+2, docNum);
        bindRcLineDetailsValues(rcLineDetailsBatch, lineId+3, rcId, docLineId+3, BigDecimal.valueOf(0.0), BigDecimal.valueOf(142169), recAmt, defAmt,
                relPct, null, curr, rcPobId+3, docNum);
        bindRcLineDetailsValues(rcLineDetailsBatch, lineId+4, rcId, docLineId+4, BigDecimal.valueOf(0.0), BigDecimal.valueOf(133283), recAmt, defAmt,
                relPct, null, curr, rcPobId+4, docNum);

        PreparedBatch rcHeadDetailsBatch = handle.prepareBatch(SfcTestConstants.INSERT_RC_HEAD_DETAILS_MULTIPLE);
        bindRcHeadDetails(rcHeadDetailsBatch, rcId);

        PreparedBatch pobTmplValuesBatch = handle.prepareBatch(SfcTestConstants.INSERT_POB_TMPL_VALUES_MULTIPLE);

        PreparedBatch rcPobValuesBatch = handle.prepareBatch(SfcTestConstants.INSERT_RC_POB_VALUES_MULTIPLE);
        PreparedBatch rcPobActValuesBatch = handle.prepareBatch(SfcTestConstants.INSERT_RC_POB_ACT_VALUES_MULTIPLE);
        for(int i=0;i<5;i++) {
            bindRcPobValues(rcPobValuesBatch, rcPobId+i, rcPobName+i, pobId+i,
                    pobVersion, rcId, pobId+i, rcPobId+i, rcPobIndicators);
            bindRcPobActValues(rcPobActValuesBatch, pobId+i, rcId, rcPobId+i, 1);
            bindPobTmplValues(pobTmplValuesBatch, pobId+i, pobVersion, pobTmplName+i);
        }

        insertSfcPaymentDetailsValues(handle, docLineId+0);
        insertPobVcLineValues(handle, financeTypeId);

        sfcStatusValuesBatch.execute();
        rcLineDetailsBatch.execute();
        rcHeadDetailsBatch.execute();
        rcPobValuesBatch.execute();
        pobTmplValuesBatch.execute();
        rcPobActValuesBatch.execute();

        this.sfcTestVariables.sfcStatusValuesInserted = true;
        this.sfcTestVariables.rcLineDetailsInserted = true;
        this.sfcTestVariables.rcHeadDetailsInserted = true;
        this.sfcTestVariables.rcPobValuesInserted = true;
        this.sfcTestVariables.pobTmplValuesInserted = true;
        this.sfcTestVariables.rcPobActValuesInserted = true;
        this.sfcTestVariables.pobVcLineValuesInserted = true;
    }

    private void insertRcHeadDetails(Handle handle) {
        handle.createUpdate(SfcTestConstants.INSERT_RC_HEAD_DETAILS).execute();
        this.sfcTestVariables.rcId = 11;
        this.sfcTestVariables.rcHeadDetailsInserted = true;
    }

    private void bindRcHeadDetails(PreparedBatch batch, long id) {
        batch.bind("id", id).add();
    }

    private void insertRcLineDetailsValues(Handle handle, String docLineId, String docNum) {
        handle.createUpdate(SfcTestConstants.INSERT_RC_LINE)
                .bind("docLineId", docLineId)
                .bind("docNum", docNum)
                .execute();
        this.sfcTestVariables.rcLineDetailsInserted = true;
    }

    private void insertRcLineDetailsValuesSoUpdate(Handle handle, String docLineId, String docNum) {
        handle.createUpdate(SfcTestConstants.INSERT_RC_LINE_SO_UPDATE)
                .bind("docLineId", docLineId)
                .bind("docNum", docNum)
                .bind("principleAmt", BigDecimal.valueOf(1111669.85))
                .execute();
        this.sfcTestVariables.rcLineDetailsInserted = true;
    }

    private void insertRcLineDetailsValuesRipLine(Handle handle, String docLineId, String docNum) {
        handle.createUpdate(SfcTestConstants.INSERT_RC_LINE_RIP_LINE)
                .bind("docLineId", docLineId)
                .bind("docNum", docNum)
                .bind("principleAmt", BigDecimal.valueOf(2976451.24))
                .execute();
        this.sfcTestVariables.rcLineDetailsInserted = true;
    }

    private void insertRcLineDetailsValuesPaymentUpdate(Handle handle, String docLineId, String docNum) {
        handle.createUpdate(SfcTestConstants.INSERT_RC_LINE_PAYMENT_UPDATE)
                .bind("docLineId", docLineId)
                .bind("docNum", docNum)
                .bind("principleAmt", BigDecimal.valueOf(2976451.24))
                .execute();
        this.sfcTestVariables.rcLineDetailsInserted = true;
    }

    private void bindRcLineDetailsValues(PreparedBatch batch, long id, long rcId, String docLineId, BigDecimal extSllPrc, BigDecimal extFvPrc, BigDecimal recAmt, BigDecimal defAmt,
            BigDecimal relPct, BigDecimal npvInterestRate, String curr, long rcPobId, String docNum) {
        batch.bind("id", id)
                .bind("rcId", rcId)
                .bind("docLineId", docLineId)
                .bind("extSllPrc", extSllPrc)
                .bind("extFvPrc", extFvPrc)
                .bind("recAmt", recAmt)
                .bind("defAmt", defAmt)
                .bind("relPct", relPct)
                .bind("npvInterestRate", npvInterestRate)
                .bind("curr", curr)
                .bind("rcPobId", rcPobId)
                .bind("docNum", docNum)
                .add();
    }

    private void insertSfcPaymentDetailsValues(Handle handle, String docLineId) throws ParseException {

        PreparedBatch batch = handle.prepareBatch(SfcTestConstants.INSERT_SFC_PAYMENT_DETAILS);
        List<SfcPaymentDetails> sfcPaymentDetails = new ArrayList<>();
        Integer id = ThreadLocalRandom.current().nextInt();

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"),
        docLineId, BigDecimal.valueOf(127551.02), null, null,
        new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"), new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2022")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2022"),
                docLineId, BigDecimal.valueOf(131377.55), null, null,
                new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2022"), new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2023")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id, new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2023"),
                docLineId, BigDecimal.valueOf(135319.05), null, null,
                new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2023"), new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2023")));

        for(SfcPaymentDetails sfcPaymentDetail : sfcPaymentDetails){
            batch.bind("id", sfcPaymentDetail.getId())
                    .bind("paymtDate", sfcPaymentDetail.getPaymtDate())
                    .bind("paymtAmount", sfcPaymentDetail.getPaymtAmt())
                    .bind("docLineId", sfcPaymentDetail.getDocLineId())
                    .bind("paymtStartDate", sfcPaymentDetail.getPaymtStartDate())
                    .bind("paymtEndDate", sfcPaymentDetail.getPaymtEndDate())
                    .bind("clientId", 1)
                    .bind("secAtrVal", "0").add();
        }
        batch.execute();
        this.sfcTestVariables.sfcPaymentDetailsInserted = true;

    }

    private void insertSfcPaymentDetailsValuesSoUpdate(Handle handle, String docLineId) throws ParseException {

        PreparedBatch batch = handle.prepareBatch(SfcTestConstants.INSERT_SFC_PAYMENT_DETAILS_SO_UPDATE);
        List<SfcPaymentDetails> sfcPaymentDetails = new ArrayList<>();
        Integer id = ThreadLocalRandom.current().nextInt();

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2019"),
                docLineId, BigDecimal.valueOf(171861.46), BigDecimal.valueOf(171861.46), BigDecimal.valueOf(0),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2019"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2020")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2020"),
                docLineId, BigDecimal.valueOf(177017.16), BigDecimal.valueOf(168126), BigDecimal.valueOf(8891.16),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2020"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2021")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2021"),
                docLineId, BigDecimal.valueOf(182327.69), BigDecimal.valueOf(164483.92), BigDecimal.valueOf(17843.77),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2021"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2022")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2022"),
                docLineId, BigDecimal.valueOf(187797.67), BigDecimal.valueOf(160914.96), BigDecimal.valueOf(26882.71),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2022"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2023")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2023"),
                docLineId, BigDecimal.valueOf(193431.55), BigDecimal.valueOf(157423.28), BigDecimal.valueOf(36008.27),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2023"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2024")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2024"),
                docLineId, BigDecimal.valueOf(199234.32), BigDecimal.valueOf(154001.62), BigDecimal.valueOf(45232.7),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2024"), new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2024")));

        for(SfcPaymentDetails sfcPaymentDetail : sfcPaymentDetails){
            batch.bind("id", sfcPaymentDetail.getId())
                    .bind("paymtDate", sfcPaymentDetail.getPaymtDate())
                    .bind("paymtAmount", sfcPaymentDetail.getPaymtAmt())
                    .bind("docLineId", sfcPaymentDetail.getDocLineId())
                    .bind("paymtStartDate", sfcPaymentDetail.getPaymtStartDate())
                    .bind("paymtEndDate", sfcPaymentDetail.getPaymtEndDate())
                    .bind("netPaymtValue", sfcPaymentDetail.getNetPaymtAmt())
                    .bind("interestAccrual", sfcPaymentDetail.getInterestAccrual())
                    .bind("clientId", 1)
                    .bind("secAtrVal", "0").add();
        }
        batch.execute();
        this.sfcTestVariables.sfcPaymentDetailsInserted = true;

    }

    private void insertSfcPaymentDetailsValuesRipLine(Handle handle, String docLineId) throws ParseException {

        PreparedBatch batch = handle.prepareBatch(SfcTestConstants.INSERT_SFC_PAYMENT_DETAILS_SO_UPDATE);
        List<SfcPaymentDetails> sfcPaymentDetails = new ArrayList<>();
        Integer id = ThreadLocalRandom.current().nextInt();

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2018"),
                docLineId, BigDecimal.valueOf(460152.14), BigDecimal.valueOf(460152.14), BigDecimal.valueOf(0),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2018"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2019")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2019"),
                docLineId, BigDecimal.valueOf(473956.31), BigDecimal.valueOf(450167.07), BigDecimal.valueOf(23789.24),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2019"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2020")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2020"),
                docLineId, BigDecimal.valueOf(488175.04), BigDecimal.valueOf(440382.94), BigDecimal.valueOf(47792.1),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2020"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2021")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2021"),
                docLineId, BigDecimal.valueOf(502820.7), BigDecimal.valueOf(430843.34), BigDecimal.valueOf(71977.36),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2021"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2022")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2022"),
                docLineId, BigDecimal.valueOf(517905.18), BigDecimal.valueOf(421494.49), BigDecimal.valueOf(96410.69),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2022"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2023")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2023"),
                docLineId, BigDecimal.valueOf(533441.87), BigDecimal.valueOf(412348.25), BigDecimal.valueOf(121093.62),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2023"), new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2023")));

        for(SfcPaymentDetails sfcPaymentDetail : sfcPaymentDetails){
            batch.bind("id", sfcPaymentDetail.getId())
                    .bind("paymtDate", sfcPaymentDetail.getPaymtDate())
                    .bind("paymtAmount", sfcPaymentDetail.getPaymtAmt())
                    .bind("docLineId", sfcPaymentDetail.getDocLineId())
                    .bind("paymtStartDate", sfcPaymentDetail.getPaymtStartDate())
                    .bind("paymtEndDate", sfcPaymentDetail.getPaymtEndDate())
                    .bind("netPaymtValue", sfcPaymentDetail.getNetPaymtAmt())
                    .bind("interestAccrual", sfcPaymentDetail.getInterestAccrual())
                    .bind("clientId", 1)
                    .bind("secAtrVal", "0").add();
        }
        batch.execute();
        this.sfcTestVariables.sfcPaymentDetailsInserted = true;

    }

    private void insertSfcPaymentDetailsValuesPaymentUpdate(Handle handle, String docLineId) throws ParseException {

        PreparedBatch batch = handle.prepareBatch(SfcTestConstants.INSERT_SFC_PAYMENT_DETAILS_SO_UPDATE);
        List<SfcPaymentDetails> sfcPaymentDetails = new ArrayList<>();
        Integer id = ThreadLocalRandom.current().nextInt();

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2019"),
                docLineId, BigDecimal.valueOf(460152.14), BigDecimal.valueOf(460152.14), BigDecimal.valueOf(0),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2019"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2020")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2020"),
                docLineId, BigDecimal.valueOf(473956.31), BigDecimal.valueOf(450167.07), BigDecimal.valueOf(23789.24),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2020"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2021")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2021"),
                docLineId, BigDecimal.valueOf(488175.04), BigDecimal.valueOf(440382.94), BigDecimal.valueOf(47792.1),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2021"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2022")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2022"),
                docLineId, BigDecimal.valueOf(502820.7), BigDecimal.valueOf(430843.34), BigDecimal.valueOf(71977.36),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2022"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2023")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2023"),
                docLineId, BigDecimal.valueOf(517905.18), BigDecimal.valueOf(421494.49), BigDecimal.valueOf(96410.69),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2023"), new SimpleDateFormat("dd/MM/yyyy").parse("27/09/2024")));

        sfcPaymentDetails.add(new SfcPaymentDetails(id++, new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2024"),
                docLineId, BigDecimal.valueOf(533441.87), BigDecimal.valueOf(412348.25), BigDecimal.valueOf(121093.62),
                new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2024"), new SimpleDateFormat("dd/MM/yyyy").parse("28/09/2024")));

        for(SfcPaymentDetails sfcPaymentDetail : sfcPaymentDetails){
            batch.bind("id", sfcPaymentDetail.getId())
                    .bind("paymtDate", sfcPaymentDetail.getPaymtDate())
                    .bind("paymtAmount", sfcPaymentDetail.getPaymtAmt())
                    .bind("docLineId", sfcPaymentDetail.getDocLineId())
                    .bind("paymtStartDate", sfcPaymentDetail.getPaymtStartDate())
                    .bind("paymtEndDate", sfcPaymentDetail.getPaymtEndDate())
                    .bind("netPaymtValue", sfcPaymentDetail.getNetPaymtAmt())
                    .bind("interestAccrual", sfcPaymentDetail.getInterestAccrual())
                    .bind("clientId", 1)
                    .bind("secAtrVal", "0").add();
        }
        batch.execute();
        this.sfcTestVariables.sfcPaymentDetailsInserted = true;

    }

    private void insertSfcStatusValues(Handle handle, String docLineId, String docNum) {
        handle.createUpdate(SfcTestConstants.INSERT_SFC_STATUS_VALUES)
                .bind("docLineId", docLineId)
                .bind("docNum", docNum)
                .execute();
        this.sfcTestVariables.sfcStatusValuesInserted = true;
    }

    private void insertSfcStatusValuesSoUpdate(Handle handle, String docLineId, String docNum) {
        handle.createUpdate(SfcTestConstants.INSERT_SFC_STATUS_VALUES_SO)
                .bind("docLineId", docLineId)
                .bind("docNum", docNum)
                .execute();
        this.sfcTestVariables.sfcStatusValuesInserted = true;
    }

    private void insertSfcStatusValuesRipLine(Handle handle, String docLineId, String docNum) {
        handle.createUpdate(SfcTestConstants.INSERT_SFC_STATUS_VALUES_RIP_LINE)
                .bind("docLineId", docLineId)
                .bind("docNum", docNum)
                .execute();
        this.sfcTestVariables.sfcStatusValuesInserted = true;
    }

    private void insertSfcStatusValuesPaymentUpdate(Handle handle, String docLineId, String docNum) {
        handle.createUpdate(SfcTestConstants.INSERT_SFC_STATUS_VALUES_PAYMENT_UPDATE)
                .bind("docLineId", docLineId)
                .bind("docNum", docNum)
                .execute();
        this.sfcTestVariables.sfcStatusValuesInserted = true;
    }

    private void bindSfcStatusValues(PreparedBatch batch, long id, String status, String docLineId, long rcId, long lineId, long crtdPrdId, String indicators, String docNum) {
        batch.bind("docLineId", docLineId)
                .bind("status", status)
                .bind("id", id)
                .bind("rcId", rcId)
                .bind("lineId", lineId)
                .bind("crtdPrdId", crtdPrdId)
                .bind("indicators", indicators)
                .bind("docNum", docNum)
                .add();
    }

    private void insertRcPobValues(Handle handle) {
        handle.createUpdate(SfcTestConstants.INSERT_RC_POB_VALUES)
                .execute();
        this.sfcTestVariables.rcPobValuesInserted = true;
        this.sfcTestVariables.pobId = 15;
    }

    private void bindRcPobValues(PreparedBatch batch, long id, String name, long pobId,
            String pobVersion, long rcId, long condId, long leadLineId, String indicators) {
        batch.bind("id", id)
                .bind("name", name)
                .bind("pobId", pobId)
                .bind("pobVersion", pobVersion)
                .bind("rcId", rcId)
                .bind("condId", condId)
                .bind("leadLineId", leadLineId)
                .bind("indicators", indicators)
                .add();
    }

    private void insertPobTmplValues(Handle handle) {
        handle.createUpdate(SfcTestConstants.INSERT_POB_TMPL_VALUES)
                .execute();
        this.sfcTestVariables.pobTmplValuesInserted = true;
    }

    private void bindPobTmplValues(PreparedBatch batch, long id, String version, String name) {
        batch.bind("id", id)
                .bind("version", version)
                .bind("name", name)
                .add();
    }

    private void insertRcPobActValues(Handle handle) {
        handle.createUpdate(SfcTestConstants.INSERT_RC_POB_ACT_VALUES)
                .execute();
        this.sfcTestVariables.rcPobActValuesInserted = true;
    }

    private void bindRcPobActValues(PreparedBatch batch, long relId, long rcId, long rcPobId, long eventId) {
        batch.bind("relId", relId)
                .bind("rcId", rcId)
                .bind("rcPobId", rcPobId)
                .bind("eventId", eventId)
                .add();
    }

    private void insertFinanceTypeValues(Handle handle, String weightageColumn, String indicators) {
        handle.createUpdate(SfcTestConstants.INSERT_FINANCE_TYPE_VALUES)
                .bind("weightageColumn", weightageColumn)
                .bind("indicators", indicators)
                .execute();
        this.sfcTestVariables.financeTypeValuesInserted = true;
    }

    private void insertVcTypeValues(Handle handle) {
        handle.createUpdate(SfcTestConstants.INSERT_VC_TYPE_VALUES)
                .execute();
        this.sfcTestVariables.vcTypeValuesInserted = true;
    }

    private void insertPobVcLineValues(Handle handle, long financeTypeId) {
        handle.createUpdate(SfcTestConstants.INSERT_POB_VC_LINE_VALUES)
                .bind("financeTypeId", financeTypeId)
                .execute();
        this.sfcTestVariables.pobVcLineValuesInserted = true;
    }

    private void insertPobVcLineValuesMultiple(Handle handle, long financeTypeId, long pobId, long pobVcId) {
        handle.createUpdate(SfcTestConstants.INSERT_POB_VC_LINE_VALUES_MULTIPLE)
                .bind("financeTypeId", financeTypeId)
                .bind("pobId", pobId)
                .bind("pobVcId", pobVcId)
                .execute();
        this.sfcTestVariables.pobVcLineValuesInserted = true;
    }

    private void insertRcSchedulesSoUpdate(Handle handle) throws FileNotFoundException {

        String absolutePath = new File("").getAbsolutePath();
        FileReader fr = new FileReader( absolutePath
                + "/src/integration-test/java/com/zuora/neo/engine/jobs/sfc/RcScheduleSoUpdate"+".sql") ;
        BufferedReader br = new BufferedReader(fr);
        String sql = br.lines().collect(Collectors.joining());
        List<String> rcScheduleSoUpdateInsertStatements = Arrays.asList(sql.split(";"));

        for (String rcScheduleSoUpdateInsertStmt : rcScheduleSoUpdateInsertStatements) {
            handle.createUpdate(rcScheduleSoUpdateInsertStmt).execute();
        }
        this.sfcTestVariables.sfcRcSchdDetailsInserted = true;

    }

    private void insertRcSchedulesRipLine(Handle handle) throws FileNotFoundException {

        String absolutePath = new File("").getAbsolutePath();
        FileReader fr = new FileReader( absolutePath
                + "/src/integration-test/java/com/zuora/neo/engine/jobs/sfc/RcScheduleRipLine"+".sql") ;
        BufferedReader br = new BufferedReader(fr);
        String sql = br.lines().collect(Collectors.joining());
        List<String> rcScheduleSoUpdateInsertStatements = Arrays.asList(sql.split(";"));

        for (String rcScheduleSoUpdateInsertStmt : rcScheduleSoUpdateInsertStatements) {
            handle.createUpdate(rcScheduleSoUpdateInsertStmt).execute();
        }
        this.sfcTestVariables.sfcRcSchdDetailsInserted = true;

    }

    private void insertRcSchedulesPaymentUpdate(Handle handle) throws FileNotFoundException {

        String absolutePath = new File("").getAbsolutePath();
        FileReader fr = new FileReader( absolutePath
                + "/src/integration-test/java/com/zuora/neo/engine/jobs/sfc/RcSchedulePaymentUpdate"+".sql") ;
        BufferedReader br = new BufferedReader(fr);
        String sql = br.lines().collect(Collectors.joining());
        List<String> rcScheduleSoUpdateInsertStatements = Arrays.asList(sql.split(";"));

        for (String rcScheduleSoUpdateInsertStmt : rcScheduleSoUpdateInsertStatements) {
            handle.createUpdate(rcScheduleSoUpdateInsertStmt).execute();
        }
        this.sfcTestVariables.sfcRcSchdDetailsInserted = true;

    }

    private void insertRcLinePaTableValuesSoUpdate(Handle handle, long financeTypeId) throws FileNotFoundException {
        String absolutePath = new File("").getAbsolutePath();
        FileReader fr = new FileReader( absolutePath
                + "/src/integration-test/java/com/zuora/neo/engine/jobs/sfc/RcLinePaDataSoUpdate"+".sql") ;
        BufferedReader br = new BufferedReader(fr);
        String sql = br.lines().collect(Collectors.joining());
        List<String> rcLinePaDataInsertStatements = Arrays.asList(sql.split(";"));

        for (String rcLinePaDataInsertStmt : rcLinePaDataInsertStatements) {
            handle.createUpdate(rcLinePaDataInsertStmt)
            .bind("financeTypeId", financeTypeId).execute();
        }

        this.sfcTestVariables.rcLinePaDataInserted = true;
    }

    private void insertRcLinePaTableValuesRipLine(Handle handle, long financeTypeId) throws FileNotFoundException {
        String absolutePath = new File("").getAbsolutePath();
        FileReader fr = new FileReader( absolutePath
                + "/src/integration-test/java/com/zuora/neo/engine/jobs/sfc/RcLinePaDataRipLine"+".sql") ;
        BufferedReader br = new BufferedReader(fr);
        String sql = br.lines().collect(Collectors.joining());
        List<String> rcLinePaDataInsertStatements = Arrays.asList(sql.split(";"));

        for (String rcLinePaDataInsertStmt : rcLinePaDataInsertStatements) {
            handle.createUpdate(rcLinePaDataInsertStmt)
                    .bind("financeTypeId", financeTypeId).execute();
        }

        this.sfcTestVariables.rcLinePaDataInserted = true;
    }

    private void insertRcLinePaTableValuesPaymentUpdate(Handle handle, long financeTypeId) throws FileNotFoundException {
        String absolutePath = new File("").getAbsolutePath();
        FileReader fr = new FileReader( absolutePath
                + "/src/integration-test/java/com/zuora/neo/engine/jobs/sfc/RcLinePaDataPaymentUpdate"+".sql") ;
        BufferedReader br = new BufferedReader(fr);
        String sql = br.lines().collect(Collectors.joining());
        List<String> rcLinePaDataInsertStatements = Arrays.asList(sql.split(";"));

        for (String rcLinePaDataInsertStmt : rcLinePaDataInsertStatements) {
            handle.createUpdate(rcLinePaDataInsertStmt)
                    .bind("financeTypeId", financeTypeId).execute();
        }

        this.sfcTestVariables.rcLinePaDataInserted = true;
    }

    private void insertSfcCalcDetailsSoUpdate(Handle handle) throws FileNotFoundException {

        String absolutePath = new File("").getAbsolutePath();
        FileReader fr = new FileReader( absolutePath
                + "/src/integration-test/java/com/zuora/neo/engine/jobs/sfc/SfcCalcDetailsSoUpdate"+".sql") ;
        BufferedReader br = new BufferedReader(fr);
        String sql = br.lines().collect(Collectors.joining());
        List<String> sfcCalcInsertStatements = Arrays.asList(sql.split(";"));

        for (String sfcCalcInsertStmt : sfcCalcInsertStatements) {
            handle.createUpdate(sfcCalcInsertStmt).execute();
        }

        this.sfcTestVariables.sfcCalcDetailsInserted = true;
    }

    private void insertSfcCalcDetailsRipLine(Handle handle) throws FileNotFoundException {

        String absolutePath = new File("").getAbsolutePath();
        FileReader fr = new FileReader( absolutePath
                + "/src/integration-test/java/com/zuora/neo/engine/jobs/sfc/SfcCalcDetailsRipLine"+".sql") ;
        BufferedReader br = new BufferedReader(fr);
        String sql = br.lines().collect(Collectors.joining());
        List<String> sfcCalcInsertStatements = Arrays.asList(sql.split(";"));

        for (String sfcCalcInsertStmt : sfcCalcInsertStatements) {
            handle.createUpdate(sfcCalcInsertStmt).execute();
        }

        this.sfcTestVariables.sfcCalcDetailsInserted = true;
    }

    private void insertSfcCalcDetailsPaymentUpdate(Handle handle) throws FileNotFoundException {

        String absolutePath = new File("").getAbsolutePath();
        FileReader fr = new FileReader( absolutePath
                + "/src/integration-test/java/com/zuora/neo/engine/jobs/sfc/SfcCalcDetailsPaymentUpdate"+".sql") ;
        BufferedReader br = new BufferedReader(fr);
        String sql = br.lines().collect(Collectors.joining());
        List<String> sfcCalcInsertStatements = Arrays.asList(sql.split(";"));

        for (String sfcCalcInsertStmt : sfcCalcInsertStatements) {
            handle.createUpdate(sfcCalcInsertStmt).execute();
        }

        this.sfcTestVariables.sfcCalcDetailsInserted = true;
    }

    private BigDecimal getNpvAmountFromSfcStatusTable(Jdbi jdbi, TestDbParams dbParams, String docLineId){
        return jdbi.withHandle(handle -> {
            SfcDao sfcDao = handle.attach(SfcDao.class);
            List<SfcStatusValues> sfcStatusValues = sfcDao.getSfcStatusValuesByDocLineId(docLineId);
            logger.info("SFC Status Values Size after execution {}", sfcStatusValues.size());
            if(!sfcStatusValues.isEmpty()){
                logger.info("SFC Status Values NPV Value {}", sfcStatusValues.get(0).getNetNpvAmt());
                logger.info("SFC Status Value Status {}", sfcStatusValues.get(0).getStatus());
                return sfcStatusValues.get(0).getNetNpvAmt();
            }
            return null;
        });
    }

    private String getSfcStatusForDocLineId(Jdbi jdbi, String docLineId){
        return jdbi.withHandle(handle -> {
            SfcDao sfcDao = handle.attach(SfcDao.class);
            List<SfcStatusValues> sfcStatusValues = sfcDao.getSfcStatusValuesByDocLineId(docLineId);
            logger.info("SFC Status Values Size after execution {}", sfcStatusValues.size());
            if(!sfcStatusValues.isEmpty()){
                logger.info("SFC Status Value Status {}", sfcStatusValues.get(0).getStatus());
                return sfcStatusValues.get(0).getStatus();
            }
            return null;
        });
    }

    private long getFinanceTypeIdFromFinanceTable(Jdbi jdbi){
        return jdbi.withHandle(handle -> {
            SfcDao sfcDao = handle.attach(SfcDao.class);
            List<FinanceTypeValues> financeTypeValuesList = sfcDao.getFinanceTypeDetailsForSfc();
            logger.info("Finance Type Values List Size after execution {}", financeTypeValuesList.size());
            if(!financeTypeValuesList.isEmpty()){
                logger.info("Finance Type Id retrieved from DB {}", financeTypeValuesList.get(0).getId());
                return financeTypeValuesList.get(0).getId();
            }
            return null;
        });
    }

    private BigDecimal getPrincipleAmountForRcLine(Jdbi jdbi) {
        return jdbi.withHandle(handle -> {
            BigDecimal principleAmount = handle.createQuery(SfcTestConstants.RETRIEVE_PRINCIPLE_AMT_FOR_RC_LINE)
                    .bind("docLineId", sfcTestVariables.docLineId)
                    .mapTo(BigDecimal.class)
                    .findFirst().orElse(null);
            return principleAmount;
        });
    }

    private void deleteRcHeadDetails(Handle handle) {
        int deletedRows = handle.createUpdate("delete from rpro_rc_head_g where id BETWEEN :id AND :id + 5")
                .bind("id", this.sfcTestVariables.rcId)
                .execute();
        logger.info("Deleted RC Head table rows {}", deletedRows);
    }

    private void deleteRcPobDetails(Handle handle) {
        int deletedRows = handle.createUpdate("delete from rpro_rc_pob_g where rc_id BETWEEN :rcId AND :rcId + 5")
                .bind("rcId", this.sfcTestVariables.rcId)
                .execute();
        logger.info("Deleted RC POB table rows {}", deletedRows);
    }

    private void deleteRcLineDetails(Handle handle) {
        int deletedRows = handle.createUpdate("delete from rpro_rc_line_g where doc_line_id LIKE '%NEO_SFC_TEST%'")
                .execute();
        logger.info("Deleted RC Line table rows {}", deletedRows);
    }

    private void deleteSfcStatusValues(Handle handle) {
        int deletedRows = handle.createUpdate("delete from rpro_sfc_status_g where doc_line_id LIKE '%NEO_SFC_TEST%'")
                .execute();
        logger.info("Deleted SFC Status Table rows {}", deletedRows);
    }

    private void deleteSfcPaymentDetails(Handle handle) {
        int deletedRows = handle.createUpdate("delete from rpro_sfc_paymt_det_g where doc_line_id LIKE '%NEO_SFC_TEST%'")
                .execute();
        logger.info("Deleted SFC Payment Table rows {}", deletedRows);
    }

    private void deleteRcPobActValues(Handle handle) {
        int deletedRows = handle.createUpdate("delete from rpro_rc_pob_act_g where rc_id BETWEEN :rcId AND :rcId + 5")
                .bind("rcId", this.sfcTestVariables.rcId)
                .execute();
        logger.info("Deleted RC POB ACT table rows {}", deletedRows);
    }

    private void deletePobTmplValues(Handle handle) {
        int deletedRows = handle.createUpdate("delete from rpro_pob_tmpl_g where id BETWEEN :pobId AND :pobId + 5")
                .bind("pobId", this.sfcTestVariables.pobId)
                .execute();
        logger.info("Deleted POB TMPL table rows {}", deletedRows);
    }

    private void deleteFinanceTypeValues(Handle handle) {
        int deletedRows = handle.createUpdate("delete from rpro_financ_type_g where id = :financeTypeId")
                .bind("financeTypeId", this.sfcTestVariables.financeTypeId)
                .execute();
        logger.info("Deleted Finance Type table rows {}", deletedRows);
    }

    private void deleteVcTypeValues(Handle handle) {
        int deletedRows = handle.createUpdate("delete from rpro_vc_type_g where id = :vcTypeId")
                .bind("vcTypeId", this.sfcTestVariables.financeTypeId)
                .execute();
        logger.info("Deleted Vc Type table rows {}", deletedRows);
    }

    private void deletePobVcLineValues(Handle handle) {
        int deletedRows = handle.createUpdate("delete from rpro_pob_vc_line_g where id between 15 and 9999")
                .execute();
        logger.info("Deleted Vc Type table rows {}", deletedRows);
    }

    private void deleteRcLinePaData(Handle handle) {
        int deletedRows = handle.createUpdate("delete from rpro_rc_line_pa_g where line_id between 10 and 9999")
                .execute();
        logger.info("Deleted Rc Line Pa Data rows {}", deletedRows);
    }

    private void deleteRcSchdDetails(Handle handle) {
        int deletedRows = handle.createUpdate("delete from rpro_rc_schd_g where rc_id between 10 and 9999")
                .execute();
        logger.info("Deleted Rc Schd Data rows {}", deletedRows);
    }

    private void deleteSfcCalcDetails(Handle handle) {
        int deletedRows = handle.createUpdate("delete from rpro_sfc_calc_det_g where rc_id between 10 and 9999")
                .execute();
        logger.info("Deleted Sfc Calc Details rows {}", deletedRows);
    }

    @Before
    public void setup() {
        SfcTestVariables sfcTestVariables = new SfcTestVariables();
        this.sfcTestVariables = sfcTestVariables;
    }

    @After
    public void tearDown() {
        Jdbi jdbi = DbTestContext.getConnection();
        if (sfcTestVariables.rcLineDetailsInserted) {
            jdbi.useHandle(this::deleteRcLineDetails);
        }
        if (sfcTestVariables.sfcStatusValuesInserted) {
            jdbi.useHandle(this::deleteSfcStatusValues);
        }
        if (sfcTestVariables.sfcPaymentDetailsInserted) {
            jdbi.useHandle(this::deleteSfcPaymentDetails);
        }
        if (sfcTestVariables.rcHeadDetailsInserted) {
            jdbi.useHandle(this::deleteRcHeadDetails);
        }
        if (sfcTestVariables.rcPobValuesInserted) {
            jdbi.useHandle(this::deleteRcPobDetails);
        }
        if (sfcTestVariables.pobTmplValuesInserted) {
            jdbi.useHandle(this::deletePobTmplValues);
        }
        if (sfcTestVariables.rcPobActValuesInserted) {
            jdbi.useHandle(this::deleteRcPobActValues);
        }
        if (sfcTestVariables.financeTypeValuesInserted) {
            jdbi.useHandle(this::deleteFinanceTypeValues);
        }
        if (sfcTestVariables.vcTypeValuesInserted) {
            jdbi.useHandle(this::deleteVcTypeValues);
        }
        if (sfcTestVariables.pobVcLineValuesInserted) {
            jdbi.useHandle(this::deletePobVcLineValues);
        }
        if(sfcTestVariables.rcLinePaDataInserted) {
            jdbi.useHandle(this::deleteRcLinePaData);
        }
        if(sfcTestVariables.sfcRcSchdDetailsInserted) {
            jdbi.useHandle(this::deleteRcSchdDetails);
        }
        if(sfcTestVariables.sfcCalcDetailsInserted) {
            jdbi.useHandle(this::deleteSfcCalcDetails);
        }
    }

    private void waitForWorkflowComplete(WorkflowExecutionEntity wfe) {
        with().pollInterval(Duration.ofMillis(500)).and().with().pollDelay(100, TimeUnit.MILLISECONDS).await("Workflow complete")
                .atMost(20000_0000, TimeUnit.MILLISECONDS)
                .until(workflowComplete(wfe));
    }

    private Callable<Boolean> workflowComplete(WorkflowExecutionEntity wfe) {
        return new Callable<Boolean>() {
            public Boolean call() throws Exception {
                WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
                WorkflowExecutionStatus currentStatus = info.getStatus();
                if (currentStatus == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_RUNNING) {
                    return false;
                }
                return true;
            }
        };
    }
}
