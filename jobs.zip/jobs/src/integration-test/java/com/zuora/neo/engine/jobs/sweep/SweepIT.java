package com.zuora.neo.engine.jobs.sweep;

import com.zuora.neo.engine.api.WorkflowExecutionEntity;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.JobsMetadata;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.sweep.activities.SweepActivitiesImpl;
import com.zuora.neo.engine.jobs.sweep.db.api.CurrentPeriod;
import com.zuora.neo.engine.jobs.sweep.db.api.NextPeriod;
import com.zuora.neo.engine.jobs.sweep.db.dao.SweepDao;
import com.zuora.neo.engine.test.BaseIntegrationTest;
import com.zuora.neo.engine.test.config.IntegrationTestConfig;
import com.zuora.neo.engine.test.config.TestDbParams;
import com.zuora.neo.engine.test.db.common.DbTestContext;
import io.temporal.api.enums.v1.WorkflowExecutionStatus;
import io.temporal.api.failure.v1.ApplicationFailureInfo;
import io.temporal.api.history.v1.History;
import io.temporal.api.history.v1.HistoryEvent;
import io.temporal.api.history.v1.WorkflowExecutionFailedEventAttributes;
import io.temporal.api.workflow.v1.WorkflowExecutionInfo;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.PreparedBatch;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import static org.awaitility.Awaitility.with;
import static org.junit.Assert.*;

public class SweepIT extends BaseIntegrationTest {

    private static final Logger logger = LoggerFactory.getLogger(SweepIT.class);

    private SweepTestVariables sweepTestVariables = null;

    private static class SweepTestVariables {

        String atr1 = null;
        boolean scheduleInserted = false;
        long bookId;
        long rcId;

        boolean summarizationExecuted = false;

        Date today, tomorrow, dayAfterTomorrow;
    }

    /*
        Send a request to run the sweep Job
        This test will run by sending a dummy program id and avoid updates to rpro_schd_prog
        It just checks the workflow status is completed at the end
     */
    @Test
    public void sweepHappyPath() throws IOException, InterruptedException {
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SWEEP.getId(), 1234, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), "10~GAAP~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
    }

    /*
        Create sweep records in rpro_rc_schd table , get the ids of created records
        Send a request to run the sweep Job
        This test will run by sending a dummy program id and avoid updates to rpro_schd_prog
        It just checks the workflow status is completed at the end
        After the run check the records and their next period id
     */

    @Test
    public void sweepAllWithData() throws IOException, InterruptedException {
        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        long noOfRows = ThreadLocalRandom.current().nextLong(1, 5 + 1);

        AtomicLong periodId = new AtomicLong();
        Jdbi jdbi = DbTestContext.getConnection();

        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            long crtdPeriodId = commonDao.getCrtdPeriodId(null, dbParams.getOrgId());
            //assume book name GAAP always exists
            long bookId = commonDao.getBookId("GAAP", dbParams.getClientId());
            periodId.set(commonDao.getPeriodId(bookId, dbParams.getOrgId()));
            //insert records to rpro_rc_schd
            insertSchedule(handle, testConfig, periodId.get(), periodId.get(), crtdPeriodId, sweepTestVariables.atr1, bookId,
                    noOfRows, null);//pass null for RC line id
        });

        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SWEEP.getId(), 1234, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), "10~GAAP~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
        long updatedRecordCount = getUpdatedRecordCountAfterWorkflowExecution(jdbi, periodId.get(), dbParams, sweepTestVariables.atr1);
        assertEquals("Updated record count isn't matching  ",
                noOfRows, updatedRecordCount);
    }

    /*
        Create sweep records in rpro_rc_schd table ,
        Create  a record in rpro_rc_line
         get the ids of created records
        Send a request to run the sweep Job with RC ID
        This test will run by sending a dummy program id and avoid updates to rpro_schd_prog
        It just checks the workflow status is completed at the end
        After the run check the records and their next period id for the given RC id
     */

    @Test
    public void sweepWithRCFilter() throws IOException, InterruptedException {
        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        long noOfRows = ThreadLocalRandom.current().nextLong(1, 5 + 1);
        AtomicLong periodId = new AtomicLong();
        Jdbi jdbi = DbTestContext.getConnection();

        AtomicLong rcLineId = new AtomicLong();

        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            rcLineId.set(commonDao.getNextSequenceNumber("rpro_rc_line_id_s", dbParams.getClientId()));
            long crtdPeriodId = commonDao.getCrtdPeriodId(null, dbParams.getOrgId());
            //assume book name GAAP always exists
            long bookId = commonDao.getBookId("GAAP", dbParams.getClientId());
            periodId.set(commonDao.getPeriodId(bookId, dbParams.getOrgId()));
            //inserting same id as rc and rc line id is ok -
            //will allow us to pass the same id as rc and test
            insertRcLine(handle, testConfig, rcLineId.get(), rcLineId.get());
            //insert records to rpro_rc_schd
            insertSchedule(handle, testConfig, periodId.get(), periodId.get(), crtdPeriodId, sweepTestVariables.atr1, bookId,
                    noOfRows, rcLineId.get());
        });
        String paramText = "10~GAAP~" + rcLineId;

        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SWEEP.getId(), 1234, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), paramText);
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        logger.info("before waiting for workflow complete");
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
        long updatedRecordCount = getUpdatedRecordCountAfterWorkflowExecution(jdbi, periodId.get(), dbParams, sweepTestVariables.atr1);

        assertEquals("Updated record count isn't matching  ",
                noOfRows, updatedRecordCount);
    }

    /**
     * Provides a book name that doesnt exist in DB . The workflow should fail with NonRetryableActivityException
     */
    @Test
    public void sweepWithWrongBookName() throws IOException, InterruptedException {
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SWEEP.getId(), 1234, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), "10~GAAPWRONG~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status should have failed " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_FAILED);

        WorkflowExecutionFailedEventAttributes failedEventAttributes = findFailedEventAttributes(wfe);
        assertNotNull(" Should have found a WorkflowExecution Failed event", failedEventAttributes);
        String errorMessage = failedEventAttributes.getFailure().getCause().getMessage();
        assertEquals("Error message expected is wrong", SweepActivitiesImpl.INVALID_BOOKNAME_MESSAGE, errorMessage);
        ApplicationFailureInfo apfInfo = failedEventAttributes.getFailure().getCause().getApplicationFailureInfo();
        String errorType = apfInfo.getType();
        assertEquals("Didnt get NonRetryableActivityException", NonRetryableActivityException.class.getName(), errorType);
    }

    /**
     * Simulates an exception by setting test variables for invalid period id The workflow should fail with NonRetryableActivityException
     */
    @Test
    public void sweepWithInvalidPeriod() throws IOException, InterruptedException {
        //the value will be cleared automatically by BaseTestExecutionListener
        setTestVariable(TestEvaluator.INVALID_PERIOD_KEY, true);
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SWEEP.getId(), 1234, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), "10~GAAP~");
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status should have failed " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_FAILED);

        WorkflowExecutionFailedEventAttributes failedEventAttributes = findFailedEventAttributes(wfe);
        assertNotNull(" Should have found a WorkflowExecution Failed event", failedEventAttributes);
        String errorMessage = failedEventAttributes.getFailure().getCause().getMessage();
        assertEquals("Error message expected is wrong", SweepActivitiesImpl.INVALID_PERIOD_MESSAGE, errorMessage);
        ApplicationFailureInfo apfInfo = failedEventAttributes.getFailure().getCause().getApplicationFailureInfo();
        String errorType = apfInfo.getType();
        assertEquals("Didnt get NonRetryableActivityException", NonRetryableActivityException.class.getName(), errorType);
    }

    private String getSqlStatement (Long pp_amt, Long pq_amt, Long py_amt, Boolean rc) {
        StringBuilder sqlStatement = new StringBuilder();

        sqlStatement.append("Select count(1) from rpro_rc_schd where POST_PRD_ID = :nextPeriodId and ");
        if (pp_amt != null) {
            sqlStatement.append("PP_AMT = " + pp_amt + " and ");
        }
        if (pq_amt != null) {
            sqlStatement.append("PQ_AMT = " + pq_amt + " and ");
        }
        if (py_amt != null) {
            sqlStatement.append("PY_AMT = " + py_amt + " and ");
        }
        if (rc) {
            sqlStatement.append("ROOT_LINE_ID in (Select ID from RPRO_RC_LINE where RC_ID = :rcId) and ");
        }
        sqlStatement.append("UPDT_PRD_ID = :updatePeriodId and " +
                "BOOK_ID = :bookId and " +
                "SEC_ATR_VAL = :orgId and " +
                "RPRO_RC_SCHD_PKG.GET_INTERFACED_FLAG(INDICATORS) = 'N' and " +
                "CLIENT_ID = :clientId and " +
                "ATR1 = :atr1");

        return sqlStatement.toString();
    }

    /*
        Add records without rcId and sweeps.
        Initially, pp_amt = pq_amt = py_amt = amount = 100
        The condition cur_qt_dt = nxt_qt_dt is true here
        The tests should update pp_amt to a value of -100
     */
    @Test
    public void sweepAndUpdate1() throws IOException {
        String sqlStatement = getSqlStatement(-100L, null, null, false);
        sweepAndUpdateHelper(sqlStatement, sweepTestVariables.tomorrow, sweepTestVariables.today, sweepTestVariables.tomorrow, sweepTestVariables.today, true);
    }

    /*
        Add records with rcId and sweeps.
        Initially, pp_amt = pq_amt = py_amt = amount = 100
        The condition cur_qt_dt = nxt_qt_dt is true here
        The tests should update pp_amt to a value of -100
     */
    @Test
    public void sweepAndUpdateWithRC1() throws IOException {
        String sqlStatement = getSqlStatement(-100L, null, null, true);
        AtomicLong rcLineId = new AtomicLong();
        sweepAndUpdateHelperWithRC(sqlStatement, sweepTestVariables.tomorrow, sweepTestVariables.today, sweepTestVariables.tomorrow, sweepTestVariables.today, true, rcLineId);
    }

    /*
        Add records without rcId and sweeps.
        cur_qt_dt != nxt_qt_dt (negative case)
        Initially, pp_amt = pq_amt = py_amt = amount = 100
        The condition cur_qt_dt = nxt_qt_dt is false here (negative case)
        The tests should not make any updates to pp_amt
     */
    @Test
    public void sweepAndUpdateInvalidDate1() throws IOException {
        String sqlStatement = getSqlStatement(-100L, null, null, false);
        sweepAndUpdateHelper(sqlStatement, sweepTestVariables.today, sweepTestVariables.today, sweepTestVariables.tomorrow, sweepTestVariables.today, false);
    }

    /*
        Add records with rcId and sweeps.
        cur_qt_dt != nxt_qt_dt (negative case)
        Initially, pp_amt = pq_amt = py_amt = amount = 100
        The condition cur_qt_dt = nxt_qt_dt is false here (negative case)
        The tests should not make any updates to pp_amt
     */
    @Test
    public void sweepAndUpdateWithRCInvalidDate1() throws IOException {
        String sqlStatement = getSqlStatement(-100L, null, null, true);
        AtomicLong rcLineId = new AtomicLong();
        sweepAndUpdateHelperWithRC(sqlStatement, sweepTestVariables.today, sweepTestVariables.today, sweepTestVariables.tomorrow, sweepTestVariables.today, false, rcLineId);
    }

    /*
        Add records without rcId and sweeps.
        Initially, pp_amt = pq_amt = py_amt = amount = 100
        The condition nxt_qt_dt = nxt_yr_dt is true here
        The tests should update to pp_amt, pq_amt, py_amt to 0, 0, 100 respectively
     */
    @Test
    public void sweepAndUpdate2() throws IOException {
        String sqlStatement = getSqlStatement(0L, 0L, 100L, false);
        sweepAndUpdateHelper(sqlStatement, sweepTestVariables.today, sweepTestVariables.today, sweepTestVariables.tomorrow, sweepTestVariables.tomorrow, true);
    }

    /*
        Add records with rcId and sweeps.
        Initially, pp_amt = pq_amt = py_amt = amount = 100
        The condition nxt_qt_dt = nxt_yr_dt is true here
        The tests should update to pp_amt, pq_amt, py_amt to 0, 0, 100 respectively
     */
    @Test
    public void sweepAndUpdateWithRC2() throws IOException {
        String sqlStatement = getSqlStatement(0L, 0L, 100L, true);
        AtomicLong rcLineId = new AtomicLong();
        sweepAndUpdateHelperWithRC(sqlStatement, sweepTestVariables.today, sweepTestVariables.today, sweepTestVariables.tomorrow, sweepTestVariables.tomorrow, true, rcLineId);
    }

    /*
        Add records without rcId and sweeps.
        nxt_qt_dt != nxt_yr_dt (negative case)
        Initially, pp_amt = pq_amt = py_amt = amount = 100
        The condition nxt_qt_dt = nxt_yr_dt is false here
        The tests should not make any updates
     */
    @Test
    public void sweepAndUpdateInvalidDate2() throws IOException {
        String sqlStatement = getSqlStatement(0L, 0L, 100L, false);
        sweepAndUpdateHelper(sqlStatement, sweepTestVariables.tomorrow, sweepTestVariables.today, sweepTestVariables.tomorrow, sweepTestVariables.today, false);
    }

    /*
        Add records with rcId and sweeps.
        nxt_qt_dt != nxt_yr_dt (negative case)
        Initially, pp_amt = pq_amt = py_amt = amount = 100
        The condition nxt_qt_dt = nxt_yr_dt is false here
        The tests should not make any updates
     */
    @Test
    public void sweepAndUpdateWithRCInvalidDate2() throws IOException {
        String sqlStatement = getSqlStatement(0L, 0L, 100L, true);
        AtomicLong rcLineId = new AtomicLong();
        sweepAndUpdateHelperWithRC(sqlStatement, sweepTestVariables.tomorrow, sweepTestVariables.today, sweepTestVariables.tomorrow, sweepTestVariables.today, false, rcLineId);
    }



    /*
        Add records without rcId and sweeps.
        Initially, pp_amt = pq_amt = py_amt = amount = 100
        The condition cur_qt_dt != nxt_qt_dt and nxt_qt_dt != nxt_yr_dt are true here
        The tests should update pp_amt, pq_amt to 0, 0 respectively
     */
    @Test
    public void sweepAndUpdate3() throws IOException {
        String sqlStatement = getSqlStatement(0L, 0L, null, false);
        sweepAndUpdateHelper(sqlStatement, sweepTestVariables.today, sweepTestVariables.today, sweepTestVariables.tomorrow, sweepTestVariables.dayAfterTomorrow, true);
    }

    /*
        Add records with rcId and sweeps.
        Initially, pp_amt = pq_amt = py_amt = amount = 100
        The condition cur_qt_dt != nxt_qt_dt and nxt_qt_dt != nxt_yr_dt are true here
        The tests should update pp_amt, pq_amt to 0, 0 respectively
     */
    @Test
    public void sweepAndUpdateWithRC3() throws IOException {
        String sqlStatement = getSqlStatement(0L, 0L, null, true);
        AtomicLong rcLineId = new AtomicLong();
        sweepAndUpdateHelperWithRC(sqlStatement, sweepTestVariables.today, sweepTestVariables.today, sweepTestVariables.tomorrow, sweepTestVariables.dayAfterTomorrow, true, rcLineId);
    }

    /*
        Add records without rcId and sweeps.
        (cur_qt_dt != nxt_qt_dt and nxt_qt_dt != nxt_yr_dt) -> both conditions are false (negative case)
        Initially, pp_amt = pq_amt = py_amt = amount = 100
        The condition cur_qt_dt != nxt_qt_dt and nxt_qt_dt != nxt_yr_dt are false here
        The tests should not make any updates
     */
    @Test
    public void sweepAndUpdateWithInvalidDate3() throws IOException {
        String sqlStatement = getSqlStatement(0L, 0L, null, false);
        sweepAndUpdateHelper(sqlStatement, sweepTestVariables.tomorrow, sweepTestVariables.today, sweepTestVariables.tomorrow, sweepTestVariables.today, false);
    }

    /*
        Add records with rcId and sweeps.
        (cur_qt_dt != nxt_qt_dt and nxt_qt_dt != nxt_yr_dt) -> both conditions are false (negative case)
        Initially, pp_amt = pq_amt = py_amt = amount = 100
        The condition cur_qt_dt != nxt_qt_dt and nxt_qt_dt != nxt_yr_dt are false here
        The tests should not make any updates
     */
    @Test
    public void sweepAndUpdateWithRCInvalidDate3() throws IOException {
        String sqlStatement = getSqlStatement(0L, 0L, null, true);
        AtomicLong rcLineId = new AtomicLong();
        sweepAndUpdateHelperWithRC(sqlStatement, sweepTestVariables.tomorrow, sweepTestVariables.today, sweepTestVariables.tomorrow, sweepTestVariables.today, false, rcLineId);
    }

    @Test
    public void sweepAndSummarize() throws Exception {
        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        long noOfRows = ThreadLocalRandom.current().nextLong(2, 6 + 1);

        AtomicLong periodId = new AtomicLong();
        Jdbi jdbi = DbTestContext.getConnection();

        AtomicLong rcLineId = new AtomicLong(90000);

        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            long bookId = commonDao.getBookId("GAAP", dbParams.getClientId());
            periodId.set(commonDao.getPeriodId(bookId, dbParams.getOrgId()));

            this.sweepTestVariables.summarizationExecuted = true;
            this.sweepTestVariables.rcId = rcLineId.get();

            //insert records to rpro_rc_schd, rpro_rc_line, rpro_rc_head
            insertRecordsForSummarization(handle, testConfig, noOfRows, periodId.get(), sweepTestVariables.atr1, bookId, rcLineId.get(), "SYSADMIN", new Date());
        });
        String paramText = "10~GAAP~" + rcLineId;

        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SWEEP.getId(), 1234, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), paramText);
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        logger.info("before waiting for workflow complete");
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);


        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            long bookId = commonDao.getBookId("GAAP", dbParams.getClientId());
            verifyRecordsSummarization(handle, dbParams, noOfRows, periodId.get(), sweepTestVariables.atr1, bookId, rcLineId.get());
        });
    }

    /*
    Test to validate whether the transaction is getting rollback or not incase of errors.
    Raising exception after inserting records to RPRO_RC_SCHD_SWEEP_SUMMARY in SweepActivitesImpl
    and comparing zero rows in the table at the end.
     */
    @Test
    public void sweepWithTransactionCheck() throws Exception {

        setTestVariable(TestEvaluator.TRANSACTION_ERROR, true);

        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        long noOfRows = ThreadLocalRandom.current().nextLong(2, 6 + 1);

        AtomicLong periodId = new AtomicLong();
        Jdbi jdbi = DbTestContext.getConnection();

        AtomicLong rcLineId = new AtomicLong(90000);

        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            long bookId = commonDao.getBookId("GAAP", dbParams.getClientId());
            periodId.set(commonDao.getPeriodId(bookId, dbParams.getOrgId()));

            this.sweepTestVariables.summarizationExecuted = true;
            this.sweepTestVariables.rcId = rcLineId.get();

            //insert records to rpro_rc_schd, rpro_rc_line, rpro_rc_head
            insertRecordsForSummarization(handle, testConfig, noOfRows, periodId.get(), sweepTestVariables.atr1, bookId, rcLineId.get(), "SYSADMIN",
                    new Date());
        });
        String paramText = "10~GAAP~" + rcLineId;

        long requestId = 263646;

        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SWEEP.getId(), requestId, dbParams.getTenantId(), dbParams.getOrgId(),
                dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), paramText);
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        logger.info("before waiting for workflow complete");
        waitForWorkflowComplete(wfe);

        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);

        assertTrue("Workflow status should have failed " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_FAILED);

        WorkflowExecutionFailedEventAttributes failedEventAttributes = findFailedEventAttributes(wfe);
        assertNotNull(" Should have found a WorkflowExecution Failed event", failedEventAttributes);
        String errorMessage = failedEventAttributes.getFailure().getCause().getMessage();
        assertEquals("Error message expected is wrong", SweepActivitiesImpl.TRANSACTION_ERROR_MESSAGE, errorMessage);

        long count = jdbi.withHandle(handle -> {
            return handle.createQuery("Select count(1) from RPRO_RC_SCHD_SWEEP_SUMMARY where SWEEP_BATCH_ID = :requestId")
                    .bind("requestId", requestId)
                    .mapTo(Long.class).first();
        });

        assertEquals(0l,count);
    }

    @Test
    public void sweepWithExistingSweepSummaryRecords() throws Exception {

        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        long noOfRows = ThreadLocalRandom.current().nextLong(2, 6 + 1);

        AtomicLong periodId = new AtomicLong();
        Jdbi jdbi = DbTestContext.getConnection();

        long requestId = 263648;

        AtomicLong rcLineId = new AtomicLong(90100);

        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            long bookId = commonDao.getBookId("GAAP", dbParams.getClientId());
            periodId.set(commonDao.getPeriodId(bookId, dbParams.getOrgId()));

            this.sweepTestVariables.summarizationExecuted = true;
            this.sweepTestVariables.rcId = rcLineId.get();

            //insert records to rpro_rc_schd, rpro_rc_line, rpro_rc_head
            insertRecordsForSummarizationWithSummaryData(handle, testConfig, noOfRows, periodId.get(), sweepTestVariables.atr1, bookId, rcLineId.get(), "SYSADMIN",
                    new Date(),noOfRows/2, requestId);
        });
        String paramText = "10~GAAP~" + rcLineId;



        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SWEEP.getId(), requestId, dbParams.getTenantId(), dbParams.getOrgId(),
                dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), paramText);
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        logger.info("before waiting for workflow complete");
        waitForWorkflowComplete(wfe);

        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);

        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);


        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            long bookId = commonDao.getBookId("GAAP", dbParams.getClientId());
            verifyRecordsSummarization(handle, dbParams, noOfRows, periodId.get(), sweepTestVariables.atr1, bookId, rcLineId.get());
        });
    }

    @Test
    public void schemaNameInWorkflowID() throws IOException, InterruptedException {

        String schemaName = "schemaNameInWorkFlow";
        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        long noOfRows = ThreadLocalRandom.current().nextLong(1, 5 + 1);

        AtomicLong periodId = new AtomicLong();
        Jdbi jdbi = DbTestContext.getConnection();

        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            long crtdPeriodId = commonDao.getCrtdPeriodId(null, dbParams.getOrgId());
            //assume book name GAAP always exists
            long bookId = commonDao.getBookId("GAAP", dbParams.getClientId());
            periodId.set(commonDao.getPeriodId(bookId, dbParams.getOrgId()));
            //insert records to rpro_rc_schd
            insertSchedule(handle, testConfig, periodId.get(), periodId.get(), crtdPeriodId, sweepTestVariables.atr1, bookId,
                    noOfRows, null);//pass null for RC line id
        });

        WorkflowRequest request = new WorkflowRequest(JobsMetadata.SWEEP.getId(), 1234, dbParams.getTenantId(), dbParams.getOrgId(), dbParams.getClientId(),
                dbParams.getUser(),
                dbParams.getRoleId(), "10~GAAP~", schemaName);
        WorkflowExecutionEntity wfe = submitWorkflowRequest(request);
        waitForWorkflowComplete(wfe);
        WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
        assertTrue("Workflow status is not complete " + info.getStatus(),
                info.getStatus() == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_COMPLETED);
        long updatedRecordCount = getUpdatedRecordCountAfterWorkflowExecution(jdbi, periodId.get(), dbParams, sweepTestVariables.atr1);
        assertEquals("Updated record count isn't matching  ",
                noOfRows, updatedRecordCount);
        assertTrue("workflow id does not contain schema name", wfe.getExecutionId().contains(schemaName) );
    }

    private WorkflowExecutionFailedEventAttributes findFailedEventAttributes(WorkflowExecutionEntity wfe) {
        History history = getWorkflowExecutionHistory(wfe);
        List<HistoryEvent> eventList = history.getEventsList();
        //lets iterate in reverse for quick finding
        ListIterator<HistoryEvent> listIterator = eventList.listIterator(eventList.size());
        WorkflowExecutionFailedEventAttributes failedEventAttributes = null;
        while (listIterator.hasPrevious()) {
            HistoryEvent event = listIterator.previous();
            if (event.hasWorkflowExecutionFailedEventAttributes()) {
                failedEventAttributes = event.getWorkflowExecutionFailedEventAttributes();
                break;
            }
        }
        return failedEventAttributes;
    }

    private long getUpdatedRecordCountAfterWorkflowExecution(Jdbi jdbi, long periodId, TestDbParams dbParams, String atr1) {
        return jdbi.withHandle(handle -> {
            SweepDao sweepDao = handle.attach(SweepDao.class);
            NextPeriod nextPeriod = sweepDao.getNextPeriodDetails(periodId, dbParams.getClientId());
            long postPeriodId = nextPeriod.getNextPeriodId();
            long updatePeriodId = nextPeriod.getNextPeriodId();
            return fetchUpdatedRecordCount(handle, atr1, postPeriodId, updatePeriodId);
        });
    }

    private void waitForWorkflowComplete(WorkflowExecutionEntity wfe) {
        with().pollInterval(Duration.ofMillis(500)).and().with().pollDelay(100, TimeUnit.MILLISECONDS).await("Workflow complete")
                .atMost(100_000, TimeUnit.MILLISECONDS)
                .until(workflowComplete(wfe));
    }

    private long fetchUpdatedRecordCount(Handle handle, String atr1, long postPeriodId,  long updatePeriodId) {
        long updatedCount = handle.createQuery("Select count(1) from rpro_rc_schd where ATR1 =:atr1 and post_prd_id = :postPeriodId and updt_prd_id = :updatePeriodId")
                .bind("atr1", atr1)
                .bind("postPeriodId", postPeriodId)
                .bind("updatePeriodId", updatePeriodId)
                .mapTo(Long.class).first();
        return updatedCount;
    }

    private static final String INSERT_SCHED_STRING =
            "insert into rpro_rc_schd (ID ,CURR ,AMOUNT, PP_AMT ,PQ_AMT,PY_AMT , INDICATORS,PRD_ID ,POST_PRD_ID,CRTD_PRD_ID ,ATR1,CLIENT_ID,SEC_ATR_VAL,BOOK_ID"
                    + ",ROOT_LINE_ID)  "
                    + "values(rpro_utility_pkg.generate_id ( 'rpro_rc_schd_id_s', :clientId),'USD',100,100,100,100,"
                    + "'NLRNNYNNNNRNNNNNNNNNNNNNNNNNNNNNNNNNNNNN' , :periodId,:postPeriodId,:crtdPeriodId,:atr1,:clientId,:orgId,:bookId,:rootLineId)";

    private void insertSchedule(Handle handle, IntegrationTestConfig testConfig,
                                long periodId, long postPeriodId, long crtdPeriodId, String atr1, long bookId, long noOfRows, Long rcLineId) {
        TestDbParams dbParams = testConfig.getTestDbParams();
        PreparedBatch batch = handle.prepareBatch(INSERT_SCHED_STRING);

        logger.info("inserting {} records", noOfRows);

        for (int i = 0; i < noOfRows; i++) {
            batch.bind("clientId", dbParams.getClientId())
                    .bind("periodId", periodId)
                    .bind("postPeriodId", postPeriodId)
                    .bind("crtdPeriodId", crtdPeriodId)
                    .bind("atr1", atr1)
                    .bind("orgId", dbParams.getOrgId())
                    .bind("bookId", bookId)
                    .bind("rootLineId", rcLineId)
                    .add();
        }
        batch.execute();
        sweepTestVariables.scheduleInserted = true;
        sweepTestVariables.bookId = bookId;
    }

    @Before
    public void setup() {
        SweepTestVariables sweepTestVariables = new SweepTestVariables();
        sweepTestVariables.atr1 = UUID.randomUUID().toString();

        Date tomorrow = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(tomorrow);
        c.add(Calendar.DATE, 1);
        tomorrow = c.getTime();

        Date dayAfterTomorrow = new Date();
        Calendar c1 = Calendar.getInstance();
        c1.setTime(dayAfterTomorrow);
        c1.add(Calendar.DATE, 2);
        dayAfterTomorrow = c1.getTime();

        sweepTestVariables.today = new Date();
        sweepTestVariables.tomorrow = tomorrow;
        sweepTestVariables.dayAfterTomorrow = dayAfterTomorrow;

        this.sweepTestVariables = sweepTestVariables;
    }


    @After
    public void tearDown() {
        if (sweepTestVariables.scheduleInserted) {
            Jdbi jdbi = DbTestContext.getConnection();
            jdbi.useHandle(handle -> {
                deleteSchedule(handle);
                if (this.sweepTestVariables.rcId > 0) {
                    deleteRcLines(handle);
                }
                if (this.sweepTestVariables.summarizationExecuted) {
                    int recordsDeleted = deleteSummarizationRecords(handle);
                    logger.info("{} records deleted after summarization", recordsDeleted);
                }
            });
        }
    }

    private int executeDeleteQuery (Handle handle, String sqlStatement) {
        return handle.createUpdate(sqlStatement)
                .bind("atr1", this.sweepTestVariables.atr1)
                .bind("rcId", this.sweepTestVariables.rcId)
                .execute();
    }

    private int deleteSummarizationRecords (Handle handle) {
        int recordsDeleted = 0;

        recordsDeleted += executeDeleteQuery(handle, "delete from RPRO_RC_HEAD where ATR1 = :atr1 and ID = :rcId");
        recordsDeleted += executeDeleteQuery(handle, "delete from RPRO_RI_ACCT_SUMM where LINE_ID = :rcId");
        recordsDeleted += executeDeleteQuery(handle, "delete from RPRO_RI_WF_SUMM where LINE_ID = :rcId");
        recordsDeleted += executeDeleteQuery(handle, "delete from RPRO_RI_ACCT_SUMM_S3 where LINE_ID = :rcId");
        recordsDeleted += executeDeleteQuery(handle, "delete from RPRO_TREND_OPEN_PRD where LINE_ID = :rcId");
        recordsDeleted += executeDeleteQuery(handle, "delete from RPRO_RC_HEAD where ID = :rcId");


        return recordsDeleted;
    }

    private void deleteSchedule(Handle handle) {
        TestDbParams dbParams = getTestConfig().getTestDbParams();
        int deleted = handle.createUpdate(
                        "delete from rpro_rc_schd where CLIENT_ID=:clientId and SEC_ATR_VAL =:orgId and BOOK_ID =:bookId and  ATR1=:atr1 ")
                .bind("clientId", dbParams.getClientId())
                .bind("atr1", sweepTestVariables.atr1)
                .bind("orgId", dbParams.getOrgId())
                .bind("bookId", sweepTestVariables.bookId)
                .execute();
    }

    private void deleteRcLines(Handle handle) {
        int deleted = handle.createUpdate(
                        "delete from rpro_rc_line where RC_ID=:rcId")
                .bind("rcId", this.sweepTestVariables.rcId)
                .execute();
        logger.info("deleted RC lines  {}", deleted);
    }


    private static final String INSERT_RC_LINE_STRING =
            "insert into rpro_rc_line (ID ,RC_ID , CLIENT_ID, SEC_ATR_VAL)  "
                    + "values(:rcLineId,:rcId, :clientId, :orgId)";

    private void insertRcLine(Handle handle, IntegrationTestConfig testConfig,
                              long generatedRcId,
                              long generatedRcLineId
    ) {
        TestDbParams dbParams = testConfig.getTestDbParams();
        int x = handle.createUpdate(INSERT_RC_LINE_STRING)
                .bind("rcLineId", generatedRcLineId)
                .bind("clientId", dbParams.getClientId())
                .bind("rcId", generatedRcId)
                .bind("orgId", dbParams.getOrgId())
                .execute();
        this.sweepTestVariables.rcId = generatedRcId;
    }

    private void sweepAndUpdateHelper (String sqlStatement, Date cur_qt_dt, Date cur_yr_dt, Date nxt_qt_dt, Date nxt_yr_dt, Boolean shouldPass) throws IOException {
        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        long noOfRows = ThreadLocalRandom.current().nextLong(1, 5 + 1);

        AtomicLong periodId = new AtomicLong();
        Jdbi jdbi = DbTestContext.getConnection();

        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            long crtdPeriodId = commonDao.getCrtdPeriodId(null, dbParams.getOrgId());
            //assume book name GAAP always exists
            long bookId = commonDao.getBookId("GAAP", dbParams.getClientId());
            periodId.set(commonDao.getPeriodId(bookId, dbParams.getOrgId()));
            //insert records to rpro_rc_schd
            insertSchedule(handle, testConfig, periodId.get(), periodId.get(), crtdPeriodId, sweepTestVariables.atr1, bookId, noOfRows, null);//pass null for RC line id

            CurrentPeriod currentPeriod = new CurrentPeriod(cur_qt_dt, cur_yr_dt);
            NextPeriod nextPeriod = new NextPeriod(1873, nxt_qt_dt, nxt_yr_dt);

            updateRecords(periodId, handle, nextPeriod, currentPeriod, bookId, dbParams.getOrgId(), sweepTestVariables.atr1, dbParams.getClientId(), noOfRows, sqlStatement, shouldPass,null);

        });
    }

    private void sweepAndUpdateHelperWithRC (String sqlStatement, Date cur_qt_dt, Date cur_yr_dt, Date nxt_qt_dt, Date nxt_yr_dt, Boolean shouldPass, AtomicLong rcLineId) throws IOException {
        IntegrationTestConfig testConfig = getTestConfig();
        TestDbParams dbParams = testConfig.getTestDbParams();
        long noOfRows = ThreadLocalRandom.current().nextLong(1, 5 + 1);

        AtomicLong periodId = new AtomicLong();
        Jdbi jdbi = DbTestContext.getConnection();

        jdbi.useHandle(handle -> {
            CommonDao commonDao = handle.attach(CommonDao.class);
            rcLineId.set(commonDao.getNextSequenceNumber("rpro_rc_line_id_s", dbParams.getClientId()));
            long crtdPeriodId = commonDao.getCrtdPeriodId(null, dbParams.getOrgId());
            //assume book name GAAP always exists
            long bookId = commonDao.getBookId("GAAP", dbParams.getClientId());
            periodId.set(commonDao.getPeriodId(bookId, dbParams.getOrgId()));

            //inserting same id as rc and rc line id is ok -
            //will allow us to pass the same id as rc and test
            insertRcLine(handle, testConfig, rcLineId.get(), rcLineId.get());

            //insert records to rpro_rc_schd
            insertSchedule(handle, testConfig, periodId.get(), periodId.get(), crtdPeriodId, sweepTestVariables.atr1, bookId, noOfRows, rcLineId.get());//pass null for RC line id

            CurrentPeriod currentPeriod = new CurrentPeriod(cur_qt_dt, cur_yr_dt);
            NextPeriod nextPeriod = new NextPeriod(1873, nxt_qt_dt, nxt_yr_dt);

            updateRecords(periodId, handle, nextPeriod, currentPeriod, bookId, dbParams.getOrgId(), sweepTestVariables.atr1, dbParams.getClientId(), noOfRows, sqlStatement, shouldPass, new BigDecimal(rcLineId.get()));

        });
    }

    private Integer sweepUpdate(Handle handle, long nextPeriodId, Date currentQuarterDate, Date nextQuarterDate, Date nextYearDate, String updtBy, long updatePeriodId, long postPeriodId, long bookId, String orgId, BigDecimal rcId) {

        SweepDao sweepDao = handle.attach(SweepDao.class);
        if (rcId != null) {
            return sweepDao.sweepUpdateForRC(nextPeriodId, currentQuarterDate, nextQuarterDate, nextYearDate, updtBy, updatePeriodId, postPeriodId, bookId, orgId, rcId);
        } else {
            return sweepDao.sweepUpdate(nextPeriodId, currentQuarterDate, nextQuarterDate, nextYearDate, updtBy, updatePeriodId, postPeriodId, bookId, orgId);
        }

    }

    private void updateRecords (AtomicLong periodId, Handle handle, NextPeriod nextPeriod, CurrentPeriod currentPeriod, long bookId, String orgId, String atr1, long clientId, long rowsInserted, String sqlStatement, Boolean shouldPass, BigDecimal rcId) {

        long nextPeriodId = nextPeriod.getNextPeriodId(),
                updatePeriodId = nextPeriodId,
                postPeriodId = periodId.get();
        Date currentQuarterDate = currentPeriod.getCurrentQuarterDate(),
                nextQuarterDate = nextPeriod.getNextQuarterDate(),
                nextYearDate = nextPeriod.getNextYearDate();
        String updtBy = "testUser";

        Integer rowsUpdated = sweepUpdate(handle, nextPeriodId, currentQuarterDate, nextQuarterDate, nextYearDate, updtBy, updatePeriodId, postPeriodId, bookId, orgId, rcId);

        assertSame("Record updating failed", shouldPass, verifyUpdatedRecords(handle, nextPeriodId, updatePeriodId, bookId, orgId, atr1, clientId, rowsInserted, sqlStatement, rcId));
    }

    private Boolean verifyUpdatedRecords (Handle handle, long nextPeriodId, long updatePeriodId, long bookId, String orgId, String atr1, long clientId, long rowsInserted, String sqlStatement, BigDecimal rcId) {
        long updatedCount = executeCountQuery(handle, nextPeriodId, updatePeriodId, bookId, orgId, atr1, clientId, sqlStatement, rcId);
        return  (Objects.equals(updatedCount, rowsInserted));
    }

    private long executeCountQuery (Handle handle, long nextPeriodId, long updatePeriodId, long bookId, String orgId, String atr1, long clientId, String sqlStatement, BigDecimal rcId) {

        long updatedCount;

        if (rcId != null) {
            updatedCount = handle.createQuery(sqlStatement)
                    .bind("rcId", rcId)
                    .bind("nextPeriodId", nextPeriodId)
                    .bind("updatePeriodId", updatePeriodId)
                    .bind("bookId", bookId)
                    .bind("orgId", orgId)
                    .bind("clientId", clientId)
                    .bind("atr1", atr1)
                    .mapTo(Long.class).first();
        } else {
            updatedCount = handle.createQuery(sqlStatement)
                    .bind("nextPeriodId", nextPeriodId)
                    .bind("updatePeriodId", updatePeriodId)
                    .bind("bookId", bookId)
                    .bind("orgId", orgId)
                    .bind("clientId", clientId)
                    .bind("atr1", atr1)
                    .mapTo(Long.class).first();
        }

        return updatedCount;
    }
        private void insertRecordsForSummarization (Handle handle, IntegrationTestConfig testConfig, long noOfRows, long periodId, String atr1, long bookId, long rcId, String createdBy, Date creationTime) throws ParseException {
        TestDbParams dbParams = testConfig.getTestDbParams();

        Date exRateDate = new SimpleDateFormat("yyyy-MM-dd").parse("2001-06-06");

        String insert_rc_schd = "insert into RPRO_RC_SCHD (ID, " +
                "CURR, AMOUNT, PP_AMT, PQ_AMT, PY_AMT, INDICATORS, " +
                "PRD_ID, POST_PRD_ID, CRTD_PRD_ID, ATR1, CLIENT_ID, SEC_ATR_VAL,BOOK_ID," +
                "REL_ID, RC_ID," +
                "CRTD_BY, CRTD_DT, UPDT_BY, UPDT_DT," +
                "ROOT_LINE_ID, ORIG_LINE_ID," +
                "RC_VER, LINE_ID, POB_ID, REL_PCT, DR_SEGMENTS,CR_SEGMENTS," +
                "F_EX_RATE, G_EX_RATE, EX_RATE_DATE," +
                "REF_BILL_ID)" +
                "values (rpro_utility_pkg.generate_id('rpro_rc_schd_id_s', 1)," +
                "'USD', 5000, 0, 0, 0, 'NLRNNYNNNNRNNNNNNNNNNNNNNNNNNNFNNNNNNNNN'," +
                ":periodId, :periodId, :periodId, :atr1, :clientId, :orgId, :bookId," +
                ":rcId, :rcId," +
                ":createdBy, :creationTime, :createdBy, :creationTime," +
                ":rcId, :rcId," +
                "1, :rcId, :rcId, 0, 22, 22," +
                "1, 1, :exRateDate," +
                "1)";

        String insert_rc_line = "insert into RPRO_RC_LINE (ID, RC_ID, CLIENT_ID, SEC_ATR_VAL, BOOK_ID, ATR1) " +
                "values (:rcId, :rcId, :clientId, :orgId, :bookId, :atr1)";

        String insert_rc_head = "insert into RPRO_RC_HEAD (ID, SELL_AMT, INDICATORS, MAX_SCHD_PRD, CLIENT_ID, SEC_ATR_VAL, BOOK_ID, ATR1) " +
                "values (:rcId, 40000, 'NNENNYNNNANNNNRNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN', :periodId, :clientId, :orgId, :bookId, :atr1)";

        logger.info("inserting {} records with rc starting from {}", noOfRows, rcId);

        PreparedBatch batch_rc_schd = handle.prepareBatch(insert_rc_schd);
        for (int i = 0; i < noOfRows; i++) {
            batch_rc_schd.bind("clientId", dbParams.getClientId())
                    .bind("periodId", periodId)
                    .bind("atr1", atr1)
                    .bind("orgId", dbParams.getOrgId())
                    .bind("bookId", bookId)
                    .bind("rcId", rcId)
                    .bind("createdBy", createdBy)
                    .bind("creationTime", creationTime)
                    .bind("exRateDate", exRateDate)
                    .add();
        }
        batch_rc_schd.execute();

        PreparedBatch batch_rc_line = handle.prepareBatch(insert_rc_line);
        batch_rc_line.bind("clientId", dbParams.getClientId())
                .bind("atr1", atr1)
                .bind("orgId", dbParams.getOrgId())
                .bind("bookId", bookId)
                .bind("rcId", rcId)
                .add();
        batch_rc_line.execute();

        PreparedBatch batch_rc_head = handle.prepareBatch(insert_rc_head);
        batch_rc_head.bind("clientId", dbParams.getClientId())
                .bind("periodId", periodId)
                .bind("atr1", atr1)
                .bind("orgId", dbParams.getOrgId())
                .bind("bookId", bookId)
                .bind("rcId", rcId)
                .add();
        batch_rc_head.execute();

        sweepTestVariables.scheduleInserted = true;
        sweepTestVariables.bookId = bookId;
    }

    private void insertRecordsForSummarizationWithSummaryData (Handle handle, IntegrationTestConfig testConfig, long noOfRows, long periodId, String atr1,
            long bookId, long rcId, String createdBy, Date creationTime, long sweepSummaryRows, long requestId) throws ParseException {

        assertTrue("summary records should not be more than schedule records",sweepSummaryRows<noOfRows);

        //insert records to rpro_rc_schd, rpro_rc_line, rpro_rc_head
        insertRecordsForSummarization(handle, testConfig, noOfRows, periodId, sweepTestVariables.atr1, bookId, rcId, "SYSADMIN",
                new Date());



        String insertStatementSub =
                "insert into RPRO_RC_SCHD_SWEEP_SUMMARY(ATR5 ,ATR3,POST_BATCH_ID,ATR4,ATR1,ATR2,LINE_ID, RORD_INV_REF,AMOUNT,INDICATORS,CLIENT_ID,"
                        + "REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,DR_LINK_ID ,CRTD_BY,ID,JE_BATCH_ID,BLD_FX_DT,REL_PCT,CRTD_PRD_ID,DIST_ID,BLD_FX_RATE,"
                        + "CR_SEGMENTS,F_EX_RATE,CURR, ORIG_LINE_ID,POST_PRD_ID,CR_LINK_ID,RC_VER,UPDT_DT,SCHD_ADDL_ID,"
                        + "UPDT_PRD_ID,RC_ID ,POB_ID,PQ_AMT,MODEL_ID,SEC_ATR_VAL,G_EX_RATE,POST_DATE,JE_BATCH_NAME,EX_RATE_DATE,"
                        + "CRTD_DT ,PRD_ID,PY_AMT,UPDT_BY,DR_SEGMENTS,REL_ID,PP_AMT,SWEEP_BATCH_ID) select ATR5 ,ATR3,POST_BATCH_ID,ATR4,ATR1,ATR2,"
                        + "LINE_ID, RORD_INV_REF,AMOUNT,INDICATORS,CLIENT_ID,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,DR_LINK_ID"
                        + ",CRTD_BY,ID,JE_BATCH_ID,BLD_FX_DT,REL_PCT,CRTD_PRD_ID,DIST_ID,BLD_FX_RATE,CR_SEGMENTS,F_EX_RATE,CURR"
                        + ",ORIG_LINE_ID,POST_PRD_ID,CR_LINK_ID,RC_VER,UPDT_DT,SCHD_ADDL_ID,UPDT_PRD_ID,RC_ID"
                        + ",POB_ID,PQ_AMT,MODEL_ID,SEC_ATR_VAL,G_EX_RATE,POST_DATE,JE_BATCH_NAME,EX_RATE_DATE,CRTD_DT"
                        + ",PRD_ID,PY_AMT,UPDT_BY,DR_SEGMENTS,REL_ID,PP_AMT , "+ (requestId-1) + " from RPRO_RC_SCHD RPRO_RC_SCHD "
                        + " WHERE ROWNUM <= " +  sweepSummaryRows;

        handle.createUpdate(insertStatementSub).execute();

    }

    private void verifyRecordsSummarization (Handle handle, TestDbParams dbParams, long noOfRows, long periodId, String atr1, long bookId, long rcId) {
        SweepDao sweepDao = handle.attach(SweepDao.class);
        long nextPeriodId = sweepDao.getNextPeriodDetails(periodId, dbParams.getClientId()).getNextPeriodId();

        StringBuilder prefixQuery;
        long count;

        long expectedAmount = noOfRows * 5000;

        prefixQuery = new StringBuilder("SELECT COUNT(1) FROM RPRO_RC_SCHD WHERE POST_PRD_ID = :nextPeriodId AND ATR1 = :atr1");
        count = getCount(handle, dbParams, prefixQuery, atr1, bookId, nextPeriodId, expectedAmount, rcId);
        assertSame("Sweep results not updated", noOfRows, count);

        prefixQuery = new StringBuilder("SELECT COUNT(1) FROM RPRO_RI_ACCT_SUMM WHERE LINE_ID = :rcId AND T_RL = 0 AND F_RL = 0 AND R_RL = 0");
        count = getCount(handle, dbParams, prefixQuery, atr1, bookId, nextPeriodId, expectedAmount, rcId);
        assertSame("RPRO_RI_ACCT_SUMM results not matching", 1L, count);
        prefixQuery = new StringBuilder("SELECT COUNT(1) FROM RPRO_RI_ACCT_SUMM WHERE LINE_ID = :rcId AND T_RL = :negativeAmount AND F_RL = :negativeAmount AND R_RL = :negativeAmount");
        count = getCount(handle, dbParams, prefixQuery, atr1, bookId, nextPeriodId, expectedAmount, rcId);
        assertSame("RPRO_RI_ACCT_SUMM results not matching", 1L, count);

        prefixQuery = new StringBuilder("SELECT COUNT(1) FROM RPRO_RI_WF_SUMM WHERE LINE_ID = :rcId AND T_AT = :positiveAmount AND F_AT = :positiveAmount AND R_AT = :positiveAmount AND PRD_ID = :nextPeriodId");
        count = getCount(handle, dbParams, prefixQuery, atr1, bookId, nextPeriodId, expectedAmount, rcId);
        assertSame("RPRO_RI_WF_SUMM results not matching", 1L, count);
        prefixQuery = new StringBuilder("SELECT COUNT(1) FROM RPRO_RI_WF_SUMM WHERE LINE_ID = :rcId AND T_AT = :negativeAmount AND F_AT = :negativeAmount AND R_AT = :negativeAmount");
        count = getCount(handle, dbParams, prefixQuery, atr1, bookId, nextPeriodId, expectedAmount, rcId);
        assertSame("RPRO_RI_WF_SUMM results not matching", 2L, count);

        prefixQuery = new StringBuilder("SELECT COUNT(1) FROM RPRO_RC_HEAD WHERE ID = :rcId AND MAX_SCHD_PRD = :nextPeriodId AND SUBSTR(INDICATORS, 3, 1) = 'A'");
        count = getCount(handle, dbParams, prefixQuery, atr1, bookId, nextPeriodId, expectedAmount, rcId);
        assertSame("RPRO_RC_HEAD results not matching", 1L, count);

    }

    private long getCount(Handle handle, TestDbParams dbParams, StringBuilder prefixQuery, String atr1, long bookId, long nextPeriodId, long expectedAmount, long rcId) {

        StringBuilder suffix = new StringBuilder(" AND CLIENT_ID = :clientId AND BOOK_ID = :bookId AND SEC_ATR_VAL = :orgId");

        String query = prefixQuery.append(suffix).toString();

        return handle.createQuery(query)
                .bind("nextPeriodId", nextPeriodId)
                .bind("positiveAmount", expectedAmount)
                .bind("negativeAmount", -expectedAmount)
                .bind("atr1", atr1)
                .bind("bookId", bookId)
                .bind("clientId", dbParams.getClientId())
                .bind("orgId", dbParams.getOrgId())
                .bind("rcId", rcId)
                .mapTo(Long.class).first();
    }


    private Callable<Boolean> workflowComplete(WorkflowExecutionEntity wfe) {
        return new Callable<Boolean>() {
            public Boolean call() throws Exception {
                WorkflowExecutionInfo info = getWorkflowExecutionInfo(wfe);
                WorkflowExecutionStatus currentStatus = info.getStatus();
                if (currentStatus == WorkflowExecutionStatus.WORKFLOW_EXECUTION_STATUS_RUNNING) {
                    return false;
                }
                return true;
            }
        };
    }
}