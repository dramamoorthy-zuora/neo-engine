package com.zuora.neo.engine.jobs.sfc;

public class SfcTestConstants {

    public static final String FINANC_TYPE_IND_SELL_PRICE = "YYBRdeLSLYNNNNNNNNNNNNNNN";
    public static final String FINANC_TYPE_IND_FV_PRICE = "YYBRdeLCLYNNNNNNNNNNNNNNN";

    public static final String INSERT_SFC_STATUS_VALUES = "INSERT INTO RPRO_SFC_STATUS_G "
            + "(ID,STATUS,DOC_LINE_ID,RC_ID,LINE_ID,NET_NPV_AMT,NET_INTEREST_ACCRUAL,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,BOOK_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS, DOC_NUM)"
            + " VALUES (1234567,'Ready for SFC',:docLineId,11,12,null,null,1,202202,'0',1,'SYSADMIN',to_date('18-07-22','DD-MM-RR'),'SYSADMIN',"
            + "to_date('18-07-22','DD-MM-RR'),'NNNNNNNNNNNNNNNNNNNN', :docNum)";

    public static final String INSERT_SFC_STATUS_VALUES_SO = "INSERT INTO RPRO_SFC_STATUS_G "
            + "(ID,STATUS,DOC_LINE_ID,RC_ID,LINE_ID,NET_NPV_AMT,NET_INTEREST_ACCRUAL,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,BOOK_ID,CRTD_BY,"
            + " CRTD_DT,UPDT_BY,UPDT_DT, INDICATORS,DOC_NUM,RIP_DATE,ERROR_MSG,"
            + " CT_MD_COMMENTS,RIP_AMT) "
            + " VALUES (1234567,'SO Updated',:docLineId,11,12,976811.24,134858.61,1,202205,'0',1,'SYSADMIN',"
            + " to_date('03-01-23','DD-MM-RR'),'SYSADMIN',to_date('03-01-23','DD-MM-RR'),'NYNNNNNNNNNNNNNNNNNN',:docNum,null,null,"
            + " 'Annual Finance Rate Change', null)";

    public static final String INSERT_SFC_STATUS_VALUES_RIP_LINE = "Insert into RPRO_SFC_STATUS_G "
            + "(ID,STATUS,DOC_LINE_ID,RC_ID,LINE_ID,NET_NPV_AMT,NET_INTEREST_ACCRUAL,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,BOOK_ID,CRTD_BY,"
            + "CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,DOC_NUM,RIP_DATE,ERROR_MSG,"
            + "CT_MD_COMMENTS,RIP_AMT)"
            + " VALUES (1234567,'Ripped',:docLineId,11,12,2615388.23,361063.01,1,202205,'0',1,'SYSADMIN',"
            + "to_date('10-01-23','DD-MM-RR'),'SYSADMIN',to_date('10-01-23','DD-MM-RR'),'NNYNNNNNNNNNNNNNNNNN',:docNum,to_date('27-09-21','DD-MM-RR'),null,"
            + "'Contract Ripped',null)";

    public static final String INSERT_SFC_STATUS_VALUES_PAYMENT_UPDATE = "Insert into RPRO_SFC_STATUS_G "
            + "(ID,STATUS,DOC_LINE_ID,RC_ID,LINE_ID,NET_NPV_AMT,NET_INTEREST_ACCRUAL,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,BOOK_ID,CRTD_BY,"
            + "CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,DOC_NUM,RIP_DATE,ERROR_MSG,"
            + "CT_MD_COMMENTS,RIP_AMT)"
            + " VALUES (1234567,'Payment Details Updated',:docLineId,11,12,1077747.7,146953.66,1,202205,'0',1,'SYSADMIN',"
            + "to_date('12-01-23','DD-MM-RR'),'SYSADMIN',to_date('12-01-23','DD-MM-RR'),'NYNNNNNNNNNNNNNNNNNN',:docNum,null,null,"
            + "null,null)";

    public static final String INSERT_SFC_STATUS_VALUES_MULTIPLE = "INSERT INTO RPRO_SFC_STATUS_G "
            + "(ID,STATUS,DOC_LINE_ID,RC_ID,LINE_ID,NET_NPV_AMT,NET_INTEREST_ACCRUAL,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,BOOK_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS, DOC_NUM)"
            + " VALUES (:id,:status,:docLineId,:rcId,:lineId,null,null,1,:crtdPrdId,'0',1,'SYSADMIN',to_date('18-07-22','DD-MM-RR'),'SYSADMIN',"
            + "to_date('18-07-22','DD-MM-RR'),:indicators, :docNum)";

    public static final String INSERT_RC_LINE = "INSERT INTO RPRO_RC_LINE_G (ID, RC_ID, DOC_LINE_ID, EXT_SLL_PRC, EXT_FV_PRC, EXT_LST_PRC, REC_AMT, DEF_AMT, REL_PCT, NPV_INTEREST_RATE,"
            + " CURR, BOOK_ID, CLIENT_ID, RC_POB_ID, F_EX_RATE, G_EX_RATE, DOC_DATE, SEC_ATR_VAL, DOC_NUM)"
            + " VALUES (12, 11, :docLineId, 394247.62, 394247.62, 394247.62, 394247.62, 0, 100, 7.48, 'USD', 1, 1, 17, 1, 1, to_date('01-02-22','DD-MM-RR'), '0', :docNum)";

    public static final String INSERT_RC_LINE_SO_UPDATE = "INSERT INTO RPRO_RC_LINE_G (ID, RC_ID, DOC_LINE_ID, EXT_SLL_PRC, EXT_FV_PRC, EXT_LST_PRC, REC_AMT, DEF_AMT, REL_PCT, NPV_INTEREST_RATE,"
            + " CURR, BOOK_ID, CLIENT_ID, RC_POB_ID, F_EX_RATE, G_EX_RATE, DOC_DATE, SEC_ATR_VAL, DOC_NUM, PRINCIPLE_AMT, START_DATE, END_DATE, SO_RIP_DATE)"
            + " VALUES (12, 11, :docLineId, 1800311, 85469022.72, 1187069.76, 1800311, 0, 100, 5.25, 'USD', 1, 1, 17, 1, 1, to_date('25-09-18','DD-MM-RR'), '0', :docNum, :principleAmt,"
            + " to_date('28-09-19','DD-MM-RR'), to_date('27-09-25','DD-MM-RR'), null)";

    public static final String INSERT_RC_LINE_RIP_LINE = "INSERT INTO RPRO_RC_LINE_G (ID, RC_ID, DOC_LINE_ID, EXT_SLL_PRC, EXT_FV_PRC, EXT_LST_PRC, REC_AMT, DEF_AMT, REL_PCT, NPV_INTEREST_RATE,"
            + " CURR, BOOK_ID, CLIENT_ID, RC_POB_ID, F_EX_RATE, G_EX_RATE, DOC_DATE, SEC_ATR_VAL, DOC_NUM, PRINCIPLE_AMT, START_DATE, END_DATE, SO_RIP_DATE)"
            + " VALUES (12, 11, :docLineId, 4209227, 228839865.12, 3178331.46, 4209227, 0, 100, 5.25, 'USD', 1, 1, 17, 1, 1, to_date('25-09-18','DD-MM-RR'), '0', :docNum, :principleAmt,"
            + " to_date('28-09-18','DD-MM-RR'), to_date('27-09-24','DD-MM-RR'), null)";

    public static final String INSERT_RC_LINE_PAYMENT_UPDATE = "INSERT INTO RPRO_RC_LINE_G (ID, RC_ID, DOC_LINE_ID, EXT_SLL_PRC, EXT_FV_PRC, EXT_LST_PRC, REC_AMT, DEF_AMT, REL_PCT, NPV_INTEREST_RATE,"
            + " CURR, BOOK_ID, CLIENT_ID, RC_POB_ID, F_EX_RATE, G_EX_RATE, DOC_DATE, SEC_ATR_VAL, DOC_NUM, PRINCIPLE_AMT, START_DATE, END_DATE, SO_RIP_DATE)"
            + " VALUES (12, 11, :docLineId, 1800311, 85469022.72, 1187069.76, 1800311, 0, 100, 5.25, 'USD', 1, 1, 17, 1, 1, to_date('25-09-18','DD-MM-RR'), '0', :docNum, :principleAmt,"
            + " to_date('28-09-18','DD-MM-RR'), to_date('27-09-24','DD-MM-RR'), null)";

    public static final String INSERT_RC_LINE_MULTIPLE = "INSERT INTO RPRO_RC_LINE_G (ID, RC_ID, DOC_LINE_ID, EXT_SLL_PRC, EXT_FV_PRC, EXT_LST_PRC, REC_AMT, DEF_AMT, REL_PCT, NPV_INTEREST_RATE,"
            + " CURR, BOOK_ID, CLIENT_ID, RC_POB_ID, F_EX_RATE, G_EX_RATE, DOC_DATE, SEC_ATR_VAL, DOC_NUM)"
            + " VALUES (:id, :rcId, :docLineId, :extSllPrc, :extFvPrc, :extSllPrc, :recAmt, :defAmt, :relPct, :npvInterestRate, :curr, 1, 1, :rcPobId, 1, 1, to_date('01-02-22','DD-MM-RR'), '0', :docNum)";

    public static final String INSERT_SFC_PAYMENT_DETAILS = "INSERT INTO RPRO_SFC_PAYMT_DET_G (ID,PAYMT_DATE,PAYMT_AMOUNT, DOC_LINE_ID,PAYMT_START_DT,PAYMT_END_DT, CLIENT_ID, SEC_ATR_VAL) "
            + "values (:id, :paymtDate, :paymtAmount, :docLineId, :paymtStartDate, :paymtEndDate, :clientId, :secAtrVal)";

    public static final String INSERT_SFC_PAYMENT_DETAILS_SO_UPDATE = "INSERT INTO RPRO_SFC_PAYMT_DET_G (ID,PAYMT_DATE,PAYMT_AMOUNT, NET_PAYMT_VALUE, INTEREST_ACCRUAL, "
            + " DOC_LINE_ID,PAYMT_START_DT,PAYMT_END_DT, CLIENT_ID, SEC_ATR_VAL) "
            + "values (:id, :paymtDate, :paymtAmount, :netPaymtValue, :interestAccrual, :docLineId, :paymtStartDate, :paymtEndDate, :clientId, :secAtrVal)";

    public static final String INSERT_RC_HEAD_DETAILS = "INSERT INTO RPRO_RC_HEAD_G (ID, BOOK_ID, CLIENT_ID, SEC_ATR_VAL) VALUES (11,1,1,'0')";

    public static final String INSERT_RC_HEAD_DETAILS_MULTIPLE = "INSERT INTO RPRO_RC_HEAD_G (ID, BOOK_ID, CLIENT_ID, SEC_ATR_VAL) VALUES (:id,1,1,'0')";

    public static final String INSERT_RC_POB_VALUES = "INSERT INTO RPRO_RC_POB_G (ID,NAME,POB_ID,POB_VERSION,RC_ID,COND_ID,LEAD_LINE_ID,CLIENT_ID,"
            + "INDICATORS,BOOK_ID,SEC_ATR_VAL) VALUES (17,'POB_INT_TEST_SFC_1',15,1,11,15,17,1,'SNNNNNNNNRNNNNNNNNNN',1,'0')";

    public static final String INSERT_RC_POB_VALUES_MULTIPLE = "INSERT INTO RPRO_RC_POB_G (ID,NAME,POB_ID,POB_VERSION,RC_ID,COND_ID,LEAD_LINE_ID,CLIENT_ID,"
            + "INDICATORS,BOOK_ID,SEC_ATR_VAL) VALUES (:id,:name,:pobId,:pobVersion,:rcId,:condId,:leadLineId,1,:indicators,1,'0')";

    public static final String INSERT_POB_TMPL_VALUES = "INSERT INTO RPRO_POB_TMPL_G (ID, VERSION, NAME, CLIENT_ID) "
            + "VALUES (15, 1, 'POB_INT_TEST_SFC', 1)";

    public static final String INSERT_POB_TMPL_VALUES_MULTIPLE = "INSERT INTO RPRO_POB_TMPL_G (ID, VERSION, NAME, CLIENT_ID) "
            + "VALUES (:id, :version, :name, 1)";

    public static final String INSERT_RC_POB_ACT_VALUES = "INSERT INTO RPRO_RC_POB_ACT_G (REL_ID, RC_ID, RC_POB_ID, EVENT_ID, SEC_ATR_VAL, BOOK_ID, CLIENT_ID) "
            + "VALUES (15, 11, 17, 3, '0', 1, 1)";

    public static final String INSERT_RC_POB_ACT_VALUES_MULTIPLE = "INSERT INTO RPRO_RC_POB_ACT_G (REL_ID, RC_ID, RC_POB_ID, EVENT_ID, SEC_ATR_VAL, BOOK_ID, CLIENT_ID) "
            + "VALUES (:relId, :rcId, :rcPobId, :eventId, '0', 1, 1)";

    public static final String INSERT_FINANCE_TYPE_VALUES = "INSERT INTO RPRO_FINANC_TYPE_G (ID,NAME,DESCRIPTION,VERSION,REV_REC_TYPE,INTEREST_RATE,ELIGIBLITY_COLUMN,"
            + "ELIGIBLITY_VALUE,PRNCL_WEIGHTAGE_COLUMN,START_DATE,END_DATE,INDICATORS,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SEQ) values "
            + "(21,'SFC','SFC with Interest Calculator',1,'DR_APR',null,null,null,:weightageColumn,to_date('01-01-15','DD-MM-RR'),"
            + "to_date('03-03-22','DD-MM-RR'),:indicators,1,201501,'MIGRATION',to_date('01-01-15','DD-MM-RR'),'MIGRATION',to_date('01-01-15','DD-MM-RR'),0)";

    public static final String INSERT_VC_TYPE_VALUES = "Insert into RPRO_VC_TYPE_G (ID,NAME,DESCRIPTION,INDICATORS,HOLD_BACK_SEGS,RELEASE_SEGS,CLIENT_ID,CRTD_PRD_ID,"
            + "CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SEQ,EXP_FLD_NAME,EXP_NUM) values (21,'SFC','SFC with Interest Calculator','YYNNNReDBdcLYYNNSNNNYYNNN',null,null,1,201501,"
            + "'MIGRATION',to_date('01-01-15', 'DD-MM-RR'),'SYSADMIN',to_date('05-07-22','DD-MM-RR'),0,null,null)";

    public static final String INSERT_POB_VC_LINE_VALUES = "INSERT INTO RPRO_POB_VC_LINE_G (ID,POB_TMPL_ID,POB_VERSION,VC_TYPE_ID,SEQ,INDICATORS,CLIENT_ID,CRTD_PRD_ID,"
            + "CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT) VALUES (21,15,1,:financeTypeId,2,'YNNNNNNNNNNNNNNNNNNN',1,201501,'MIGRATION',to_date('01-01-15','DD-MM-RR'),'SYSADMIN',to_date('05-07-22','DD-MM-RR'))";

    public static final String INSERT_POB_VC_LINE_VALUES_MULTIPLE = "INSERT INTO RPRO_POB_VC_LINE_G (ID,POB_TMPL_ID,POB_VERSION,VC_TYPE_ID,SEQ,INDICATORS,CLIENT_ID,CRTD_PRD_ID,"
            + "CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT) VALUES (:pobVcId,:pobId,1,:financeTypeId,2,'YNNNNNNNNNNNNNNNNNNN',1,201501,'MIGRATION',to_date('01-01-15','DD-MM-RR'),'SYSADMIN',to_date('05-07-22','DD-MM-RR'))";

    public static final String INSERT_RC_LINE_PA_SO_UPDATE = "INSERT INTO RPRO_RC_LINE_PA_G (ID,LINE_ID,VC_TYPE_ID,DEF_AMT,REC_AMT,PA_BASE_AMT,"
            + "APPLIED_PCT,VC_GRP_ID,INDICATORS,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,"
            + "BATCH_ID,SEC_ATR_VAL,BOOK_ID,RC_ID,HIER_SEQ,ACCRUED_AMT,CLEARED_AMT,EXPIRED_AMT,COMMENTS,"
            + "PA_BASE_QTY,EST_AMT,ACT_AMT,EST_QTY,ACT_QTY,VC_STRAT_ID,ORIG_EST_QTY,ORIG_EST_AMT,CLEARED_QTY,"
            + "ACCRUED_QTY,PARENT_ID,EXPIRY_DATE,START_DATE,END_DATE,CALCULATION_METHOD,INTEREST_RATE,FNC_TYPE_VERSION) "
            + "values (18,12,21,0,134858.61,134858.61,134858.61,null,'YNSNNNNNNNNNNNNNNNNN',1,202205,'SYSADMIN',"
            + "to_date('03-01-23','DD-MM-RR'),'SYSADMIN',to_date('03-01-23','DD-MM-RR'),null,'0',1,11,null,134858.61,0,null,"
            + "'SFC VC',1,0,134858.61,0,1,null,1,134858.61,0,null,null,null,null,null,null,null,1)";

    public static final String INSERT_RC_SCHD_SO_UPDATE = "INSERT INTO RPRO_RC_SCHD_G (ID,REL_ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,\n"
            + "INDICATORS,POST_DATE,PRD_ID,POST_PRD_ID,POST_BATCH_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,"
            + "ATR1,ATR2,ATR3,ATR4,ATR5,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,DIST_ID,REF_BILL_ID,"
            + "ROOT_LINE_ID,BOOK_ID,BLD_FX_DT,BLD_FX_RATE,RORD_INV_REF,ORIG_LINE_ID,DR_LINK_ID,CR_LINK_ID,MODEL_ID,JE_BATCH_ID,"
            + "JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT,UPDT_PRD_ID,SCHD_ADDL_ID) "
            + "values (:id,null,11,1,18,17,'USD',:amount,null,'NedNNNNNNNVNNNNNNNNNNNNNNNNNNNFNNNNNNNNN',null,:prdId,:postPrdId,"
            + "null,'9876','2345',1,1,to_date('25-09-18','DD-MM-RR'),null,null,null,null,null,1,202205,'0','SYSADMIN',"
            + "to_date('03-01-23','DD-MM-RR'),'SYSADMIN',to_date('03-01-23','DD-MM-RR'),null,1,12,1,null,null,null,"
            + "18,null,null,null,null,null,null,null,null,null,null)";



    public static final String RETRIEVE_PRINCIPLE_AMT_FOR_RC_LINE = "SELECT PRINCIPLE_AMT FROM RPRO_RC_LINE_G WHERE DOC_LINE_ID = :docLineId";
}
