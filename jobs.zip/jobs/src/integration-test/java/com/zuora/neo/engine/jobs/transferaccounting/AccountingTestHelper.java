package com.zuora.neo.engine.jobs.transferaccounting;

import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.transferaccounting.activities.AccountingActivitiesImpl;

import com.zuora.neo.engine.test.db.common.DbTestContext;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

public class AccountingTestHelper {
    private static long schdId1;
    private static long maxSchdId;
    private static  long maxMjeSchdId;
    private static long lineId1;
    private static long lineId2;
    private static long lineId3;
    private static long lineId4;
    private static long lineId5;
    private static long lineId6;
    private static long lineId7;
    private static long lineId8;
    private static long headId1;
    private static long headId2;
    private static long headId3;
    private static long headId4;
    private static long jeHeadId1;
    private static long jeHeadId2;
    private static long jeHeadId3;
    private static long jeHeadId4;
    private static List<Long> mjeLineId;
    private static List<Long> mjeJELineId;
    private static Long periodId;
    private static Long postPeriodId;
    private static Long crtdPeriodId;
    private static Long updtPeriodId;
    private static Long sobId;
    private static String sobName;

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AccountingActivitiesImpl.class);
    public static void regularSchdData()
    {
        schdId1 = 3500001;
        maxSchdId = schdId1;

        headId1 = 95000;
        headId2 = 95001;
        headId3 = 95002;
        headId4 = 95003;

        lineId1 = 95001;
        lineId2 = 95002;
        lineId3 = 95003;
        lineId4 = 95004;
        lineId5 = 95005;
        lineId6 = 95006;
        lineId7 = 95007;
        lineId8 = 95008;
        sobId = Long.valueOf(1);
        sobName = "1";
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            long prdId = handle.createQuery("SELECT id FROM rpro_period_g WHERE LOWER(status) IN ('pending', 'open') AND  book_id = 1 AND sec_atr_val = '5'").mapTo(long.class).first();
            long crtdPrdId = handle.createQuery("SELECT DISTINCT rp.ID prd_id FROM rpro_period_g rp WHERE rp.close_date IS NULL AND rp.book_id = nvl( 1, rp.book_id) AND rp.sec_atr_val = nvl('5', rp.sec_atr_val)").mapTo(long.class).first();
            periodId = prdId;
            postPeriodId = periodId;
            crtdPeriodId = crtdPrdId;
            updtPeriodId = periodId;
            insertIntoRproRcHead(handle);
            insertIntoRproRcLine(handle);
            insertIntoRproRcSchd(handle);
            LOGGER.info("               RC DATA INSERTED ");
        });

    }

    public static void deleteRegularSchdData()
    {
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            int row1=handle.createUpdate("delete from rpro_rc_schd where id between 3500001 and "+maxSchdId).execute();

            int row2=handle.createUpdate("delete from rpro_rc_head where id between 95000 and 95003").execute();

            int row3=handle.createUpdate("delete from rpro_rc_line where id between 95001 and 95008").execute();

            LOGGER.info("DELETE COUNT  "+row1+"  "+row2+"  "+row3);
        });
    }
    //TODO : need to change *sysadmin
    static void insertIntoRproRcSchd(Handle handle) {
        //long schdId = 3500001;
        for (int i = 0; i < 1; i++) {
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    " values(" + schdId1 + "," + headId1 + ",1," + lineId1 + ",18462,'USD',787.51,0,'NWXNNNNNNNANNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,1," + lineId1 + ",1,19928,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId1 + ",1," + lineId1 + ",18462,'USD',6835.37,0,'NLRNNNNNNNRNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-02-22',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,95000," + lineId1 + ",1,19930,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId1 + ",1," + lineId1 + ",18462,'USD',2189.01,0,'NNWNNNNNNNANYNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,NULL," + lineId1 + ",1,19928,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId1 + ",1," + lineId2 + ",18463,'USD',-2189.01,0,'NNWNNNNNNNANYNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,NULL," + lineId2 + ",1,19929,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId1 + ",1," + lineId2 + ",18463,'USD',-787.51,0,'NWXNNNNNNNANNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,1," + lineId2 + ",1,19929,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId1 + ",1," + lineId2 + ",18463,'USD',7195.12,0,'NLRNNNNNNNRNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-02-22',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,95001," + lineId2 + ",1,19931,0,0,0)").execute();
            schdId1++;
        }

        for (int i = 0; i < 1; i++) {
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    " values(" + schdId1 + "," + headId2 + ",1," + lineId3 + ",18462,'USD',787.51,0,'NWXNNNNNNNANNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,1," + lineId3 + ",1,19928,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId2 + ",1," + lineId3 + ",18462,'USD',6835.37,0,'NLRNNNNNNNRNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-02-22',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,95002," + lineId3 + ",1,19930,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId2 + ",1," + lineId3 + ",18462,'USD',2189.01,0,'NNWNNNNNNNANYNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,NULL," + lineId3 + ",1,19928,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId2 + ",1," + lineId4 + ",18463,'USD',-2189.01,0,'NNWNNNNNNNANYNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,NULL," + lineId4 + ",1,19929,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId2 + ",1," + lineId4 + ",18463,'USD',-787.51,0,'NWXNNNNNNNANNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,1," + lineId4 + ",1,19929,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId2 + ",1," + lineId4 + ",18463,'USD',7195.12,0,'NLRNNNNNNNRNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-02-22',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,95003," + lineId4 + ",1,19931,0,0,0)").execute();
            schdId1++;
        }

        for (int i = 0; i < 1; i++) {
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    " values(" + schdId1 + "," + headId3 + ",1," + lineId5 + ",18462,'USD',787.51,0,'NWXNNNNNNNANNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,1," + lineId5 + ",1,19928,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId3 + ",1," + lineId5 + ",18462,'USD',6835.37,0,'NLRNNNNNNNRNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-02-22',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,95004," + lineId5 + ",1,19930,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId3 + ",1," + lineId5 + ",18462,'USD',2189.01,0,'NNWNNNNNNNANYNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,NULL," + lineId5 + ",1,19928,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId3 + ",1," + lineId6 + ",18463,'USD',-2189.01,0,'NNWNNNNNNNANYNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,NULL," + lineId6 + ",1,19929,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId3 + ",1," + lineId6 + ",18463,'USD',-787.51,0,'NWXNNNNNNNANNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,1," + lineId6 + ",1,19929,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId3 + ",1," + lineId6 + ",18463,'USD',7195.12,0,'NLRNNNNNNNRNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-02-22',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,95005," + lineId6 + ",1,19931,0,0,0)").execute();
            schdId1++;
        }

        for (int i = 0; i < 1; i++) {
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    " values(" + schdId1 + "," + headId4 + ",1," + lineId7 + ",18462,'USD',787.51,0,'NWXNNNNNNNANNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,1," + lineId7 + ",1,19928,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId4 + ",1," + lineId7 + ",18462,'USD',6835.37,0,'NLRNNNNNNNRNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-02-22',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,95006," + lineId7 + ",1,19930,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId4 + ",1," + lineId7 + ",18462,'USD',2189.01,0,'NNWNNNNNNNANYNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,NULL," + lineId7 + ",1,19928,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId4 + ",1," + lineId8 + ",18463,'USD',-2189.01,0,'NNWNNNNNNNANYNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,NULL," + lineId8 + ",1,19929,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId4 + ",1," + lineId8 + ",18463,'USD',-787.51,0,'NWXNNNNNNNANNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-08-21',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,1," + lineId8 + ",1,19929,0,0,0)").execute();
            schdId1++;
            handle.createUpdate("insert into rpro_rc_schd(ID,RC_ID,RC_VER,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,EX_RATE_DATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,PP_AMT,PQ_AMT,PY_AMT)" +
                    "values(" + schdId1 + "," + headId4 + ",1," + lineId8 + ",18463,'USD',7195.12,0,'NLRNNNNNNNRNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'104:21:00','104:21:00',1,1,'01-02-22',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,95007," + lineId8 + ",1,19931,0,0,0)").execute();
            schdId1++;
        }
        maxSchdId = schdId1;
    }

    static void insertIntoRproRcHead(Handle handle)
    {
        handle.createUpdate("INSERT INTO rpro_rc_head(ID,VERSION,BATCH_ID,BOOK_ID,LIST_AMT,SELL_AMT,TOT_CV_AMT,TMPL_ID,OBJ_VERSION,INDICATORS,FV_DATE,CURR,F_CUR" +
                ",F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INIT_POB_EXP_DT,CSTMR_NM,CT_MOD_END_DT,ACCT_UPDT_DT,LIFECYCLE_CHANGE_DT) " +
                "values("+headId1+",1,11658,1,51000,39000,2189.01,10020,0,'NNDNNYNNNANNNYRNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN','01-08-21','USD','USD',1,1,1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,'28-02-22','SSL','28-02-22',SYSDATE,SYSDATE)").execute();

        handle.createUpdate("INSERT INTO rpro_rc_head(ID,VERSION,BATCH_ID,BOOK_ID,LIST_AMT,SELL_AMT,TOT_CV_AMT,TMPL_ID,OBJ_VERSION,INDICATORS,FV_DATE,CURR,F_CUR" +
                ",F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INIT_POB_EXP_DT,CSTMR_NM,CT_MOD_END_DT,ACCT_UPDT_DT,LIFECYCLE_CHANGE_DT) " +
                "values("+headId2+",1,11658,1,51000,39000,2189.01,10020,0,'NNDNNYNNNANNNYRNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN','01-08-21','USD','USD',1,1,1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,'28-02-22','SSL','28-02-22',SYSDATE,SYSDATE)").execute();

        handle.createUpdate("INSERT INTO rpro_rc_head(ID,VERSION,BATCH_ID,BOOK_ID,LIST_AMT,SELL_AMT,TOT_CV_AMT,TMPL_ID,OBJ_VERSION,INDICATORS,FV_DATE,CURR,F_CUR" +
                ",F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INIT_POB_EXP_DT,CSTMR_NM,CT_MOD_END_DT,ACCT_UPDT_DT,LIFECYCLE_CHANGE_DT) " +
                "values("+headId3+",1,11658,1,51000,39000,2189.01,10020,0,'NNDNNYNNNANNNYRNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN','01-08-21','USD','USD',1,1,1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,'28-02-22','SSL','28-02-22',SYSDATE,SYSDATE)").execute();

        handle.createUpdate("INSERT INTO rpro_rc_head(ID,VERSION,BATCH_ID,BOOK_ID,LIST_AMT,SELL_AMT,TOT_CV_AMT,TMPL_ID,OBJ_VERSION,INDICATORS,FV_DATE,CURR,F_CUR" +
                ",F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INIT_POB_EXP_DT,CSTMR_NM,CT_MOD_END_DT,ACCT_UPDT_DT,LIFECYCLE_CHANGE_DT) " +
                "values("+headId4+",1,11658,1,51000,39000,2189.01,10020,0,'NNDNNYNNNANNNYRNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN','01-08-21','USD','USD',1,1,1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,'28-02-22','SSL','28-02-22',SYSDATE,SYSDATE)").execute();

    }

    static void insertIntoRproRcLine(Handle handle)//SAAS prod family,company code 50,booking amount, CV_AMT_IMPRTMT is NULL
    {

        handle.createUpdate("INSERT INTO rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,EXT_SLL_PRC,EXT_FV_PRC,DEF_AMT,REC_AMT,CV_AMT,ALCTBL_XT_PRC,ALCTD_XT_PRC,BLD_DEF_AMT,BLD_REC_AMT,CSTMR_NM,DOC_NUM,DOC_DATE" +
                ",DOC_LINE_NUM,DOC_LINE_ID,ITEM_NUM,ORD_QTY,INV_QTY,START_DATE,END_DATE,EXT_LST_PRC,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,DISC_AMT,DISC_PCT,ALCTBL_FN_XT_PRC,REF_DOC,FV_GRP_ID" +
                ",FV_PRC,FV_TYPE,DEF_SEGMENTS,REV_SEGMENTS,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,UNSCHD_ADJ,POSTED_PCT,REL_PCT,TERM,CUST_NUM,CUM_CV_AMT,CUM_ALCTD_AMT,FV_DATE,ORIG_FV_DT,VC_AMT" +
                ",UNIT_SELL_PRC,UNIT_LIST_PRC,IMPAIR_RETRIEVE_AMT,BELOW_FV_PRC,ABOVE_FV_PRC,FV_TMPL_ID,FV_EXPR,PRICE_POINT,ORIG_QUANTITY,NET_SLL_PRC,NET_LST_PRC,CV_AMT_IMPRTMT,AVG_PRCING_MTHD,UPDT_PRD_ID,SOB_ID)" +
                "values("+lineId1+","+headId1+",'SO',18462,19000,49227.27,0,19000,2189.01,19000,21189.01,0,19000,'SSL','SSL451','01-08-21','5','SSL451.1','Phone',1,1,'01-02-22','23-04-22',22000" +
                ",'YNNNNNNNNNNNNNNNRNNNNNNNNNNNNNNNNNNNNNYNNNYNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',11658,1,'USD','USD',1,1,3000,13.64,19000" +
                ",'                                                            SSL451                        1                             SSL451.1                                                                                                                                                             01-AUG-2021    '" +
                ",-1,16409.0909090909090909090909090909090909,'SSP','103:20:00','104:21:00',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,0,0,100,3,10,2189.01,21189.01,'01-08-21','01-08-21',0" +
                ",6333.333333333333333333333333333333333333,7333.333333333333333333333333333333333333,0,46765.9090909090909090909090909090909092,51688.6363636363636363636363636363636362,10040" +
                ",'EXT_SLL_PRC*(EXT_SLL_PRC/EXT_LST_PRC)','SPBR-Mid Point',1,19000,22000,0,'VOLUME',"+ updtPeriodId +","+sobId+")").execute();

        handle.createUpdate("INSERT INTO rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,EXT_SLL_PRC,EXT_FV_PRC,DEF_AMT,REC_AMT,CV_AMT,ALCTBL_XT_PRC,ALCTD_XT_PRC,BLD_DEF_AMT,BLD_REC_AMT,CSTMR_NM,DOC_NUM,DOC_DATE" +
                ",DOC_LINE_NUM,DOC_LINE_ID,ITEM_NUM,ORD_QTY,INV_QTY,START_DATE,END_DATE,EXT_LST_PRC,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,DISC_AMT,DISC_PCT,ALCTBL_FN_XT_PRC,REF_DOC,FV_GRP_ID" +
                ",FV_PRC,FV_TYPE,DEF_SEGMENTS,REV_SEGMENTS,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,UNSCHD_ADJ,POSTED_PCT,REL_PCT,TERM,CUST_NUM,CUM_CV_AMT,CUM_ALCTD_AMT,FV_DATE,ORIG_FV_DT,VC_AMT" +
                ",UNIT_SELL_PRC,UNIT_LIST_PRC,IMPAIR_RETRIEVE_AMT,BELOW_FV_PRC,ABOVE_FV_PRC,FV_TMPL_ID,FV_EXPR,PRICE_POINT,ORIG_QUANTITY,NET_SLL_PRC,NET_LST_PRC,CV_AMT_IMPRTMT,AVG_PRCING_MTHD,UPDT_PRD_ID,SOB_ID)" +
                "values("+lineId2+","+headId1+",'SO',18463,20000,41379.31,0,20000,-2189.01,20000,17810.99,0,20000,'SSL','SSL451','01-08-21','2','SSL451.2','Phone',1,1,'01-02-22','23-04-22',29000," +
                "'YNNNNNNNNNNNNNNNRNNNNNNNNNNNNNNNNNNNNNYNNNYNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',11658,1,'USD','USD',1,1,9000,31.03,20000" +
                ",'                                                            SSL451                        2                             SSL451.2                                                                                                                                                             01-AUG-2021    '" +
                ",-1,13793.1034482758620689655172413793103448,'SSP','103:20:00','104:21:00',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,0,0,100,3,10,-2189.01,17810.99,'01-08-21','01-08-21',0" +
                ",6666.666666666666666666666666666666666667,9666.666666666666666666666666666666666667,0,39310.3448275862068965517241379310344828,43448.275862068965517241379310344827586,10040" +
                ",'EXT_SLL_PRC*(EXT_SLL_PRC/EXT_LST_PRC)','SPBR-Mid Point',1,20000,29000,0,'VOLUME',"+ updtPeriodId +","+sobId+")").execute();

        handle.createUpdate("INSERT INTO rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,EXT_SLL_PRC,EXT_FV_PRC,DEF_AMT,REC_AMT,CV_AMT,ALCTBL_XT_PRC,ALCTD_XT_PRC,BLD_DEF_AMT,BLD_REC_AMT,CSTMR_NM,DOC_NUM,DOC_DATE" +
                ",DOC_LINE_NUM,DOC_LINE_ID,ITEM_NUM,ORD_QTY,INV_QTY,START_DATE,END_DATE,EXT_LST_PRC,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,DISC_AMT,DISC_PCT,ALCTBL_FN_XT_PRC,REF_DOC,FV_GRP_ID" +
                ",FV_PRC,FV_TYPE,DEF_SEGMENTS,REV_SEGMENTS,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,UNSCHD_ADJ,POSTED_PCT,REL_PCT,TERM,CUST_NUM,CUM_CV_AMT,CUM_ALCTD_AMT,FV_DATE,ORIG_FV_DT,VC_AMT" +
                ",UNIT_SELL_PRC,UNIT_LIST_PRC,IMPAIR_RETRIEVE_AMT,BELOW_FV_PRC,ABOVE_FV_PRC,FV_TMPL_ID,FV_EXPR,PRICE_POINT,ORIG_QUANTITY,NET_SLL_PRC,NET_LST_PRC,CV_AMT_IMPRTMT,AVG_PRCING_MTHD,UPDT_PRD_ID,SOB_ID)" +
                "values("+lineId3+","+headId2+",'SO',18462,19000,49227.27,0,19000,2189.01,19000,21189.01,0,19000,'SSL','SSL451','01-08-21','5','SSL451.1','Phone',1,1,'01-02-22','23-04-22',22000" +
                ",'YNNNNNNNNNNNNNNNRNNNNNNNNNNNNNNNNNNNNNYNNNYNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',11658,1,'USD','USD',1,1,3000,13.64,19000" +
                ",'                                                            SSL451                        1                             SSL451.1                                                                                                                                                             01-AUG-2021    '" +
                ",-1,16409.0909090909090909090909090909090909,'SSP','103:20:00','104:21:00',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,0,0,100,3,10,2189.01,21189.01,'01-08-21','01-08-21',0" +
                ",6333.333333333333333333333333333333333333,7333.333333333333333333333333333333333333,0,46765.9090909090909090909090909090909092,51688.6363636363636363636363636363636362,10040" +
                ",'EXT_SLL_PRC*(EXT_SLL_PRC/EXT_LST_PRC)','SPBR-Mid Point',1,19000,22000,0,'VOLUME',"+ updtPeriodId +","+sobId+")").execute();

        handle.createUpdate("INSERT INTO rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,EXT_SLL_PRC,EXT_FV_PRC,DEF_AMT,REC_AMT,CV_AMT,ALCTBL_XT_PRC,ALCTD_XT_PRC,BLD_DEF_AMT,BLD_REC_AMT,CSTMR_NM,DOC_NUM,DOC_DATE" +
                ",DOC_LINE_NUM,DOC_LINE_ID,ITEM_NUM,ORD_QTY,INV_QTY,START_DATE,END_DATE,EXT_LST_PRC,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,DISC_AMT,DISC_PCT,ALCTBL_FN_XT_PRC,REF_DOC,FV_GRP_ID" +
                ",FV_PRC,FV_TYPE,DEF_SEGMENTS,REV_SEGMENTS,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,UNSCHD_ADJ,POSTED_PCT,REL_PCT,TERM,CUST_NUM,CUM_CV_AMT,CUM_ALCTD_AMT,FV_DATE,ORIG_FV_DT,VC_AMT" +
                ",UNIT_SELL_PRC,UNIT_LIST_PRC,IMPAIR_RETRIEVE_AMT,BELOW_FV_PRC,ABOVE_FV_PRC,FV_TMPL_ID,FV_EXPR,PRICE_POINT,ORIG_QUANTITY,NET_SLL_PRC,NET_LST_PRC,CV_AMT_IMPRTMT,AVG_PRCING_MTHD,UPDT_PRD_ID,SOB_ID)" +
                "values("+lineId4+","+headId2+",'SO',18463,20000,41379.31,0,20000,-2189.01,20000,17810.99,0,20000,'SSL','SSL451','01-08-21','2','SSL451.2','Phone',1,1,'01-02-22','23-04-22',29000," +
                "'YNNNNNNNNNNNNNNNRNNNNNNNNNNNNNNNNNNNNNYNNNYNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',11658,1,'USD','USD',1,1,9000,31.03,20000" +
                ",'                                                            SSL451                        2                             SSL451.2                                                                                                                                                             01-AUG-2021    '" +
                ",-1,13793.1034482758620689655172413793103448,'SSP','103:20:00','104:21:00',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,0,0,100,3,10,-2189.01,17810.99,'01-08-21','01-08-21',0" +
                ",6666.666666666666666666666666666666666667,9666.666666666666666666666666666666666667,0,39310.3448275862068965517241379310344828,43448.275862068965517241379310344827586,10040" +
                ",'EXT_SLL_PRC*(EXT_SLL_PRC/EXT_LST_PRC)','SPBR-Mid Point',1,20000,29000,0,'VOLUME',"+ updtPeriodId +","+sobId+")").execute();

        handle.createUpdate("INSERT INTO rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,EXT_SLL_PRC,EXT_FV_PRC,DEF_AMT,REC_AMT,CV_AMT,ALCTBL_XT_PRC,ALCTD_XT_PRC,BLD_DEF_AMT,BLD_REC_AMT,CSTMR_NM,DOC_NUM,DOC_DATE" +
                ",DOC_LINE_NUM,DOC_LINE_ID,ITEM_NUM,ORD_QTY,INV_QTY,START_DATE,END_DATE,EXT_LST_PRC,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,DISC_AMT,DISC_PCT,ALCTBL_FN_XT_PRC,REF_DOC,FV_GRP_ID" +
                ",FV_PRC,FV_TYPE,DEF_SEGMENTS,REV_SEGMENTS,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,UNSCHD_ADJ,POSTED_PCT,REL_PCT,TERM,CUST_NUM,CUM_CV_AMT,CUM_ALCTD_AMT,FV_DATE,ORIG_FV_DT,VC_AMT" +
                ",UNIT_SELL_PRC,UNIT_LIST_PRC,IMPAIR_RETRIEVE_AMT,BELOW_FV_PRC,ABOVE_FV_PRC,FV_TMPL_ID,FV_EXPR,PRICE_POINT,ORIG_QUANTITY,NET_SLL_PRC,NET_LST_PRC,CV_AMT_IMPRTMT,AVG_PRCING_MTHD,UPDT_PRD_ID,SOB_ID)" +
                "values("+lineId5+","+headId3+",'SO',18462,19000,49227.27,0,19000,2189.01,19000,21189.01,0,19000,'SSL','SSL451','01-08-21','5','SSL451.1','Phone',1,1,'01-02-22','23-04-22',22000" +
                ",'YNNNNNNNNNNNNNNNRNNNNNNNNNNNNNNNNNNNNNYNNNYNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',11658,1,'USD','USD',1,1,3000,13.64,19000" +
                ",'                                                            SSL451                        1                             SSL451.1                                                                                                                                                             01-AUG-2021    '" +
                ",-1,16409.0909090909090909090909090909090909,'SSP','103:20:00','104:21:00',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,0,0,100,3,10,2189.01,21189.01,'01-08-21','01-08-21',0" +
                ",6333.333333333333333333333333333333333333,7333.333333333333333333333333333333333333,0,46765.9090909090909090909090909090909092,51688.6363636363636363636363636363636362,10040" +
                ",'EXT_SLL_PRC*(EXT_SLL_PRC/EXT_LST_PRC)','SPBR-Mid Point',1,19000,22000,0,'VOLUME',"+ updtPeriodId +","+sobId+")").execute();

        handle.createUpdate("INSERT INTO rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,EXT_SLL_PRC,EXT_FV_PRC,DEF_AMT,REC_AMT,CV_AMT,ALCTBL_XT_PRC,ALCTD_XT_PRC,BLD_DEF_AMT,BLD_REC_AMT,CSTMR_NM,DOC_NUM,DOC_DATE" +
                ",DOC_LINE_NUM,DOC_LINE_ID,ITEM_NUM,ORD_QTY,INV_QTY,START_DATE,END_DATE,EXT_LST_PRC,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,DISC_AMT,DISC_PCT,ALCTBL_FN_XT_PRC,REF_DOC,FV_GRP_ID" +
                ",FV_PRC,FV_TYPE,DEF_SEGMENTS,REV_SEGMENTS,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,UNSCHD_ADJ,POSTED_PCT,REL_PCT,TERM,CUST_NUM,CUM_CV_AMT,CUM_ALCTD_AMT,FV_DATE,ORIG_FV_DT,VC_AMT" +
                ",UNIT_SELL_PRC,UNIT_LIST_PRC,IMPAIR_RETRIEVE_AMT,BELOW_FV_PRC,ABOVE_FV_PRC,FV_TMPL_ID,FV_EXPR,PRICE_POINT,ORIG_QUANTITY,NET_SLL_PRC,NET_LST_PRC,CV_AMT_IMPRTMT,AVG_PRCING_MTHD,UPDT_PRD_ID,SOB_ID)" +
                "values("+lineId6+","+headId3+",'SO',18463,20000,41379.31,0,20000,-2189.01,20000,17810.99,0,20000,'SSL','SSL451','01-08-21','2','SSL451.2','Phone',1,1,'01-02-22','23-04-22',29000," +
                "'YNNNNNNNNNNNNNNNRNNNNNNNNNNNNNNNNNNNNNYNNNYNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',11658,1,'USD','USD',1,1,9000,31.03,20000" +
                ",'                                                            SSL451                        2                             SSL451.2                                                                                                                                                             01-AUG-2021    '" +
                ",-1,13793.1034482758620689655172413793103448,'SSP','103:20:00','104:21:00',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,0,0,100,3,10,-2189.01,17810.99,'01-08-21','01-08-21',0" +
                ",6666.666666666666666666666666666666666667,9666.666666666666666666666666666666666667,0,39310.3448275862068965517241379310344828,43448.275862068965517241379310344827586,10040" +
                ",'EXT_SLL_PRC*(EXT_SLL_PRC/EXT_LST_PRC)','SPBR-Mid Point',1,20000,29000,0,'VOLUME',"+ updtPeriodId +","+sobId+")").execute();

        handle.createUpdate("INSERT INTO rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,EXT_SLL_PRC,EXT_FV_PRC,DEF_AMT,REC_AMT,CV_AMT,ALCTBL_XT_PRC,ALCTD_XT_PRC,BLD_DEF_AMT,BLD_REC_AMT,CSTMR_NM,DOC_NUM,DOC_DATE" +
                ",DOC_LINE_NUM,DOC_LINE_ID,ITEM_NUM,ORD_QTY,INV_QTY,START_DATE,END_DATE,EXT_LST_PRC,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,DISC_AMT,DISC_PCT,ALCTBL_FN_XT_PRC,REF_DOC,FV_GRP_ID" +
                ",FV_PRC,FV_TYPE,DEF_SEGMENTS,REV_SEGMENTS,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,UNSCHD_ADJ,POSTED_PCT,REL_PCT,TERM,CUST_NUM,CUM_CV_AMT,CUM_ALCTD_AMT,FV_DATE,ORIG_FV_DT,VC_AMT" +
                ",UNIT_SELL_PRC,UNIT_LIST_PRC,IMPAIR_RETRIEVE_AMT,BELOW_FV_PRC,ABOVE_FV_PRC,FV_TMPL_ID,FV_EXPR,PRICE_POINT,ORIG_QUANTITY,NET_SLL_PRC,NET_LST_PRC,CV_AMT_IMPRTMT,AVG_PRCING_MTHD,UPDT_PRD_ID,SOB_ID)" +
                "values("+lineId7+","+headId4+",'SO',18462,19000,49227.27,0,19000,2189.01,19000,21189.01,0,19000,'SSL','SSL451','01-08-21','5','SSL451.1','Phone',1,1,'01-02-22','23-04-22',22000" +
                ",'YNNNNNNNNNNNNNNNRNNNNNNNNNNNNNNNNNNNNNYNNNYNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',11658,1,'USD','USD',1,1,3000,13.64,19000" +
                ",'                                                            SSL451                        1                             SSL451.1                                                                                                                                                             01-AUG-2021    '" +
                ",-1,16409.0909090909090909090909090909090909,'SSP','103:20:00','104:21:00',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,0,0,100,3,10,2189.01,21189.01,'01-08-21','01-08-21',0" +
                ",6333.333333333333333333333333333333333333,7333.333333333333333333333333333333333333,0,46765.9090909090909090909090909090909092,51688.6363636363636363636363636363636362,10040" +
                ",'EXT_SLL_PRC*(EXT_SLL_PRC/EXT_LST_PRC)','SPBR-Mid Point',1,19000,22000,0,'VOLUME',"+ updtPeriodId +","+sobId+")").execute();

        handle.createUpdate("INSERT INTO rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,EXT_SLL_PRC,EXT_FV_PRC,DEF_AMT,REC_AMT,CV_AMT,ALCTBL_XT_PRC,ALCTD_XT_PRC,BLD_DEF_AMT,BLD_REC_AMT,CSTMR_NM,DOC_NUM,DOC_DATE" +
                ",DOC_LINE_NUM,DOC_LINE_ID,ITEM_NUM,ORD_QTY,INV_QTY,START_DATE,END_DATE,EXT_LST_PRC,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,DISC_AMT,DISC_PCT,ALCTBL_FN_XT_PRC,REF_DOC,FV_GRP_ID" +
                ",FV_PRC,FV_TYPE,DEF_SEGMENTS,REV_SEGMENTS,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,UNSCHD_ADJ,POSTED_PCT,REL_PCT,TERM,CUST_NUM,CUM_CV_AMT,CUM_ALCTD_AMT,FV_DATE,ORIG_FV_DT,VC_AMT" +
                ",UNIT_SELL_PRC,UNIT_LIST_PRC,IMPAIR_RETRIEVE_AMT,BELOW_FV_PRC,ABOVE_FV_PRC,FV_TMPL_ID,FV_EXPR,PRICE_POINT,ORIG_QUANTITY,NET_SLL_PRC,NET_LST_PRC,CV_AMT_IMPRTMT,AVG_PRCING_MTHD,UPDT_PRD_ID,SOB_ID)" +
                "values("+lineId8+","+headId4+",'SO',18463,20000,41379.31,0,20000,-2189.01,20000,17810.99,0,20000,'SSL','SSL451','01-08-21','2','SSL451.2','Phone',1,1,'01-02-22','23-04-22',29000," +
                "'YNNNNNNNNNNNNNNNRNNNNNNNNNNNNNNNNNNNNNYNNNYNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',11658,1,'USD','USD',1,1,9000,31.03,20000" +
                ",'                                                            SSL451                        2                             SSL451.2                                                                                                                                                             01-AUG-2021    '" +
                ",-1,13793.1034482758620689655172413793103448,'SSP','103:20:00','104:21:00',1,"+ crtdPeriodId +",'5','SYSADMIN',SYSDATE,'SYSADMIN',SYSDATE,0,0,100,3,10,-2189.01,17810.99,'01-08-21','01-08-21',0" +
                ",6666.666666666666666666666666666666666667,9666.666666666666666666666666666666666667,0,39310.3448275862068965517241379310344828,43448.275862068965517241379310344827586,10040" +
                ",'EXT_SLL_PRC*(EXT_SLL_PRC/EXT_LST_PRC)','SPBR-Mid Point',1,20000,29000,0,'VOLUME',"+ updtPeriodId +","+sobId+")").execute();
    }


    public static void mjeSchdData()
    {
        schdId1 = 3600001;
        maxMjeSchdId = schdId1;
        headId1 = 100000;
        headId2 = 100001;
        headId3 = 100002;
        headId4 = 100003;

        jeHeadId1 = 100000;
        jeHeadId2 = 100001;
        jeHeadId3 = 100002;
        jeHeadId4 = 100003;
        sobId = Long.valueOf(1);
        sobName = "5";
        mjeLineId =  Arrays.asList(new Long(100001), new Long(100002), new Long(100003), new Long(100004), new Long(100005), new Long(100006),
                new Long(100007), new Long(100008), new Long(100009), new Long(100010), new Long(100011), new Long(100012),
                new Long(100013), new Long(100014), new Long(100015), new Long(100016), new Long(100017), new Long(100018),
                new Long(100019), new Long(100020));
        mjeJELineId = Arrays.asList(new Long(100001), new Long(100002), new Long(100003), new Long(100004), new Long(100005), new Long(100006),
                new Long(100007), new Long(100008), new Long(100009), new Long(100010), new Long(100011), new Long(100012),
                new Long(100013), new Long(100014), new Long(100015), new Long(100016), new Long(100017), new Long(100018),
                new Long(100019), new Long(100020));

        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            long prdId = handle.createQuery("SELECT id FROM rpro_period_g WHERE LOWER(status) IN ('pending', 'open') AND  book_id = 1 AND sec_atr_val = '5'").mapTo(long.class).first();
            long crtdPrdId = handle.createQuery("SELECT DISTINCT rp.ID prd_id FROM rpro_period_g rp WHERE rp.close_date IS NULL AND rp.book_id = nvl( 1, rp.book_id) AND rp.sec_atr_val = nvl('5', rp.sec_atr_val)").mapTo(long.class).first();
            periodId = prdId;
            postPeriodId = periodId;
            crtdPeriodId = crtdPrdId;
            updtPeriodId = periodId;
            insertIntoMjeRproRcHead(handle);
            insertIntoMjeRproJeRcHead(handle);
            insertIntoMjeRproRcLine(handle);
            insertIntoMjeRproRcJeLine(handle);
            insertIntoMjeRproRcSchd(handle);
            LOGGER.info("               MJE DATA INSERTED ");
        });

    }

    public static void deleteMjeSchdData()
    {
        Jdbi jdbi = DbTestContext.getConnection();
        jdbi.useHandle(handle -> {
            int row1=handle.createUpdate("delete from rpro_rc_schd_g where id between 3600001 and "+maxMjeSchdId).execute();
            int row2=handle.createUpdate("delete from rpro_rc_head_g where id between 100000 and 100003").execute();
            int row3=handle.createUpdate("delete from rpro_je_head_g where id between 100000 and 100003").execute();
            int row4=handle.createUpdate("delete from rpro_rc_line_g where id between 100001 and 100020").execute();
            int row5=handle.createUpdate("delete from rpro_je_line_g where id between 100001 and 100020").execute();
            LOGGER.info("DELETE COUNT  "+row1+"  "+row2+"  "+row3+"  "+row4+"  "+row5);
        });
    }





    private static void insertIntoMjeRproRcHead(Handle handle)//SEC_ATR_val
    {
        handle.createUpdate("INSERT into Rpro_rc_head(ID,VERSION,BATCH_ID,BOOK_ID,OBJ_VERSION,INDICATORS,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,ACCT_UPDT_DT,LIFECYCLE_CHANGE_DT) " +
                "VALUES("+headId1+",1,-1,1,1,'NNENNYNNNANNNNRNNNNNYNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','MONI','03-01-23','03-01-23','03-01-23')").execute();

        handle.createUpdate("INSERT into Rpro_rc_head(ID,VERSION,BATCH_ID,BOOK_ID,OBJ_VERSION,INDICATORS,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,ACCT_UPDT_DT,LIFECYCLE_CHANGE_DT) " +
                "VALUES("+headId2+",1,-1,1,1,'NNENNYNNNANNNNRNNNNNYNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','MONI','03-01-23','03-01-23','03-01-23')").execute();

        handle.createUpdate("INSERT into Rpro_rc_head(ID,VERSION,BATCH_ID,BOOK_ID,OBJ_VERSION,INDICATORS,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,ACCT_UPDT_DT,LIFECYCLE_CHANGE_DT) " +
                "VALUES("+headId3+",1,-1,1,1,'NNENNYNNNANNNNRNNNNNYNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','MONI','03-01-23','03-01-23','03-01-23')").execute();

        handle.createUpdate("INSERT into Rpro_rc_head(ID,VERSION,BATCH_ID,BOOK_ID,OBJ_VERSION,INDICATORS,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,ACCT_UPDT_DT,LIFECYCLE_CHANGE_DT) " +
                "VALUES("+headId4+",1,-1,1,1,'NNENNYNNNANNNNRNNNNNYNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','MONI','03-01-23','03-01-23','03-01-23')").execute();

    }

    private static void insertIntoMjeRproRcLine(Handle handle)//F_CURR and SOB id need to be null  || SEC_ATR_VAL
    {
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(0)+","+headId1+",'MJE',19267,'Activity type1','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(1)+","+headId1+",'MJE',19268,'Activity type1','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(2)+","+headId1+",'MJE',19269,'Activity type2','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(3)+","+headId1+",'MJE',19270,'Activity type2','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(4)+","+headId1+",'MJE',19271,'Activity type2','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();

        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(5)+","+headId2+",'MJE',19272,'Activity type1','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(6)+","+headId2+",'MJE',19273,'Activity type1','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(7)+","+headId2+",'MJE',19274,'Activity type2','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId+",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(8)+","+headId2+",'MJE',19275,'Activity type2','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(9)+","+headId2+",'MJE',19276,'Activity type2','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();

        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(10)+","+headId3+",'MJE',19277,'Activity type1','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(11)+","+headId3+",'MJE',19278,'Activity type1','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(12)+","+headId3+",'MJE',19279,'Activity type2','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(13)+","+headId3+",'MJE',19280,'Activity type2','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(14)+","+headId3+",'MJE',19281,'Activity type2','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();

        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(15)+","+headId4+",'MJE',19282,'Activity type1','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(16)+","+headId4+",'MJE',19283,'Activity type1','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(17)+","+headId4+",'MJE',19284,'Activity type2','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(18)+","+headId4+",'MJE',19285,'Activity type2','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();
        handle.createUpdate("INSERT into Rpro_rc_line(ID,RC_ID,TYPE,RC_POB_ID,CSTMR_NM,INDICATORS,BATCH_ID,BOOK_ID,CURR,F_CUR,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,SOB_ID) " +
                "VALUES("+mjeLineId.get(19)+","+headId4+",'MJE',19286,'Activity type2','YNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNI',-1,1,'USD',NULL,1,1,1,"+ crtdPeriodId +",'5','SYSTEM','03-01-23','SYSTEM','03-01-23',"+sobId+")").execute();

    }

    private static void insertIntoMjeRproRcSchd(Handle handle)
    {

        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010390,"+headId1+","+mjeJELineId.get(0)+",19267,'USD',1500,0,'NLNNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'301:302:303',NULL,1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(0)+",1,"+mjeJELineId.get(0)+","+jeHeadId1+",'test107',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010392,"+headId1+","+mjeJELineId.get(1)+",19268,'USD',1000,0,'NLNNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'301:302:304',NULL,1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(1)+",1,"+mjeJELineId.get(1)+","+jeHeadId1+",'test107',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010394,"+headId1+","+mjeJELineId.get(2)+",19269,'USD',500,0,'NNRNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",NULL,'402:405:403',1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(2)+",1,"+mjeJELineId.get(2)+","+jeHeadId1+",'test107',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010396,"+headId1+","+mjeJELineId.get(3)+",19270,'USD',600,0,'NNRNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",NULL,'402:405:403',1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(3)+",1,"+mjeJELineId.get(3)+","+jeHeadId1+",'test107',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010398,"+headId1+","+mjeJELineId.get(4)+",19271,'USD',1400,0,'NNRNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",NULL,'402:405:405',1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(4)+",1,"+mjeJELineId.get(4)+","+jeHeadId1+",'test107',0,0,0)").execute();
        schdId1++;


        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010400,"+headId2+","+mjeJELineId.get(5)+",19272,'USD',1500,0,'NLNNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'301:302:303',NULL,1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(5)+",1,"+mjeJELineId.get(5)+","+jeHeadId2+",'test108',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010402,"+headId2+","+mjeJELineId.get(6)+",19273,'USD',1000,0,'NLNNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'301:302:304',NULL,1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(6)+",1,"+mjeJELineId.get(6)+","+jeHeadId2+",'test108',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010404,"+headId2+","+mjeJELineId.get(7)+",19274,'USD',500,0,'NNRNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",NULL,'402:405:403',1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(7)+",1,"+mjeJELineId.get(7)+","+jeHeadId2+",'test108',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010406,"+headId2+","+mjeJELineId.get(8)+",19275,'USD',600,0,'NNRNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",NULL,'402:405:403',1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(8)+",1,"+mjeJELineId.get(8)+","+jeHeadId2+",'test108',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010408,"+headId2+","+mjeJELineId.get(9)+",19276,'USD',1400,0,'NNRNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",NULL,'402:405:405',1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(9)+",1,"+mjeJELineId.get(9)+","+jeHeadId2+",'test108',0,0,0)").execute();
        schdId1++;


        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010410,"+headId3+","+mjeJELineId.get(10)+",19277,'USD',1500,0,'NLNNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'301:302:303',NULL,1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(10)+",1,"+mjeJELineId.get(10)+","+jeHeadId3+",'test109',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010412,"+headId3+","+mjeJELineId.get(11)+",19278,'USD',1000,0,'NLNNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'301:302:304',NULL,1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(11)+",1,"+mjeJELineId.get(11)+","+jeHeadId3+",'test109',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010414,"+headId3+","+mjeJELineId.get(12)+",19279,'USD',500,0,'NNRNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",NULL,'402:405:403',1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(12)+",1,"+mjeJELineId.get(12)+","+jeHeadId3+",'test109',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010416,"+headId3+","+mjeJELineId.get(13)+",19280,'USD',600,0,'NNRNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",NULL,'402:405:403',1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(13)+",1,"+mjeJELineId.get(13)+","+jeHeadId3+",'test109',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010418,"+headId3+","+mjeJELineId.get(14)+",19281,'USD',1400,0,'NNRNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",NULL,'402:405:405',1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(14)+",1,"+mjeJELineId.get(14)+","+jeHeadId3+",'test109',0,0,0)").execute();
        schdId1++;


        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010420,"+headId4+","+mjeJELineId.get(15)+",19282,'USD',1500,0,'NLNNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'301:302:303',NULL,1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(15)+",1,"+mjeJELineId.get(15)+","+jeHeadId4+",'test110',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010422,"+headId4+","+mjeJELineId.get(16)+",19283,'USD',1000,0,'NLNNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",'301:302:304',NULL,1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(16)+",1,"+mjeJELineId.get(16)+","+jeHeadId4+",'test110',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010424,"+headId4+","+mjeJELineId.get(17)+",19284,'USD',500,0,'NNRNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",NULL,'402:405:403',1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(17)+",1,"+mjeJELineId.get(17)+","+jeHeadId4+",'test110',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010426,"+headId4+","+mjeJELineId.get(18)+",19285,'USD',600,0,'NNRNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",NULL,'402:405:403',1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(18)+",1,"+mjeJELineId.get(18)+","+jeHeadId4+",'test110',0,0,0)").execute();
        schdId1++;
        handle.createUpdate("INSERT into Rpro_rc_schd(ID,REL_ID,RC_ID,LINE_ID,POB_ID,CURR,AMOUNT,REL_PCT,INDICATORS,PRD_ID,POST_PRD_ID,DR_SEGMENTS,CR_SEGMENTS,F_EX_RATE,G_EX_RATE,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,REF_BILL_ID,ROOT_LINE_ID,BOOK_ID,ORIG_LINE_ID,JE_BATCH_ID,JE_BATCH_NAME,PP_AMT,PQ_AMT,PY_AMT)" +
                " VALUES("+schdId1+",3010428,"+headId4+","+mjeJELineId.get(19)+",19286,'USD',1400,0,'NNRNNNNNNNMNNNNNNNNNNNNNNNNNNNNNNNNNNNNN',"+ periodId +","+ postPeriodId +",NULL,'402:405:405',1,1,1,"+ crtdPeriodId +",'5','MONI','03-01-23','MONI','03-01-23',1,"+mjeLineId.get(19)+",1,"+mjeJELineId.get(19)+","+jeHeadId4+",'test110',0,0,0)").execute();

        maxMjeSchdId = schdId1;
    }

    private static void insertIntoMjeRproJeRcHead(Handle handle)//SOB-name<F CURR NULL,SEC_ATR_VAL
    {
        handle.createUpdate("INSERT into Rpro_je_head(ID,NAME,CATEGORY_CODE,EX_RATE_TYPE,HASH_TOTAL,SOB_NAME,SOB_ID,FN_CUR,PRD_ID,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,BOOK_ID,REV_REC_TYPE,APPR_NAME,DT_FRMT)" +
                " VALUES("+jeHeadId1+",'test107','Category Code1','User',2500,'"+sobName+"',"+sobId+",NULL,"+ periodId +",1,"+ crtdPeriodId +",'5','SYSADMIN','03-01-23','MONI','03-01-23','ANNYNNNNYNNSNNNNNNNI',1,'DR_APR','Moni','MM/DD/YYYY')").execute();

        handle.createUpdate("INSERT into Rpro_je_head(ID,NAME,CATEGORY_CODE,EX_RATE_TYPE,HASH_TOTAL,SOB_NAME,SOB_ID,FN_CUR,PRD_ID,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,BOOK_ID,REV_REC_TYPE,APPR_NAME,DT_FRMT)" +
                " VALUES("+jeHeadId2+",'test108','Category Code1','User',2500,'"+sobName+"',"+sobId+",NULL,"+ periodId +",1,"+ crtdPeriodId +",'5','SYSADMIN','03-01-23','MONI','03-01-23','ANNYNNNNYNNSNNNNNNNI',1,'DR_APR','Moni','MM/DD/YYYY')").execute();

        handle.createUpdate("INSERT into Rpro_je_head(ID,NAME,CATEGORY_CODE,EX_RATE_TYPE,HASH_TOTAL,SOB_NAME,SOB_ID,FN_CUR,PRD_ID,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,BOOK_ID,REV_REC_TYPE,APPR_NAME,DT_FRMT)" +
                " VALUES("+jeHeadId3+",'test109','Category Code1','User',2500,'"+sobName+"',"+sobId+",NULL,"+ periodId +",1,"+ crtdPeriodId +",'5','SYSADMIN','03-01-23','MONI','03-01-23','ANNYNNNNYNNSNNNNNNNI',1,'DR_APR','Moni','MM/DD/YYYY')").execute();

        handle.createUpdate("INSERT into Rpro_je_head(ID,NAME,CATEGORY_CODE,EX_RATE_TYPE,HASH_TOTAL,SOB_NAME,SOB_ID,FN_CUR,PRD_ID,CLIENT_ID,CRTD_PRD_ID,SEC_ATR_VAL,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,BOOK_ID,REV_REC_TYPE,APPR_NAME,DT_FRMT)" +
                " VALUES("+jeHeadId4+",'test110','Category Code1','User',2500,'"+sobName+"',"+sobId+",NULL,"+ periodId +",1,"+ crtdPeriodId +",'5','SYSADMIN','03-01-23','MONI','03-01-23','ANNYNNNNYNNSNNNNNNNI',1,'DR_APR','Moni','MM/DD/YYYY')").execute();

    }

    private static void insertIntoMjeRproRcJeLine(Handle handle)
    {
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(0)+","+headId1+",'Activity type1','USD',1500,1,1,1500,'Reason Code1',999,'Contract liability','301','302','303',NULL,NULL,NULL,NULL,NULL,1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(1)+","+headId1+",'Activity type1','USD',1000,1,1,1000,'Reason Code1',999,'Contract liability','301','302','304',NULL,NULL,NULL,NULL,NULL,1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(2)+","+headId1+",'Activity type2','USD',500,1,1,500,'Reason Code1',NULL,NULL,NULL,NULL,NULL,999,'Revenue','402','405','403',1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(3)+","+headId1+",'Activity type2','USD',600,1,1,600,'Reason Code1',NULL,NULL,NULL,NULL,NULL,999,'Revenue','402','405','403',1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(4)+","+headId1+",'Activity type2','USD',1400,1,1,1400,'Reason Code1',NULL,NULL,NULL,NULL,NULL,999,'Revenue','402','405','405',1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();


        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(5)+","+headId2+",'Activity type1','USD',1500,1,1,1500,'Reason Code1',999,'Contract liability','301','302','303',NULL,NULL,NULL,NULL,NULL,1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(6)+","+headId2+",'Activity type1','USD',1000,1,1,1000,'Reason Code1',999,'Contract liability','301','302','304',NULL,NULL,NULL,NULL,NULL,1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(7)+","+headId2+",'Activity type2','USD',500,1,1,500,'Reason Code1',NULL,NULL,NULL,NULL,NULL,999,'Revenue','402','405','403',1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(8)+","+headId2+",'Activity type2','USD',600,1,1,600,'Reason Code1',NULL,NULL,NULL,NULL,NULL,999,'Revenue','402','405','403',1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(9)+","+headId2+",'Activity type2','USD',1400,1,1,1400,'Reason Code1',NULL,NULL,NULL,NULL,NULL,999,'Revenue','402','405','405',1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();


        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(10)+","+headId3+",'Activity type1','USD',1500,1,1,1500,'Reason Code1',999,'Contract liability','301','302','303',NULL,NULL,NULL,NULL,NULL,1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(11)+","+headId3+",'Activity type1','USD',1000,1,1,1000,'Reason Code1',999,'Contract liability','301','302','304',NULL,NULL,NULL,NULL,NULL,1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(12)+","+headId3+",'Activity type2','USD',500,1,1,500,'Reason Code1',NULL,NULL,NULL,NULL,NULL,999,'Revenue','402','405','403',1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(13)+","+headId3+",'Activity type2','USD',600,1,1,600,'Reason Code1',NULL,NULL,NULL,NULL,NULL,999,'Revenue','402','405','403',1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(14)+","+headId3+",'Activity type2','USD',1400,1,1,1400,'Reason Code1',NULL,NULL,NULL,NULL,NULL,999,'Revenue','402','405','405',1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();


        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(15)+","+headId4+",'Activity type1','USD',1500,1,1,1500,'Reason Code1',999,'Contract liability','301','302','303',NULL,NULL,NULL,NULL,NULL,1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(16)+","+headId4+",'Activity type1','USD',1000,1,1,1000,'Reason Code1',999,'Contract liability','301','302','304',NULL,NULL,NULL,NULL,NULL,1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(17)+","+headId4+",'Activity type2','USD',500,1,1,500,'Reason Code1',NULL,NULL,NULL,NULL,NULL,999,'Revenue','402','405','403',1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(18)+","+headId4+",'Activity type2','USD',600,1,1,600,'Reason Code1',NULL,NULL,NULL,NULL,NULL,999,'Revenue','402','405','403',1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
        handle.createUpdate("INSERT into Rpro_je_line(ID,HEADER_ID,ACTIVITY_TYPE,CURR,AMOUNT,EX_RATE,G_EX_RATE,FUNC_AMOUNT,REASON_CODE,DR_CC_ID,DR_ACTIVITY_TYPE,DR_SEGMENT1,DR_SEGMENT2,DR_SEGMENT3,CR_CC_ID,CR_ACTIVITY_TYPE,CR_SEGMENT1,CR_SEGMENT2,CR_SEGMENT3,CLIENT_ID,CRTD_PRD_ID,CRTD_BY,CRTD_DT,UPDT_BY,UPDT_DT,INDICATORS,SEC_ATR_VAL,BOOK_ID) " +
                "VALUES("+mjeJELineId.get(19)+","+headId4+",'Activity type2','USD',1400,1,1,1400,'Reason Code1',NULL,NULL,NULL,NULL,NULL,999,'Revenue','402','405','405',1,"+ crtdPeriodId +",'SYSADMIN','03-01-23','SYSADMIN','03-01-23','YNNNNNNNNNNNNNNNNNNN','5',1)").execute();
    }

}
