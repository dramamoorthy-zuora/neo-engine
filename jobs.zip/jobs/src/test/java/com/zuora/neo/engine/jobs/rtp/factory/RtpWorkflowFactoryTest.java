package com.zuora.neo.engine.jobs.rtp.factory;

import com.zuora.neo.engine.jobs.caclnetting.service.CaclNettingRtpService;
import com.zuora.neo.engine.jobs.ltst.service.LtstRtpService;
import com.zuora.neo.engine.jobs.rtp.constants.RtpConstants;
import com.zuora.neo.engine.jobs.summarization.service.SummarizationRtpService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

@RunWith(MockitoJUnitRunner.class)
public class RtpWorkflowFactoryTest {

    @Mock
    CaclNettingRtpService caclNettingRtpService;

    @Mock
    LtstRtpService ltstRtpService;

    @Mock
    SummarizationRtpService summarizationRtpService;

    @InjectMocks
    RtpWorkflowFactory rtpWorkflowFactory;

    @Test
    public void testRtpWorkflowFactory() {
        assertEquals(rtpWorkflowFactory.getService(1), caclNettingRtpService);
        assertEquals(rtpWorkflowFactory.getService(2), ltstRtpService);
        assertEquals(rtpWorkflowFactory.getService(3), summarizationRtpService);

        IllegalArgumentException illegalArgumentException = assertThrows(IllegalArgumentException.class,
                () -> rtpWorkflowFactory.getService(100));

        assertEquals(illegalArgumentException.getMessage(), RtpConstants.INVALID_STEP_ID + "100");
    }

}
