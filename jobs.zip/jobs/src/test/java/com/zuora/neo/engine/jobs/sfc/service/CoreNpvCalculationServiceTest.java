package com.zuora.neo.engine.jobs.sfc.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.sfc.api.SfcSegmentsFlagsVersions;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;
import com.zuora.neo.engine.jobs.sfc.exception.NoDetailsFoundException;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.OutParameters;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class CoreNpvCalculationServiceTest {

    @Mock
    private SfcDao sfcDao;

    @Mock
    private CommonDao commonDao;

    @Mock
    private OutParameters outParameters;

    @Mock
    Handle handle;

    @Mock
    SfcTablesBatchInsertUpdateService sfcTablesBatchInsertUpdateService;

    @Mock
    SfcServiceUtils sfcServiceUtils;

    @Mock
    SfcSegmentsFlagsVersions sfcSegmentsFlagsVersions;

    @InjectMocks
    CoreNpvCalculationService coreNpvCalculationService;

    @Test
    public void testCalculateFinalInterestRate() {
        BigDecimal finalInterestRate = CoreNpvCalculationService.calculateFinalInterestRate(BigDecimal.valueOf(52.33));
        assertEquals(finalInterestRate, BigDecimal.valueOf(1.5233));
    }

    @Test
    public void testCalculateInterestRates() {
        BigDecimal interestRate = CoreNpvCalculationService.calculateInterestRates(BigDecimal.valueOf(1), BigDecimal.valueOf(0), BigDecimal.valueOf(7), BigDecimal.valueOf(7));
        assertEquals(interestRate, BigDecimal.valueOf(1.07));
    }

    @Test
    public void testCalculateNetNpv() throws ParseException, NoDetailsFoundException {

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");

        Map<String, Integer> currencyMap = new HashMap<>();
        currencyMap.put("fmvwcea:USD", 2);

        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(100.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(105.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetailsList.add(rcLineDetails);

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        Mockito.when(commonDao.getTotalDays(Mockito.any(), Mockito.any())).thenReturn(outParameters);
        Mockito.when(outParameters.getDouble("p_regular_days")).thenReturn(4.00);
        Mockito.when(outParameters.getDouble("p_leap_days")).thenReturn(0.00);
        Mockito.doNothing().when(sfcDao).updatePaymentBatchById(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
        Mockito.when(commonDao.createVc(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any(), Mockito.any())).thenReturn(outParameters);
        Mockito.when(outParameters.getString("p_err_msg")).thenReturn("");
        Mockito.when(outParameters.getInt("p_err_code")).thenReturn(0);
        Mockito.doNothing().when(sfcDao).updateRcLinePaTableWithFncTypeVersion(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());

        coreNpvCalculationService.calculateNetNpv(sfcDao, commonDao, sfcStatusValues, sfcPaymentDetailsList, rcLineDetailsList, currencyMap,
                12345, 10020,10007, 1, financeTypeValuesList, request);
        assertEquals(sfcStatusValues.getNetNpvAmt(), BigDecimal.valueOf(204.92));
        assertEquals(sfcStatusValues.getNetInterestAccrual(), BigDecimal.valueOf(0.08));
    }

    @Test
    public void testCalculateNetNpvNegativeLine() throws ParseException, NoDetailsFoundException {

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");

        Map<String, Integer> currencyMap = new HashMap<>();
        currencyMap.put("fmvwcea:USD", 2);

        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(-100.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(-105.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(-25.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetailsList.add(rcLineDetails);

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        Mockito.when(commonDao.getTotalDays(Mockito.any(), Mockito.any())).thenReturn(outParameters);
        Mockito.when(outParameters.getDouble("p_regular_days")).thenReturn(4.00);
        Mockito.when(outParameters.getDouble("p_leap_days")).thenReturn(0.00);
        Mockito.doNothing().when(sfcDao).updatePaymentBatchById(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
        Mockito.when(commonDao.createVc(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any(), Mockito.any())).thenReturn(outParameters);
        Mockito.when(outParameters.getString("p_err_msg")).thenReturn("");
        Mockito.when(outParameters.getInt("p_err_code")).thenReturn(0);
        Mockito.doNothing().when(sfcDao).updateRcLinePaTableWithFncTypeVersion(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());

        coreNpvCalculationService.calculateNetNpv(sfcDao, commonDao, sfcStatusValues, sfcPaymentDetailsList, rcLineDetailsList, currencyMap, 12345,
                10020,10007, 1, financeTypeValuesList, request);
        assertEquals(sfcStatusValues.getNetNpvAmt(), BigDecimal.valueOf(-204.92));
        assertEquals(sfcStatusValues.getNetInterestAccrual(), BigDecimal.valueOf(-0.08));
    }

    @Test
    public void testCalculateNetNpvZeroDivisible() throws ParseException {

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");

        Map<String, Integer> currencyMap = new HashMap<>();
        currencyMap.put("fmvwcea:USD", 2);

        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(100.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(105.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetailsList.add(rcLineDetails);

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        Mockito.when(commonDao.getTotalDays(Mockito.any(), Mockito.any())).thenReturn(outParameters);
        Mockito.when(outParameters.getDouble("p_regular_days")).thenReturn(-1.00);
        Mockito.when(outParameters.getDouble("p_leap_days")).thenReturn(0.00);

        try {
            coreNpvCalculationService.calculateNetNpv(sfcDao, commonDao, sfcStatusValues, sfcPaymentDetailsList, rcLineDetailsList, currencyMap, 12345, 10020,
                    10007, 1, financeTypeValuesList, request);
        } catch (ArithmeticException e) {
            assertTrue(e instanceof ArithmeticException );
        } catch (NoDetailsFoundException e) {
            assertTrue(e instanceof NoDetailsFoundException );
        }
    }

    @Test
    public void testCalculateNetNpvLineStartDate() throws ParseException, NoDetailsFoundException {

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");

        Map<String, Integer> currencyMap = new HashMap<>();
        currencyMap.put("fmvwcea:USD", 2);

        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(100.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(105.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/06/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/06/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/06/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetails.setStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/04/2021"));
        rcLineDetailsList.add(rcLineDetails);

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        Mockito.when(commonDao.getTotalDays(Mockito.any(), Mockito.any())).thenReturn(outParameters);
        Mockito.when(outParameters.getDouble("p_regular_days")).thenReturn(4.00);
        Mockito.when(outParameters.getDouble("p_leap_days")).thenReturn(0.00);
        Mockito.doNothing().when(sfcDao).updatePaymentBatchById(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
        Mockito.when(commonDao.createVc(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any(), Mockito.any())).thenReturn(outParameters);
        Mockito.when(outParameters.getString("p_err_msg")).thenReturn("");
        Mockito.when(outParameters.getInt("p_err_code")).thenReturn(0);
        Mockito.doNothing().when(sfcDao).updateRcLinePaTableWithFncTypeVersion(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());

        coreNpvCalculationService.calculateNetNpv(sfcDao, commonDao, sfcStatusValues, sfcPaymentDetailsList, rcLineDetailsList, currencyMap,
                12345, 10020,10007, 1, financeTypeValuesList, request);
        assertEquals(sfcStatusValues.getNetNpvAmt(), BigDecimal.valueOf(204.92));
        assertEquals(sfcStatusValues.getNetInterestAccrual(), BigDecimal.valueOf(0.08));
    }

}
