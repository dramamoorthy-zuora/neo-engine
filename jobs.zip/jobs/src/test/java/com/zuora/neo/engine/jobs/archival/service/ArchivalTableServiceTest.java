package com.zuora.neo.engine.jobs.archival.service;

import com.zuora.neo.engine.common.lookup.LookupEntity;
import com.zuora.neo.engine.common.lookup.LookupMapper;
import com.zuora.neo.engine.common.lookup.LookupService;
import com.zuora.neo.engine.db.common.DbContext;

import com.zuora.neo.engine.jobs.archival.db.model.ArchivalSettingsEntity;
import com.zuora.neo.engine.jobs.archival.db.model.DataArchivalTable;
import com.zuora.neo.engine.jobs.archival.db.dao.DataArchivableTablesDao;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;

import org.mockito.MockedStatic;
import org.mockito.Mockito;

import org.mockito.junit.MockitoJUnitRunner;

import java.sql.Connection;

import java.util.*;


import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ArchivalTableServiceTest {

    @InjectMocks
    ArchivalTableService archivalTableService;
    LookupMapper mapper;

    private static final Jdbi jdbi = mock(Jdbi.class);
    private static final Handle handle = mock(Handle.class);
    private static final MockedStatic<DbContext> utilities = Mockito.mockStatic(DbContext.class);
    private static final Connection connection = mock(Connection.class);
    private static final ArchivalSettingsEntity archivalSettingsEntity = mock(ArchivalSettingsEntity.class);
    private static final LookupService lookupService = mock(LookupService.class);
    private static final LookupEntity setting = mock(LookupEntity.class);
    private static final DataArchivableTablesDao dataArchivableTablesDao = mock(DataArchivableTablesDao.class);

    @Before
    public void setup() {
        utilities.when(DbContext::getConnection).thenReturn(jdbi);
        when(jdbi.open()).thenReturn(handle);
        when(handle.attach(any())).thenReturn(dataArchivableTablesDao);
    }

    @Test
    public void testFetchArchivalOrDeletableTables() {
        List<DataArchivalTable> archivalTableList = Arrays.asList(new DataArchivalTable(),new DataArchivalTable());
        when(dataArchivableTablesDao.getArchivalTableList()).thenReturn(archivalTableList);
        List<DataArchivalTable> archivalOrDeletableTables = archivalTableService.fetchArchivalTables(handle);
        assertEquals(2,archivalOrDeletableTables.size());
    }

    @Test
    public void testGetSchemaName() {
        when(dataArchivableTablesDao.getSchemaName()).thenReturn("revpro");
        String schemaName = archivalTableService.getSchemaName(handle);
        assertEquals("revpro", schemaName);
    }

    @Test
    public void testInsertRcMapping() {
        List rcIds = Arrays.asList(1001);
        archivalTableService.insertRcMapping(handle,rcIds);
        verify(dataArchivableTablesDao,atLeastOnce()).insertRcMapping(rcIds);
    }

    @Test
    public void testUpdateCopyQueryInDaTable() {
        archivalTableService.updateCopyQueryInDaTable(handle);
        verify(dataArchivableTablesDao,atLeastOnce()).updateCopyQuery();
    }

    @Test
    public void testGetExpiredRcsTest() {
        List<Long> expireRcList = Collections.singletonList(1001l);
        Mockito.when(dataArchivableTablesDao.getExpiredRcs(0,1,"M")).thenReturn(expireRcList);
        List rcIds = archivalTableService.getExpiredRcs(handle,1, "M",0);
        assertEquals( Collections.singletonList(1001L), rcIds);
    }

    @Test
    public void testUpdateBatchStatus() {
        int result = archivalTableService.updateBatchStatus(handle,"M", Collections.singletonList(10014L));
        verify(dataArchivableTablesDao,atLeastOnce()).updateCopyAndDeleteStatus("M", Collections.singletonList(10014L));
        Assert.assertEquals(0,result);
    }

    @Test
    public void testGetArchivalSettings() {
        Object result = lookupService.fetchLookupData(handle,"1",mapper);
        assertNull(result);
    }

}

