package com.zuora.neo.engine.jobs.rtp;

import org.junit.Test;
import org.junit.runner.RunWith;

import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class WorkItemResultTest {

    @Test
    public void testWorkItemResult() {

        String errorMessage = "WorkItem failed";
        Integer returnCode = 2;

        WorkItemResult workItemResult = new WorkItemResult(errorMessage, returnCode);

        assertEquals(workItemResult.getErrorMessage(), errorMessage);
        assertEquals(workItemResult.getReturnCode(), returnCode);

        String toString = "WorkItemResult{errorMessage='" + errorMessage + "', returnCode=" + returnCode + "}";
        assertEquals(workItemResult.toString(), toString);
    }
}
