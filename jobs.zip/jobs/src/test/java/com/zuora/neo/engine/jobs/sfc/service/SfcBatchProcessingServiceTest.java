package com.zuora.neo.engine.jobs.sfc.service;

import static com.zuora.neo.engine.jobs.sfc.db.api.PrincipleWeightageColumn.EXT_FV_PRC;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.db.api.AccountValue;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.sfc.SfcResult;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;
import com.zuora.neo.engine.jobs.sfc.exception.NoDetailsFoundException;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.OutParameters;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class SfcBatchProcessingServiceTest {

    @Mock
    private SfcDao sfcDao;

    @Mock
    private CommonDao commonDao;

    @Mock
    private OutParameters outParameters;

    @Mock
    private Handle handle;

    @Mock
    private NpvCalculationService npvCalculationService;

    @Mock
    private AccrualEntryService accrualEntryService;

    @Mock
    private SfcScheduleCreationService sfcScheduleCreationService;

    @Mock
    private RcLinePaDataService rcLinePaDataService;

    @Mock
    private PrincipleAmountCalculationService principleAmountCalculationService;

    @Mock
    private SfcTablesBatchInsertUpdateService sfcTablesBatchInsertUpdateService;

    @Mock
    private RcLineDetailsService rcLineDetailsService;

    @InjectMocks
    SfcBatchProcessingService sfcBatchProcessingService;

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcBatchProcessingServiceTest.class);


    @Test
    public void testProcessSfcForBatchWithoutPrincipleAmount() throws ParseException, SQLException {

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        long openPeriodId = 202202;

        List<SfcStatusValues> sfcStatusValuesList = new ArrayList<>();
        List<SfcPaymentDetails> sfcPaymentDetailsBatch = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsBatch = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsByDocNum = new ArrayList<>();
        List<RcLinePaData> rcLinePaDataList = new ArrayList<>();

        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");
        sfcStatusValues.setDocNum("SO379");
        sfcStatusValues.setStatus("Ready for SFC");
        sfcStatusValuesList.add(sfcStatusValues);
        sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.6");
        sfcStatusValues.setDocNum("SO379");
        sfcStatusValues.setStatus("Ready for SFC");
        sfcStatusValuesList.add(sfcStatusValues);

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(100.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsBatch.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(105.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsBatch.add(sfcPaymentDetails);

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setRelPct(BigDecimal.valueOf(100.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setDocDate(new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2019"));
        rcLineDetails.setDocNum("SO379");
        rcLineDetailsBatch.add(rcLineDetails);
        rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.5");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setRelPct(BigDecimal.valueOf(100.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(6.00));
        rcLineDetails.setDocDate(new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2019"));
        rcLineDetails.setDocNum("SO379");
        rcLineDetailsBatch.add(rcLineDetails);

        rcLineDetails = new RcLineDetails();
        rcLineDetails.setDocNum("SO379");
        rcLineDetails.setExtSllPrc(BigDecimal.valueOf(25.00));
        rcLineDetails.setExtFvPrc(BigDecimal.valueOf(25.00));
        rcLineDetails.setExtLstPrc(BigDecimal.valueOf(25.00));
        rcLineDetails.setSumOfExtSllPrc(BigDecimal.valueOf(100.00));
        rcLineDetails.setSumOfExtFvPrc(BigDecimal.valueOf(100.00));
        rcLineDetails.setSumOfExtLstPrc(BigDecimal.valueOf(100.00));
        rcLineDetailsByDocNum.add(rcLineDetails);

        List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
        FinanceTypeFlagDetails financeTypeFlagDetails = new FinanceTypeFlagDetails(10020, "", "", "", "", "");
        financeTypeFlagDetailsList.add(financeTypeFlagDetails);

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        List<CalendarDetails> calendarDetailsList = new ArrayList<>();
        CalendarDetails calendarDetail = new CalendarDetails(202202, "FEB-22", new Date(), new Date());
        calendarDetailsList.add(calendarDetail);

        List<AccountValue> accountValuesList = new ArrayList<>();

        Map<String, Integer> currencyMap = new HashMap<>();
        currencyMap.put("fmvwcea:USD", 2);

        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();
        sfcDbCacheContext.setFinanceTypeValuesList(financeTypeValuesList);
        sfcDbCacheContext.setCalendarDetailsCache(calendarDetailsList);
        sfcDbCacheContext.setCalendarDetails(calendarDetailsList);
        sfcDbCacheContext.setCurrentPeriodId(openPeriodId);
        sfcDbCacheContext.setCurrencyMap(currencyMap);
        sfcDbCacheContext.setBookId(1);

        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(sfcDao.getRcLineDetailsByDocLineIdList(Mockito.any())).thenReturn(rcLineDetailsBatch);
        Mockito.when(sfcDao.getRcLineDetailsByDocNum(Mockito.any())).thenReturn(rcLineDetailsByDocNum);
        Mockito.doNothing().when(sfcTablesBatchInsertUpdateService).batchUpdateSfcStatusTable(Mockito.any(), Mockito.any());
        Mockito.doNothing().when(rcLineDetailsService).updatePrincipleAmountToRcLineDetailsBatch(Mockito.any(), Mockito.any());
/*        Mockito.when(commonDao.getVersionFromRcId(Mockito.anyLong())).thenReturn(Long.valueOf(1));
        Mockito.when(commonDao.getOpenPeriodId(Mockito.any())).thenReturn(Long.valueOf(202202));
        Mockito.when(commonDao.getPeriodId(Mockito.any(), Mockito.any())).thenReturn(Long.valueOf(202202));
        Mockito.when(commonDao.getPeriodDetailsById(Mockito.anyLong())).thenReturn(calendarDetailsList);
        Mockito.when(sfcDao.getSfcAcct(Mockito.anyLong(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(outParameters);
        Mockito.when(outParameters.getString(Mockito.any())).thenReturn("");
        Mockito.when(outParameters.getInt(Mockito.any())).thenReturn(0);
        Mockito.when(principleAmountCalculationService.determineWeightageMethod(Mockito.any())).thenReturn(null);
        Mockito.doNothing().when(principleAmountCalculationService).calculatePrincipleAmount(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
        Mockito.doNothing().when(sfcDao).updateRcLineDetailsWithPrincipleAmt(Mockito.any(), Mockito.any());
        Mockito.doNothing().when(npvCalculationService).calculateNetNpv(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.anyList(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
        try {
            Mockito.doNothing().when(accrualEntryService).createAccrualEntry(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                    Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any(), Mockito.any(), Mockito.any());
            Mockito.doNothing().when(sfcScheduleCreationService).createSfcSchedule(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                    Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any(),
                    Mockito.any(), Mockito.any());
        } catch (BatchInsertUpdateException e) {
            LOGGER.debug("Exception occurred during the test.");
        }
        Mockito.doNothing().when(rcLinePaDataService).updateAmountsToRcLinePaData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyLong());*/
        SfcResult sfcResult = new SfcResult();
        sfcBatchProcessingService.processSfcForBatch(sfcStatusValuesList, sfcDbCacheContext, sfcResult, request, handle);
        assertEquals(sfcStatusValuesList.get(0).getStatus(), "Principle Amount Calculated");
    }
}
