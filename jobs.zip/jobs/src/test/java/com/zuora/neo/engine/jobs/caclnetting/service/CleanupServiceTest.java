package com.zuora.neo.engine.jobs.caclnetting.service;

import com.zuora.neo.engine.db.api.PeriodDetails;
import com.zuora.neo.engine.jobs.caclnetting.config.CaclProperties;
import com.zuora.neo.engine.jobs.caclnetting.db.dao.CaclNettingDao;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CleanupServiceTest {

    @Mock
    private CaclNettingDao nettingDao;

    private static final BigDecimal batchId = new BigDecimal(1.0);

    @Mock
    CaclProperties caclProperties;

    @InjectMocks
    private CleanupService cleanupService;

    private static PeriodDetails periodDetailsMock = new PeriodDetails(1, 1, 1);

    @Test
    public void testDeleteNetRc() {

        when(caclProperties.getBookId()).thenReturn(1L);
        when(caclProperties.getClientId()).thenReturn(1L);
        when(caclProperties.getOrgId()).thenReturn("");

        when(caclProperties.isNettingEnabled()).thenReturn(true);
        when(caclProperties.isNettingRcMje()).thenReturn(true);
        when(caclProperties.getCaclNetRc()).thenReturn("");
        when(caclProperties.getHeadPeriod()).thenReturn("");
        when(caclProperties.getScheduleTable()).thenReturn("");

        when(caclProperties.getHeadPeriodSequence()).thenReturn("");
        when(caclProperties.getScheduleSequence()).thenReturn("");

        cleanupService.deleteNetRc(nettingDao, batchId);

        verify(nettingDao, times(1)).deleteNetRc(any(), anyString(), anyLong(), anyLong(), anyString());

    }

    @Test
    public void testRemoveHeaderEntries() {
        when(caclProperties.getBookId()).thenReturn(1L);
        when(caclProperties.getClientId()).thenReturn(1L);
        when(caclProperties.getOrgId()).thenReturn("");
        when(caclProperties.getPeriodDetails()).thenReturn(periodDetailsMock);

        when(caclProperties.isNettingEnabled()).thenReturn(true);
        when(caclProperties.isNettingRcMje()).thenReturn(true);
        when(caclProperties.getCaclNetRc()).thenReturn("");
        when(caclProperties.getHeadPeriod()).thenReturn("");
        when(caclProperties.getScheduleTable()).thenReturn("");

        when(caclProperties.getHeadPeriodSequence()).thenReturn("");
        when(caclProperties.getScheduleSequence()).thenReturn("");

        cleanupService.removeHeaderEntries(nettingDao, batchId);

        verify(nettingDao, times(1)).removeNettingHeaders(any(), anyLong(), anyString(), anyString(), anyLong(),
                anyLong(), anyString());
    }

    @Test
    public void testRemoveIntermediateEntries() {
        when(caclProperties.getBookId()).thenReturn(1L);
        when(caclProperties.getClientId()).thenReturn(1L);
        when(caclProperties.getOrgId()).thenReturn("");
        when(caclProperties.getPeriodDetails()).thenReturn(periodDetailsMock);

        when(caclProperties.isNettingEnabled()).thenReturn(true);
        when(caclProperties.isNettingRcMje()).thenReturn(true);
        when(caclProperties.getCaclNetRc()).thenReturn("");
        when(caclProperties.getHeadPeriod()).thenReturn("");
        when(caclProperties.getScheduleTable()).thenReturn("");

        when(caclProperties.getHeadPeriodSequence()).thenReturn("");
        when(caclProperties.getScheduleSequence()).thenReturn("");

        cleanupService.removeIntermediateEntries(nettingDao, batchId);

        verify(nettingDao, times(1)).cleanIntermediateEntries(anyLong(), any(), anyString(),
                anyLong(), anyLong(), anyString());
    }

    @Test
    public void testRemoveScheduleEntries() {
        when(caclProperties.getBookId()).thenReturn(1L);
        when(caclProperties.getClientId()).thenReturn(1L);
        when(caclProperties.getOrgId()).thenReturn("");
        when(caclProperties.getUser()).thenReturn("");
        when(caclProperties.getPeriodDetails()).thenReturn(periodDetailsMock);

        when(caclProperties.isNettingEnabled()).thenReturn(true);
        when(caclProperties.isNettingRcMje()).thenReturn(true);
        when(caclProperties.getCaclNetRc()).thenReturn("");
        when(caclProperties.getHeadPeriod()).thenReturn("");
        when(caclProperties.getScheduleTable()).thenReturn("");

        when(caclProperties.getHeadPeriodSequence()).thenReturn("");
        when(caclProperties.getScheduleSequence()).thenReturn("");

        cleanupService.removeScheduleEntries(nettingDao, batchId);

        verify(nettingDao, times(1)).deleteUnpostedSchedules(any(), anyLong(), anyLong(),
                anyString(), anyString(), anyString(), anyString(), anyLong(), anyLong(), anyString());

        verify(nettingDao, times(1)).reversePostedSchedules(any(), anyLong(), anyLong(),
                anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(),
                anyString(), anyLong(), anyLong(), anyString());

        verify(nettingDao, times(1)).updatePostedSchedules(any(), anyLong(), anyLong(),
                anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyLong(),
                anyLong(), anyString());
    }

}