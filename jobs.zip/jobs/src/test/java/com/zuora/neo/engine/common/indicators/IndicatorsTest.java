package com.zuora.neo.engine.common.indicators;

import oracle.jdbc.internal.XSPrincipal;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;


@RunWith(MockitoJUnitRunner.class)
public class IndicatorsTest {
    @Test
    public void TestIndicatorCreation() {
        Indicators<LineTestIndicator> indicator = new Indicators<>(LineTestIndicator.class);
        assertEquals("YYNNNN",indicator.toString());
    }

    @Test
    public void TestIndicatorReadFromDBCase() {


        try {
            Indicators<LineTestIndicator> indicator = Indicators.valueOf(LineTestIndicator.class, "YYYYYY");
            assertEquals("YYYYYY",indicator.toString());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @Test
    public void handleInvalidLengthIndicatorWithProperDefaults() {

        Indicators<LineTestIndicator> ind = Indicators.valueOf(LineTestIndicator.class, "NY");
        assertEquals("NYNNNN", ind.toString());
    }

    @Test
    public void TestSetAndGetIndicator() {
        Indicators<LineTestIndicator> indicator = new Indicators<>(LineTestIndicator.class);
        assertEquals('Y', indicator.getIndicator(LineTestIndicator.ROOTLINE));
        indicator.setIndicator(LineTestIndicator.ROOTLINE,'N');
        assertEquals('N', indicator.getIndicator(LineTestIndicator.ROOTLINE));
    }

    @Test
    public void TestResetToDefault() {
        Indicators<LineTestIndicator> indicator = new Indicators<>(LineTestIndicator.class);
        indicator.setIndicator(LineTestIndicator.ROOTLINE,'N');
        assertEquals("NYNNNN", indicator.toString());
        indicator.resetToDefault();
        assertEquals("YYNNNN",indicator.toString());

    }

    @Test
    public void TestMultipleIndicator() {
        Indicators<LineTestIndicator> indicator = new Indicators<>(LineTestIndicator.class);
        assertEquals("YYNNNN",indicator.toString());
        FlagValuePair<LineTestIndicator> rootLine = new FlagValuePair<>(LineTestIndicator.ROOTLINE, 'N');
        FlagValuePair<LineTestIndicator> nonLeadLine = new FlagValuePair<>(LineTestIndicator.NONLEADLINE, 'Y');
        indicator.setIndicators(Arrays.asList(rootLine, nonLeadLine));
        assertEquals("NYYNNN",indicator.toString());

    }

}
