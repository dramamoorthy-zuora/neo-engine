package com.zuora.neo.engine.jobs.sfc.activities;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;

public class SfcActivitiesTest {

    //private static final ProcessSfcService processSfcService = mock(ProcessSfcService.class);
    /*
    private static final SfcActivitiesImpl sfcActivitiesImpl = mock(SfcActivitiesImpl.class);


    @Test
    public void testProcessSfc() {
        List<SfcStatusValues> sfcStatusValuesList = null;
        Mockito.when(processSfcService.processSfc(Mockito.anyInt(), Mockito.anyInt())).thenReturn(0);
        sfcActivitiesImpl.processSfc();
        assertNull(sfcStatusValuesList);
    }

     */


    /*@Test
    public void testValidSfcLineEmptyPayments() throws SQLException {
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        boolean isValid = SfcActivitiesImpl.validSfcLine(sfcStatusValues, sfcPaymentDetailsList, rcLineDetailsList);
        assertFalse(isValid);
    }

    @Test
    public void testValidSfcLineNoInterestPopulated() throws SQLException {
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails.Builder().withDocLineId("SO_123_4.5")
                .withId(1)
                .withNetPaymtAmt(BigDecimal.valueOf(123.23))
                .withPaymtDate(new Date())
                .withPaymtEndDate(new Date())
                .withPaymtStartDate(new Date())
                .build();

        RcLineDetails rcLineDetails = new RcLineDetails.Builder().withId(1)
                .withRecAmt(BigDecimal.valueOf(5.0))
                .build();

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        sfcPaymentDetailsList.add(sfcPaymentDetails);
        rcLineDetailsList.add(rcLineDetails);

        boolean isValid = SfcActivitiesImpl.validSfcLine(sfcStatusValues, sfcPaymentDetailsList, rcLineDetailsList);
        assertFalse(isValid);
        assertEquals(sfcStatusValues.getStatus(), "Interest not Populated");
    }

    @Test
    public void testValidSfcLineRevNotRec() throws SQLException {
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails.Builder().withDocLineId("SO_123_4.5")
                .withId(1)
                .withNetPaymtAmt(BigDecimal.valueOf(123.23))
                .withPaymtDate(new Date())
                .withPaymtEndDate(new Date())
                .withPaymtStartDate(new Date())
                .build();

        RcLineDetails rcLineDetails = new RcLineDetails.Builder().withId(1)
                .withRecAmt(BigDecimal.valueOf(0.0))
                .withnpvInterestRate(BigDecimal.valueOf(1.01))
                .build();

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        sfcPaymentDetailsList.add(sfcPaymentDetails);
        rcLineDetailsList.add(rcLineDetails);

        boolean isValid = SfcActivitiesImpl.validSfcLine(sfcStatusValues, sfcPaymentDetailsList, rcLineDetailsList);
        assertFalse(isValid);
        assertEquals(sfcStatusValues.getStatus(), "Revenue Not recognised");
    }

    @Test
    public void testGetNpvValueFromDailyInterest() {

        BigDecimal npvAmount = SfcActivitiesImpl.getNpvValueFromDailyInterest(BigDecimal.valueOf(1.00), BigDecimal.valueOf(0.000123), 5, 2 );
        assertEquals(npvAmount, BigDecimal.valueOf(1.00).setScale(2, RoundingMode.HALF_EVEN));
    }

    //@Test
    public void testCalcNpvFromCacheSfcStatus() throws SQLException, ParseException {

        List<SfcStatusValues> sfcStatusValuesList = new ArrayList<>();
        List<SfcPaymentDetails> sfcPaymentDetailsBatch = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsBatch = new ArrayList<>();
        List<RcLinePaData> rcLinePaDataList = new ArrayList<>();

        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");
        sfcStatusValuesList.add(sfcStatusValues);
        sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.6");
        sfcStatusValuesList.add(sfcStatusValues);

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(100.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsBatch.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(105.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsBatch.add(sfcPaymentDetails);

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetailsBatch.add(rcLineDetails);

        Map<String, Integer> currencyMap = new HashMap<>();
        currencyMap.put("fmvwcea:USD", 2);

        WorkflowRequest request = new WorkflowRequest(533, 11290909, "fmvwcea", "0", 1, "SYSADMIN", 1, "Parameter Text");

        List<CalendarDetails> calendarDetailsList = new ArrayList<>();
        CalendarDetails calendarDetails = new CalendarDetails(Long.valueOf(202105), "MAY-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/05/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/05/2021"));
        calendarDetailsList.add(calendarDetails);
        calendarDetails = new CalendarDetails(Long.valueOf(202106), "JUN-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("30/06/2021"));
        calendarDetailsList.add(calendarDetails);

        //mocks for Net NPV Calculation
        Mockito.when(sfcDao.getSfcPaymentDetailsByDocLineIdList(Mockito.any())).thenReturn(sfcPaymentDetailsBatch);
        Mockito.when(sfcDao.getRcLineDetailsByDocLineIdList(Mockito.any())).thenReturn(rcLineDetailsBatch);
        Mockito.when(sfcDao.getVcIdForSfc()).thenReturn(10020);
        Mockito.when(sfcDao.getRcLinePaDataForLineId(Mockito.any())).thenReturn(rcLinePaDataList);
        Mockito.doNothing().when(sfcDao).updateSfcStatusWithNpvInterestAndStatus(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
        Mockito.when(commonDao.getTotalDays(Mockito.any(), Mockito.any())).thenReturn(outParameters);
        Mockito.when(outParameters.getDouble("p_regular_days")).thenReturn(365.00);
        Mockito.when(outParameters.getDouble("p_leap_days")).thenReturn(0.00);
        Mockito.doNothing().when(sfcDao).updatePaymentBatchById(Mockito.any(), Mockito.any(), Mockito.any());
        //TODO - Mock properly once the datatypes are changed from Integer to long
        //Mockito.when(commonDao.createVc(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(outParameters);
        Mockito.when(outParameters.getString("p_err_msg")).thenReturn("NA");
        Mockito.when(outParameters.getInt("p_leap_days")).thenReturn(0);

        //mocks for Schedule Record
        Mockito.when(commonDao.getOpenPeriodId(Mockito.any())).thenReturn(Long.valueOf(202201));
        Mockito.when(commonDao.getVersionFromRcId(Mockito.any())).thenReturn(Long.valueOf(1));
        Mockito.when(commonDao.getPeriodsBetweenStartEndDate(Mockito.any(), Mockito.any())).thenReturn(calendarDetailsList);
        Mockito.when(sfcDao.getYearDays(Mockito.any())).thenReturn(Long.valueOf(365));
        Mockito.when(commonDao.getCreatedPeriodId(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Long.valueOf(202101));
        Mockito.when(commonDao.getNextValFromSequence(Mockito.any(), Mockito.any())).thenReturn(Long.valueOf(10001));
        SfcActivitiesImpl.calcNpvFromCache(sfcStatusValuesList, sfcDao, commonDao, currencyMap, request, handle);

    } */
}
