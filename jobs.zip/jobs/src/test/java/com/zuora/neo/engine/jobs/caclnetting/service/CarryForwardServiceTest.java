package com.zuora.neo.engine.jobs.caclnetting.service;

import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.PeriodDetails;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.caclnetting.config.CaclProperties;
import com.zuora.neo.engine.jobs.caclnetting.db.dao.CaclNettingDao;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CarryForwardServiceTest {

    @Mock
    private CaclProperties caclProperties;
    @Mock
    private CaclNettingDao nettingDao;
    @Mock
    private NeoWorkflowLogger neoWorkflowLogger;

    @Spy
    @InjectMocks
    CarryForwardService carryForwardService;

    private static PeriodDetails periodDetailsMock = new PeriodDetails(1, 1, 1);

    @Test
    public void testCarryForwardEntries() {
        when(caclProperties.getBookId()).thenReturn(1L);
        when(caclProperties.getClientId()).thenReturn(1L);
        when(caclProperties.getOrgId()).thenReturn("0");

        when(caclProperties.isNettingEnabled()).thenReturn(true);
        when(caclProperties.isNettingRcMje()).thenReturn(true);
        when(caclProperties.getPeriodDetails()).thenReturn(periodDetailsMock);
        when(caclProperties.getCaclNetRc()).thenReturn("");
        when(caclProperties.getHeadPeriod()).thenReturn("");
        when(caclProperties.getScheduleTable()).thenReturn("");
        when(caclProperties.getUser()).thenReturn("");

        when(caclProperties.getHeadPeriodSequence()).thenReturn("");
        when(caclProperties.getScheduleSequence()).thenReturn("");

        when(nettingDao.insertCarryForwardEntries(anyLong(), anyLong(), anyLong(), any(),
                anyString(), anyString(),
                anyString(), anyLong(), anyLong(), anyString())).thenReturn(1);

        int entriesCount = carryForwardService.carryForwardEntries(nettingDao, new BigDecimal(1.0));
        assertEquals(1, entriesCount);

    }
}
