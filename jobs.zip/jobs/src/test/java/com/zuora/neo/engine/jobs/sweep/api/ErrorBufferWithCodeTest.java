package com.zuora.neo.engine.jobs.sweep.api;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ErrorBufferWithCodeTest {

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>{@link ErrorBufferWithCode#ErrorBufferWithCode(String, Integer)}
     *   <li>{@link ErrorBufferWithCode#getErrorBuffer()}
     *   <li>{@link ErrorBufferWithCode#getReturnCode()}
     * </ul>
     */
    @Test
    public void testConstructor() {
        ErrorBufferWithCode actualErrorBufferWithCode = new ErrorBufferWithCode("An error occurred", 1);

        assertEquals("An error occurred", actualErrorBufferWithCode.getErrorBuffer());
        assertEquals(1, actualErrorBufferWithCode.getReturnCode().intValue());
    }
}

