package com.zuora.neo.engine.jobs.sweep.db.api;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Ignore;
import org.junit.Test;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class CurrentPeriodTest {

    /**
     * Method under test: {@link CurrentPeriod#CurrentPeriod(Date, Date)}
     */
    @Test
    public void testConstructor() {
        LocalDateTime atStartOfDayResult = LocalDate.of(1970, 1, 1).atStartOfDay();
        Date fromResult = Date.from(atStartOfDayResult.atZone(ZoneId.of("UTC")).toInstant());
        LocalDateTime atStartOfDayResult1 = LocalDate.of(1970, 1, 1).atStartOfDay();
        Date fromResult1 = Date.from(atStartOfDayResult1.atZone(ZoneId.of("UTC")).toInstant());
        new CurrentPeriod(fromResult, fromResult1);

        assertEquals("1970-01-01", (new SimpleDateFormat("yyyy-MM-dd")).format(fromResult));
        assertEquals("1970-01-01", (new SimpleDateFormat("yyyy-MM-dd")).format(fromResult1));
    }

    /**
     * Method under test: {@link CurrentPeriod#CurrentPeriod(java.util.Date, java.util.Date)}
     */
    @Test
    public void testConstructor2() {
        java.sql.Date date = mock(java.sql.Date.class);
        when(date.getTime()).thenReturn(10L);
        LocalDateTime atStartOfDayResult = LocalDate.of(1970, 1, 1).atStartOfDay();
        new CurrentPeriod(date, java.util.Date.from(atStartOfDayResult.atZone(ZoneId.of("UTC")).toInstant()));

        verify(date).getTime();
    }

    /**
     * Method under test: {@link CurrentPeriod#CurrentPeriod(java.util.Date, java.util.Date)}
     */
    @Test
    @Ignore("TODO: Complete this test")
    public void testConstructor3() {
        java.sql.Date date = mock(java.sql.Date.class);
        when(date.getTime()).thenReturn(10L);
        new CurrentPeriod(date, null);

    }

    /**
     * Method under test: {@link CurrentPeriod#getCurrentQuarterDate()}
     */
    @Test
    @Ignore("TODO: Complete this test")
    public void testGetCurrentQuarterDate() {
        LocalDateTime atStartOfDayResult = LocalDate.of(1970, 1, 1).atStartOfDay();
        Date currentQuarterDate = Date.from(atStartOfDayResult.atZone(ZoneId.of("UTC")).toInstant());
        LocalDateTime atStartOfDayResult1 = LocalDate.of(1970, 1, 1).atStartOfDay();
        (new CurrentPeriod(currentQuarterDate, Date.from(atStartOfDayResult1.atZone(ZoneId.of("UTC")).toInstant()))).getCurrentQuarterDate();
    }

    /**
     * Method under test: {@link CurrentPeriod#getCurrentQuarterDate()}
     */
    @Test
    public void testGetCurrentQuarterDate2() {
        java.sql.Date date = mock(java.sql.Date.class);
        when(date.getTime()).thenReturn(10L);
        LocalDateTime atStartOfDayResult = LocalDate.of(1970, 1, 1).atStartOfDay();
        (new CurrentPeriod(date, java.util.Date.from(atStartOfDayResult.atZone(ZoneId.of("UTC")).toInstant()))).getCurrentQuarterDate();
        verify(date).getTime();
    }

    /**
     * Method under test: {@link CurrentPeriod#getCurrentYearDate()}
     */
    @Test
    @Ignore("TODO: Complete this test")
    public void testGetCurrentYearDate() {

        LocalDateTime atStartOfDayResult = LocalDate.of(1970, 1, 1).atStartOfDay();
        Date currentQuarterDate = Date.from(atStartOfDayResult.atZone(ZoneId.of("UTC")).toInstant());
        LocalDateTime atStartOfDayResult1 = LocalDate.of(1970, 1, 1).atStartOfDay();
        (new CurrentPeriod(currentQuarterDate, Date.from(atStartOfDayResult1.atZone(ZoneId.of("UTC")).toInstant()))).getCurrentYearDate();
    }

    /**
     * Method under test: {@link CurrentPeriod#getCurrentYearDate()}
     */
    @Test
    public void testGetCurrentYearDate2() {
        java.sql.Date date = mock(java.sql.Date.class);
        when(date.getTime()).thenReturn(10L);
        LocalDateTime atStartOfDayResult = LocalDate.of(1970, 1, 1).atStartOfDay();
        (new CurrentPeriod(date, java.util.Date.from(atStartOfDayResult.atZone(ZoneId.of("UTC")).toInstant()))).getCurrentYearDate();
        verify(date).getTime();
    }
}

