package com.zuora.neo.engine.jobs.sweep.activities.summarization;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class SweepSummarizationDataTest {

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>default or parameterless constructor of {@link SweepSummarizationData}
     *   <li>{@link SweepSummarizationData#setBookId(long)}
     *   <li>{@link SweepSummarizationData#setNextPeriodId(long)}
     *   <li>{@link SweepSummarizationData#setOrgId(String)}
     *   <li>{@link SweepSummarizationData#setPeriodId(long)}
     *   <li>{@link SweepSummarizationData#setSweepBatchId(long)}
     *   <li>{@link SweepSummarizationData#setSweepType(String)}
     *   <li>{@link SweepSummarizationData#getBookId()}
     *   <li>{@link SweepSummarizationData#getNextPeriodId()}
     *   <li>{@link SweepSummarizationData#getOrgId()}
     *   <li>{@link SweepSummarizationData#getPeriodId()}
     *   <li>{@link SweepSummarizationData#getSweepBatchId()}
     *   <li>{@link SweepSummarizationData#getSweepType()}
     * </ul>
     */
    @Test
    public void testConstructor() {
        SweepSummarizationData actualSweepSummarizationData = new SweepSummarizationData();
        actualSweepSummarizationData.setBookId(123L);
        actualSweepSummarizationData.setNextPeriodId(123L);
        actualSweepSummarizationData.setOrgId("42");
        actualSweepSummarizationData.setPeriodId(123L);
        actualSweepSummarizationData.setSweepBatchId(123L);
        actualSweepSummarizationData.setSweepType("Sweep Type");
        assertEquals(123L, actualSweepSummarizationData.getBookId());
        assertEquals(123L, actualSweepSummarizationData.getNextPeriodId());
        assertEquals("42", actualSweepSummarizationData.getOrgId());
        assertEquals(123L, actualSweepSummarizationData.getPeriodId());
        assertEquals(123L, actualSweepSummarizationData.getSweepBatchId());
        assertEquals("Sweep Type", actualSweepSummarizationData.getSweepType());
    }
}

