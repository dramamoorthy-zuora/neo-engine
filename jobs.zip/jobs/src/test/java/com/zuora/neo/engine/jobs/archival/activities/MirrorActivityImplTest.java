package com.zuora.neo.engine.jobs.archival.activities;

import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.common.util.CommonUtils;
import com.zuora.neo.engine.db.common.DbContext;

import com.zuora.neo.engine.jobs.archival.ArchivalResult;

import com.zuora.neo.engine.jobs.archival.common.QueryLogger;
import com.zuora.neo.engine.jobs.archival.db.dao.DataArchivableTablesDao;
import com.zuora.neo.engine.jobs.archival.db.model.ArchivalSettingsEntity;

import com.zuora.neo.engine.jobs.archival.db.model.DataArchivalTable;
import com.zuora.neo.engine.jobs.archival.enums.ArchivalStatus;
import com.zuora.neo.engine.jobs.archival.enums.BatchStatus;
import com.zuora.neo.engine.jobs.archival.service.ArchivalTableService;

import com.uber.m3.tally.Scope;
import io.temporal.activity.Activity;

import io.temporal.activity.ActivityExecutionContext;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.Update;

import org.junit.Before;
import org.junit.Test;

import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.util.*;

import static org.junit.Assert.assertEquals;


import static org.mockito.Mockito.*;

public class MirrorActivityImplTest {


    private static final Jdbi jdbi = mock(Jdbi.class);
    private static final Handle handle = mock(Handle.class);
    private static final MockedStatic<DbContext> utilities = Mockito.mockStatic(DbContext.class);
    private static final ArchivalSettingsEntity archivalSettingsEntity =new ArchivalSettingsEntity();
    private static final MockedStatic<Activity> activity = Mockito.mockStatic(Activity.class);
    private static final ActivityExecutionContext context = mock(ActivityExecutionContext.class);
    private static final Scope scope = mock(Scope.class);
    private static final  MockedStatic<WorkflowContextManager> workflowContextManager = Mockito.mockStatic(WorkflowContextManager.class);
    private static final WorkflowContext workflowContext = mock(WorkflowContext.class);
    private static final WorkflowRequest workflowRequest = mock(WorkflowRequest.class);
    private static final  MockedStatic<CommonUtils> commonUtils = Mockito.mockStatic(CommonUtils.class);
    private static final QueryLogger queryLogger = mock(QueryLogger.class);

    @Before
    public void setup() {
        utilities.when(DbContext::getConnection).thenReturn(jdbi);
        Mockito.when(jdbi.open()).thenReturn(handle);
        workflowContextManager.when(WorkflowContextManager::getWorkflowContext).thenReturn(workflowContext);
        when(workflowContext.getRequest()).thenReturn(workflowRequest);
        when(workflowRequest.getRequestId()).thenReturn(1l);
    }

    //@Test
    public void testProcessArchivalRecordsWhenArchivalTableIsEmpty(){

        ArchivalTableService archivalTableService = mock (ArchivalTableService.class);
        MirrorActivity mirrorActivity = new MirrorActivityImpl(archivalTableService, queryLogger);
        List<DataArchivalTable> archivalOrDeletableTables = Arrays.asList();

        when(archivalTableService.clearUnProcessedEntriesFromPreviousBatch(handle)).thenReturn(1);
        when(archivalTableService.fetchArchivalTables(handle)).thenReturn(archivalOrDeletableTables);
        when(archivalTableService.getArchivalSettings(handle, "DATA_ARCHIVE")).thenReturn(archivalSettingsEntity);
        when(context.getMetricsScope()).thenReturn(scope);
        when(archivalTableService.isArchivalEnabled(handle)).thenReturn(true);
        activity.when(Activity::getExecutionContext).thenReturn(context);
        ArchivalResult results = mirrorActivity.processArchivalRecords();
        assertEquals(ArchivalStatus.DATA_ERROR, results.getStatus());
        assertEquals("Archival Meta data table is empty", results.getMessage());
    }

    //@Test
    public void testProcessArchivalRecordsWhenExpiredRcIsEmpty(){
        ArchivalTableService archivalTableService = mock (ArchivalTableService.class);
        MirrorActivity mirrorActivity = new MirrorActivityImpl(archivalTableService, queryLogger);

        List<DataArchivalTable> archivalOrDeletableTables = new ArrayList<>();
        archivalOrDeletableTables.add(new DataArchivalTable());

        when(archivalTableService.clearUnProcessedEntriesFromPreviousBatch(handle)).thenReturn(1);
        when(archivalTableService.fetchArchivalTables(handle)).thenReturn(archivalOrDeletableTables);

        when(archivalTableService.getArchivalSettings(handle, "DATA_ARCHIVE")).thenReturn(archivalSettingsEntity);
        when(archivalTableService.insertHeadGDetails(handle, archivalSettingsEntity)).thenReturn(1);
        when(archivalTableService.getExpiredRcs(handle, 1, BatchStatus.NEW.label, archivalSettingsEntity.getBatchSize()))
                .thenReturn(new ArrayList<>());
        when(context.getMetricsScope()).thenReturn(scope);
        when(archivalTableService.isArchivalEnabled(handle)).thenReturn(true);
        activity.when(Activity::getExecutionContext).thenReturn(context);

        ArchivalResult results = mirrorActivity.processArchivalRecords();
        assertEquals(ArchivalStatus.EMPTY_BATCH, results.getStatus());
        assertEquals("No expired rc's found to migrate", results.getMessage());
    }

    //@Test
    public void testProcessArchivalRecordsWhenActivityIsCancelled(){
        ArchivalTableService archivalTableService = mock (ArchivalTableService.class);
        MirrorActivity mirrorActivity = new MirrorActivityImpl(archivalTableService, queryLogger);

        List<DataArchivalTable> archivalOrDeletableTables = new ArrayList<>();
        DataArchivalTable table = new DataArchivalTable();
        table.setName("testTable");
        archivalOrDeletableTables.add(table);

        when(archivalTableService.clearUnProcessedEntriesFromPreviousBatch(handle)).thenReturn(1);
        when(archivalTableService.fetchArchivalTables(handle)).thenReturn(archivalOrDeletableTables);
        when(archivalTableService.getSchemaName(any())).thenReturn("testSchema");

        List rcIds= Collections.singletonList(1001);
        when(archivalTableService.getArchivalSettings(handle, "DATA_ARCHIVE")).thenReturn(archivalSettingsEntity);

        when(archivalTableService.getExpiredRcs(handle, 1, BatchStatus.NEW.label, archivalSettingsEntity.getBatchSize()))
                .thenReturn(rcIds);
        commonUtils.when(() -> CommonUtils.isActivityCancelled(any())).thenReturn(true);
        when(context.getMetricsScope()).thenReturn(scope);
        when(archivalTableService.isArchivalEnabled(handle)).thenReturn(true);
        activity.when(Activity::getExecutionContext).thenReturn(context);

        ArchivalResult results = mirrorActivity.processArchivalRecords();
        assertEquals(ArchivalStatus.ACTIVITY_CANCELLED, results.getStatus());
        assertEquals("Activity is cancelled by the temporal cluster ", results.getMessage());
    }

    //@Test(expected = RuntimeException.class)
    public void testThrowsRuntimeExceptionWhenProcessArchivalRecords(){
        ArchivalTableService archivalTableService = mock (ArchivalTableService.class);
        MirrorActivity mirrorActivity = new MirrorActivityImpl(archivalTableService, queryLogger);

        List<DataArchivalTable> archivalOrDeletableTables = new ArrayList<>();
        archivalOrDeletableTables.add(new DataArchivalTable());

        when(archivalTableService.clearUnProcessedEntriesFromPreviousBatch(handle)).thenReturn(1);
        when(archivalTableService.fetchArchivalTables(handle)).thenReturn(archivalOrDeletableTables);
        when(context.getMetricsScope()).thenReturn(scope);
        when(archivalTableService.getArchivalSettings(handle, "DATA_ARCHIVE")).thenReturn(archivalSettingsEntity);
        when(archivalTableService.insertHeadGDetails(handle, archivalSettingsEntity)).thenReturn(1);
        when(archivalTableService.getExpiredRcs(handle, 1, BatchStatus.NEW.label, archivalSettingsEntity.getBatchSize()))
                .thenThrow(RuntimeException.class);
        when(archivalTableService.isArchivalEnabled(handle)).thenReturn(true);
        activity.when(Activity::getExecutionContext).thenReturn(context);
        ArchivalResult results = mirrorActivity.processArchivalRecords();
        assertEquals(ArchivalStatus.DATA_ERROR, results.getStatus());
        assertEquals("Unexpected error. See the error stack for more information", results.getMessage());

    }

    //@Test
    public void testThrowsRuntimeExceptionWhenArchivalIsNotEnabled() {
        ArchivalTableService archivalTableService = mock (ArchivalTableService.class);
        MirrorActivity mirrorActivity = new MirrorActivityImpl(archivalTableService, queryLogger);

        List<DataArchivalTable> archivalOrDeletableTables = new ArrayList<>();
        archivalOrDeletableTables.add(new DataArchivalTable());

        when(archivalTableService.clearUnProcessedEntriesFromPreviousBatch(handle)).thenReturn(1);
        when(archivalTableService.fetchArchivalTables(handle)).thenReturn(archivalOrDeletableTables);

        when(archivalTableService.getArchivalSettings(handle, "DATA_ARCHIVE")).thenReturn(archivalSettingsEntity);
        when(archivalTableService.insertHeadGDetails(handle, archivalSettingsEntity)).thenReturn(1);
        when(archivalTableService.isArchivalEnabled(handle)).thenReturn(false);
        when(archivalTableService.getExpiredRcs(handle, 1, BatchStatus.NEW.label, archivalSettingsEntity.getBatchSize()))
                .thenReturn(new ArrayList<>(Arrays.asList(1L, 2L, 3L)));

        ArchivalResult results = mirrorActivity.processArchivalRecords();
        assertEquals(ArchivalStatus.ARCHIVAL_NOT_ENABLED, results.getStatus());
        assertEquals("Archival is not enabled for this tenant.", results.getMessage());
    }
}



