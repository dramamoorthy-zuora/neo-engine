package com.zuora.neo.engine.jobs.caclnetting.service;

import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.api.PeriodDetails;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.caclnetting.config.CaclProperties;
import com.zuora.neo.engine.jobs.caclnetting.db.dao.CaclNettingDao;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CaclNettingRtpServiceTest {

    @Mock
    private CommonDao commonDao;
    @Mock
    private CaclNettingDao nettingDao;
    @Mock
    private CaclProperties caclProperties;
    @Mock
    private InitializerService initializerService;

    @Mock
    private NeoWorkflowLogger neoWorkflowLogger;

    @Spy
    @InjectMocks
    private CaclNettingRtpService caclNettingRtpService;

    private static final BigDecimal batchId = new BigDecimal(1.0);

    private static final String user = "UNIT_TEST", createLineLevel = "Y", orgId = "0";

    private static final Long bookId = 1L, clientId = 1L;

    private static PeriodDetails periodDetailsMock = new PeriodDetails(1, 1, 1);

    @Test
    public void testNettingRtp() {
        WorkflowRequest workflowRequestMock = new WorkflowRequest(497, 1000L, "test", "0", 1L,
                "user", 1L, "~");

        WorkflowContext workflowContext = new WorkflowContext(workflowRequestMock);
        WorkflowContextManager.setWorkflowContext(workflowContext);

        List<Long> bookIds = new ArrayList<>();
        bookIds.add(1L);
        bookIds.add(2L);

        when(nettingDao.getUniqueBookIdsForRtpBatch(any(), anyString(), anyString())).thenReturn(bookIds);
        when(caclProperties.getNettingLevel()).thenReturn("APPLICATION");

        doNothing().when(caclNettingRtpService).processWorkItemForGivenBook(nettingDao, commonDao, batchId, "Y");

        caclNettingRtpService.performNettingRtp(nettingDao, commonDao, batchId, orgId);

        verify(caclProperties, times(2)).getNettingLevel();
    }

}