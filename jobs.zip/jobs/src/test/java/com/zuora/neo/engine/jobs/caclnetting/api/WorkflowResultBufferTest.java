package com.zuora.neo.engine.jobs.caclnetting.api;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class WorkflowResultBufferTest {

    @Test
    public void testGettersAndSetters() {
        WorkflowResultBuffer workflowResultBuffer = new WorkflowResultBuffer();

        workflowResultBuffer.setReturnCode(0);
        workflowResultBuffer.setMessageBuffer("COMPLETED");

        assertEquals(workflowResultBuffer.getReturnCode(), 0);
        assertEquals(workflowResultBuffer.getMessageBuffer(), "COMPLETED");
    }

}
