package com.zuora.neo.engine.jobs.sfc.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.api.AccountValue;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.CurrencyDetails;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.sfc.SfcResult;
import com.zuora.neo.engine.jobs.sfc.constants.SfcConstants;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.context.SfcPostProcessDetailsContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;

import org.jdbi.v3.core.Handle;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class SoUpdateServiceTest {

    @Mock
    private SfcDao sfcDao;

    @Mock
    private CommonDao commonDao;

    @Mock
    Handle handle;

    @Mock
    SfcServiceUtils sfcServiceUtils;

    @Mock
    RcLinePaDataService rcLinePaDataService;

    @Mock
    RcHeadDataService rcHeadDataService;

    @Mock
    SfcCalcDetailService sfcCalcDetailService;

    @Mock
    RippedLineProcessingService rippedLineProcessingService;

    @Mock
    SfcTablesBatchInsertUpdateService sfcTablesBatchInsertUpdateService;

    @InjectMocks
    SoUpdateService soUpdateService;

    private void populateTestData(List<RcLineDetails> rcLineDetailsBatch, List<SfcPaymentDetails> sfcPaymentDetailsBatch,
            List<SfcCalcDetails> sfcCalcDetailsBatch, List<RcScheduleRecord> rcScheduleRecordBatch) throws ParseException {

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setRelPct(BigDecimal.valueOf(100.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setDocDate(new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2019"));
        rcLineDetails.setDocNum("SO379");
        rcLineDetailsBatch.add(rcLineDetails);

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(100.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsBatch.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(105.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsBatch.add(sfcPaymentDetails);

        SfcCalcDetails sfcCalcDetails = new SfcCalcDetails(1);
        sfcCalcDetails.setId(1);
        sfcCalcDetails.setLineId(11200);
        sfcCalcDetails.setRcId(10007);
        sfcCalcDetails.setPeriodId(202202);
        sfcCalcDetails.setInterest(BigDecimal.valueOf(100.00));
        sfcCalcDetailsBatch.add(sfcCalcDetails);
        sfcCalcDetails.setId(2);
        sfcCalcDetails.setLineId(11200);
        sfcCalcDetails.setRcId(10007);
        sfcCalcDetails.setPeriodId(2022023);
        sfcCalcDetails.setInterest(BigDecimal.valueOf(100.00));
        sfcCalcDetailsBatch.add(sfcCalcDetails);

        RcScheduleRecord rcScheduleRecord = new RcScheduleRecord();
        rcScheduleRecord.setId(1);
        rcScheduleRecord.setLineId(111);
        rcScheduleRecord.setRcId(10007);
        rcScheduleRecord.setRootLineId(11200);
        rcScheduleRecord.setAmount(BigDecimal.valueOf(100.00));
        rcScheduleRecordBatch.add(rcScheduleRecord);
        rcScheduleRecord.setId(2);
        rcScheduleRecord.setLineId(111);
        rcScheduleRecord.setRcId(10007);
        rcScheduleRecord.setRootLineId(11200);
        rcScheduleRecord.setAmount(BigDecimal.valueOf(100.00));
        rcScheduleRecordBatch.add(rcScheduleRecord);
    }

    @Test
    public void testGetSfcDetails() throws ParseException {

        List<SfcStatusValues> sfcStatusValuesList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsBatch = new ArrayList<>();
        List<SfcPaymentDetails> sfcPaymentDetailsBatch = new ArrayList<>();
        List<SfcCalcDetails> sfcCalcDetailsBatch = new ArrayList<>();
        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();
        populateTestData(rcLineDetailsBatch, sfcPaymentDetailsBatch, sfcCalcDetailsBatch, rcScheduleRecordBatch);

        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(sfcDao.getRcLineDetailsByDocLineIdListWithAttributes(Mockito.any())).thenReturn(rcLineDetailsBatch);
        Mockito.when(sfcDao.getSfcPaymentDetailsByDocLineIdList(Mockito.any())).thenReturn(sfcPaymentDetailsBatch);

        SfcPostProcessDetailsContext sfcPostProcessDetailsContext = soUpdateService.getSfcDetails(sfcStatusValuesList, handle);
        assertEquals(sfcPostProcessDetailsContext.getRcLineDetailsBatchMap().size(), 1);
        assertTrue(sfcPostProcessDetailsContext.getRcLineDetailsBatchMap().containsKey("SO_123_4.6"));
        assertEquals(sfcPostProcessDetailsContext.getSfcPaymentDetailsBatchMap().size(), 1);
        assertTrue(sfcPostProcessDetailsContext.getSfcPaymentDetailsBatchMap().containsKey("SO_123_4.6"));
    }

    @Test
    public void testGetSfcDetailsNoData() throws ParseException {

        List<SfcStatusValues> sfcStatusValuesList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsBatch = new ArrayList<>();
        List<SfcPaymentDetails> sfcPaymentDetailsBatch = new ArrayList<>();

        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");
        sfcStatusValues.setDocNum("SO379");
        sfcStatusValues.setStatus("Ready for SFC");
        sfcStatusValuesList.add(sfcStatusValues);
        sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.6");
        sfcStatusValues.setDocNum("SO379");
        sfcStatusValues.setStatus("Ready for SFC");
        sfcStatusValuesList.add(sfcStatusValues);

        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(sfcDao.getRcLineDetailsByDocLineIdListWithAttributes(Mockito.any())).thenReturn(rcLineDetailsBatch);
        Mockito.when(sfcDao.getSfcPaymentDetailsByDocLineIdList(Mockito.any())).thenReturn(sfcPaymentDetailsBatch);

        SfcPostProcessDetailsContext sfcPostProcessDetailsContext = soUpdateService.getSfcDetails(sfcStatusValuesList, handle);
        assertEquals(sfcPostProcessDetailsContext.getRcLineDetailsBatchMap().size(), 0);
        assertFalse(sfcPostProcessDetailsContext.getRcLineDetailsBatchMap().containsKey("SO_123_4.6"));
        assertEquals(sfcPostProcessDetailsContext.getSfcPaymentDetailsBatchMap().size(), 0);
        assertFalse(sfcPostProcessDetailsContext.getSfcPaymentDetailsBatchMap().containsKey("SO_123_4.6"));
    }

    @Test
    public void testProcessUpdatedSoNoReCalc() throws ParseException {

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        WorkflowContext workflowContext = new WorkflowContext(request);
        WorkflowContextManager.setWorkflowContext(workflowContext);

        List<SfcStatusValues> sfcStatusValuesList = new ArrayList<>();
        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsBatch = new ArrayList<>();
        List<SfcPaymentDetails> sfcPaymentDetailsBatch = new ArrayList<>();
        List<SfcCalcDetails> sfcCalcDetailsBatch = new ArrayList<>();
        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();
        populateTestData(rcLineDetailsBatch, sfcPaymentDetailsBatch, sfcCalcDetailsBatch, rcScheduleRecordBatch);
        List<RcLinePaData> rcLinePaDataList = new ArrayList<>();
        long openPeriodId = 202202;
        SfcResult sfcResult = new SfcResult();

        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.6");
        sfcStatusValues.setDocNum("SO379");
        sfcStatusValues.setIndicators("NNNNNNNNNN");
        sfcStatusValues.setStatus("Ready for SFC");
        sfcStatusValuesList.add(sfcStatusValues);

        List<CurrencyDetails> currencyDetailsList = new ArrayList<>();
        CurrencyDetails currencyDetails = new CurrencyDetails("USD", 2, "USD");
        currencyDetailsList.add(currencyDetails);

        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020, "SFC", "SFC with Interest Calculator",
                1, "DR_APR", null, null, null, "EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"), new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1, 201501, "MIGRATION", new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"), "MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"), 1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        Map<String, String> paramsMap = new HashMap<>();
        paramsMap.put(SfcConstants.BOOK_NAME_PARAM, "1");

        List<AccountValue> accountValuesList = new ArrayList<>();
        AccountValue accountValue = new AccountValue();
        accountValue.setAcctSeg("1234");
        accountValue.setClientId(1);
        accountValuesList.add(accountValue);

        List<CalendarDetails> calendarDetailsList = new ArrayList<>();
        CalendarDetails calendarDetail = new CalendarDetails(202202, "FEB-22", new Date(), new Date());
        calendarDetailsList.add(calendarDetail);

        RcLinePaData rcLinePaData = new RcLinePaData();
        rcLinePaData.setId(111);
        rcLinePaData.setRcId(10007);
        rcLinePaData.setLineId(11200);
        rcLinePaData.setVcTypeId(10020);
        rcLinePaData.setFncTypeVersion(1);
        rcLinePaDataList.add(rcLinePaData);

        Map<String, Integer> currencyMap = new HashMap<>();
        currencyMap.put("fmvwcea:USD", 2);

        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();
        sfcDbCacheContext.setFinanceTypeValuesList(financeTypeValuesList);
        sfcDbCacheContext.setCalendarDetailsCache(calendarDetailsList);
        sfcDbCacheContext.setCalendarDetails(calendarDetailsList);
        sfcDbCacheContext.setCurrentPeriodId(openPeriodId);
        sfcDbCacheContext.setCurrencyMap(currencyMap);
        sfcDbCacheContext.setBookId(1);

        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(handle.attach(CommonDao.class)).thenReturn(commonDao);
        Mockito.when(sfcDao.getRcLineDetailsByDocLineIdListWithAttributes(Mockito.any())).thenReturn(rcLineDetailsBatch);
        Mockito.when(sfcDao.getRcLinePaDataForLineId(Mockito.anyLong(), Mockito.anyLong())).thenReturn(rcLinePaDataList);
        //Mockito.when(sfcDao.getSfcCalcByDocLine(Mockito.anyLong())).thenReturn(sfcCalcDetailsBatch);
        Mockito.when(sfcServiceUtils.validSfcLine(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
        Mockito.when(sfcServiceUtils.getFinanceTypeForRcLine(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(financeTypeValuesList);
        Mockito.doNothing().when(sfcTablesBatchInsertUpdateService).batchUpdateSfcStatusTable(sfcStatusValuesList, handle);
        Mockito.doNothing().when(rippedLineProcessingService).processRippedSfcLine(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.anyLong(), Mockito.any(), Mockito.anyList(), Mockito.anyList(), Mockito.any(), Mockito.any());

        soUpdateService.processUpdatedSo(sfcStatusValuesList, sfcDbCacheContext, sfcResult, handle);
        assertEquals(sfcStatusValuesList.get(0).getStatus(), "Completed");

    }

    @Test
    public void testProcessUpdatedSoReCalc() throws ParseException {

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        WorkflowContext workflowContext = new WorkflowContext(request);
        WorkflowContextManager.setWorkflowContext(workflowContext);

        List<SfcStatusValues> sfcStatusValuesList = new ArrayList<>();
        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsBatch = new ArrayList<>();
        List<SfcPaymentDetails> sfcPaymentDetailsBatch = new ArrayList<>();
        List<SfcCalcDetails> sfcCalcDetailsBatch = new ArrayList<>();
        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();
        populateTestData(rcLineDetailsBatch, sfcPaymentDetailsBatch, sfcCalcDetailsBatch, rcScheduleRecordBatch);
        List<RcLinePaData> rcLinePaDataList = new ArrayList<>();
        long openPeriodId = 202202;
        SfcResult sfcResult = new SfcResult();

        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.6");
        sfcStatusValues.setDocNum("SO379");
        sfcStatusValues.setIndicators("NYNNNNNNNN");
        sfcStatusValues.setStatus("Ready for SFC");
        sfcStatusValuesList.add(sfcStatusValues);

        List<CurrencyDetails> currencyDetailsList = new ArrayList<>();
        CurrencyDetails currencyDetails = new CurrencyDetails("USD", 2, "USD");
        currencyDetailsList.add(currencyDetails);

        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020, "SFC", "SFC with Interest Calculator",
                1, "DR_APR", null, null, null, "EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"), new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1, 201501, "MIGRATION", new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"), "MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"), 1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        Map<String, String> paramsMap = new HashMap<>();
        paramsMap.put(SfcConstants.BOOK_NAME_PARAM, "1");

        List<AccountValue> accountValuesList = new ArrayList<>();
        AccountValue accountValue = new AccountValue();
        accountValue.setAcctSeg("1234");
        accountValue.setClientId(1);
        accountValuesList.add(accountValue);

        List<CalendarDetails> calendarDetailsList = new ArrayList<>();
        CalendarDetails calendarDetail = new CalendarDetails(202202, "FEB-22", new Date(), new Date());
        calendarDetailsList.add(calendarDetail);

        RcLinePaData rcLinePaData = new RcLinePaData();
        rcLinePaData.setId(111);
        rcLinePaData.setRcId(10007);
        rcLinePaData.setLineId(11200);
        rcLinePaData.setVcTypeId(10020);
        rcLinePaData.setFncTypeVersion(1);
        rcLinePaDataList.add(rcLinePaData);

        Map<String, Integer> currencyMap = new HashMap<>();
        currencyMap.put("fmvwcea:USD", 2);

        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();
        sfcDbCacheContext.setFinanceTypeValuesList(financeTypeValuesList);
        sfcDbCacheContext.setCalendarDetailsCache(calendarDetailsList);
        sfcDbCacheContext.setCalendarDetails(calendarDetailsList);
        sfcDbCacheContext.setCurrentPeriodId(openPeriodId);
        sfcDbCacheContext.setCurrencyMap(currencyMap);
        sfcDbCacheContext.setBookId(1);

        SoUpdateService soUpdateService1 = Mockito.spy(soUpdateService);

        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(handle.attach(CommonDao.class)).thenReturn(commonDao);
        Mockito.when(sfcDao.getRcLineDetailsByDocLineIdListWithAttributes(Mockito.any())).thenReturn(rcLineDetailsBatch);
        Mockito.when(sfcDao.getRcLinePaDataForLineId(Mockito.anyLong(), Mockito.anyLong())).thenReturn(rcLinePaDataList);
        Mockito.when(sfcServiceUtils.validSfcLine(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
        Mockito.when(sfcDao.getSfcCalcByDocLine(Mockito.anyLong())).thenReturn(sfcCalcDetailsBatch);
        Mockito.when(sfcServiceUtils.getFinanceTypeForRcLine(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(financeTypeValuesList);
        Mockito.doNothing().when(sfcTablesBatchInsertUpdateService).batchUpdateSfcStatusTable(sfcStatusValuesList, handle);
        Mockito.doNothing().when(soUpdateService1).deleteSfcCalcDetailsForLine(Mockito.any(),Mockito.any());

        soUpdateService1.processUpdatedSo(sfcStatusValuesList, sfcDbCacheContext, sfcResult, handle);
        assertEquals(sfcStatusValuesList.get(0).getStatus(), "Ready for SFC");

    }

    @Test
    public void testProcessUpdatedSoNoFinancType() throws ParseException {

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        WorkflowContext workflowContext = new WorkflowContext(request);
        WorkflowContextManager.setWorkflowContext(workflowContext);

        List<SfcStatusValues> sfcStatusValuesList = new ArrayList<>();
        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsBatch = new ArrayList<>();
        List<SfcPaymentDetails> sfcPaymentDetailsBatch = new ArrayList<>();
        List<SfcCalcDetails> sfcCalcDetailsBatch = new ArrayList<>();
        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();
        populateTestData(rcLineDetailsBatch, sfcPaymentDetailsBatch, sfcCalcDetailsBatch, rcScheduleRecordBatch);
        List<RcLinePaData> rcLinePaDataList = new ArrayList<>();
        long openPeriodId = 202202;
        SfcResult sfcResult = new SfcResult();

        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.6");
        sfcStatusValues.setDocNum("SO379");
        sfcStatusValues.setIndicators("NYNNNNNNNN");
        sfcStatusValues.setStatus("Ready for SFC");
        sfcStatusValuesList.add(sfcStatusValues);

        List<CurrencyDetails> currencyDetailsList = new ArrayList<>();
        CurrencyDetails currencyDetails = new CurrencyDetails("USD", 2, "USD");
        currencyDetailsList.add(currencyDetails);

        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020, "SFC", "SFC with Interest Calculator",
                1, "DR_APR", null, null, null, "EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"), new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1, 201501, "MIGRATION", new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"), "MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"), 1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        Map<String, String> paramsMap = new HashMap<>();
        paramsMap.put(SfcConstants.BOOK_NAME_PARAM, "1");

        List<AccountValue> accountValuesList = new ArrayList<>();
        AccountValue accountValue = new AccountValue();
        accountValue.setAcctSeg("1234");
        accountValue.setClientId(1);
        accountValuesList.add(accountValue);

        List<CalendarDetails> calendarDetailsList = new ArrayList<>();
        CalendarDetails calendarDetail = new CalendarDetails(202202, "FEB-22", new Date(), new Date());
        calendarDetailsList.add(calendarDetail);

        RcLinePaData rcLinePaData = new RcLinePaData();
        rcLinePaData.setId(111);
        rcLinePaData.setRcId(10007);
        rcLinePaData.setLineId(11200);
        rcLinePaData.setVcTypeId(10020);
        rcLinePaData.setFncTypeVersion(1);
        rcLinePaDataList.add(rcLinePaData);

        Map<String, Integer> currencyMap = new HashMap<>();
        currencyMap.put("fmvwcea:USD", 2);

        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();
        sfcDbCacheContext.setFinanceTypeValuesList(financeTypeValuesList);
        sfcDbCacheContext.setCalendarDetailsCache(calendarDetailsList);
        sfcDbCacheContext.setCalendarDetails(calendarDetailsList);
        sfcDbCacheContext.setCurrentPeriodId(openPeriodId);
        sfcDbCacheContext.setCurrencyMap(currencyMap);
        sfcDbCacheContext.setBookId(1);

        SoUpdateService soUpdateService1 = Mockito.spy(soUpdateService);

        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(handle.attach(CommonDao.class)).thenReturn(commonDao);
        Mockito.when(sfcDao.getRcLineDetailsByDocLineIdListWithAttributes(Mockito.any())).thenReturn(rcLineDetailsBatch);
        Mockito.when(sfcDao.getRcLinePaDataForLineId(Mockito.anyLong(), Mockito.anyLong())).thenReturn(rcLinePaDataList);
        Mockito.doNothing().when(sfcTablesBatchInsertUpdateService).batchUpdateSfcStatusTable(sfcStatusValuesList, handle);

        soUpdateService1.processUpdatedSo(sfcStatusValuesList, sfcDbCacheContext, sfcResult, handle);
        assertEquals(sfcStatusValuesList.get(0).getStatus(), "Ready for SFC");

    }
}