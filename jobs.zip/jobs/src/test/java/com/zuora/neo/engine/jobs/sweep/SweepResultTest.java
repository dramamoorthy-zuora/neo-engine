package com.zuora.neo.engine.jobs.sweep;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class SweepResultTest {

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>default or parameterless constructor of {@link SweepResult}
     *   <li>{@link SweepResult#setBookId(long)}
     *   <li>{@link SweepResult#setRowsUpdated(int)}
     *   <li>{@link SweepResult#setSummaryRecords(int)}
     *   <li>{@link SweepResult#setSweepType(String)}
     *   <li>{@link SweepResult#toString()}
     *   <li>{@link SweepResult#getBookId()}
     *   <li>{@link SweepResult#getRowsUpdated()}
     *   <li>{@link SweepResult#getSummaryRecords()}
     *   <li>{@link SweepResult#getSweepType()}
     * </ul>
     */
    @Test
    public void testConstructor() {
        SweepResult actualSweepResult = new SweepResult();
        actualSweepResult.setBookId(123L);
        actualSweepResult.setRowsUpdated(1);
        actualSweepResult.setSummaryRecords(1);
        actualSweepResult.setSweepType("Sweep Type");
        String actualToStringResult = actualSweepResult.toString();
        assertEquals(123L, actualSweepResult.getBookId());
        assertEquals(1, actualSweepResult.getRowsUpdated());
        assertEquals(1, actualSweepResult.getSummaryRecords());
        assertEquals("Sweep Type", actualSweepResult.getSweepType());
        assertEquals("SweepResult{rowsUpdated=1, summaryRecords=1}", actualToStringResult);
    }
}

