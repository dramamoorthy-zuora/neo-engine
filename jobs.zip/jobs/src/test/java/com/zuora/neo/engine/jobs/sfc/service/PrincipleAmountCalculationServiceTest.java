package com.zuora.neo.engine.jobs.sfc.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.PrincipleWeightageColumn;
import com.zuora.neo.engine.jobs.sfc.exception.NoDetailsFoundException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class PrincipleAmountCalculationServiceTest {


    @Test
    public void testDetermineWeightageMethodWithIndicatorC() throws ParseException {

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        PrincipleAmountCalculationService principleAmountCalculationService = new PrincipleAmountCalculationService();

        PrincipleWeightageColumn principleWeightageColumn = principleAmountCalculationService.determineWeightageMethod(financeTypeValuesList);

        assertEquals(PrincipleWeightageColumn.EXT_FV_PRC, principleWeightageColumn);

    }

    @Test
    public void testDetermineWeightageMethodWithIndicatorNotC() throws ParseException {

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLSLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        PrincipleAmountCalculationService principleAmountCalculationService = new PrincipleAmountCalculationService();

        PrincipleWeightageColumn principleWeightageColumn = principleAmountCalculationService.determineWeightageMethod(financeTypeValuesList);

        assertEquals(PrincipleWeightageColumn.EXT_SLL_PRC, principleWeightageColumn);

    }

    @Test
    public void testDetermineWeightageMethodWithEmptyList() {

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        PrincipleAmountCalculationService principleAmountCalculationService = new PrincipleAmountCalculationService();
        PrincipleWeightageColumn principleWeightageColumn = principleAmountCalculationService.determineWeightageMethod(financeTypeValuesList);

        assertEquals(PrincipleWeightageColumn.EXT_SLL_PRC, principleWeightageColumn);

    }

    @Test
    public void testCalculatePrincipleAmountExtSllPriceHappyFlow() throws NoDetailsFoundException {
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setDocLineId("SO_LINE_123");
        rcLineDetails.setDocNum("SO_NUM_123");
        rcLineDetails.setExtFvPrc(BigDecimal.valueOf(1000.00));
        rcLineDetails.setExtSllPrc(BigDecimal.valueOf(1000.00));
        rcLineDetails.setExtFvPrc(BigDecimal.valueOf(1200.00));

        Map<String, RcLineDetails> rcLineDetailsByDocNumMap = new HashMap<>();

        RcLineDetails rcLineDetailsForDocMap = new RcLineDetails();
        rcLineDetailsForDocMap.setSumOfExtLstPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtFvPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtSllPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setDocNum("SO_NUM_123");

        rcLineDetailsByDocNumMap.put("SO_NUM_123", rcLineDetailsForDocMap);

        PrincipleWeightageColumn principleWeightageColumn = PrincipleWeightageColumn.EXT_SLL_PRC;
        Integer currRound = 2;

        PrincipleAmountCalculationService principleAmountCalculationService = new PrincipleAmountCalculationService();

        principleAmountCalculationService.calculatePrincipleAmount(rcLineDetails, rcLineDetailsByDocNumMap, principleWeightageColumn, currRound);

        assertNotNull(rcLineDetails.getPrincipleAmount());
        assertEquals(BigDecimal.valueOf((long) 100000, 2), rcLineDetails.getPrincipleAmount());


    }

    @Test
    public void testCalculatePrincipleAmountWithExtSllPrcNull() {
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setDocLineId("SO_LINE_123");
        rcLineDetails.setDocNum("SO_NUM_123");
        rcLineDetails.setExtFvPrc(BigDecimal.valueOf(1000.00));
        rcLineDetails.setExtLstPrc(BigDecimal.valueOf(1200.00));

        Map<String, RcLineDetails> rcLineDetailsByDocNumMap = new HashMap<>();

        RcLineDetails rcLineDetailsForDocMap = new RcLineDetails();
        rcLineDetailsForDocMap.setSumOfExtLstPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtFvPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtSllPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setDocNum("SO_NUM_123");

        rcLineDetailsByDocNumMap.put("SO_NUM_123", rcLineDetailsForDocMap);

        PrincipleWeightageColumn principleWeightageColumn = PrincipleWeightageColumn.EXT_SLL_PRC;
        Integer currRound = 2;

        PrincipleAmountCalculationService principleAmountCalculationService = new PrincipleAmountCalculationService();

        try {
            principleAmountCalculationService.calculatePrincipleAmount(rcLineDetails, rcLineDetailsByDocNumMap, principleWeightageColumn, currRound);
        } catch (Exception e) {
            assertEquals(NoDetailsFoundException.class, e.getClass());
        }

    }

    @Test
    public void testCalculatePrincipleAmountWithExtSllPrcZero() {
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setDocLineId("SO_LINE_123");
        rcLineDetails.setDocNum("SO_NUM_123");
        rcLineDetails.setExtSllPrc(BigDecimal.valueOf(0.00));
        rcLineDetails.setExtFvPrc(BigDecimal.valueOf(1000.00));
        rcLineDetails.setExtLstPrc(BigDecimal.valueOf(1200.00));

        Map<String, RcLineDetails> rcLineDetailsByDocNumMap = new HashMap<>();

        RcLineDetails rcLineDetailsForDocMap = new RcLineDetails();
        rcLineDetailsForDocMap.setSumOfExtLstPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtFvPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtSllPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setDocNum("SO_NUM_123");

        rcLineDetailsByDocNumMap.put("SO_NUM_123", rcLineDetailsForDocMap);

        PrincipleWeightageColumn principleWeightageColumn = PrincipleWeightageColumn.EXT_SLL_PRC;
        Integer currRound = 2;

        PrincipleAmountCalculationService principleAmountCalculationService = new PrincipleAmountCalculationService();

        try {
            principleAmountCalculationService.calculatePrincipleAmount(rcLineDetails, rcLineDetailsByDocNumMap, principleWeightageColumn, currRound);
        } catch (Exception e) {
            assertEquals(NoDetailsFoundException.class, e.getClass());
        }

    }

    @Test
    public void testCalculatePrincipleAmountExtFvPriceHappyFlow() throws NoDetailsFoundException {
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setDocLineId("SO_LINE_123");
        rcLineDetails.setDocNum("SO_NUM_123");
        rcLineDetails.setExtFvPrc(BigDecimal.valueOf(1000.00));
        rcLineDetails.setExtSllPrc(BigDecimal.valueOf(1000.00));
        rcLineDetails.setExtLstPrc(BigDecimal.valueOf(1200.00));

        Map<String, RcLineDetails> rcLineDetailsByDocNumMap = new HashMap<>();

        RcLineDetails rcLineDetailsForDocMap = new RcLineDetails();
        rcLineDetailsForDocMap.setSumOfExtLstPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtFvPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtSllPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setDocNum("SO_NUM_123");

        rcLineDetailsByDocNumMap.put("SO_NUM_123", rcLineDetailsForDocMap);

        PrincipleWeightageColumn principleWeightageColumn = PrincipleWeightageColumn.EXT_FV_PRC;
        Integer currRound = 2;

        PrincipleAmountCalculationService principleAmountCalculationService = new PrincipleAmountCalculationService();

        principleAmountCalculationService.calculatePrincipleAmount(rcLineDetails, rcLineDetailsByDocNumMap, principleWeightageColumn, currRound);

        assertNotNull(rcLineDetails.getPrincipleAmount());
        assertEquals(BigDecimal.valueOf((long) 100000, 2), rcLineDetails.getPrincipleAmount());


    }

    @Test
    public void testCalculatePrincipleAmountWithExtFvPrcNull() {
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setDocLineId("SO_LINE_123");
        rcLineDetails.setDocNum("SO_NUM_123");
        rcLineDetails.setExtLstPrc(BigDecimal.valueOf(1200.00));

        Map<String, RcLineDetails> rcLineDetailsByDocNumMap = new HashMap<>();

        RcLineDetails rcLineDetailsForDocMap = new RcLineDetails();
        rcLineDetailsForDocMap.setSumOfExtLstPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtFvPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtSllPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setDocNum("SO_NUM_123");

        rcLineDetailsByDocNumMap.put("SO_NUM_123", rcLineDetailsForDocMap);

        PrincipleWeightageColumn principleWeightageColumn = PrincipleWeightageColumn.EXT_FV_PRC;
        Integer currRound = 2;

        PrincipleAmountCalculationService principleAmountCalculationService = new PrincipleAmountCalculationService();

        try {
            principleAmountCalculationService.calculatePrincipleAmount(rcLineDetails, rcLineDetailsByDocNumMap, principleWeightageColumn, currRound);
        } catch (Exception e) {
            assertEquals(NoDetailsFoundException.class, e.getClass());
        }

    }

    @Test
    public void testCalculatePrincipleAmountWithExtFvPrcZero() {
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setDocLineId("SO_LINE_123");
        rcLineDetails.setDocNum("SO_NUM_123");
        rcLineDetails.setExtFvPrc(BigDecimal.valueOf(0.00));
        rcLineDetails.setExtLstPrc(BigDecimal.valueOf(1200.00));

        Map<String, RcLineDetails> rcLineDetailsByDocNumMap = new HashMap<>();

        RcLineDetails rcLineDetailsForDocMap = new RcLineDetails();
        rcLineDetailsForDocMap.setSumOfExtLstPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtFvPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtSllPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setDocNum("SO_NUM_123");

        rcLineDetailsByDocNumMap.put("SO_NUM_123", rcLineDetailsForDocMap);

        PrincipleWeightageColumn principleWeightageColumn = PrincipleWeightageColumn.EXT_FV_PRC;
        Integer currRound = 2;

        PrincipleAmountCalculationService principleAmountCalculationService = new PrincipleAmountCalculationService();

        try {
            principleAmountCalculationService.calculatePrincipleAmount(rcLineDetails, rcLineDetailsByDocNumMap, principleWeightageColumn, currRound);
        } catch (Exception e) {
            assertEquals(NoDetailsFoundException.class, e.getClass());
        }

    }

    @Test
    public void testCalculatePrincipleAmountExtLstPriceHappyFlow() throws NoDetailsFoundException {
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setDocLineId("SO_LINE_123");
        rcLineDetails.setDocNum("SO_NUM_123");
        rcLineDetails.setExtFvPrc(BigDecimal.valueOf(1000.00));
        rcLineDetails.setExtSllPrc(BigDecimal.valueOf(1000.00));
        rcLineDetails.setExtLstPrc(BigDecimal.valueOf(1200.00));

        Map<String, RcLineDetails> rcLineDetailsByDocNumMap = new HashMap<>();

        RcLineDetails rcLineDetailsForDocMap = new RcLineDetails();
        rcLineDetailsForDocMap.setSumOfExtLstPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtFvPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtSllPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setDocNum("SO_NUM_123");

        rcLineDetailsByDocNumMap.put("SO_NUM_123", rcLineDetailsForDocMap);

        PrincipleWeightageColumn principleWeightageColumn = PrincipleWeightageColumn.EXT_LST_PRC;
        Integer currRound = 2;

        PrincipleAmountCalculationService principleAmountCalculationService = new PrincipleAmountCalculationService();

        principleAmountCalculationService.calculatePrincipleAmount(rcLineDetails, rcLineDetailsByDocNumMap, principleWeightageColumn, currRound);

        assertNotNull(rcLineDetails.getPrincipleAmount());
        assertEquals(BigDecimal.valueOf((long) 120000, 2), rcLineDetails.getPrincipleAmount());

    }

    @Test
    public void testCalculatePrincipleAmountWithExtLstPrcNull() {
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setDocLineId("SO_LINE_123");
        rcLineDetails.setDocNum("SO_NUM_123");
        rcLineDetails.setExtFvPrc(BigDecimal.valueOf(1000.00));

        Map<String, RcLineDetails> rcLineDetailsByDocNumMap = new HashMap<>();

        RcLineDetails rcLineDetailsForDocMap = new RcLineDetails();
        rcLineDetailsForDocMap.setSumOfExtLstPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtFvPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setSumOfExtSllPrc(BigDecimal.valueOf(10000.00));
        rcLineDetailsForDocMap.setDocNum("SO_NUM_123");

        rcLineDetailsByDocNumMap.put("SO_NUM_123", rcLineDetailsForDocMap);

        PrincipleWeightageColumn principleWeightageColumn = PrincipleWeightageColumn.EXT_LST_PRC;
        Integer currRound = 2;

        PrincipleAmountCalculationService principleAmountCalculationService = new PrincipleAmountCalculationService();

        try {
            principleAmountCalculationService.calculatePrincipleAmount(rcLineDetails, rcLineDetailsByDocNumMap, principleWeightageColumn, currRound);
        } catch (Exception e) {
            assertEquals(NoDetailsFoundException.class, e.getClass());
        }

    }



}
