package com.zuora.neo.engine.jobs.caclnetting.config;

import com.zuora.neo.engine.common.ScheduleTypes;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.caclnetting.db.dao.CaclNettingDao;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CaclPropertiesTest {

    @Mock
    private CommonDao commonDao;
    @Mock
    private CaclNettingDao nettingDao;
    @InjectMocks
    CaclProperties caclProperties;

    private static final BigDecimal batchId = new BigDecimal(1.0);

    private static final String user = "UNIT_TEST", createLineLevel = "Y", orgId = "0";

    private static final Long bookId = 1L, clientId = 1L;

    @Test
    public void testConstructor(){
        assertSame(caclProperties.isNettingEnabled(), false);
        assertSame(caclProperties.isNettingRcMje(), false);
    }

    @Test
    public void testGenerateTableName() {
        String tableName = "RPRO_CACL_NET_RC";
        assertEquals(tableName, caclProperties.generateTableName(tableName, false));
        assertEquals(tableName + "_SHADOW", caclProperties.generateTableName(tableName, true));
    }

    @Test
    public void testLoadProperties() {

        when(commonDao.getProfileValue(anyString(), anyString())).thenReturn("Y");

        caclProperties.loadProperties(commonDao, bookId, clientId, orgId, user);

        String expectedScheduleType = "";

        expectedScheduleType += "'" + ScheduleTypes.ALLOCATION.getScheduleType() + "'";
        expectedScheduleType += ",'" + ScheduleTypes.INTER_COMPANY.getScheduleType() + "'";
        expectedScheduleType += ",'" + ScheduleTypes.VARIABLE_CONSIDERATION.getScheduleType() + "'";
        expectedScheduleType += ",'" + ScheduleTypes.MJE.getScheduleType() + "'";

        assertEquals(expectedScheduleType, caclProperties.getSchdTypes());

    }

}
