package com.zuora.neo.engine.jobs.sfc.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.PreparedBatch;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class SfcCalcDetailServiceTest {

    @Mock
    private Handle handle;

    @Mock
    private PreparedBatch preparedBatch;

    @InjectMocks
    SfcCalcDetailService sfcCalcDetailService;

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SfcCalcDetailServiceTest.class);

    @Test
    public void testPopulateSfcCalcDetail() {

        BigDecimal interest = BigDecimal.valueOf(3.00);

        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRcPobId(12345);
        rcLineDetails.setfexRate(BigDecimal.valueOf(1));
        rcLineDetails.setgexRate(BigDecimal.valueOf(1));
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setDocDate(new Date());
        rcLineDetails.setClientId(1);
        rcLineDetails.setSecAtrVal("0");
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetailsList.add(rcLineDetails);

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");

        CalendarDetails calendarDetail = new CalendarDetails(202202, "FEB-22", new Date(), new Date());

        BigDecimal rebBegin = new BigDecimal(2.00);
        BigDecimal rebEndAfInt = new BigDecimal(2.00);
        BigDecimal npvReb = new BigDecimal(2.00);

        Date startDate = new Date();
        Date endDate = new Date();

        SfcCalcDetails sfcCalcDetails = sfcCalcDetailService.populateSfcCalcDetail(request, rcLineDetailsList, calendarDetail, rebBegin, rebEndAfInt, npvReb, interest,
                202202, startDate, endDate);
        assertEquals(sfcCalcDetails.getClientId(), rcLineDetailsList.get(0).getClientId());
        assertEquals(sfcCalcDetails.getCreatedPeriodId(), 202202);
        assertEquals(sfcCalcDetails.getReceivableEnd(), rebEndAfInt);
        assertEquals(sfcCalcDetails.getReceivableBegin(), rebBegin);
    }

    //@Test
    public void testInsertSfcCalcDetails() {

        BigDecimal interest = BigDecimal.valueOf(3.00);

        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRcPobId(12345);
        rcLineDetails.setfexRate(BigDecimal.valueOf(1));
        rcLineDetails.setgexRate(BigDecimal.valueOf(1));
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setDocDate(new Date());
        rcLineDetails.setClientId(1);
        rcLineDetails.setSecAtrVal("0");
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetailsList.add(rcLineDetails);

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");

        CalendarDetails calendarDetail = new CalendarDetails(202202, "FEB-22", new Date(), new Date());

        BigDecimal rebBegin = new BigDecimal(2.00);
        BigDecimal rebEndAfInt = new BigDecimal(2.00);
        BigDecimal npvReb = new BigDecimal(2.00);

        Date startDate = new Date();
        Date endDate = new Date();

        SfcCalcDetails sfcCalcDetails = sfcCalcDetailService.populateSfcCalcDetail(request, rcLineDetailsList, calendarDetail, rebBegin, rebEndAfInt, npvReb, interest,
                202202, startDate, endDate);
        List<SfcCalcDetails> sfcCalcDetailsList = new ArrayList<>();
        sfcCalcDetailsList.add(sfcCalcDetails);

        List<SfcCalcDetails> sfcCalcDetailsBatch = new ArrayList<>();
        sfcCalcDetailsBatch.addAll(sfcCalcDetailsList);

        Mockito.when(handle.prepareBatch(any())).thenReturn(preparedBatch);
        Mockito.when(preparedBatch.execute()).thenReturn(new int[]{1,1,1});
        Mockito.doNothing().when(preparedBatch)
                .bind(anyString(), anyLong())
                .bind(anyString(), anyLong())
                .bind(anyString(), eq(BigDecimal.class))
                .bind(anyString(), eq(BigDecimal.class))
                .bind(anyString(), eq(BigDecimal.class))
                .bind(anyString(), eq(BigDecimal.class))
                .bind(anyString(), anyLong())
                .bind(anyString(), anyLong())
                .bind(anyString(), anyLong())
                .bind(anyString(), anyString())
                .bind(anyString(), anyLong())
                .bind(anyString(), anyString())
                .bind(anyString(), eq(Date.class))
                .bind(anyString(), anyString())
                .bind(anyString(), eq(Date.class))
                .bind(anyString(), anyString())
                .bind(anyString(), eq(Date.class))
                .bind(anyString(), eq(Date.class));


        sfcCalcDetailService.insertSfcCalcDetailsBatch(sfcCalcDetailsBatch, handle);
    }
}
