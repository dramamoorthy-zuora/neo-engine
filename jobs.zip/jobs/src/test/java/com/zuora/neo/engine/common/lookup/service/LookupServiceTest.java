package com.zuora.neo.engine.common.lookup.service;

import com.zuora.neo.engine.common.lookup.LookupDataDao;

import com.zuora.neo.engine.common.lookup.LookupMapper;
import com.zuora.neo.engine.common.lookup.LookupService;
import com.zuora.neo.engine.db.common.DbContext;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

//@RunWith(MockitoJUnitRunner.class)
public class LookupServiceTest {

    @InjectMocks
    LookupService lookupService;
    @Spy
    LookupMapper mapper;

    private static final Jdbi jdbi = mock(Jdbi.class);
    private static final Handle handle = mock(Handle.class);
    private static final MockedStatic<DbContext> utilities = Mockito.mockStatic(DbContext.class);

    //@Test
    public void fetchLookupDataTest() {
        LookupDataDao lookupDataDao = mock(LookupDataDao.class);
        utilities.when(DbContext::getConnection).thenReturn(jdbi);
        Mockito.when(handle.attach(any())).thenReturn(lookupDataDao);
        Object  result = lookupService.fetchLookupData(handle,"1",  mapper);
        Assert.assertNull(result);
        verify(lookupDataDao,atLeastOnce()).findByLkpName(any());

    }

}

