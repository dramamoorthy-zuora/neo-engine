package com.zuora.neo.engine.jobs.sfc.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;

import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.exception.NonRetryableActivityException;
import com.zuora.neo.engine.jobs.sfc.SfcResult;
import com.zuora.neo.engine.jobs.sfc.api.SfcSegmentsFlagsVersions;
import com.zuora.neo.engine.jobs.sfc.constants.SfcStatus;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.context.SfcPostProcessDetailsContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;
import com.zuora.neo.engine.jobs.sfc.exception.NoDetailsFoundException;

import io.temporal.api.enums.v1.RetryState;
import io.temporal.client.WorkflowFailedException;
import io.temporal.failure.ActivityFailure;
import io.temporal.failure.ApplicationFailure;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.OutParameters;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class NpvCalculationServiceTest {

    @Mock
    private SfcDao sfcDao;

    @Mock
    private CommonDao commonDao;

    @Mock
    Handle handle;

    @Mock
    SfcTablesBatchInsertUpdateService sfcTablesBatchInsertUpdateService;

    @Mock
    SfcServiceUtils sfcServiceUtils;

    @Mock
    SfcSegmentsFlagsVersions sfcSegmentsFlagsVersions;

    @Mock
    CoreNpvCalculationService coreNpvCalculationService;

    @InjectMocks
    NpvCalculationService npvCalculationService;

    @Test
    public void testCalculateNpvInterestForBatch() throws ParseException, NoDetailsFoundException {

        List<SfcStatusValues> sfcStatusValuesList = new ArrayList<>();
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.6");
        sfcStatusValuesList.add(sfcStatusValues);

        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(100.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(105.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetailsList.add(rcLineDetails);

        SfcResult sfcResult = new SfcResult();

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);
        sfcDbCacheContext.setFinanceTypeValuesList(financeTypeValuesList);

        List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
        FinanceTypeFlagDetails financeTypeFlagDetails = new FinanceTypeFlagDetails(10020, "YNNN", "YNNN", "Y", "Y", "Y");
        financeTypeFlagDetailsList.add(financeTypeFlagDetails);

        List<RcLinePaData> rcLinePaDataList = new ArrayList<>();
        RcLinePaData rcLinePaData = new RcLinePaData();
        rcLinePaData.setDefAmt(BigDecimal.valueOf(25.00));
        rcLinePaData.setRecAmt(BigDecimal.valueOf(0.0));
        rcLinePaData.setVcTypeId(10020);
        rcLinePaData.setId(10053);
        rcLinePaData.setIndicators("YNNNNNNNNNNNNNN");
        rcLinePaDataList.add(rcLinePaData);


        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        WorkflowContext workflowContext = new WorkflowContext(request);
        WorkflowContextManager.setWorkflowContext(workflowContext);



        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(handle.attach(CommonDao.class)).thenReturn(commonDao);
        Mockito.when(sfcDao.getRcLineDetailsByDocLineIdList(Mockito.any())).thenReturn(rcLineDetailsList);
        Mockito.when(sfcDao.getSfcPaymentDetailsByDocLineIdList(Mockito.any())).thenReturn(sfcPaymentDetailsList);
        Mockito.when(sfcServiceUtils.getFinanceTypeForRcLine(Mockito.anyList(), Mockito.any(), Mockito.anyList())).thenReturn(financeTypeValuesList);
        Mockito.when(sfcServiceUtils.validSfcLine(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
        Mockito.doNothing().when(sfcTablesBatchInsertUpdateService).batchUpdateSfcStatusTable(Mockito.anyList(), Mockito.any());
        Mockito.doNothing().when(coreNpvCalculationService).calculateNetNpv(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyList(), Mockito.anyList(), Mockito.any(), Mockito.anyLong(),
                Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList(), Mockito.any());
        npvCalculationService.calculateNpvInterestForBatch(sfcStatusValuesList, sfcDbCacheContext, sfcResult, handle);

        assertEquals(SfcStatus.NPV_INTEREST_CALCULATED.getStatus(), sfcStatusValuesList.get(0).getStatus());
    }

    @Test
    public void testCalculateNpvInterestForBatchInvalid() throws ParseException, NoDetailsFoundException {

        List<SfcStatusValues> sfcStatusValuesList = new ArrayList<>();
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.6");
        sfcStatusValues.setStatus(SfcStatus.PRINCIPLE_AMOUNT_CALCULATED.getStatus());
        sfcStatusValuesList.add(sfcStatusValues);

        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(100.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(105.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetailsList.add(rcLineDetails);

        SfcResult sfcResult = new SfcResult();

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);
        sfcDbCacheContext.setFinanceTypeValuesList(financeTypeValuesList);

        List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
        FinanceTypeFlagDetails financeTypeFlagDetails = new FinanceTypeFlagDetails(10020, "YNNN", "YNNN", "Y", "Y", "Y");
        financeTypeFlagDetailsList.add(financeTypeFlagDetails);

        List<RcLinePaData> rcLinePaDataList = new ArrayList<>();
        RcLinePaData rcLinePaData = new RcLinePaData();
        rcLinePaData.setDefAmt(BigDecimal.valueOf(25.00));
        rcLinePaData.setRecAmt(BigDecimal.valueOf(0.0));
        rcLinePaData.setVcTypeId(10020);
        rcLinePaData.setId(10053);
        rcLinePaData.setIndicators("YNNNNNNNNNNNNNN");
        rcLinePaDataList.add(rcLinePaData);


        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        WorkflowContext workflowContext = new WorkflowContext(request);
        WorkflowContextManager.setWorkflowContext(workflowContext);



        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(handle.attach(CommonDao.class)).thenReturn(commonDao);
        Mockito.when(sfcDao.getRcLineDetailsByDocLineIdList(Mockito.any())).thenReturn(rcLineDetailsList);
        Mockito.when(sfcDao.getSfcPaymentDetailsByDocLineIdList(Mockito.any())).thenReturn(sfcPaymentDetailsList);
        Mockito.when(sfcServiceUtils.getFinanceTypeForRcLine(Mockito.anyList(), Mockito.any(), Mockito.anyList())).thenReturn(financeTypeValuesList);
        Mockito.when(sfcServiceUtils.validSfcLine(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
        Mockito.doNothing().when(sfcTablesBatchInsertUpdateService).batchUpdateSfcStatusTable(Mockito.anyList(), Mockito.any());
        Mockito.doThrow(new NoDetailsFoundException("No Details Found Exception")).when(coreNpvCalculationService).calculateNetNpv(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyList(), Mockito.anyList(), Mockito.any(), Mockito.anyLong(),
                Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyList(), Mockito.any());
        npvCalculationService.calculateNpvInterestForBatch(sfcStatusValuesList, sfcDbCacheContext, sfcResult, handle);

        assertEquals(SfcStatus.PRINCIPLE_AMOUNT_CALCULATED.getStatus(), sfcStatusValuesList.get(0).getStatus());
    }

    @Test
    public void testCalculateNpvInterestForBatchSfcTypeUnavailable() throws ParseException, NoDetailsFoundException {

        List<SfcStatusValues> sfcStatusValuesList = new ArrayList<>();
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.6");
        sfcStatusValues.setStatus(SfcStatus.PRINCIPLE_AMOUNT_CALCULATED.getStatus());
        sfcStatusValuesList.add(sfcStatusValues);

        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(100.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(105.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetailsList.add(rcLineDetails);

        SfcResult sfcResult = new SfcResult();

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);
        sfcDbCacheContext.setFinanceTypeValuesList(financeTypeValuesList);

        List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
        FinanceTypeFlagDetails financeTypeFlagDetails = new FinanceTypeFlagDetails(10020, "YNNN", "YNNN", "Y", "Y", "Y");
        financeTypeFlagDetailsList.add(financeTypeFlagDetails);

        List<RcLinePaData> rcLinePaDataList = new ArrayList<>();
        RcLinePaData rcLinePaData = new RcLinePaData();
        rcLinePaData.setDefAmt(BigDecimal.valueOf(25.00));
        rcLinePaData.setRecAmt(BigDecimal.valueOf(0.0));
        rcLinePaData.setVcTypeId(10020);
        rcLinePaData.setId(10053);
        rcLinePaData.setIndicators("YNNNNNNNNNNNNNN");
        rcLinePaDataList.add(rcLinePaData);


        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        WorkflowContext workflowContext = new WorkflowContext(request);
        WorkflowContextManager.setWorkflowContext(workflowContext);

        List<FinanceTypeValues> financeTypeValuesListEmpty = new ArrayList<>();



        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(handle.attach(CommonDao.class)).thenReturn(commonDao);
        Mockito.when(sfcDao.getRcLineDetailsByDocLineIdList(Mockito.any())).thenReturn(rcLineDetailsList);
        Mockito.when(sfcDao.getSfcPaymentDetailsByDocLineIdList(Mockito.any())).thenReturn(sfcPaymentDetailsList);
        Mockito.when(sfcServiceUtils.getFinanceTypeForRcLine(Mockito.anyList(), Mockito.any(), Mockito.anyList())).thenReturn(financeTypeValuesListEmpty);
        npvCalculationService.calculateNpvInterestForBatch(sfcStatusValuesList, sfcDbCacheContext, sfcResult, handle);

        assertEquals(SfcStatus.PRINCIPLE_AMOUNT_CALCULATED.getStatus(), sfcStatusValuesList.get(0).getStatus());
    }

}
