package com.zuora.neo.engine.jobs.sweep.db.api;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Ignore;
import org.junit.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

public class NextPeriodTest {

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>{@link NextPeriod#NextPeriod(long, Date, Date)}
     *   <li>{@link NextPeriod#getNextPeriodId()}
     * </ul>
     */
    @Test
    public void testConstructor() {
        LocalDateTime atStartOfDayResult = LocalDate.of(1970, 1, 1).atStartOfDay();
        Date nextQuarterDate = Date.from(atStartOfDayResult.atZone(ZoneId.of("UTC")).toInstant());
        LocalDateTime atStartOfDayResult1 = LocalDate.of(1970, 1, 1).atStartOfDay();
        assertEquals(123L, (new NextPeriod(123L, nextQuarterDate, Date.from(atStartOfDayResult1.atZone(ZoneId.of("UTC")).toInstant()))).getNextPeriodId());
    }

    /**
     * Method under test: {@link NextPeriod#getNextQuarterDate()}
     */
    @Test
    @Ignore("TODO: Complete this test")
    public void testGetNextQuarterDate() {
        LocalDateTime atStartOfDayResult = LocalDate.of(1970, 1, 1).atStartOfDay();
        Date nextQuarterDate = Date.from(atStartOfDayResult.atZone(ZoneId.of("UTC")).toInstant());
        LocalDateTime atStartOfDayResult1 = LocalDate.of(1970, 1, 1).atStartOfDay();
        (new NextPeriod(123L, nextQuarterDate, Date.from(atStartOfDayResult1.atZone(ZoneId.of("UTC")).toInstant()))).getNextQuarterDate();
    }

    /**
     * Method under test: {@link NextPeriod#getNextQuarterDate()}
     */
    @Test
    public void testGetNextQuarterDate2() {
        java.sql.Date date = mock(java.sql.Date.class);
        when(date.getTime()).thenReturn(10L);
        LocalDateTime atStartOfDayResult = LocalDate.of(1970, 1, 1).atStartOfDay();
        (new NextPeriod(123L, date, java.util.Date.from(atStartOfDayResult.atZone(ZoneId.of("UTC")).toInstant()))).getNextQuarterDate();
        verify(date).getTime();
    }

    /**
     * Method under test: {@link NextPeriod#getNextYearDate()}
     */
    @Test
    @Ignore("TODO: Complete this test")
    public void testGetNextYearDate() {

        LocalDateTime atStartOfDayResult = LocalDate.of(1970, 1, 1).atStartOfDay();
        Date nextQuarterDate = Date.from(atStartOfDayResult.atZone(ZoneId.of("UTC")).toInstant());
        LocalDateTime atStartOfDayResult1 = LocalDate.of(1970, 1, 1).atStartOfDay();
        (new NextPeriod(123L, nextQuarterDate, Date.from(atStartOfDayResult1.atZone(ZoneId.of("UTC")).toInstant()))).getNextYearDate();
    }

    /**
     * Method under test: {@link NextPeriod#getNextYearDate()}
     */
    @Test
    public void testGetNextYearDate2() {
        java.sql.Date date = mock(java.sql.Date.class);
        when(date.getTime()).thenReturn(10L);
        LocalDateTime atStartOfDayResult = LocalDate.of(1970, 1, 1).atStartOfDay();
        (new NextPeriod(123L, date, java.util.Date.from(atStartOfDayResult.atZone(ZoneId.of("UTC")).toInstant()))).getNextYearDate();
        verify(date).getTime();
    }
}

