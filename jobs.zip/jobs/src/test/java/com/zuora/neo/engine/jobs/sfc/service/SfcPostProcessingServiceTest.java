package com.zuora.neo.engine.jobs.sfc.service;

import static org.junit.Assert.assertEquals;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.sfc.SfcResult;
import com.zuora.neo.engine.jobs.sfc.api.SfcSegmentsFlagsVersions;
import com.zuora.neo.engine.jobs.sfc.constants.SfcStatus;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.context.SfcPostProcessDetailsContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;

import org.jdbi.v3.core.Handle;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class SfcPostProcessingServiceTest {

    @Mock
    ParseProgramParameters parseProgramParameters;
    @Mock
    NpvCalculationService npvCalculationService;
    @Mock
    AccrualEntryService accrualEntryService;
    @Mock
    SfcScheduleCreationService sfcScheduleCreationService;
    @Mock
    RcLinePaDataService rcLinePaDataService;
    @Mock
    PrincipleAmountCalculationService principleAmountCalculationService;
    @Mock
    SoUpdateProcessingService soUpdateProcessingService;
    @Mock
    SfcTablesBatchInsertUpdateService sfcTablesBatchInsertUpdateService;
    @Mock
    RippedLineProcessingService rippedLineProcessingService;
    @Mock
    SfcServiceUtils sfcServiceUtils;
    @Mock
    RcHeadDataService rcHeadDataService;
    @Mock
    SfcDao sfcDao;
    @Mock
    CommonDao commonDao;
    @Mock
    Handle handle;
    @Mock
    SfcSegmentsFlagsVersions sfcSegmentsFlagsVersions;
    @InjectMocks
    SfcPostProcessingService sfcPostProcessingService;


    @Test
    public void testGetPeriodId() throws ParseException {

        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();
        Date startDate = new SimpleDateFormat("dd/MM/yyyy").parse("05/06/2021");
        long openPeriodId = 202205;
        List<CalendarDetails> calendarDetailsCache = new ArrayList<>();
        CalendarDetails calendarDetails = new CalendarDetails(202106, "JUNE-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("30/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/12/2021"));
        calendarDetailsCache.add(calendarDetails);
        sfcDbCacheContext.setCalendarDetailsCache(calendarDetailsCache);
        long periodId = sfcPostProcessingService.getPeriodId(sfcDbCacheContext, startDate, openPeriodId);
        assertEquals(202106, periodId);
    }

    @Test
    public void testPerformSfcCalculations() throws ParseException {

        List<SfcStatusValues> sfcStatusValuesList = new ArrayList<>();
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");
        sfcStatusValues.setStatus(SfcStatus.NPV_INTEREST_CALCULATED.getStatus());
        sfcStatusValues.setNetInterestAccrual(BigDecimal.ONE);
        sfcStatusValues.setIndicators("NYYYNNNNNNNNNNNNNNNNN");
        sfcStatusValuesList.add(sfcStatusValues);

        Map<String, List<RcLineDetails>> rcLineDetailsBatchMap = new HashMap<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.5");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetails.setStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("05/06/2021"));
        rcLineDetailsList.add(rcLineDetails);
        rcLineDetailsBatchMap.put("SO_123_4.5", rcLineDetailsList);

        Map<String, List<SfcPaymentDetails>> sfcPaymentDetailsBatchMap = new HashMap<>();
        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(100.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(105.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetailsBatchMap.put("SO_123_4.6", sfcPaymentDetailsList);

        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();
        List<RcLinePaData> rcLinePaDataRecordBatch = new ArrayList<>();


        SfcPostProcessDetailsContext sfcPostProcessDetailsContext = new SfcPostProcessDetailsContext();
        sfcPostProcessDetailsContext.setRcLineDetailsBatchMap(rcLineDetailsBatchMap);
        sfcPostProcessDetailsContext.setSfcPaymentDetailsBatchMap(sfcPaymentDetailsBatchMap);
        sfcPostProcessDetailsContext.setRcLinePaDataRecordBatch(rcLinePaDataRecordBatch);
        sfcPostProcessDetailsContext.setRcScheduleRecordBatch(rcScheduleRecordBatch);

        List<CalendarDetails> calendarDetailsCache = new ArrayList<>();
        CalendarDetails calendarDetails = new CalendarDetails(202106, "JUNE-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("30/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/12/2021"));
        calendarDetailsCache.add(calendarDetails);

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
        FinanceTypeFlagDetails financeTypeFlagDetails = new FinanceTypeFlagDetails(10020, "YNNN", "YNNN", "Y", "Y", "Y");
        financeTypeFlagDetailsList.add(financeTypeFlagDetails);

        List<RcLinePaData> rcLinePaDataList = new ArrayList<>();
        RcLinePaData rcLinePaData = new RcLinePaData();
        rcLinePaData.setDefAmt(BigDecimal.valueOf(25.00));
        rcLinePaData.setRecAmt(BigDecimal.valueOf(0.0));
        rcLinePaData.setVcTypeId(10020);
        rcLinePaData.setId(10053);
        rcLinePaData.setIndicators("YNNNNNNNNNNNNNN");
        rcLinePaDataList.add(rcLinePaData);


        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();
        sfcDbCacheContext.setCurrentPeriodId(202102);
        sfcDbCacheContext.setCalendarDetailsCache(calendarDetailsCache);
        sfcDbCacheContext.setFinanceTypeValuesList(financeTypeValuesList);

        SfcResult sfcResult = new SfcResult();
        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");

        Mockito.when(handle.attach(CommonDao.class)).thenReturn(commonDao);
        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(sfcServiceUtils.getFinanceTypeForRcLine(Mockito.anyList(), Mockito.any(), Mockito.anyList())).thenReturn(financeTypeValuesList);
        Mockito.when(sfcServiceUtils.validSfcLine(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
        Mockito.when(sfcServiceUtils.getSegmentsFlagsVersions(Mockito.anyList(), Mockito.anyList(),
                Mockito.anyList(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sfcSegmentsFlagsVersions);
        Mockito.when(sfcSegmentsFlagsVersions.getFinanceTypeFlagDetailsList()).thenReturn(financeTypeFlagDetailsList);
        Mockito.when(sfcDao.getRcLinePaDataForLineId(Mockito.anyLong())).thenReturn(rcLinePaDataList);
        Mockito.doNothing().when(accrualEntryService).createAccrualEntry(Mockito.anyList(), Mockito.anyList(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.anyList(), Mockito.anyLong(), Mockito.anyChar());
        Mockito.doNothing().when(sfcScheduleCreationService).createSfcSchedule(Mockito.any(), Mockito.anyList(), Mockito.anyList(), Mockito.anyLong(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
        Mockito.doNothing().when(rcLinePaDataService).populateAmountsForPaRecord(Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any());
        Mockito.doNothing().when(rcLinePaDataService).populateIdsVersionsForPaRecord(Mockito.any(), Mockito.anyLong(), Mockito.anyLong(), Mockito.anyLong());
        Mockito.doNothing().when(rcLinePaDataService).updateAmountsToRcLinePaDataBatch(Mockito.any(), Mockito.any());


        sfcPostProcessingService.performSfcCalculations(sfcStatusValuesList,sfcPostProcessDetailsContext, sfcDbCacheContext, sfcResult, request,
                handle);

        assertEquals(SfcStatus.COMPLETED.getStatus(), sfcStatusValues.getStatus());

    }

    @Test
    public void testPerformSfcCalculationsInvalidLine() throws ParseException {

        List<SfcStatusValues> sfcStatusValuesList = new ArrayList<>();
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");
        sfcStatusValues.setStatus(SfcStatus.NPV_INTEREST_CALCULATED.getStatus());
        sfcStatusValuesList.add(sfcStatusValues);

        Map<String, List<RcLineDetails>> rcLineDetailsBatchMap = new HashMap<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.5");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetails.setStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("05/06/2021"));
        rcLineDetailsList.add(rcLineDetails);
        rcLineDetailsBatchMap.put("SO_123_4.5", rcLineDetailsList);

        Map<String, List<SfcPaymentDetails>> sfcPaymentDetailsBatchMap = new HashMap<>();
        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(100.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(105.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetailsBatchMap.put("SO_123_4.6", sfcPaymentDetailsList);

        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();
        List<RcLinePaData> rcLinePaDataRecordBatch = new ArrayList<>();


        SfcPostProcessDetailsContext sfcPostProcessDetailsContext = new SfcPostProcessDetailsContext();
        sfcPostProcessDetailsContext.setRcLineDetailsBatchMap(rcLineDetailsBatchMap);
        sfcPostProcessDetailsContext.setSfcPaymentDetailsBatchMap(sfcPaymentDetailsBatchMap);
        sfcPostProcessDetailsContext.setRcLinePaDataRecordBatch(rcLinePaDataRecordBatch);
        sfcPostProcessDetailsContext.setRcScheduleRecordBatch(rcScheduleRecordBatch);

        List<CalendarDetails> calendarDetailsCache = new ArrayList<>();
        CalendarDetails calendarDetails = new CalendarDetails(202106, "JUNE-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("30/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/12/2021"));
        calendarDetailsCache.add(calendarDetails);

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
        FinanceTypeFlagDetails financeTypeFlagDetails = new FinanceTypeFlagDetails(10020, "YNNN", "YNNN", "Y", "Y", "Y");
        financeTypeFlagDetailsList.add(financeTypeFlagDetails);

        List<RcLinePaData> rcLinePaDataList = new ArrayList<>();
        RcLinePaData rcLinePaData = new RcLinePaData();
        rcLinePaData.setDefAmt(BigDecimal.valueOf(25.00));
        rcLinePaData.setRecAmt(BigDecimal.valueOf(0.0));
        rcLinePaData.setVcTypeId(10020);
        rcLinePaData.setId(10053);
        rcLinePaData.setIndicators("YNNNNNNNNNNNNNN");
        rcLinePaDataList.add(rcLinePaData);


        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();
        sfcDbCacheContext.setCurrentPeriodId(202102);
        sfcDbCacheContext.setCalendarDetailsCache(calendarDetailsCache);
        sfcDbCacheContext.setFinanceTypeValuesList(financeTypeValuesList);

        SfcResult sfcResult = new SfcResult();
        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");

        Mockito.when(handle.attach(CommonDao.class)).thenReturn(commonDao);
        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(sfcServiceUtils.getFinanceTypeForRcLine(Mockito.anyList(), Mockito.any(), Mockito.anyList())).thenReturn(financeTypeValuesList);
        Mockito.when(sfcServiceUtils.validSfcLine(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(false);
        Mockito.doNothing().when(rcLinePaDataService).updateAmountsToRcLinePaDataBatch(Mockito.any(), Mockito.any());


        sfcPostProcessingService.performSfcCalculations(sfcStatusValuesList,sfcPostProcessDetailsContext, sfcDbCacheContext, sfcResult, request,
                handle);

        assertEquals(SfcStatus.NPV_INTEREST_CALCULATED.getStatus(), sfcStatusValues.getStatus());

    }

    @Test
    public void testPerformSfcCalculationsSfcSetupUnavailable() throws ParseException {

        List<SfcStatusValues> sfcStatusValuesList = new ArrayList<>();
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");
        sfcStatusValues.setStatus(SfcStatus.NPV_INTEREST_CALCULATED.getStatus());
        sfcStatusValuesList.add(sfcStatusValues);

        Map<String, List<RcLineDetails>> rcLineDetailsBatchMap = new HashMap<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.5");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetails.setStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("05/06/2021"));
        rcLineDetailsList.add(rcLineDetails);
        rcLineDetailsBatchMap.put("SO_123_4.5", rcLineDetailsList);

        Map<String, List<SfcPaymentDetails>> sfcPaymentDetailsBatchMap = new HashMap<>();
        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(100.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(105.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetailsBatchMap.put("SO_123_4.6", sfcPaymentDetailsList);

        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();
        List<RcLinePaData> rcLinePaDataRecordBatch = new ArrayList<>();


        SfcPostProcessDetailsContext sfcPostProcessDetailsContext = new SfcPostProcessDetailsContext();
        sfcPostProcessDetailsContext.setRcLineDetailsBatchMap(rcLineDetailsBatchMap);
        sfcPostProcessDetailsContext.setSfcPaymentDetailsBatchMap(sfcPaymentDetailsBatchMap);
        sfcPostProcessDetailsContext.setRcLinePaDataRecordBatch(rcLinePaDataRecordBatch);
        sfcPostProcessDetailsContext.setRcScheduleRecordBatch(rcScheduleRecordBatch);

        List<CalendarDetails> calendarDetailsCache = new ArrayList<>();
        CalendarDetails calendarDetails = new CalendarDetails(202106, "JUNE-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("30/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/12/2021"));
        calendarDetailsCache.add(calendarDetails);

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        List<FinanceTypeValues> financeTypeValuesListEmpty = new ArrayList<>();

        List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
        FinanceTypeFlagDetails financeTypeFlagDetails = new FinanceTypeFlagDetails(10020, "YNNN", "YNNN", "Y", "Y", "Y");
        financeTypeFlagDetailsList.add(financeTypeFlagDetails);

        List<RcLinePaData> rcLinePaDataList = new ArrayList<>();
        RcLinePaData rcLinePaData = new RcLinePaData();
        rcLinePaData.setDefAmt(BigDecimal.valueOf(25.00));
        rcLinePaData.setRecAmt(BigDecimal.valueOf(0.0));
        rcLinePaData.setVcTypeId(10020);
        rcLinePaData.setId(10053);
        rcLinePaData.setIndicators("YNNNNNNNNNNNNNN");
        rcLinePaDataList.add(rcLinePaData);


        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();
        sfcDbCacheContext.setCurrentPeriodId(202102);
        sfcDbCacheContext.setCalendarDetailsCache(calendarDetailsCache);
        sfcDbCacheContext.setFinanceTypeValuesList(financeTypeValuesList);

        SfcResult sfcResult = new SfcResult();
        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");

        Mockito.when(handle.attach(CommonDao.class)).thenReturn(commonDao);
        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(sfcServiceUtils.getFinanceTypeForRcLine(Mockito.anyList(), Mockito.any(), Mockito.anyList())).thenReturn(financeTypeValuesListEmpty);
        Mockito.doNothing().when(rcLinePaDataService).updateAmountsToRcLinePaDataBatch(Mockito.any(), Mockito.any());


        sfcPostProcessingService.performSfcCalculations(sfcStatusValuesList,sfcPostProcessDetailsContext, sfcDbCacheContext, sfcResult, request,
                handle);

        assertEquals(SfcStatus.NPV_INTEREST_CALCULATED.getStatus(), sfcStatusValues.getStatus());
    }


}
