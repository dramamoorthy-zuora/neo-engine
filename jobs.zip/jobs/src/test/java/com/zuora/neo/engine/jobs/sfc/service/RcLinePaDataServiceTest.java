package com.zuora.neo.engine.jobs.sfc.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import com.zuora.neo.engine.db.api.RcLinePaData;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.PreparedBatch;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class RcLinePaDataServiceTest {

    @Mock
    PreparedBatch updateRcLinePaDataBatch;

    @Mock
    Handle handle;

    @InjectMocks
    RcLinePaDataService rcLinePaDataService;

    //@Test
    public void testUpdateAmountsToRcLinePaDataBatch() {

        RcLinePaDataService rcLinePaDataServiceMock = mock(RcLinePaDataService.class);

        List<RcLinePaData> rcLinePaDataList = new ArrayList<>();
        RcLinePaData rcLinePaData = new RcLinePaData();
        rcLinePaData.setVcTypeId(10020);
        rcLinePaData.setLineId(10010);
        rcLinePaData.setFncTypeVersion(1);
        rcLinePaData.setClientId(1);
        rcLinePaDataList.add(rcLinePaData);

        Mockito.when(handle.prepareBatch(Mockito.any())).thenReturn(updateRcLinePaDataBatch);
        Mockito.doNothing().when(rcLinePaDataServiceMock).bindRcLinePaDataForUpdate(Mockito.any(), Mockito.any(), Mockito.anyLong(), Mockito.anyLong());
        Mockito.when(updateRcLinePaDataBatch.execute()).thenReturn(new int[] {0});

        rcLinePaDataService.updateAmountsToRcLinePaDataBatch(handle, rcLinePaDataList);
    }

    @Test
    public void testPopulateAmountsForPaRecord() {

        RcLinePaDataService rcLinePaDataService = new RcLinePaDataService();

        RcLinePaData rcLinePaData = new RcLinePaData();
        BigDecimal recAmt = BigDecimal.TEN;
        BigDecimal defAmt = BigDecimal.valueOf(25.00);
        BigDecimal accruedAmt = BigDecimal.valueOf(25.00);

        rcLinePaDataService.populateAmountsForPaRecord(rcLinePaData, recAmt, defAmt, accruedAmt);

        assertEquals(BigDecimal.TEN, rcLinePaData.getRecAmt());
        assertEquals(BigDecimal.valueOf(25.00), rcLinePaData.getDefAmt());
        assertEquals(BigDecimal.valueOf(25.00), rcLinePaData.getAccruedAmt());
    }

    @Test
    public void testPopulateIdsAndVersionsForPaRecord() {

        RcLinePaDataService rcLinePaDataService = new RcLinePaDataService();

        RcLinePaData rcLinePaData = new RcLinePaData();
        long lineId = Long.valueOf(10010);
        long vcTypeId = Long.valueOf(10020);
        long financeTypeVersion = 1;

        rcLinePaDataService.populateIdsVersionsForPaRecord(rcLinePaData, lineId, vcTypeId, financeTypeVersion);

        assertEquals(10010, rcLinePaData.getLineId());
        assertEquals(10020, rcLinePaData.getVcTypeId());
        assertEquals(1, rcLinePaData.getFncTypeVersion());
    }

}
