package com.zuora.neo.engine.jobs.rtp.service;

import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.rtp.config.RtpProperties;
import com.zuora.neo.engine.jobs.rtp.constants.RtpConstants;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;
import io.temporal.failure.ApplicationFailure;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RtpInitializerServiceTest {

    @Mock
    RtpProperties rtpProperties;

    @Mock
    NeoWorkflowLogger neoWorkflowLogger;

    @InjectMocks
    RtpInitializerService rtpInitializerService;

    @Test
    public void testRtpDisabled() {
        CommonDao commonDao = mock(CommonDao.class);
        when(rtpProperties.isRtpEnabled()).thenReturn(false);
        // when(commonDao.getProfileValue(anyString(), anyString())).thenReturn("Y");

        ApplicationFailure applicationFailure = assertThrows(ApplicationFailure.class,
                () -> rtpInitializerService.initialize(commonDao));

        assertEquals(applicationFailure.getOriginalMessage(), RtpConstants.RTP_DISABLED);
    }
}
