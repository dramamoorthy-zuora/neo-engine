package com.zuora.neo.engine.jobs.sfc.service;

import static org.junit.Assert.assertEquals;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SchdIndicator;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;

import org.jdbi.v3.core.Handle;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class AccrualEntryServiceTest {

    @Mock
    private RcScheduleService rcScheduleService;

    @InjectMocks
    AccrualEntryService accrualEntryService;

    @Test
    public void testCreateAccrualEntry() throws ParseException {

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");

        Map<String, Integer> currencyMap = new HashMap<>();
        currencyMap.put("fmvwcea:USD", 2);

        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(100.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(105.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetailsList.add(rcLineDetails);

        List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
        FinanceTypeFlagDetails financeTypeFlagDetails = new FinanceTypeFlagDetails(10020, "YNNN", "YNNN", "Y", "Y", "Y");
        financeTypeFlagDetailsList.add(financeTypeFlagDetails);

        RcScheduleRecord rcScheduleRecord = new RcScheduleRecord();
        rcScheduleRecord.setId(123);

        List<RcLinePaData> rcLinePaDataList = new ArrayList<>();

        SchdIndicator schdIndicator = new SchdIndicator();

        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();

        Mockito.when(rcScheduleService.populateRcScheduleRecord(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(rcScheduleRecord);

        accrualEntryService.createAccrualEntry(rcLineDetailsList, rcLinePaDataList, request, BigDecimal.valueOf(1),
                financeTypeFlagDetailsList, 202202,1, "NNNN", "NNNN", schdIndicator, rcScheduleRecordBatch, 202202);

        assertEquals(schdIndicator.getCrAcctgFlag(), 'Y');
        assertEquals(schdIndicator.getDrAcctgFlag(), 'Y');

    }

    @Test
    public void testCreateImpairmentEntry() {

        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetailsList.add(rcLineDetails);

        RcScheduleRecord rcScheduleRecord = new RcScheduleRecord();
        rcScheduleRecord.setId(123);

        List<RcLinePaData> rcLinePaDataRecordList = new ArrayList<>();
        RcLinePaData rcLinePaData = new RcLinePaData();
        rcLinePaData.setVcTypeId(10020);
        rcLinePaDataRecordList.add(rcLinePaData);

        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        BigDecimal intAccrual = BigDecimal.ONE;
        long openPeriodId = 202205;
        long rcVersion = 1;
        String drAcctSeg = "1234";
        String crAcctSeg = "5678";
        char crAcctgFlag = 'Y';
        char drAcctgFlag = 'Y';
        SchdIndicator schdIndicator = new SchdIndicator();


        Mockito.when(rcScheduleService.populateRcScheduleRecord(Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any(), Mockito.any(),
                Mockito.any())).thenReturn(rcScheduleRecord);

        accrualEntryService.createImpairmentEntry(rcLineDetailsList, rcLinePaDataRecordList, request, intAccrual, openPeriodId, rcVersion,
                drAcctSeg, crAcctSeg, crAcctgFlag, drAcctgFlag, schdIndicator, rcScheduleRecordBatch);

        assertEquals(1, rcScheduleRecordBatch.size());
        assertEquals('Y', SchdIndicator.valueOf(rcScheduleRecordBatch.get(0).getIndicators()).getCrAcctgFlag());
        assertEquals('Y', SchdIndicator.valueOf(rcScheduleRecordBatch.get(0).getIndicators()).getDrAcctgFlag());
        assertEquals('N', SchdIndicator.valueOf(rcScheduleRecordBatch.get(0).getIndicators()).getIntialRepEntryFlag());
        assertEquals(202205, rcScheduleRecordBatch.get(0).getPeriodId());
        assertEquals(202205, rcScheduleRecordBatch.get(0).getPostPeriodId());
    }

}
