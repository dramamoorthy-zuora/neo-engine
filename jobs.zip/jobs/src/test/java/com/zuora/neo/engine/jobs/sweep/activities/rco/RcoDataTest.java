package com.zuora.neo.engine.jobs.sweep.activities.rco;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;

import org.junit.Ignore;
import org.junit.Test;

public class RcoDataTest {

    /**
     * Method under test: {@link RcoData#getCreatedDate()}
     */
    @Test
    public void testGetCreatedDate2() {
        Timestamp timestamp = mock(Timestamp.class);
        when(timestamp.getTime()).thenReturn(10L);

        RcoData rcoData = new RcoData();
        rcoData.setAdditionalParams("Additional Params");
        rcoData.setBookId(123L);
        rcoData.setCreatedDate(timestamp);
        rcoData.setRcoEventType(RcoEventType.ACCOUNT_ANALYSIS);
        rcoData.getCreatedDate();
        verify(timestamp).getTime();
    }

    /**
     * Method under test: {@link RcoData#setCreatedDate(Timestamp)}
     */
    @Test
    public void testSetCreatedDate() {
        RcoData rcoData = new RcoData();
        Timestamp timestamp = mock(Timestamp.class);
        when(timestamp.getTime()).thenReturn(10L);
        rcoData.setCreatedDate(timestamp);
        verify(timestamp).getTime();
    }

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>default or parameterless constructor of {@link RcoData}
     *   <li>{@link RcoData#setAdditionalParams(String)}
     *   <li>{@link RcoData#setBookId(long)}
     *   <li>{@link RcoData#setRcoEventType(RcoEventType)}
     *   <li>{@link RcoData#getAdditionalParams()}
     *   <li>{@link RcoData#getBookId()}
     *   <li>{@link RcoData#getRcoEventType()}
     * </ul>
     */
    @Test
    public void testConstructor() {
        RcoData actualRcoData = new RcoData();
        actualRcoData.setAdditionalParams("Additional Params");
        actualRcoData.setBookId(123L);
        actualRcoData.setRcoEventType(RcoEventType.ACCOUNT_ANALYSIS);
        assertEquals("Additional Params", actualRcoData.getAdditionalParams());
        assertEquals(123L, actualRcoData.getBookId());
        assertEquals(RcoEventType.ACCOUNT_ANALYSIS, actualRcoData.getRcoEventType());
    }
}

