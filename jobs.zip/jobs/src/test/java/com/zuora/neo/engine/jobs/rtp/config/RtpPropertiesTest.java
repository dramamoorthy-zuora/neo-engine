package com.zuora.neo.engine.jobs.rtp.config;

import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.rtp.constants.RtpConstants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class RtpPropertiesTest {

    @InjectMocks
    RtpProperties rtpProperties;

    @Test
    public void testDefaults() {
        assertFalse(rtpProperties.isRtpEnabled());
        assertEquals(rtpProperties.getBatchSize(), 1);

        String result = "RtpProperties{rtpEnabled=false, batchSize=1, maxRetryCount=5, shadowMode=true}";
        assertEquals(rtpProperties.toString(), result);
    }

    @Test
    public void testLoad() {
        CommonDao commonDao = mock(CommonDao.class);

        when(commonDao.getProfileValueFromTable(anyString(), anyString())).thenReturn("N");
        when(commonDao.getProfileValueFromTable(anyString(), anyInt())).thenReturn(5000);

        rtpProperties.load(commonDao);

        assertFalse(rtpProperties.isRtpEnabled());
        assertEquals(rtpProperties.getBatchSize(), 5000);
    }
}
