package com.zuora.neo.engine.jobs.caclnetting.service;

import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.PeriodDetails;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.caclnetting.config.CaclProperties;
import com.zuora.neo.engine.jobs.caclnetting.db.dao.CaclNettingDao;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CaclServiceTest {

    @Mock
    private CommonDao commonDao;
    @Mock
    private CaclNettingDao nettingDao;
    @Mock
    private CaclProperties caclProperties;
    @Mock
    private NeoWorkflowLogger neoWorkflowLogger;
    @Mock
    private CleanupService cleanupService;

    private static final BigDecimal batchId = new BigDecimal(1.0);

    private static final String user = "UNIT_TEST", createLineLevel = "Y", orgId = "0";

    private static final Long bookId = 1L, clientId = 1L;

    private static PeriodDetails periodDetailsMock = new PeriodDetails(1, 1, 1);

    @InjectMocks
    CaclService caclService;

    List<CalendarDetails> calendarDetailsList = new ArrayList<>();
    CalendarDetails calendarDetails = new CalendarDetails(1, "FEB-22", new Date(), new Date());

    @Test
    public void testNettingService() {
        calendarDetailsList.add(calendarDetails);

        when(caclProperties.getBookId()).thenReturn(1L);
        when(caclProperties.getClientId()).thenReturn(1L);
        when(caclProperties.getOrgId()).thenReturn("");

        when(caclProperties.isNettingEnabled()).thenReturn(true);
        when(caclProperties.isNettingRcMje()).thenReturn(true);
        when(caclProperties.getPeriodDetails()).thenReturn(periodDetailsMock);
        when(caclProperties.getCaclNetRc()).thenReturn("");
        when(caclProperties.getHeadPeriod()).thenReturn("");
        when(caclProperties.getScheduleTable()).thenReturn("");

        when(caclProperties.getHeadPeriodSequence()).thenReturn("");
        when(caclProperties.getScheduleSequence()).thenReturn("");

        when(commonDao.getProfileValue("REPORTING_CURRENCY", "USD")).thenReturn("USD");

        when(nettingDao.insertIntoIntermediateTable(anyLong(), anyLong(), anyLong(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), any(), anyString(), anyString(), anyString(), anyString(), anyLong(), anyLong(), anyString())).thenReturn(3);
        when(nettingDao.updateWithPriorPeriodAmounts(anyLong(), anyLong(), anyLong(), any(), anyString(), anyString(), anyLong(), anyLong(), anyString())).thenReturn(3);
        when(commonDao.getPeriodDetailsById(anyLong())).thenReturn(calendarDetailsList);
        when(nettingDao.insertNettingHeader(anyString(), anyLong(), any(), any(), any(), anyString(), anyString(), anyString(), anyString(), anyLong(), anyLong(), anyString())).thenReturn(1);
        when(nettingDao.insertNettingSchedules(any(), anyString(), anyLong(), anyLong(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyLong(), anyLong(), anyString())).thenReturn(3);
        when(nettingDao.updateRcStatusToComplete(any(), anyString(), anyLong(), anyLong(), anyString())).thenReturn(1);

        int rcProcessedCount = caclService.performNettingService(nettingDao, commonDao, batchId, bookId, createLineLevel, user, clientId, orgId);

        assertEquals(1, rcProcessedCount);
    }

    @Test
    public void testInsertNettingRc() {

        when(caclProperties.getBookId()).thenReturn(1L);
        when(caclProperties.getClientId()).thenReturn(1L);
        when(caclProperties.getOrgId()).thenReturn("");

        when(caclProperties.isNettingEnabled()).thenReturn(true);
        when(caclProperties.isNettingRcMje()).thenReturn(true);
        when(caclProperties.getPeriodDetails()).thenReturn(periodDetailsMock);
        when(caclProperties.getCaclNetRc()).thenReturn("");
        when(caclProperties.getHeadPeriod()).thenReturn("");
        when(caclProperties.getScheduleTable()).thenReturn("");

        when(caclProperties.getHeadPeriodSequence()).thenReturn("");
        when(caclProperties.getScheduleSequence()).thenReturn("");

        when(nettingDao.populateRealtimeNettingRc(anyLong(), anyLong(), any(),
                anyString(), anyString(), anyString())).thenReturn(1);
        when(nettingDao.cleanIntermediateEntries(anyLong(),any(), anyString(), anyLong(), anyLong(),
                anyString())).thenReturn(0);
        when(nettingDao.removeNettingHeaders(any(), anyLong(), anyString(), anyString(), anyLong(), anyLong(),
                anyString())).thenReturn(0);
        when(nettingDao.deleteUnpostedSchedules(any(), anyLong(), anyLong(), anyString(), anyString(), anyString(), anyString(),
                anyLong(), anyLong(), anyString())).thenReturn(0);
        when(nettingDao.reversePostedSchedules(any(), anyLong(), anyLong(), anyString(), anyString(), anyString(),
                anyString(), anyString(), anyString(), anyString(), anyString(), anyLong(), anyLong(), anyString())).thenReturn(0);
        when(nettingDao.updatePostedSchedules(any(), anyLong(), anyLong(), anyString(), anyString(), anyString(),
                anyString(), anyString(), anyString(), anyString(),
                anyLong(), anyLong(), anyString())).thenReturn(0);

        int count = caclService.insertNettingRc(nettingDao, batchId, 1000L, "N", true);

        assertEquals(count, 1);

    }

    @Test
    public void testPickRcsToProcess() {
        when(caclProperties.getBookId()).thenReturn(1L);
        when(caclProperties.getClientId()).thenReturn(1L);
        when(caclProperties.getOrgId()).thenReturn("");

        when(caclProperties.isNettingEnabled()).thenReturn(true);
        when(caclProperties.isNettingRcMje()).thenReturn(true);
        when(caclProperties.getPeriodDetails()).thenReturn(periodDetailsMock);
        when(caclProperties.getCaclNetRc()).thenReturn("");
        when(caclProperties.getHeadPeriod()).thenReturn("");
        when(caclProperties.getScheduleTable()).thenReturn("");

        when(caclProperties.getHeadPeriodSequence()).thenReturn("");
        when(caclProperties.getScheduleSequence()).thenReturn("");

        when(nettingDao.getRcId(anyLong())).thenReturn(1);
        when(nettingDao.insertNettingRcForGivenRc(anyLong(), anyLong(), anyLong(), any(), anyString(),
                anyString(), anyLong(), anyLong(), anyString())).thenReturn(1);
        when(nettingDao.insertRcForCurrentPeriod(anyString(), anyLong(), anyLong(), any(), anyString(), anyString(),
                anyString(), anyString(), anyLong(), anyLong(), anyString())).thenReturn(1);

        long count = caclService.pickRcToProcess(nettingDao, 1000L, "N", batchId);
        assertEquals(1, count);

    }

}