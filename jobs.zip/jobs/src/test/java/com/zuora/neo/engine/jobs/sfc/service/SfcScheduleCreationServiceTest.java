package com.zuora.neo.engine.jobs.sfc.service;

import static org.junit.Assert.assertEquals;

import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.jobs.sfc.api.SfcSegmentsFlagsVersions;
import com.zuora.neo.engine.jobs.sfc.constants.SfcStatus;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.context.SfcPostProcessDetailsContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SchdIndicator;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class SfcScheduleCreationServiceTest {

    @Mock
    SfcCalcDetailService sfcCalcDetailService;

    @Mock
    RcScheduleService rcScheduleService;


    @InjectMocks
    SfcScheduleCreationService sfcScheduleCreationService;

    @Test
    public void testCalculateDurationForPaymentPeriodsCaseOne() throws ParseException {
        SfcPaymentDetails sfcPaymentDetail = new SfcPaymentDetails();
        sfcPaymentDetail.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));

        CalendarDetails calendarDetail = new CalendarDetails(202105, "MAY-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/05/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/05/2021"));

        Map<String, Date> scheduleDates = new HashMap<>();

        long days = SfcScheduleCreationService.calculateDurationForPaymentPeriods(sfcPaymentDetail, calendarDetail, scheduleDates);
        assertEquals(5, days);
    }

    @Test
    public void testCalculateDurationForPaymentPeriodsCaseTwo() throws ParseException {
        SfcPaymentDetails sfcPaymentDetail = new SfcPaymentDetails();
        sfcPaymentDetail.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/04/2021"));
        sfcPaymentDetail.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));

        CalendarDetails calendarDetail = new CalendarDetails(202105, "MAY-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/05/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/05/2021"));

        Map<String, Date> scheduleDates = new HashMap<>();

        long days = SfcScheduleCreationService.calculateDurationForPaymentPeriods(sfcPaymentDetail, calendarDetail, scheduleDates);
        assertEquals(27, days);
    }

    @Test
    public void testCalculateDurationForPaymentPeriodsCaseThree() throws ParseException {
        SfcPaymentDetails sfcPaymentDetail = new SfcPaymentDetails();
        sfcPaymentDetail.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/01/2021"));
        sfcPaymentDetail.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/08/2021"));

        CalendarDetails calendarDetail = new CalendarDetails(202105, "MAY-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/05/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/05/2021"));

        Map<String, Date> scheduleDates = new HashMap<>();

        long days = SfcScheduleCreationService.calculateDurationForPaymentPeriods(sfcPaymentDetail, calendarDetail, scheduleDates);
        assertEquals(31, days);
    }

    @Test
    public void testCalculateDurationForPaymentPeriodsCaseFour() throws ParseException {
        SfcPaymentDetails sfcPaymentDetail = new SfcPaymentDetails();
        sfcPaymentDetail.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("31/05/2021"));

        CalendarDetails calendarDetail = new CalendarDetails(202105, "MAY-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/05/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/05/2021"));

        Map<String, Date> scheduleDates = new HashMap<>();

        long days = SfcScheduleCreationService.calculateDurationForPaymentPeriods(sfcPaymentDetail, calendarDetail, scheduleDates);
        assertEquals(1, days);
    }

    @Test
    public void testCalculateDurationForPaymentPeriodsCaseFive() throws ParseException {
        SfcPaymentDetails sfcPaymentDetail = new SfcPaymentDetails();
        sfcPaymentDetail.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("31/05/2099"));

        try {
            CalendarDetails calendarDetail = new CalendarDetails(202105, "MAY-21",
                    new SimpleDateFormat("dd/MM/yyyy").parse("01/05/2021"),
                    new SimpleDateFormat("dd/MM/yyyy").parse("31/05/2021"));

            Map<String, Date> scheduleDates = new HashMap<>();

            long days = SfcScheduleCreationService.calculateDurationForPaymentPeriods(sfcPaymentDetail, calendarDetail, scheduleDates);
        } catch (Exception e) {
            assertEquals(e.getClass() , NullPointerException.class);
        }
    }

    @Test
    public void testGetNpvValueFromDailyInterest() {
        BigDecimal rebEndBfInt = new BigDecimal("55200.00");
        BigDecimal dailyInt = new BigDecimal("0.00456");
        long noOfDays = 4;

        BigDecimal npvAmount = SfcScheduleCreationService.getNpvValueFromDailyInterest(rebEndBfInt, dailyInt, noOfDays);
        BigDecimal expected = new BigDecimal("56213.7558001816066129920000");
        assertEquals(expected, npvAmount);
    }

    //@Test
    public void testCreateSfcScheduleValid() throws ParseException {

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        WorkflowContext workflowContext = new WorkflowContext(request);
        WorkflowContextManager.setWorkflowContext(workflowContext);

        SfcStatusValues sfcStatusValue = new SfcStatusValues();
        sfcStatusValue.setDocLineId("SO_123_4.6");
        sfcStatusValue.setStatus(SfcStatus.NPV_INTEREST_CALCULATED.getStatus());
        sfcStatusValue.setNetInterestAccrual(BigDecimal.valueOf(10000));
        sfcStatusValue.setNetNpvAmt(BigDecimal.valueOf(35000));

        List<RcLinePaData> rcLinePaDataRecord = new ArrayList<>();
        RcLinePaData rcLinePaData = new RcLinePaData();
        rcLinePaData.setDefAmt(BigDecimal.valueOf(25.00));
        rcLinePaData.setRecAmt(BigDecimal.valueOf(0.0));
        rcLinePaData.setVcTypeId(10020);
        rcLinePaData.setId(10053);
        rcLinePaData.setIndicators("YNNNNNNNNNNNNNN");
        rcLinePaDataRecord.add(rcLinePaData);


        List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
        FinanceTypeFlagDetails vcTypeDetails = new FinanceTypeFlagDetails(10020, "YNNN", "YNNN", "Y", "Y", "Y");
        financeTypeFlagDetailsList.add(vcTypeDetails);

        long openPeriodId = 202201;
        SchdIndicator schdIndicator = new SchdIndicator();
        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();
        SfcPostProcessDetailsContext sfcPostProcessDetailsContext = new SfcPostProcessDetailsContext();
        SfcSegmentsFlagsVersions sfcSegmentsFlagsVersions = new SfcSegmentsFlagsVersions();

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(200.20));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/05/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/05/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);
        sfcPaymentDetails = new SfcPaymentDetails();
        sfcPaymentDetails.setDocLineId("SO_123_4.6");
        sfcPaymentDetails.setPaymtAmt(BigDecimal.valueOf(10.00));
        sfcPaymentDetails.setPaymtDate(new SimpleDateFormat("dd/MM/yyyy").parse("01/06/2021"));
        sfcPaymentDetails.setPaymtEndDate(new SimpleDateFormat("dd/MM/yyyy").parse("28/07/2021"));
        sfcPaymentDetails.setPaymtStartDate(new SimpleDateFormat("dd/MM/yyyy").parse("27/06/2021"));
        sfcPaymentDetailsList.add(sfcPaymentDetails);

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRcPobId(12345);
        rcLineDetails.setfexRate(BigDecimal.valueOf(1));
        rcLineDetails.setgexRate(BigDecimal.valueOf(1));
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setDocDate(new Date());
        rcLineDetails.setClientId(1);
        rcLineDetails.setSecAtrVal("0");
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetails.setExtSllPrc(BigDecimal.valueOf(25000));
        rcLineDetails.setPrincipleAmount(BigDecimal.valueOf(25000));
        rcLineDetailsList.add(rcLineDetails);

        Map<String, List<SfcPaymentDetails>> sfcPaymentDetailsBatchMap = new HashMap<>();
        sfcPaymentDetailsBatchMap.put("SO_123_4.6", sfcPaymentDetailsList);
        sfcPostProcessDetailsContext.setSfcPaymentDetailsBatchMap(sfcPaymentDetailsBatchMap);

        Map<String, List<RcLineDetails>> rcLineDetailsBatchMap = new HashMap<>();
        rcLineDetailsBatchMap.put("SO_123_4.6", rcLineDetailsList);
        sfcPostProcessDetailsContext.setRcLineDetailsBatchMap(rcLineDetailsBatchMap);

        sfcPostProcessDetailsContext.setRcScheduleRecordBatch(new ArrayList<>());
        sfcPostProcessDetailsContext.setSfcCalcDetailsBatch(new ArrayList<>());

        Map<String, Integer> currencyMap = new HashMap<>();
        currencyMap.put("fmvwcea:USD", 2);
        sfcDbCacheContext.setCurrencyMap(currencyMap);

        sfcSegmentsFlagsVersions.setRcVersion(1);

        List<CalendarDetails> calendarDetails = new ArrayList<>();
        calendarDetails.add(new CalendarDetails(202105, "MAY-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/05/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/05/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/12/2021")));

        calendarDetails.add(new CalendarDetails(202106, "JUNE-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("30/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/12/2021")));

        calendarDetails.add(new CalendarDetails(202107, "JULY-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/07/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("30/07/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/12/2021")));
        sfcDbCacheContext.setCalendarDetailsCache(calendarDetails);

        SfcCalcDetails sfcCalcDetails = new SfcCalcDetails(1);
        RcScheduleRecord rcScheduleRecord = new RcScheduleRecord();

        Mockito.when(sfcCalcDetailService.populateSfcCalcDetail(Mockito.any(), Mockito.anyList(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyLong(), Mockito.any(), Mockito.any())).thenReturn(sfcCalcDetails);

        Mockito.when(rcScheduleService.populateRcScheduleRecord(Mockito.anyList(), Mockito.anyList(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any(),
                Mockito.any(), Mockito.any())).thenReturn(rcScheduleRecord);

        sfcScheduleCreationService.createSfcSchedule(sfcStatusValue, rcLinePaDataRecord, financeTypeFlagDetailsList,
        openPeriodId, schdIndicator, sfcDbCacheContext, sfcPostProcessDetailsContext, sfcSegmentsFlagsVersions);

    }
}
