package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.OutParameters;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RunWith(MockitoJUnitRunner.class)
public class SfcPaymentProcessingServiceTest {

    @Mock
    Handle handle;

    @Mock
    SfcDao sfcDao;

    @Mock
    OutParameters outParameters;

    @InjectMocks
    SfcPaymentProcessingService sfcPaymentProcessingService;

    @Test
    public void testProcessedUnProcessedPayments() {

        List<SfcStatusValues> sfcStatusValuesList = new ArrayList<>();
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");
        sfcStatusValues.setDocNum("SO_123");
        sfcStatusValuesList.add(sfcStatusValues);
        sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");
        sfcStatusValues.setDocNum("SO_123");
        sfcStatusValuesList.add(sfcStatusValues);


        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(sfcDao.getNumberOfErrorLinesInPaymentStageTable(Mockito.anyList(), Mockito.anyList(), Mockito.anyList())).thenReturn(Optional.of(1));
        Mockito.when(sfcDao.processUnprocessedPaymentLines(-1)).thenReturn(outParameters);
        Mockito.when(outParameters.getInt("p_retcode")).thenReturn(1);
        Mockito.when(outParameters.getString("p_errbuff")).thenReturn("");

        sfcPaymentProcessingService.processedUnProcessedPayments(sfcStatusValuesList, handle);
    }



}
