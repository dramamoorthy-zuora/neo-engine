package com.zuora.neo.engine.common.indicators;

public enum LineTestIndicator implements IndicatorEnum {

    ROOTLINE(0, 'Y'),
    LEADLINE(1, 'Y'),
    NONLEADLINE(2, 'N');

    private int pos;
    private char val;
    private static final char[] defaults;
    private static final int indicatorSize=6;
    private static final char unusedDefaultValue = 'N';

    static {
        int size = values().length;
        defaults =  new char[size];
        for (int i = 0; i < size; i++) {
            defaults[i] = values()[i].val;
        }
    }

    LineTestIndicator(int pos, char defaultValue) {
        this.pos=pos;
        val = defaultValue;
    }

    @Override
    public int getPosition() {
        return this.pos;
    }

    @Override
    public int getSize() {
        return indicatorSize;
    }

    @Override
    public char getUnusedDefaultValue() {
        return unusedDefaultValue;
    }

    @Override
    public char[] getDefaultValue() {
        return LineTestIndicator.defaults;
    }

}
