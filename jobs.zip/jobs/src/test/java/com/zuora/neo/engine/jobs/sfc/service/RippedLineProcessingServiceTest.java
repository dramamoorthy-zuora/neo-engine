package com.zuora.neo.engine.jobs.sfc.service;

import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.jobs.sfc.api.SfcSegmentsFlagsVersions;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SchdIndicator;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcCalcDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;

import org.jdbi.v3.core.Handle;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class RippedLineProcessingServiceTest {

    @Mock
    SoUpdateProcessingService soUpdateProcessingService;

    @Mock
    AccrualEntryService accrualEntryService;

    @Mock
    Handle handle;

    @InjectMocks
    RippedLineProcessingService rippedLineProcessingService;

    @Test
    public void testProcessRippedSfcLineWithImpairment() {

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        WorkflowContext workflowContext = new WorkflowContext(request);
        WorkflowContextManager.setWorkflowContext(workflowContext);

        List<RcLinePaData> rcLinePaDataRecord = new ArrayList<>();

        SfcStatusValues sfcStatusValue = new SfcStatusValues();
        sfcStatusValue.setNetInterestAccrual(BigDecimal.valueOf(32350.00));
        sfcStatusValue.setRipAmt(BigDecimal.valueOf(23500.00));

        List<RcLineDetails> rcLineDetails = new ArrayList<>();

        List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
        FinanceTypeFlagDetails financeTypeFlagDetails = new FinanceTypeFlagDetails(10020, "Y", "Y", "Y", "Y", "Y");
        financeTypeFlagDetailsList.add(financeTypeFlagDetails);

        List<SfcPaymentDetails> sfcPaymentDetails = new ArrayList<>();
        long openPeriodId = 202201;

        SfcSegmentsFlagsVersions sfcSegmentsFlagsVersions = new SfcSegmentsFlagsVersions();
        sfcSegmentsFlagsVersions.setCrAcctSeg("1234");
        sfcSegmentsFlagsVersions.setDrAcctSeg("1234");
        sfcSegmentsFlagsVersions.setRcVersion(1);
        sfcSegmentsFlagsVersions.setIncomeAcctSeg("DABC");
        sfcSegmentsFlagsVersions.setFinanceTypeVersion(1);
        sfcSegmentsFlagsVersions.setAccrualUponBillingFlag("Y");
        sfcSegmentsFlagsVersions.setIncomeStmtFlag("Y");
        sfcSegmentsFlagsVersions.setCrAcctFlag("Y");
        sfcSegmentsFlagsVersions.setDrAcctFlag("Y");
        sfcSegmentsFlagsVersions.setContractImpairmentAccountFlag("Y");
        sfcSegmentsFlagsVersions.setImpairmentAccountFlag("Y");
        sfcSegmentsFlagsVersions.setIncomeImpairmentSeg("1234");
        sfcSegmentsFlagsVersions.setContractImparimentSeg("1234");

        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();
        List<SfcCalcDetails> sfcCalcDetailsHistoryBatch = new ArrayList<>();
        SchdIndicator schdIndicator = new SchdIndicator();


        Mockito.when(soUpdateProcessingService.processSfcForUpdatedSoLine(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.anyLong(), Mockito.any(), Mockito.anyLong(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(BigDecimal.valueOf(22350.00));

        Mockito.doNothing().when(accrualEntryService).createImpairmentEntry(Mockito.anyList(), Mockito.anyList(), Mockito.any(),
                Mockito.any(), Mockito.anyLong(), Mockito.anyLong(), Mockito.any(), Mockito.any(), Mockito.anyChar(),
                Mockito.anyChar(), Mockito.any(), Mockito.any());

        rippedLineProcessingService.processRippedSfcLine(rcLinePaDataRecord, sfcStatusValue, rcLineDetails, financeTypeFlagDetailsList, sfcPaymentDetails,
                openPeriodId, sfcSegmentsFlagsVersions, rcScheduleRecordBatch, sfcCalcDetailsHistoryBatch, schdIndicator, handle);

    }

    @Test
    public void testProcessRippedSfcLineWithoutImpairment() {

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        WorkflowContext workflowContext = new WorkflowContext(request);
        WorkflowContextManager.setWorkflowContext(workflowContext);

        List<RcLinePaData> rcLinePaDataRecord = new ArrayList<>();

        SfcStatusValues sfcStatusValue = new SfcStatusValues();
        sfcStatusValue.setNetInterestAccrual(BigDecimal.valueOf(22350.00));
        sfcStatusValue.setRipAmt(BigDecimal.valueOf(350.00));

        List<RcLineDetails> rcLineDetails = new ArrayList<>();

        List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
        FinanceTypeFlagDetails financeTypeFlagDetails = new FinanceTypeFlagDetails(10020, "Y", "Y", "Y", "Y", "Y");
        financeTypeFlagDetailsList.add(financeTypeFlagDetails);

        List<SfcPaymentDetails> sfcPaymentDetails = new ArrayList<>();
        long openPeriodId = 202201;

        SfcSegmentsFlagsVersions sfcSegmentsFlagsVersions = new SfcSegmentsFlagsVersions();
        sfcSegmentsFlagsVersions.setCrAcctSeg("1234");
        sfcSegmentsFlagsVersions.setDrAcctSeg("1234");
        sfcSegmentsFlagsVersions.setRcVersion(1);
        sfcSegmentsFlagsVersions.setIncomeAcctSeg("DABC");
        sfcSegmentsFlagsVersions.setFinanceTypeVersion(1);
        sfcSegmentsFlagsVersions.setAccrualUponBillingFlag("Y");
        sfcSegmentsFlagsVersions.setIncomeStmtFlag("Y");
        sfcSegmentsFlagsVersions.setCrAcctFlag("Y");
        sfcSegmentsFlagsVersions.setDrAcctFlag("Y");
        sfcSegmentsFlagsVersions.setContractImpairmentAccountFlag("Y");
        sfcSegmentsFlagsVersions.setImpairmentAccountFlag("Y");
        sfcSegmentsFlagsVersions.setIncomeImpairmentSeg("1234");
        sfcSegmentsFlagsVersions.setContractImparimentSeg("1234");

        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();
        List<SfcCalcDetails> sfcCalcDetailsHistoryBatch = new ArrayList<>();
        SchdIndicator schdIndicator = new SchdIndicator();


        Mockito.when(soUpdateProcessingService.processSfcForUpdatedSoLine(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.anyLong(), Mockito.any(), Mockito.anyLong(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(BigDecimal.valueOf(22350.00));

        Mockito.doNothing().when(accrualEntryService).createAccrualEntry(Mockito.anyList(), Mockito.anyList(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyLong(),
                Mockito.anyLong(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyList(), Mockito.anyLong(), Mockito.anyChar());

        rippedLineProcessingService.processRippedSfcLine(rcLinePaDataRecord, sfcStatusValue, rcLineDetails, financeTypeFlagDetailsList, sfcPaymentDetails,
                openPeriodId, sfcSegmentsFlagsVersions, rcScheduleRecordBatch, sfcCalcDetailsHistoryBatch, schdIndicator, handle);

    }
}
