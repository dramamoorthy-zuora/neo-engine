package com.zuora.neo.engine.jobs.sweep.db.mapper;

import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.jdbi.v3.core.statement.StatementContext;
import org.junit.Test;

public class CurrentPeriodMapperTest {

    /**
     * Method under test: {@link CurrentPeriodMapper#map(ResultSet, StatementContext)}
     */
    @Test
    public void testMap() throws SQLException {
        CurrentPeriodMapper currentPeriodMapper = new CurrentPeriodMapper();
        Date date = mock(Date.class);
        when(date.getTime()).thenReturn(10L);
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getDate(anyInt())).thenReturn(date);
        currentPeriodMapper.map(resultSet, mock(StatementContext.class));
        verify(resultSet, atLeast(1)).getDate(anyInt());
        verify(date, atLeast(1)).getTime();
    }

    /**
     * Method under test: {@link CurrentPeriodMapper#map(ResultSet, StatementContext)}
     */
    @Test
    public void testMap2() throws SQLException {
        CurrentPeriodMapper currentPeriodMapper = new CurrentPeriodMapper();
        ResultSet resultSet = mock(ResultSet.class);
        when(resultSet.getDate(anyInt())).thenThrow(new SQLException());
        assertThrows(SQLException.class, () -> currentPeriodMapper.map(resultSet, mock(StatementContext.class)));
        verify(resultSet).getDate(anyInt());
    }
}

