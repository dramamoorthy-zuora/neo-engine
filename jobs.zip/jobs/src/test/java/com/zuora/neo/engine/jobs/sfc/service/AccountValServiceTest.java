package com.zuora.neo.engine.jobs.sfc.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.db.api.AccountValue;
import com.zuora.neo.engine.db.api.RcScheduleRecord;

import org.jdbi.v3.core.Handle;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class AccountValServiceTest {

    @Mock
    Handle handle;

    @Test
    public void testPopulateAccountSegment() {

        AccountValService accountValService = new AccountValService();

        String acctSeg = "2134";
        long crtdPrdId = 202201;
        RcScheduleRecord rcScheduleRecord = new RcScheduleRecord();
        rcScheduleRecord.setClientId(1);
        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        String expectedIndicator = "YYYNNNNNNNNNNNNNNNNI";
        AccountValue accountValue = accountValService.populateAccountSegment(acctSeg, crtdPrdId,rcScheduleRecord, request);

        assertEquals(1, accountValue.getClientId());
        assertEquals(acctSeg, accountValue.getAcctSeg());
        assertEquals(acctSeg, accountValue.getValAcctSeg());
        assertEquals(crtdPrdId, accountValue.getCrtdPrdId());
        assertEquals(expectedIndicator, accountValue.getIndicators());
        assertEquals(request.getUser(), accountValue.getCrtdBy());
    }

    //@Test
    public void testInsertAccountSegmentsBatch() {

        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();
        RcScheduleRecord rcScheduleRecord = new RcScheduleRecord();
        rcScheduleRecord.setClientId(1);
        rcScheduleRecord.setDrSegments("ABCD");
        rcScheduleRecord.setCrSegments("EFGH");
        rcScheduleRecordBatch.add(rcScheduleRecord);

        List<AccountValue> accountValuesList = new ArrayList<>();
        AccountValue accountValue = new AccountValue();
        accountValue.setAcctSeg("1234");
        accountValue.setClientId(1);
        accountValuesList.add(accountValue);

        long openPeriodId = 202203;

        AccountValService accountValService = mock(AccountValService.class);
        Mockito.doNothing().when(accountValService).prepareBatchAndInsertAcctSegments(Mockito.any(), Mockito.anyList());

        accountValService.insertAccountSegmentsBatch(rcScheduleRecordBatch, accountValuesList, openPeriodId, handle);

        assertEquals(1, accountValue.getClientId());
    }

}
