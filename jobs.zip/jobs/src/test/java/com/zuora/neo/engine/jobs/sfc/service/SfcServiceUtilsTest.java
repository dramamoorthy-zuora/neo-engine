package com.zuora.neo.engine.jobs.sfc.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.sfc.SfcResult;
import com.zuora.neo.engine.jobs.sfc.api.SfcSegmentsFlagsVersions;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcPaymentDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SfcStatusValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;

import org.jdbi.v3.core.statement.OutParameters;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class SfcServiceUtilsTest {

    @Mock
    CommonDao commonDao;

    @Mock
    SfcDao sfcDao;

    @Mock
    OutParameters outParameters;

    @Mock
    SfcDbCacheContext sfcDbCacheContext;

    @Mock
    SfcAcctSegmentsService sfcAcctSegmentsService;

    @InjectMocks
    SfcServiceUtils sfcServiceUtils;

    @Test
    public void testValidFinanceType() {
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();

        boolean isValid = sfcServiceUtils.validSfcLine(sfcStatusValues, sfcPaymentDetailsList, rcLineDetailsList, financeTypeValuesList);
        assertFalse(isValid);
        assertEquals(sfcStatusValues.getErrMsg(), "SFC Setup is not available");
    }

    @Test
    public void testValidSfcLineEmptyPayments() throws SQLException, ParseException {
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        boolean isValid = sfcServiceUtils.validSfcLine(sfcStatusValues, sfcPaymentDetailsList, rcLineDetailsList, financeTypeValuesList);
        assertFalse(isValid);
    }


    @Test
    public void testValidSfcLineNoInterestPopulated() throws SQLException, ParseException {
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails.Builder().withDocLineId("SO_123_4.5")
                .withId(1)
                .withNetPaymtAmt(BigDecimal.valueOf(123.23))
                .withPaymtDate(new Date())
                .withPaymtEndDate(new Date())
                .withPaymtStartDate(new Date())
                .build();

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setId(1);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(5.0));

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        sfcPaymentDetailsList.add(sfcPaymentDetails);
        rcLineDetailsList.add(rcLineDetails);

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        boolean isValid = sfcServiceUtils.validSfcLine(sfcStatusValues, sfcPaymentDetailsList, rcLineDetailsList, financeTypeValuesList);
        assertFalse(isValid);
        assertEquals(sfcStatusValues.getErrMsg(), "Interest not Populated");
    }

    @Test
    public void testValidSfcLineRevNotRec() throws SQLException, ParseException {
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails.Builder().withDocLineId("SO_123_4.5")
                .withId(1)
                .withNetPaymtAmt(BigDecimal.valueOf(123.23))
                .withPaymtDate(new Date())
                .withPaymtEndDate(new Date())
                .withPaymtStartDate(new Date())
                .build();

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setId(1);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(0.0));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(1.01));

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        sfcPaymentDetailsList.add(sfcPaymentDetails);
        rcLineDetailsList.add(rcLineDetails);

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        boolean isValid = sfcServiceUtils.validSfcLine(sfcStatusValues, sfcPaymentDetailsList, rcLineDetailsList, financeTypeValuesList);
        assertFalse(isValid);
        assertEquals(sfcStatusValues.getErrMsg(), "Revenue Not recognised");
    }

    @Test
    public void testValidSfcLinePrincipleAmountNull() throws SQLException, ParseException {
        SfcStatusValues sfcStatusValues = new SfcStatusValues();
        sfcStatusValues.setDocLineId("SO_123_4.5");

        SfcPaymentDetails sfcPaymentDetails = new SfcPaymentDetails.Builder().withDocLineId("SO_123_4.5")
                .withId(1)
                .withNetPaymtAmt(BigDecimal.valueOf(123.23))
                .withPaymtDate(new Date())
                .withPaymtEndDate(new Date())
                .withPaymtStartDate(new Date())
                .build();

        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setId(1);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(0.0));
        rcLineDetails.setRelPct(BigDecimal.TEN);
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(1.01));

        List<SfcPaymentDetails> sfcPaymentDetailsList = new ArrayList<>();
        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();

        sfcPaymentDetailsList.add(sfcPaymentDetails);
        rcLineDetailsList.add(rcLineDetails);

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        boolean isValid = sfcServiceUtils.validSfcLine(sfcStatusValues, sfcPaymentDetailsList, rcLineDetailsList, financeTypeValuesList);
        assertFalse(isValid);
        assertEquals(sfcStatusValues.getErrMsg(), "Principle Amount Null/Zero");
    }

    @Test
    public void testGetSegmentsFlagsVersions() throws ParseException {

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
        FinanceTypeFlagDetails financeTypeFlagDetails = new FinanceTypeFlagDetails(10020, "YNNN", "YNNN", "Y", "Y", "Y");
        financeTypeFlagDetailsList.add(financeTypeFlagDetails);

        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetailsList.add(rcLineDetails);


        long vcTypeId = 10020;
        long bookId = 1;
        long lineId = 11200;

        SfcSegmentsFlagsVersions sfcAcctSegmentsFlags = new SfcSegmentsFlagsVersions();
        sfcAcctSegmentsFlags.setCrAcctSeg("1234");
        sfcAcctSegmentsFlags.setDrAcctSeg("1234");
        sfcAcctSegmentsFlags.setIncomeAcctSeg("1234");
        sfcAcctSegmentsFlags.setContractImparimentSeg("1234");
        sfcAcctSegmentsFlags.setIncomeImpairmentSeg("1234");

        Mockito.when(commonDao.getVersionFromRcId(Mockito.anyLong())).thenReturn(1L);
/*        Mockito.when(sfcDao.getSfcAcct(Mockito.anyLong(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyLong(),
                Mockito.any(), Mockito.any())).thenReturn(outParameters); */
        Mockito.when(sfcAcctSegmentsService.getSfcAcct(Mockito.anyLong(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.anyLong(),
                        Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sfcAcctSegmentsFlags);
        //Mockito.when(outParameters.getString(Mockito.any())).thenReturn("1234");

        SfcSegmentsFlagsVersions sfcSegmentsFlagsVersions = sfcServiceUtils.getSegmentsFlagsVersions(financeTypeValuesList, financeTypeFlagDetailsList,
                rcLineDetailsList, vcTypeId, bookId, lineId, sfcDbCacheContext, commonDao, sfcDao);

        assertEquals("R", sfcSegmentsFlagsVersions.getDrAcctFlag());
        assertEquals("d", sfcSegmentsFlagsVersions.getCrAcctFlag());
        assertEquals("e", sfcSegmentsFlagsVersions.getIncomeStmtFlag());
        assertEquals("B", sfcSegmentsFlagsVersions.getAccrualUponBillingFlag());
        assertEquals(1 , sfcSegmentsFlagsVersions.getFinanceTypeVersion());
        assertEquals(1L, sfcSegmentsFlagsVersions.getRcVersion());
        assertEquals("1234", sfcSegmentsFlagsVersions.getCrAcctSeg());
        assertEquals("1234", sfcSegmentsFlagsVersions.getDrAcctSeg());
        assertEquals("1234", sfcSegmentsFlagsVersions.getIncomeAcctSeg());
        assertEquals("1234", sfcSegmentsFlagsVersions.getIncomeImpairmentSeg());
        assertEquals("N", sfcSegmentsFlagsVersions.getImpairmentAccountFlag());
        assertEquals("N", sfcSegmentsFlagsVersions.getContractImpairmentAccountFlag());
    }

    @Test
    public void testGetFinanceTypeForRcLine() throws ParseException {

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        List<CalendarDetails> calendarDetailsList = new ArrayList<>();
        CalendarDetails calendarDetails = new CalendarDetails(202106, "JUNE-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("30/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/12/2021"));
        calendarDetailsList.add(calendarDetails);

        List<RcLinePaData> rcLinePaDataRecordBeforeProcessing = new ArrayList<>();
        RcLinePaData rcLinePaData = new RcLinePaData();
        rcLinePaData.setDefAmt(BigDecimal.valueOf(25.00));
        rcLinePaData.setRecAmt(BigDecimal.valueOf(0.0));
        rcLinePaData.setVcTypeId(10020);
        rcLinePaData.setId(10053);
        rcLinePaData.setIndicators("YNNNNNNNNNNNNNN");
        rcLinePaData.setFncTypeVersion(1);
        rcLinePaDataRecordBeforeProcessing.add(rcLinePaData);


        List<RcLineDetails> rcLineDetails = new ArrayList<>();

        Mockito.when(sfcDbCacheContext.getFinanceTypeValuesList()).thenReturn(financeTypeValuesList);
        Mockito.when(sfcDbCacheContext.getCalendarDetails()).thenReturn(calendarDetailsList);

        List<FinanceTypeValues> financeTypeValue = sfcServiceUtils.getFinanceTypeForRcLine(rcLinePaDataRecordBeforeProcessing, sfcDbCacheContext, rcLineDetails);
        assertEquals(financeTypeValuesList, financeTypeValue);
    }

    @Test
    public void testGetFinanceTypeForRcLineEmptyPaLine() throws ParseException {

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        List<CalendarDetails> calendarDetailsList = new ArrayList<>();
        CalendarDetails calendarDetails = new CalendarDetails(202106, "JUNE-21",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("30/06/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2021"),
                new SimpleDateFormat("dd/MM/yyyy").parse("31/12/2021"));
        calendarDetailsList.add(calendarDetails);

        List<RcLinePaData> rcLinePaDataRecordBeforeProcessing = new ArrayList<>();

        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetails.setDocDate(new SimpleDateFormat("dd/MM/yyyy").parse("15/06/2021"));
        rcLineDetailsList.add(rcLineDetails);


        Mockito.when(sfcDbCacheContext.getFinanceTypeValuesList()).thenReturn(financeTypeValuesList);
        Mockito.when(sfcDbCacheContext.getCalendarDetails()).thenReturn(calendarDetailsList);

        List<FinanceTypeValues> financeTypeValue = sfcServiceUtils.getFinanceTypeForRcLine(rcLinePaDataRecordBeforeProcessing, sfcDbCacheContext, rcLineDetailsList);
        assertEquals(financeTypeValuesList, financeTypeValue);
    }

    @Test
    public void testUpdateSfcStatusAndAddWarningCount() {
        SfcResult sfcResult = new SfcResult();
        SfcStatusValues sfcStatusValue = new SfcStatusValues();
        String status = "Error in Processing SFC";

        sfcServiceUtils.updateSfcStatusAndAddWarningCount(sfcResult, sfcStatusValue, status);

        assertEquals("Error in Processing SFC", sfcStatusValue.getErrMsg());
        assertEquals(1, sfcResult.getWarningCount());


    }
}
