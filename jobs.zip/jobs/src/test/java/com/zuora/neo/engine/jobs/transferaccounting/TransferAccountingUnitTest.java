package com.zuora.neo.engine.jobs.transferaccounting;

import com.zuora.neo.engine.jobs.transferaccounting.activities.AccountingActivitiesImpl;
import com.zuora.neo.engine.jobs.transferaccounting.api.BatchCriteriaCondition;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.BatchCriteria;
import com.zuora.neo.engine.jobs.transferaccounting.api.GlInsertBuilder;
import com.zuora.neo.engine.jobs.transferaccounting.db.api.GlIntegrationMap;

import org.junit.Test;
import org.junit.jupiter.api.Disabled;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;
@RunWith(MockitoJUnitRunner.class)
public class TransferAccountingUnitTest {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AccountingActivitiesImpl.class);

    @Test
    public void transferAccountingTestBatchConditionRRS() {
        BatchCriteria batchCriteriaRRS = new BatchCriteria(new Long(10000), "RC_ID", "=", "10", new Long(10040), "RRS", null);
        BatchCriteriaCondition bccRRS = BatchCriteriaCondition.createBatchCondition(batchCriteriaRRS, new StringBuilder(""), new StringBuilder(""), new StringBuilder(""), 0,new StringBuilder(""), new StringBuilder(""), 0, 0);
        assertTrue(bccRRS.getRrsFilerCount()==1);
        assertTrue(bccRRS.getMjtFilerCount()==0);
        assertTrue(bccRRS.getRcFilerCount()==0);
        LOGGER.info("**     " + bccRRS.getScheduleWhereClause().toString());
        assertTrue(bccRRS.getScheduleWhereClause().toString().equals(" AND NVL (null, rrs.RC_ID) = '10' "));
        assertTrue(bccRRS.getBookWhereClause().toString().equals(""));
        assertTrue(bccRRS.getMjtWhereClause().toString().equals(""));
        assertTrue(bccRRS.getPrdWhereClause().toString().equals(""));
        assertTrue(bccRRS.getNonSchWhereClause().toString().equals(""));

    }

    @Test
    public void transferAccountingTestBatchConditionRB() {
        BatchCriteria batchCriteriaRB=new BatchCriteria(new Long(12280),"BOOK_NAME","=","GAAP",new Long(14879),"RB",null);
        BatchCriteriaCondition bccRB=BatchCriteriaCondition.createBatchCondition(batchCriteriaRB, new StringBuilder(""), new StringBuilder(""), new StringBuilder(""), 0,new StringBuilder(""), new StringBuilder(""), 0, 0);
        assertTrue(bccRB.getRrsFilerCount()==0);
        assertTrue(bccRB.getMjtFilerCount()==0);
        assertTrue(bccRB.getRcFilerCount()==0);
        assertTrue(bccRB.getScheduleWhereClause().toString().equals(""));
        assertTrue(bccRB.getBookWhereClause().toString().equals(" AND rrs.book_id IN ( SELECT rb.id FROM rpro_book rb  WHERE rpro_book_pkg.get_enabled_flag (rb.indicators) = 'Y' AND SYSDATE BETWEEN NVL (rb.start_date, SYSDATE)  AND NVL (rb.end_date, SYSDATE + 1))"));
        assertTrue(bccRB.getMjtWhereClause().toString().equals(""));
        assertTrue(bccRB.getPrdWhereClause().toString().equals(""));
        assertTrue(bccRB.getNonSchWhereClause().toString().equals(""));
    }


    @Test
    public void transferAccountingTestBatchConditionRBFieldValNotNULL() {
        BatchCriteria batchCriteriaRB=new BatchCriteria(new Long(12280),"BOOK_NAME","=","GAAP",new Long(14879),"RB","rb.name");
        BatchCriteriaCondition bccRB=BatchCriteriaCondition.createBatchCondition(batchCriteriaRB, new StringBuilder(""), new StringBuilder(""), new StringBuilder(""), 0,new StringBuilder(""), new StringBuilder(""), 0, 0);
        assertTrue(bccRB.getRrsFilerCount()==0);
        assertTrue(bccRB.getMjtFilerCount()==0);
        assertTrue(bccRB.getRcFilerCount()==0);
        assertTrue(bccRB.getScheduleWhereClause().toString().equals(""));
        assertTrue(bccRB.getBookWhereClause().toString().equals(" AND rrs.book_id IN ( SELECT rb.id FROM rpro_book rb  WHERE rpro_book_pkg.get_enabled_flag (rb.indicators) = 'Y' AND SYSDATE BETWEEN NVL (rb.start_date, SYSDATE)  AND NVL (rb.end_date, SYSDATE + 1) AND NVL (rb.name, rb.name ) = 'GAAP') "));
        assertTrue(bccRB.getMjtWhereClause().toString().equals(""));
        assertTrue(bccRB.getPrdWhereClause().toString().equals(""));
        assertTrue(bccRB.getNonSchWhereClause().toString().equals(""));
    }
    @Test
    public void transferAccountingTestBatchConditionRC() {
        BatchCriteria batchCriteriaRC = new BatchCriteria(new Long(12280), "PERIOD_NAME", "=", "AUG-21", new Long(14883), "RC", null);
        BatchCriteriaCondition bccRC = BatchCriteriaCondition.createBatchCondition(batchCriteriaRC,  new StringBuilder(""), new StringBuilder(""), new StringBuilder(""), 0,new StringBuilder(""), new StringBuilder(""), 0, 0);
        assertTrue(bccRC.getRrsFilerCount()==0);
        assertTrue(bccRC.getMjtFilerCount()==0);
        assertTrue(bccRC.getRcFilerCount()==0);
        assertTrue(bccRC.getScheduleWhereClause().toString().equals(""));
        assertTrue(bccRC.getBookWhereClause().toString().equals(""));
        assertTrue(bccRC.getMjtWhereClause().toString().equals(""));
        assertTrue(bccRC.getPrdWhereClause().toString().equals(" AND rrs.post_prd_id IN ( SELECT id FROM rpro_calendar rc WHERE 1=1 AND NVL (null, rc.PERIOD_NAME) = 'AUG-21' )"));
        assertTrue(bccRC.getNonSchWhereClause().toString().equals(""));
    }

    @Test
    public void transferAccountingTestBatchConditionRCFieldValNotNULL() {
        BatchCriteria batchCriteriaRC = new BatchCriteria(new Long(12280), "PERIOD_NAME", "=", "AUG-21", new Long(14883), "RC", "PERIOD_NAME");
        BatchCriteriaCondition bccRC = BatchCriteriaCondition.createBatchCondition(batchCriteriaRC,  new StringBuilder(""), new StringBuilder(""), new StringBuilder(""), 0,new StringBuilder(""), new StringBuilder(""), 0, 0);
        assertTrue(bccRC.getRrsFilerCount()==0);
        assertTrue(bccRC.getMjtFilerCount()==0);
        assertTrue(bccRC.getRcFilerCount()==0);
        assertTrue(bccRC.getScheduleWhereClause().toString().equals(""));
        assertTrue(bccRC.getBookWhereClause().toString().equals(""));
        assertTrue(bccRC.getMjtWhereClause().toString().equals(""));
        assertTrue(bccRC.getPrdWhereClause().toString().equals(" AND rrs.post_prd_id IN ( SELECT id FROM rpro_calendar rc WHERE 1=1 AND NVL (PERIOD_NAME, rc.PERIOD_NAME) = 'AUG-21' AND NVL (PERIOD_NAME, rc.PERIOD_NAME) = 'AUG-21' )"));
        assertTrue(bccRC.getNonSchWhereClause().toString().equals(""));
    }

    @Test
    public void transferAccountingTestBatchConditionRJH()
    {
        BatchCriteria batchCriteriaRC = new BatchCriteria(new Long(12280), "NAME", "=", "NAME", new Long(14883), "RJH", null);
        BatchCriteriaCondition bccRC = BatchCriteriaCondition.createBatchCondition(batchCriteriaRC,  new StringBuilder(""), new StringBuilder(""), new StringBuilder(""), 0,new StringBuilder(""), new StringBuilder(""), 0, 0);
        assertTrue(bccRC.getRrsFilerCount()==0);
        assertTrue(bccRC.getMjtFilerCount()==1);
        assertTrue(bccRC.getRcFilerCount()==0);
        assertTrue(bccRC.getScheduleWhereClause().toString().equals(""));
        assertTrue(bccRC.getBookWhereClause().toString().equals(""));
        assertTrue(bccRC.getMjtWhereClause().toString().equals(" AND NVL ( null,rjh.NAME) = 'NAME' "));
        assertTrue(bccRC.getPrdWhereClause().toString().equals(""));
        assertTrue(bccRC.getNonSchWhereClause().toString().equals(""));
    }

    @Test
    public void transferAccountingTestBatchConditionRJL()
    {
        BatchCriteria batchCriteriaRC = new BatchCriteria(new Long(12280), "HEADER_ID", "=", "1", new Long(14883), "RJL", null);
        BatchCriteriaCondition bccRJL = BatchCriteriaCondition.createBatchCondition(batchCriteriaRC,  new StringBuilder(""), new StringBuilder(""), new StringBuilder(""), 0,new StringBuilder(""), new StringBuilder(""), 0, 0);
        assertTrue(bccRJL.getRrsFilerCount()==0);
        assertTrue(bccRJL.getMjtFilerCount()==1);
        assertTrue(bccRJL.getRcFilerCount()==0);
        assertTrue(bccRJL.getScheduleWhereClause().toString().equals(""));
        assertTrue(bccRJL.getBookWhereClause().toString().equals(""));
        assertTrue(bccRJL.getMjtWhereClause().toString().equals(" AND NVL ( null,rjl.HEADER_ID) = '1' "));
        assertTrue(bccRJL.getPrdWhereClause().toString().equals(""));
        assertTrue(bccRJL.getNonSchWhereClause().toString().equals(""));
    }

    @Test
    public void transferAccountingTestBatchConditionNoAlias()
    {
        BatchCriteria batchCriteriaRC = new BatchCriteria(new Long(12280), "ATR1", "=", "", new Long(14883), "RH", "");
        BatchCriteriaCondition bccRC = BatchCriteriaCondition.createBatchCondition(batchCriteriaRC,  new StringBuilder(""), new StringBuilder(""), new StringBuilder(""), 0,new StringBuilder(""), new StringBuilder(""), 0, 0);
        assertTrue(bccRC.getRrsFilerCount()==0);
        assertTrue(bccRC.getMjtFilerCount()==0);
        assertTrue(bccRC.getRcFilerCount()==1);
        assertTrue(bccRC.getScheduleWhereClause().toString().equals(""));
        assertTrue(bccRC.getBookWhereClause().toString().equals(""));
        assertTrue(bccRC.getMjtWhereClause().toString().equals(""));
        assertTrue(bccRC.getPrdWhereClause().toString().equals(""));
        assertTrue(bccRC.getNonSchWhereClause().toString().equals(" AND rh.ATR1 = ''"));
    }
    @Test
    public  void transferAccountingTestFormGlInsertFromMapConstantGL() throws InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException, NoSuchFieldException {
        GlIntegrationMap glmap=new GlIntegrationMap(0L,"USER_JE_SOURCE_NAME","GL","CONSTANT","'zuora'","indicators",0,0L,0,"displayLabel");
        GlInsertBuilder mappedValues=GlInsertBuilder.formGlInsertFromMap(glmap,"objectType",null,new StringBuilder(""),"Y","Y",new StringBuilder(""),new StringBuilder(""),0,1, false);
        assertTrue(",'zuora'".equals(mappedValues.getInsertSelect().toString()));
        assertTrue(",USER_JE_SOURCE_NAME".equals(mappedValues.getInsertStmt().toString()));
    }

    @Test
    public  void transferAccountingTestFormGlInsertFromMapConstantMJE() throws InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        GlIntegrationMap glmap=new GlIntegrationMap(0L,"ATTRIBUTE2","MANUAL-JE","CONSTANT","'zuora'","indicators",0,0L,0,"displayLabel");
        GlInsertBuilder mappedValues=GlInsertBuilder.formGlInsertFromMap(glmap,"objectType",null,new StringBuilder(""),"Y","Y",new StringBuilder(""),new StringBuilder(""),0,1, false);
        assertTrue(",'zuora'".equals(mappedValues.getInsertSelect().toString()));
        assertTrue(",ATTRIBUTE2".equals(mappedValues.getInsertStmt().toString()));
    }

    @Test
    public  void transferAccountingTestFormGlInsertFromMapExpressionGL() throws InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        GlIntegrationMap glmap=new GlIntegrationMap(0L,"ATTRIBUTE13","GL","EXPRESSION","SYSDATE +7","indicators",0,0L,0,"displayLabel");
        GlInsertBuilder mappedValues=GlInsertBuilder.formGlInsertFromMap(glmap,"GL",null,new StringBuilder(),"Y","Y",new StringBuilder(),new StringBuilder(),0,1, false);
        assertTrue(",SYSDATE +7".equals(mappedValues.getInsertSelect().toString()));
        assertTrue(",ATTRIBUTE13".equals(mappedValues.getInsertStmt().toString()));
        assertTrue(",SYSDATE +7".equals(mappedValues.getGroupByStr().toString()));
    }


    @Test
    public  void transferAccountingTestFormGlInsertFromMapExpressionMJE() throws NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException//13077
    {
        GlIntegrationMap glmap=new GlIntegrationMap(0L,"ATTRIBUTE1","MANUAL-JE","EXPRESSION","SYSTIMESTAMP-7","indicators",0,0L,0,"displayLabel");
        GlInsertBuilder mappedValues=GlInsertBuilder.formGlInsertFromMap(glmap,"MANUAL-JE",null,new StringBuilder(),"Y","Y",new StringBuilder(),new StringBuilder(),0,1, false);
        assertTrue(",SYSTIMESTAMP-7".equals(mappedValues.getInsertSelect().toString()));
        assertTrue(",ATTRIBUTE1".equals(mappedValues.getInsertStmt().toString()));
        assertTrue(",SYSTIMESTAMP-7".equals(mappedValues.getGroupByStr().toString()));
    }

    @Test
    @Disabled
    public  void transferAccountingTestFormGlInsertFromMapTransactionGl() throws InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException//13079//13081
    {
        List<GlIntegrationMap> glMapList =new ArrayList<>();
        GlIntegrationMap glmap1=new GlIntegrationMap(0L,"ENTERED_CR","GL","TRANSACTION","SCHD_CR_AMOUNT","indicators",0,0L,0,"displayLabel");
        GlIntegrationMap glmap2=new GlIntegrationMap(0L,"ENTERED_DR","GL","TRANSACTION","SCHD_DR_AMOUNT","indicators",0,0L,0,"displayLabel");
        GlIntegrationMap glmap3=new GlIntegrationMap(0L,"PERIOD_NAME","GL","TRANSACTION","SCHD_POST_PERIOD_NAME","indicators",0,0L,0,"displayLabel");
        glMapList.add(glmap1);
        glMapList.add(glmap2);
        glMapList.add(glmap3);
        StringBuilder groupByStr = new StringBuilder();
        StringBuilder insertSelect = new StringBuilder();
        StringBuilder insertStmt = new StringBuilder();
        GlInsertBuilder mappedValues=null ;
        for (int i = 0; i < glMapList.size(); ++i) {
            GlIntegrationMap glMap = glMapList.get(i);
            mappedValues=GlInsertBuilder.formGlInsertFromMap(glMap, "GL", null, groupByStr, "Y", "Y",
                    insertStmt,insertSelect, i, glMapList.size(), true);
        }
        LOGGER.info(mappedValues.getInsertSelect().toString());
        LOGGER.info(mappedValues.getInsertStmt().toString());
        LOGGER.info(mappedValues.getGroupByStr().toString());

        //assertTrue(",SUM(SCHD_CR_AMOUNT) ,SUM(SCHD_DR_AMOUNT) ,SCHD_POST_PERIOD_NAME".equals(mappedValues.getInsertSelect().toString()));
        assertTrue(",SUM(ROUND(SCHD_CR_AMOUNT,rpro_utility_pkg.curr_rounding(LINE_F_CUR))) ,SUM(ROUND(SCHD_DR_AMOUNT,rpro_utility_pkg.curr_rounding(LINE_F_CUR))) ,SCHD_POST_PERIOD_NAME".equals(mappedValues.getInsertSelect().toString()));
        assertTrue(",ENTERED_CR,ENTERED_DR,PERIOD_NAME".equals(mappedValues.getInsertStmt().toString()));
        assertTrue(",SCHD_POST_PERIOD_NAME".equals(mappedValues.getGroupByStr().toString()));
    }

    @Test
    @Disabled
    public void transferAccountingTestFormGlInsertFromMapTransactionMje() throws InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        List<GlIntegrationMap> glMapList =new ArrayList<>();
        GlIntegrationMap glmap1=new GlIntegrationMap(0L,"ACCOUNTED_CR","MANUAL-JE","TRANSACTION","SCHD_CR_AMOUNT","indicators",0,0L,0,"displayLabel");
        GlIntegrationMap glmap2=new GlIntegrationMap(0L,"ACCOUNTED_DR","MANUAL-JE","TRANSACTION","SCHD_DR_AMOUNT","indicators",0,0L,0,"displayLabel");
        GlIntegrationMap glmap3=new GlIntegrationMap(0L,"PERIOD_NAME","MANUAL-JE","TRANSACTION","SCHD_POST_PERIOD_NAME","indicators",0,0L,0,"displayLabel");
        glMapList.add(glmap1);
        glMapList.add(glmap2);
        glMapList.add(glmap3);
        StringBuilder groupByStr = new StringBuilder();
        StringBuilder insertSelect = new StringBuilder();
        StringBuilder insertStmt = new StringBuilder();
        GlInsertBuilder mappedValues=null ;
        for (int i = 0; i < glMapList.size(); ++i) {
            GlIntegrationMap glMap = glMapList.get(i);
            mappedValues=GlInsertBuilder.formGlInsertFromMap(glMap, "MANUAL-JE", null, groupByStr, "Y", "Y",
                    insertStmt,insertSelect, i, glMapList.size(), true);
        }
        LOGGER.info(mappedValues.getInsertSelect().toString());
        LOGGER.info(mappedValues.getInsertStmt().toString());
        LOGGER.info(mappedValues.getGroupByStr().toString());

        //assertTrue(",SUM(SCHD_CR_AMOUNT) ,SUM(SCHD_DR_AMOUNT) ,SCHD_POST_PERIOD_NAME".equals(mappedValues.getInsertSelect().toString()));
        assertTrue(",SUM(ROUND(SCHD_CR_AMOUNT,rpro_utility_pkg.curr_rounding(HEAD_FN_CUR))) ,SUM(ROUND(SCHD_DR_AMOUNT,rpro_utility_pkg.curr_rounding(HEAD_FN_CUR))) ,SCHD_POST_PERIOD_NAME".equals(mappedValues.getInsertSelect().toString()));
        assertTrue(",ACCOUNTED_CR,ACCOUNTED_DR,PERIOD_NAME".equals(mappedValues.getInsertStmt().toString()));
        assertTrue(",SCHD_POST_PERIOD_NAME".equals(mappedValues.getGroupByStr().toString()));
    }

}
