package com.zuora.neo.engine.jobs.sfc.activities;

import io.temporal.testing.TestWorkflowEnvironment;
import io.temporal.testing.internal.SDKTestWorkflowRule;
import io.temporal.worker.WorkerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

public class SfcWorkflowTest {

    WorkerFactory factory;

    SDKTestWorkflowRule testSfcActivityRule;

    @Autowired
    ApplicationContext applicationContext;

    private TestWorkflowEnvironment testEnvironment;

    /*
    @Rule
    public SDKTestWorkflowRule init() {
     */
       /* Worker workflowWorker = factory.newWorker(RevEngineTaskQueues.COMMON_TASK_QUEUE);
        WorkflowImplementationOptions options = WorkflowImplementationOptions.newBuilder()
                .setDefaultActivityOptions(DefaultActivityOptions.getActivityOptions())
                .setFailWorkflowExceptionTypes(new Class[]{Throwable.class})
                .build();
        workflowWorker.addWorkflowImplementationFactory(options,
                SfcWorkflow.class,
                () -> applicationContext.getBean(SfcWorkflowImpl.class)
        );

        workflowWorker.registerActivitiesImplementations(applicationContext.getBean(SfcActivitiesImpl.class));

        */
        /*
        TestEnvironmentOptions testOptions = TestEnvironmentOptions.newBuilder()
                .setWorkerFactoryOptions(WorkerFactoryOptions.newBuilder()
                        .validateAndBuildWithDefaults()
                )
                .setWorkflowClientOptions(
                        WorkflowClientOptions.newBuilder()
                                .setContextPropagators(Collections.singletonList(new NeoEngineContextPropagator()))
                                .build())
                .build();

        testEnvironment = TestWorkflowEnvironment.newInstance(testOptions);

        WorkflowImplementationOptions options = WorkflowImplementationOptions.newBuilder()
                .setDefaultActivityOptions(DefaultActivityOptions.getActivityOptions())
                .setFailWorkflowExceptionTypes(new Class[]{Throwable.class})
                .build();

        testSfcActivityRule =
                SDKTestWorkflowRule.newBuilder()
                        .setWorkflowTypes(SfcWorkflowImpl.class)
                        .setActivityImplementations(new SfcActivitiesImpl())
                        .setWorkflowTypes(options)
                        .build();

        return testSfcActivityRule;
    }
    */

    /*
    //@Test
    public void testSfcWorkflow() {

        SfcActivities sfcActivities = mock(SfcActivities.class);
        List<SfcStatusValues> sfcStatusValues = new ArrayList<>();
        //when(sfcActivities.processSfc()).thenReturn(sfcStatusValues);
        SfcWorkflow sfcWorkflow = testSfcActivityRule.newWorkflowStub(SfcWorkflow.class);
        sfcWorkflow.processSfc();
    }
     */
}
