package com.zuora.neo.engine.jobs.sweep.activities.rco;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class RcoEventTypeTest {

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>{@link RcoEventType#valueOf(String)}
     *   <li>{@link RcoEventType#getType()}
     * </ul>
     */
    @Test
    public void testValueOf() {
        assertEquals("ACCOUNT-ANALYSIS", RcoEventType.valueOf("ACCOUNT_ANALYSIS").getType());
    }
}

