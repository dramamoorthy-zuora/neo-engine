package com.zuora.neo.engine.jobs.rtp.service;

import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.dao.LockDao;
import com.zuora.neo.engine.exception.NeoEngineException;
import com.zuora.neo.engine.jobs.rtp.WorkItemResult;
import com.zuora.neo.engine.jobs.rtp.api.RtpStep;
import com.zuora.neo.engine.jobs.rtp.api.RtpWorkflowDefinition;
import com.zuora.neo.engine.jobs.rtp.config.RtpProperties;
import com.zuora.neo.engine.jobs.rtp.constants.RtpConstants;
import com.zuora.neo.engine.jobs.rtp.db.doa.RtpDao;
import com.zuora.neo.engine.jobs.rtp.factory.RtpWorkflowFactory;
import com.zuora.neo.engine.scheduler.dao.ScheduledProgramDao;
import com.zuora.neo.engine.temporal.log.NeoWorkflowLogger;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.OutParameters;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RtpWorkflowServiceTest {

    @Mock
    private RtpWorkflowFactory rtpWorkflowFactory;

    @Mock
    private ParseProgramParameters parseProgramParameters;

    @Mock
    private NeoWorkflowLogger neoWorkflowLogger;

    @Mock
    private RtpProperties rtpProperties;

    @Mock
    private RtpDao rtpDao;

    @Mock
    private ScheduledProgramDao programDao;

    @Mock
    private LockDao lockDao;

    @Mock
    private Handle handle;

    @Mock
    private RtpBatchCreatorService rtpBatchCreatorService;

    @Mock
    private RtpService rtpService;

    @Mock
    private OutParameters outParameters;

    @Mock
    private RtpCleanupService rtpCleanupService;

    @InjectMocks
    RtpWorkflowService rtpWorkflowService;

    private static final String user = "UNIT_TEST_USER", tenantId = "zk52234", orgId = "0", parameterText = "N~";

    private static final Long clientId = 1L, requestId = 1L, roleId = 5L;

    private static final BigDecimal batchId = new BigDecimal(1.0);

    private static final int programId = 544;

    private static final MockedStatic<WorkflowContextManager> workflowContextManager = Mockito.mockStatic(WorkflowContextManager.class);
    private static final WorkflowContext workflowContext = mock(WorkflowContext.class);

    @Test
    public void testRtpWorkflowService() {
        WorkflowRequest workflowRequest = new WorkflowRequest(programId, requestId, tenantId, orgId, clientId, user, roleId, parameterText);

        workflowContextManager.when(WorkflowContextManager::getWorkflowContext).thenReturn(workflowContext);
        when(workflowContext.getRequest()).thenReturn(workflowRequest);
        when(rtpBatchCreatorService.prepareWiHeaderBatchForRtp(any(), any(), any())).thenReturn(0);

        long processedCount = rtpWorkflowService.performRtp(handle, rtpDao, programDao, orgId);
        assertEquals(0, processedCount);

        List<RtpWorkflowDefinition> rtpWorkflowDefinitions = new ArrayList<>();
        rtpWorkflowDefinitions.add(new RtpWorkflowDefinition(new RtpStep(1, "CACL"), 10));
        rtpWorkflowDefinitions.add(new RtpWorkflowDefinition(new RtpStep(2, "LTST"), 20));
        rtpWorkflowDefinitions.add(new RtpWorkflowDefinition(new RtpStep(3, "SUMMARIZATION"), 30));

        when(rtpBatchCreatorService.prepareWiHeaderBatchForRtp(any(), any(), any())).thenReturn(10);
        when(rtpDao.getRtpWorkflowDefinition(anyInt())).thenReturn(rtpWorkflowDefinitions);
        // when(rtpDao.createRtpWiEntries(anyDouble(), anyString(), anyInt(), anyString())).thenReturn(10);
        when(rtpWorkflowService.getServiceFromFactory(anyInt())).thenReturn(rtpService);
        when(rtpService.process(anyString(), any())).thenReturn(new WorkItemResult("", 0));
        when(programDao.pendingJobExistsInQueue(anyString(), anyLong())).thenReturn(1);


        long processedCount2 = rtpWorkflowService.performRtp(handle, rtpDao, programDao, orgId);
        assertEquals(10, processedCount2);

        when(rtpService.process(anyString(), any())).thenReturn(new WorkItemResult("ERROR", 1));
        long processedCount3 = rtpWorkflowService.performRtp(handle, rtpDao, programDao, orgId);
        assertEquals(10, processedCount3);

    }

    @Test
    public void testAcquireLock() {
        WorkflowRequest workflowRequest = new WorkflowRequest(programId, requestId, tenantId, orgId, clientId, user, roleId, parameterText);
        when(lockDao.acquireLock(anyLong(), anyString(), anyString(), anyString())).thenReturn(outParameters);
        when(outParameters.getString("p_ret_msg")).thenReturn("Lock already exists");
        when(outParameters.getString("p_result")).thenReturn("FALSE");
        workflowContextManager.when(WorkflowContextManager::getWorkflowContext).thenReturn(workflowContext);
        when(workflowContext.getRequest()).thenReturn(workflowRequest);

        NeoEngineException neoEngineException = assertThrows(NeoEngineException.class,
                () -> rtpWorkflowService.acquireLock(lockDao, orgId));

        assertEquals(neoEngineException.getMessage(), RtpConstants.UNABLE_TO_LOCK + outParameters.getString("p_ret_msg"));

        when(outParameters.getString("p_ret_msg")).thenReturn("");
        when(outParameters.getString("p_result")).thenReturn("TRUE");
        OutParameters outParameters1 = rtpWorkflowService.acquireLock(lockDao, orgId);
        assertEquals("TRUE", outParameters1.getString("p_result"));
    }
}
