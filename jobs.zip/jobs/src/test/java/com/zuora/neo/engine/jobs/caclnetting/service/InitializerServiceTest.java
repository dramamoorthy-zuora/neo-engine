package com.zuora.neo.engine.jobs.caclnetting.service;

import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.PeriodDetails;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.caclnetting.config.CaclProperties;
import com.zuora.neo.engine.jobs.caclnetting.constants.CaclMessages;
import com.zuora.neo.engine.jobs.caclnetting.db.dao.CaclNettingDao;
import io.temporal.failure.ApplicationFailure;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class InitializerServiceTest {
    @Spy
    private CaclProperties caclProperties;

    @Mock
    private CommonDao commonDao;

    @Mock
    private CaclNettingDao nettingDao;

    @InjectMocks
    InitializerService initializerService;

    private static final BigDecimal batchId = new BigDecimal(1.0);

    private static final String user = "UNIT_TEST", createLineLevel = "Y", orgId = "0";

    private static final Long bookId = 1L, clientId = 1L;

    private static PeriodDetails periodDetailsMock = new PeriodDetails(202203, 202202, 202201);

    List<PeriodDetails> periodDetailsList = new ArrayList<>();

    List<CalendarDetails> calendarDetailsList = new ArrayList<>();
    CalendarDetails calendarDetails = new CalendarDetails(202202, "FEB-22", new Date(), new Date());


    @Test
    public void testNettingDisabled() {

        when(caclProperties.isNettingEnabled()).thenReturn(false);

        ApplicationFailure applicationFailure = assertThrows(ApplicationFailure.class,
                () -> initializerService.performInitialChecks());
        assertEquals(applicationFailure.getOriginalMessage(), CaclMessages.NETTING_DISABLED);
    }

    @Test
    public void testInitializePeriodDetails() {
        long prdId = 202202L, prevPrdId = 202201L, nextPrdId = 202203L;
        calendarDetailsList.add(calendarDetails);

        when(commonDao.getCrtdPeriodId(anyLong(), anyString())).thenReturn(prdId);
        when(commonDao.getPeriodDetailsById(prdId)).thenReturn(calendarDetailsList);
        when(commonDao.getPeriodIdByEndDate(any())).thenReturn(prevPrdId);
        when(commonDao.getPeriodIdByStartDate(any())).thenReturn(nextPrdId);

        initializerService.initializePeriodDetails(commonDao, nettingDao, bookId, clientId, orgId);

        assertEquals(prevPrdId, caclProperties.getPrevNettingPeriodId());
        assertEquals(prdId, caclProperties.getPeriodDetails().getCurrentPeriodId());
        assertEquals(nextPrdId, caclProperties.getPeriodDetails().getNextPeriodId());

    }

}