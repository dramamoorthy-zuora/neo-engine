package com.zuora.neo.engine.jobs.rtp.api;

import com.google.common.collect.Lists;
import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.impl.PojoClassFactory;
import com.openpojo.validation.Validator;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.rule.impl.GetterMustExistRule;
import com.openpojo.validation.rule.impl.SetterMustExistRule;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;
import java.util.stream.Collectors;

@RunWith(MockitoJUnitRunner.class)
public class RtpApiTest {


    List<Class> rtpApiClassesList =
            Lists.newArrayList(
                    RtpStep.class,
                    RtpWiHeader.class,
                    RtpWorkflowDefinition.class
                    );

    List<PojoClass> rtpApiClasses =
            rtpApiClassesList.stream().map(PojoClassFactory::getPojoClass).collect(Collectors.toList());

    @Test
    public void testRtpApiClasses() {
        final Validator rtpApiClassesValidator = ValidatorBuilder.create()
                .with(new GetterMustExistRule())
                .with(new SetterMustExistRule())
                .with(new GetterTester())
                .with(new SetterTester())
                .build();

        rtpApiClassesValidator.validate(rtpApiClasses);
    }
}
