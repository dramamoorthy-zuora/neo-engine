package com.zuora.neo.engine.jobs.sfc.service;

import static org.junit.Assert.assertEquals;

import com.zuora.neo.engine.db.api.Account;
import com.zuora.neo.engine.db.api.RcLineAttributes;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLineNumAttributes;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeIndicator;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;

import org.checkerframework.checker.units.qual.A;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class SfcAcctSegmentsServiceTest {

    @Mock
    SfcDao sfcDao;

    @InjectMocks
    SfcAcctSegmentsService sfcAcctSegmentsService;

    @Test
    public void testGetAccountSegmentsForFlags() {

        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();
        List<Account> accountTableList = new ArrayList<>();

        Account account = new Account();
        account.setAcctTypeId("D");
        account.setSourceType("LINE");
        account.setSourceValue("REV_SEG1");
        accountTableList.add(account);

        account = new Account();
        account.setAcctTypeId("D");
        account.setSourceType("LINE");
        account.setSourceValue("DEF_SEG1");
        accountTableList.add(account);

        account = new Account();
        account.setAcctTypeId("D");
        account.setSourceType("LINE");
        account.setSourceValue("ATR17");
        accountTableList.add(account);

        account = new Account();
        account.setAcctTypeId("D");
        account.setSourceType("LINE");
        account.setSourceValue("NUM12");
        accountTableList.add(account);

        sfcDbCacheContext.setAccountTableList(accountTableList);
        sfcDbCacheContext.setSegmentDelimiter(":");


        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setDefSegments("340002");
        rcLineDetails.setRevSegments("600003");
        RcLineAttributes rcLineAttributes = new RcLineAttributes();
        RcLineNumAttributes rcLineNumAttributes = new RcLineNumAttributes();
        rcLineAttributes.setAtr17("52209");
        rcLineNumAttributes.setNum12("54");
        rcLineDetails.setRcLineAttributes(rcLineAttributes);
        rcLineDetails.setRcLineNumAttributes(rcLineNumAttributes);

        String flag = "D";

        String segment = sfcAcctSegmentsService.getAccountSegmentsForFlags(sfcDao, sfcDbCacheContext, rcLineDetails, flag);
        assertEquals("600003:340002:52209:54", segment);
    }

    @Test
    public void testGetAccountSegmentsForFlagsTwo() {

        SfcDbCacheContext sfcDbCacheContext = new SfcDbCacheContext();
        List<Account> accountTableList = new ArrayList<>();

        Account account = new Account();
        account.setAcctTypeId("d");
        account.setSourceType("LINE");
        account.setSourceValue("REV_SEG1");
        accountTableList.add(account);

        account = new Account();
        account.setAcctTypeId("d");
        account.setSourceType("LINE");
        account.setSourceValue("REV_SEG2");
        accountTableList.add(account);

        sfcDbCacheContext.setAccountTableList(accountTableList);
        sfcDbCacheContext.setSegmentDelimiter(":");


        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setDefSegments("D1:A1");
        rcLineDetails.setRevSegments("D1:A1");
        RcLineAttributes rcLineAttributes = new RcLineAttributes();
        rcLineAttributes.setAtr1("SFC");
        rcLineDetails.setRcLineAttributes(rcLineAttributes);

        String flag = "d";

        String segment = sfcAcctSegmentsService.getAccountSegmentsForFlags(sfcDao, sfcDbCacheContext, rcLineDetails, flag);
        assertEquals("D1:A1", segment);
    }
}
