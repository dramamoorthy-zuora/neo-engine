package com.zuora.neo.engine.jobs.rtp.api;

import com.zuora.neo.engine.jobs.rtp.constants.RtpWiHeaderStatus;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class RtpWiHeaderTest {

    @Test
    public void rtpWiHeaderTest() {
        RtpWiHeader rtpWiHeader = new RtpWiHeader();

        Integer id = 123;
        Integer bookId = 0;
        Integer clientId = 1;
        String secAtrVal = "0";
        Integer rcId = 1111;
        Integer wfId = 1;
        Integer prdId = 202303;
        String status = RtpWiHeaderStatus.NEW.getHeaderStatus();

        rtpWiHeader.setId(id);
        rtpWiHeader.setBookId(bookId);
        rtpWiHeader.setClientId(clientId);
        rtpWiHeader.setSecAtrVal(secAtrVal);
        rtpWiHeader.setRcId(rcId);
        rtpWiHeader.setWfId(wfId);
        rtpWiHeader.setPrdId(prdId);
        rtpWiHeader.setStatus(status);

        assertEquals(rtpWiHeader.getId(), id);
        assertEquals(rtpWiHeader.getClientId(), clientId);
        assertEquals(rtpWiHeader.getSecAtrVal(), secAtrVal);
        assertEquals(rtpWiHeader.getBookId(), bookId);
        assertEquals(rtpWiHeader.getRcId(), rcId);
        assertEquals(rtpWiHeader.getWfId(), wfId);
        assertEquals(rtpWiHeader.getPrdId(), prdId);
        assertEquals(rtpWiHeader.getStatus(), status);
    }
}
