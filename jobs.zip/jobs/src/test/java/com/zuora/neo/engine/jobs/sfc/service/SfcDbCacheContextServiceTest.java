package com.zuora.neo.engine.jobs.sfc.service;

import static org.junit.Assert.assertEquals;

import com.zuora.neo.engine.api.WorkflowContext;
import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.common.ParseProgramParameters;
import com.zuora.neo.engine.common.WorkflowContextManager;
import com.zuora.neo.engine.db.api.AccountValue;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.CurrencyDetails;
import com.zuora.neo.engine.db.dao.CommonDao;
import com.zuora.neo.engine.jobs.sfc.constants.SfcConstants;
import com.zuora.neo.engine.jobs.sfc.context.SfcDbCacheContext;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeValues;
import com.zuora.neo.engine.jobs.sfc.db.dao.SfcDao;

import io.temporal.failure.ApplicationFailure;
import org.jdbi.v3.core.Handle;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class SfcDbCacheContextServiceTest {

    @Mock
    ParseProgramParameters parseProgramParameters;

    @Mock
    Handle handle;

    @Mock
    CommonDao commonDao;

    @Mock
    SfcDao sfcDao;

    @InjectMocks
    SfcDbCacheContextService sfcDbCacheContextService;

    @Test
    public void testFetchCommonDetailsFromDb() throws ParseException {

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        WorkflowContext workflowContext = new WorkflowContext(request);
        WorkflowContextManager.setWorkflowContext(workflowContext);

        List<CurrencyDetails> currencyDetailsList = new ArrayList<>();
        CurrencyDetails currencyDetails = new CurrencyDetails("USD", 2, "USD");
        currencyDetailsList.add(currencyDetails);

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        Map<String, String> paramsMap = new HashMap<>();
        paramsMap.put(SfcConstants.BOOK_NAME_PARAM, "1");

        List<AccountValue> accountValuesList = new ArrayList<>();
        AccountValue accountValue = new AccountValue();
        accountValue.setAcctSeg("1234");
        accountValue.setClientId(1);
        accountValuesList.add(accountValue);

        List<CalendarDetails> calendarDetailsList = new ArrayList<>();


        Mockito.when(handle.attach(CommonDao.class)).thenReturn(commonDao);
        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(commonDao.getCurrencyDetails()).thenReturn(currencyDetailsList);
        Mockito.when(parseProgramParameters.parseParamString(Mockito.any(), Mockito.anyLong(), Mockito.any())).thenReturn(paramsMap);
        Mockito.when(sfcDao.getFinanceTypeDetailsForSfc()).thenReturn(financeTypeValuesList);
        Mockito.when(commonDao.getBookId(Mockito.any(), Mockito.any())).thenReturn(Long.valueOf(1));
        Mockito.when(commonDao.getAccountValues()).thenReturn(accountValuesList);
        Mockito.when(commonDao.getPeriodId(Mockito.anyLong(), Mockito.any())).thenReturn(Long.valueOf(202205));
        Mockito.when(commonDao.cacheCalendarDetails()).thenReturn(calendarDetailsList);
        Mockito.when(commonDao.getPeriodDetailsById(Mockito.anyLong())).thenReturn(calendarDetailsList);

         SfcDbCacheContext sfcDbCacheContext = sfcDbCacheContextService.fetchCommonDetailsFromDb(handle);

        assertEquals(accountValuesList, sfcDbCacheContext.getAccountValuesList());
        assertEquals(1, sfcDbCacheContext.getBookId());
        assertEquals(calendarDetailsList, sfcDbCacheContext.getCalendarDetails());
        assertEquals(calendarDetailsList, sfcDbCacheContext.getCalendarDetailsCache());
        assertEquals(202205, sfcDbCacheContext.getCurrentPeriodId());
        assertEquals(financeTypeValuesList, sfcDbCacheContext.getFinanceTypeValuesList());


    }

    @Test
    public void testFetchCommonDetailsFromDbNoSFCType() throws ParseException {

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        WorkflowContext workflowContext = new WorkflowContext(request);
        WorkflowContextManager.setWorkflowContext(workflowContext);

        List<CurrencyDetails> currencyDetailsList = new ArrayList<>();
        CurrencyDetails currencyDetails = new CurrencyDetails("USD", 2, "USD");
        currencyDetailsList.add(currencyDetails);

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();

        Map<String, String> paramsMap = new HashMap<>();
        paramsMap.put(SfcConstants.BOOK_NAME_PARAM, "1");

        List<AccountValue> accountValuesList = new ArrayList<>();
        AccountValue accountValue = new AccountValue();
        accountValue.setAcctSeg("1234");
        accountValue.setClientId(1);
        accountValuesList.add(accountValue);

        List<CalendarDetails> calendarDetailsList = new ArrayList<>();


        Mockito.when(handle.attach(CommonDao.class)).thenReturn(commonDao);
        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(commonDao.getCurrencyDetails()).thenReturn(currencyDetailsList);

        try {
            SfcDbCacheContext sfcDbCacheContext = sfcDbCacheContextService.fetchCommonDetailsFromDb(handle);
        } catch (ApplicationFailure e) {
            assertEquals(SfcConstants.NO_SFC_TYPE_AVAILABLE, e.getMessage().substring(9,30));
        }
    }

    @Test
    public void testFetchCommonDetailsFromDbNoBookName() throws ParseException {

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");
        WorkflowContext workflowContext = new WorkflowContext(request);
        WorkflowContextManager.setWorkflowContext(workflowContext);

        List<CurrencyDetails> currencyDetailsList = new ArrayList<>();
        CurrencyDetails currencyDetails = new CurrencyDetails("USD", 2, "USD");
        currencyDetailsList.add(currencyDetails);

        List<FinanceTypeValues> financeTypeValuesList = new ArrayList<>();
        FinanceTypeValues financeTypeValues = new FinanceTypeValues(10020,"SFC","SFC with Interest Calculator",
                1,"DR_APR",null,null,null,"EXT_FV_PRC",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),new SimpleDateFormat("dd/MM/yyyy").parse("03/03/2022"),
                1,201501,"MIGRATION",new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),"MIGRATION",
                new SimpleDateFormat("dd/MM/yyyy").parse("01/01/2015"),1, "YYBRdeLCLYNNNNNNNNNNNNNNN");
        financeTypeValuesList.add(financeTypeValues);

        Map<String, String> paramsMap = new HashMap<>();
        paramsMap.put(SfcConstants.BOOK_NAME_PARAM, "1");

        List<AccountValue> accountValuesList = new ArrayList<>();
        AccountValue accountValue = new AccountValue();
        accountValue.setAcctSeg("1234");
        accountValue.setClientId(1);
        accountValuesList.add(accountValue);

        List<CalendarDetails> calendarDetailsList = new ArrayList<>();


        Mockito.when(handle.attach(CommonDao.class)).thenReturn(commonDao);
        Mockito.when(handle.attach(SfcDao.class)).thenReturn(sfcDao);
        Mockito.when(commonDao.getCurrencyDetails()).thenReturn(currencyDetailsList);
        Mockito.when(parseProgramParameters.parseParamString(Mockito.any(), Mockito.anyLong(), Mockito.any())).thenReturn(paramsMap);
        Mockito.when(sfcDao.getFinanceTypeDetailsForSfc()).thenReturn(financeTypeValuesList);
        Mockito.when(commonDao.getBookId(Mockito.any(), Mockito.any())).thenReturn(null);

        try {
            SfcDbCacheContext sfcDbCacheContext = sfcDbCacheContextService.fetchCommonDetailsFromDb(handle);
        } catch (ApplicationFailure e) {
            assertEquals(SfcConstants.INVALID_BOOKNAME_MESSAGE, e.getMessage().substring(9,48));
        }
    }
}
