package com.zuora.neo.engine.jobs.sfc.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;

import com.zuora.neo.engine.api.WorkflowRequest;
import com.zuora.neo.engine.db.api.CalendarDetails;
import com.zuora.neo.engine.db.api.RcLineDetails;
import com.zuora.neo.engine.db.api.RcLinePaData;
import com.zuora.neo.engine.db.api.RcScheduleRecord;
import com.zuora.neo.engine.jobs.sfc.db.api.FinanceTypeFlagDetails;
import com.zuora.neo.engine.jobs.sfc.db.api.SchdIndicator;

import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.statement.PreparedBatch;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class RcScheduleServiceTest {

    @Mock
    private Handle handle;

    @Mock
    private PreparedBatch preparedBatch;

    @InjectMocks
    RcScheduleService rcScheduleService;

    //@Test
    public void testInsertRcScheduleRecords() {

        List<RcScheduleRecord> rcScheduleRecordList = new ArrayList<>();

        for(int i=0; i<2; i++) {
            BigDecimal interest = BigDecimal.valueOf(3.00);
            SchdIndicator schdIndicator = new SchdIndicator();
            schdIndicator.setInterfacedFlag('Y');

            List<RcLinePaData> rcLinePaDataList = new ArrayList<>();
            RcLinePaData rcLinePaData = new RcLinePaData();
            rcLinePaData.setDefAmt(BigDecimal.valueOf(25.00));
            rcLinePaData.setRecAmt(BigDecimal.valueOf(0.0));
            rcLinePaData.setIndicators(schdIndicator.getIndicator());
            rcLinePaData.setVcTypeId(10020);
            rcLinePaData.setId(10053);
            rcLinePaDataList.add(rcLinePaData);
            rcLinePaData = new RcLinePaData();
            rcLinePaData.setDefAmt(BigDecimal.valueOf(27.00));
            rcLinePaData.setRecAmt(BigDecimal.valueOf(0.0));
            rcLinePaData.setIndicators(schdIndicator.getIndicator());
            rcLinePaData.setVcTypeId(10020);
            rcLinePaData.setId(10053);
            rcLinePaDataList.add(rcLinePaData);

            List<RcLineDetails> rcLineDetailsList = new ArrayList<>();
            RcLineDetails rcLineDetails = new RcLineDetails();
            rcLineDetails.setBookId(1);
            rcLineDetails.setId(11200);
            rcLineDetails.setDocLineId("SO_123_4.6");
            rcLineDetails.setRcId(10007);
            rcLineDetails.setRcPobId(12345);
            rcLineDetails.setfexRate(BigDecimal.valueOf(1));
            rcLineDetails.setgexRate(BigDecimal.valueOf(1));
            rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
            rcLineDetails.setDocDate(new Date());
            rcLineDetails.setClientId(1);
            rcLineDetails.setSecAtrVal("0");
            rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
            rcLineDetails.setCurrencyCode("USD");
            rcLineDetailsList.add(rcLineDetails);

            List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
            FinanceTypeFlagDetails financeTypeFlagDetails = new FinanceTypeFlagDetails(10020, "YNNN", "YNNN", "Y", "Y", "Y");
            financeTypeFlagDetailsList.add(financeTypeFlagDetails);

            WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");

            CalendarDetails calendarDetail = new CalendarDetails(202202, "FEB-22", new Date(), new Date());

            String drSegment = "NNNN";
            String crSegment = "NNNN";

            RcScheduleRecord rcScheduleRecord = rcScheduleService.populateRcScheduleRecord(rcLineDetailsList, rcLinePaDataList, calendarDetail, request,
                    interest, 1, 202202, drSegment, crSegment, schdIndicator);
            rcScheduleRecordList.add(rcScheduleRecord);
        }

        List<RcScheduleRecord> rcScheduleRecordBatch = new ArrayList<>();
        rcScheduleRecordBatch.addAll(rcScheduleRecordList);

        Mockito.when(handle.prepareBatch(any())).thenReturn(preparedBatch);
        Mockito.when(preparedBatch.execute()).thenReturn(new int[]{1,1,1});
        Mockito.doNothing().when(preparedBatch).bind(anyString(), anyLong())
                .bind(anyString(), anyLong())
                .bind(anyString(), anyLong())
                .bind(anyString(), anyLong())
                .bind(anyString(), anyLong())
                .bind(anyString(), anyString())
                .bind(anyString(), eq(BigDecimal.class))
                .bind(anyString(), anyLong())
                .bind(anyString(), anyString())
                .bind(anyString(), anyLong())
                .bind(anyString(), anyLong())
                .bind(anyString(), anyString())
                .bind(anyString(), anyString())
                .bind(anyString(), any(BigDecimal.class))
                .bind(anyString(), eq(BigDecimal.class))
                .bind(anyString(), eq(Date.class))
                .bind(anyString(), anyLong())
                .bind(anyString(), anyLong())
                .bind(anyString(), anyString())
                .bind(anyString(), anyLong())
                .bind(anyString(), anyLong())
                .bind(anyString(), anyLong())
                .bind(anyString(), anyLong())
                .bind(anyString(), anyString())
                .bind(anyString(), anyString());

            rcScheduleService.insertRcScheduleRecordsBatch(rcScheduleRecordBatch, handle);

    }

    @Test
    public void testPopulateRcScheduleRecord() {

        BigDecimal interest = BigDecimal.valueOf(3.00);
        SchdIndicator schdIndicator = new SchdIndicator();
        schdIndicator.setInterfacedFlag('Y');

        List<RcLinePaData> rcLinePaDataList = new ArrayList<>();
        RcLinePaData rcLinePaData = new RcLinePaData();
        rcLinePaData.setDefAmt(BigDecimal.valueOf(25.00));
        rcLinePaData.setRecAmt(BigDecimal.valueOf(0.0));
        rcLinePaData.setIndicators(schdIndicator.getIndicator());
        rcLinePaData.setVcTypeId(10020);
        rcLinePaData.setId(10053);
        rcLinePaDataList.add(rcLinePaData);
        rcLinePaData = new RcLinePaData();
        rcLinePaData.setDefAmt(BigDecimal.valueOf(27.00));
        rcLinePaData.setRecAmt(BigDecimal.valueOf(0.0));
        rcLinePaData.setIndicators(schdIndicator.getIndicator());
        rcLinePaData.setVcTypeId(10020);
        rcLinePaData.setId(10053);
        rcLinePaDataList.add(rcLinePaData);

        List<RcLineDetails> rcLineDetailsList = new ArrayList<>();
        RcLineDetails rcLineDetails = new RcLineDetails();
        rcLineDetails.setBookId(1);
        rcLineDetails.setId(11200);
        rcLineDetails.setDocLineId("SO_123_4.6");
        rcLineDetails.setRcId(10007);
        rcLineDetails.setRcPobId(12345);
        rcLineDetails.setfexRate(BigDecimal.valueOf(1));
        rcLineDetails.setgexRate(BigDecimal.valueOf(1));
        rcLineDetails.setRecAmt(BigDecimal.valueOf(25.00));
        rcLineDetails.setDocDate(new Date());
        rcLineDetails.setClientId(1);
        rcLineDetails.setSecAtrVal("0");
        rcLineDetails.setNpvInterestRate(BigDecimal.valueOf(7.00));
        rcLineDetails.setCurrencyCode("USD");
        rcLineDetailsList.add(rcLineDetails);

        List<FinanceTypeFlagDetails> financeTypeFlagDetailsList = new ArrayList<>();
        FinanceTypeFlagDetails financeTypeFlagDetails = new FinanceTypeFlagDetails(10020, "YNNN", "YNNN", "Y", "Y", "Y");
        financeTypeFlagDetailsList.add(financeTypeFlagDetails);

        WorkflowRequest request = new WorkflowRequest(533, 123124, "fmvwcea", "0", 1, "SYSADMIN", 5, "paramText");

        CalendarDetails calendarDetail = new CalendarDetails(202202, "FEB-22", new Date(), new Date());

        String drSegment = "NNNN";
        String crSegment = "NNNN";

        RcScheduleRecord rcScheduleRecord = rcScheduleService.populateRcScheduleRecord(rcLineDetailsList, rcLinePaDataList, calendarDetail, request,
                interest, 1, 202202, drSegment, crSegment, schdIndicator);
        assertEquals(rcScheduleRecord.getfexRate(), BigDecimal.valueOf(1));
        assertEquals(rcScheduleRecord.getgexRate(), BigDecimal.valueOf(1));
        assertEquals(rcScheduleRecord.getLineId(), rcLinePaDataList.get(0).getId());
        assertEquals(rcScheduleRecord.getIndicators(), schdIndicator.getIndicator());

    }
}
